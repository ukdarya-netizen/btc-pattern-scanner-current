/**
 * CoinGlass — агрегированный OI по всем биржам.
 * Используется для верификации сигналов: если OI растёт глобально,
 * а не только на BingX — сигнал значительно сильнее.
 *
 * Endpoint: GET /public/v2/open_interest?symbol=BTC
 * Header: coinglassSecret: <API_KEY>
 * Строка "All" в ответе = агрегат по всем биржам.
 *
 * Лимит HOBBYIST: 30 req/min.
 * Кэш: 5 мин на символ.
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";

export interface CoinglassOIResult {
  /** Агрегированное изменение OI за 5 минут в % (строка "All") */
  oiChange5m: number | null;
  /** Агрегированное изменение OI за 30 минут в % (строка "All") */
  oiChange30m: number | null;
  /** Агрегированное изменение OI за 1 час в % (строка "All") */
  oiChange1h: number | null;
  /** Агрегированное изменение OI за 4 часа в % (строка "All") */
  oiChange4h: number | null;
  /** Агрегированное изменение OI за 24 часа в % (строка "All") */
  oiChange24h: number | null;
  /** Абсолютный OI в USD (строка "All") */
  oiUsd: number | null;
  /** Глобальный торговый объём в USD (строка "All") — для пре-скрина по CoinGlass */
  cgVolUsd: number | null;
  /** OI изменение специфично для BingX (%) */
  bingxOiChange30m: number | null;
  available: boolean;
  source: "coinglass";
}

const cache = new Map<string, { result: CoinglassOIResult; ts: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 минут — каждый скан получает свежие данные

/** Преобразует BingX-символ в базовый тикер для CoinGlass */
function toBaseSymbol(bingxSymbol: string): string {
  return bingxSymbol.replace("-USDT", "");
}

export async function getCoinglassOI(symbol: string): Promise<CoinglassOIResult> {
  const apiKey = process.env.COINGLASS_API_KEY;

  const noData: CoinglassOIResult = {
    oiChange5m: null,
    oiChange30m: null,
    oiChange1h: null,
    oiChange4h: null,
    oiChange24h: null,
    oiUsd: null,
    cgVolUsd: null,
    bingxOiChange30m: null,
    available: false,
    source: "coinglass",
  };

  if (!apiKey) return noData;

  const base = toBaseSymbol(symbol);
  const cached = cache.get(base);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  try {
    const res = await fetch(
      `https://open-api.coinglass.com/public/v2/open_interest?symbol=${base}`,
      {
        headers: {
          coinglassSecret: apiKey,
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(6000),
      }
    );

    if (!res.ok) {
      logger.warn({ symbol, status: res.status }, "CoinGlass OI request failed");
      reportApiFailure("coinglass", res.status);
      return noData;
    }

    const data = await res.json() as {
      success?: boolean;
      code?: string;
      data?: {
        exchangeName: string;
        openInterestAmount: number;
        m5OIChangePercent: number;
        m30OIChangePercent: number;
        h1OIChangePercent: number;
        h4OIChangePercent?: number;
        h24OIChangePercent?: number;
        volUsd?: number;
      }[];
    };

    const rows = data.data;
    if (!rows || rows.length === 0) {
      logger.debug({ symbol }, "CoinGlass OI: no data rows");
      return noData;
    }

    // Строка "All" = агрегат по всем биржам
    const allRow = rows.find(r => r.exchangeName === "All");
    // Строка BingX
    const bingxRow = rows.find(r => r.exchangeName === "BingX");

    if (!allRow) {
      logger.debug({ symbol, exchanges: rows.map(r => r.exchangeName) }, "CoinGlass OI: no 'All' row");
      return noData;
    }

    const result: CoinglassOIResult = {
      oiChange5m: allRow.m5OIChangePercent ?? null,
      oiChange30m: allRow.m30OIChangePercent ?? null,
      oiChange1h: allRow.h1OIChangePercent ?? null,
      oiChange4h: allRow.h4OIChangePercent ?? null,
      oiChange24h: allRow.h24OIChangePercent ?? null,
      oiUsd: allRow.openInterestAmount ?? null,
      cgVolUsd: allRow.volUsd ?? null,
      bingxOiChange30m: bingxRow?.m30OIChangePercent ?? null,
      available: true,
      source: "coinglass",
    };

    reportApiSuccess("coinglass");
    cache.set(base, { result, ts: Date.now() });
    logger.debug(
      {
        symbol,
        oi5m: result.oiChange5m?.toFixed(2) + "%",
        oi30m: result.oiChange30m?.toFixed(2) + "%",
        oi1h: result.oiChange1h?.toFixed(2) + "%",
        oi4h: result.oiChange4h != null ? result.oiChange4h.toFixed(2) + "%" : "n/a",
        oi24h: result.oiChange24h != null ? result.oiChange24h.toFixed(2) + "%" : "n/a",
        bingxOI: result.bingxOiChange30m?.toFixed(2) + "%",
      },
      "CoinGlass OI fetched"
    );
    return result;
  } catch (err) {
    logger.warn({ symbol, err }, "CoinGlass OI fetch error");
    reportApiFailure("coinglass");
    return noData;
  }
}

/**
 * Батч-получение CoinGlass OI для списка BingX-символов.
 * Возвращает Map<symbol, CoinglassOIResult> для всех запрошенных символов.
 *
 * Rate limit STANDARD: 300 req/min → 50ms между запросами достаточно.
 * Символы с актуальным кэшем (< 5 мин) возвращаются мгновенно без API-вызова.
 */
export async function batchGetCoinglassOI(
  bingxSymbols: string[],
): Promise<Map<string, CoinglassOIResult>> {
  const results = new Map<string, CoinglassOIResult>();
  const STAGGER_MS = 50; // Standard plan — 300 req/min, быстрый батч

  for (let i = 0; i < bingxSymbols.length; i++) {
    const symbol = bingxSymbols[i];
    const base = toBaseSymbol(symbol);

    // Check cache first — if fresh, no stagger needed
    const cached = cache.get(base);
    const isCached = cached && Date.now() - cached.ts < CACHE_TTL;

    if (!isCached && i > 0) {
      // Stagger only if we actually need to make an API call
      await new Promise(r => setTimeout(r, STAGGER_MS));
    }

    const result = await getCoinglassOI(symbol);
    results.set(symbol, result);
  }

  return results;
}

/** Сброс кэша для тестов */
export function clearCoinglassOICache(): void {
  cache.clear();
}
