/**
 * API Health Monitor — отслеживает сбои внешних API и шлёт Telegram-алерт.
 *
 * Логика:
 * - 401/403 → критичная ошибка (ключ), алерт после 1-й ошибки
 * - 5xx/timeout → временный сбой, алерт после 3 подряд
 * - Восстановление → уведомление о восстановлении
 */

import { logger } from "./logger.js";

export type ApiName = "coinglass" | "coinalyze" | "bingx" | "coingecko" | "coinpaprika";

const API_LABELS: Record<ApiName, string> = {
  coinglass:   "CoinGlass",
  coinalyze:   "Coinalyze",
  bingx:       "BingX",
  coingecko:   "CoinGecko",
  coinpaprika: "CoinPaprika",
};

interface HealthState {
  consecutiveFailures: number;
  alertSent:           boolean;
  lastStatus?:         number;
  lastFailureAt?:      number;
}

const states = new Map<ApiName, HealthState>();

function getState(api: ApiName): HealthState {
  if (!states.has(api)) states.set(api, { consecutiveFailures: 0, alertSent: false });
  return states.get(api)!;
}

/** Вызвать когда API ответил успешно */
export function reportApiSuccess(api: ApiName): void {
  const s = getState(api);
  if (s.consecutiveFailures === 0) return; // всё и так ок

  const wasAlerted = s.alertSent;
  s.consecutiveFailures = 0;
  s.alertSent = false;

  if (wasAlerted) {
    void sendAdminAlert(
      `✅ <b>${API_LABELS[api]} восстановлен</b>\n\nAPI снова отвечает нормально.`
    );
  }
}

/** Вызвать когда API вернул ошибку */
export function reportApiFailure(api: ApiName, statusCode?: number): void {
  const s = getState(api);
  s.consecutiveFailures++;
  s.lastStatus    = statusCode;
  s.lastFailureAt = Date.now();

  // 401/403 — проблема с ключом, бьём тревогу сразу
  const isCritical = statusCode === 401 || statusCode === 403;
  const threshold  = isCritical ? 1 : 3;

  if (s.consecutiveFailures >= threshold && !s.alertSent) {
    s.alertSent = true;
    const label  = API_LABELS[api];
    const code   = statusCode ? ` (HTTP ${statusCode})` : "";
    const reason = isCritical
      ? "🔑 Проблема с API-ключом — возможно сброшен или истёк срок."
      : `Подряд ошибок: ${s.consecutiveFailures}`;

    void sendAdminAlert(
      `⚠️ <b>${label} недоступен${code}</b>\n\n` +
      `${reason}\n\n` +
      `Сигналы работают в ограниченном режиме.`
    );
  }
}

/** Возвращает текущий статус подключения (false = есть последовательные ошибки) */
export function getApiConnected(api: ApiName): boolean {
  return getState(api).consecutiveFailures === 0;
}

async function sendAdminAlert(text: string): Promise<void> {
  const token  = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
      signal:  AbortSignal.timeout(8000),
    });
    if (res.ok) {
      logger.info({ api: text.slice(0, 40) }, "API health alert sent to admin");
    }
  } catch (err) {
    logger.warn({ err }, "Failed to send API health alert");
  }
}
