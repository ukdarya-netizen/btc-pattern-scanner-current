// ── Watcher message formatters & P&L helpers ─────────────────────────────────
// Pure functions: string formatting, P&L math, Telegram message builders.
// No side effects, no DB calls, no in-memory state.

import type { TrackedSignal } from "@workspace/db";
import {
  PARTIAL_TARGET, FIRST_TARGET, TRAILING_ACTIVATION_PCT, TRAILING_FIXED_PCT,
  STOP_LOSS, MAX_WATCH_DAYS, MILESTONES,
} from "./watcher-config.js";

// ── Price / number formatters ─────────────────────────────────────────────────

export function fmtP(p: number) {
  return p < 1 ? `$${p.toFixed(6)}` : p < 100 ? `$${p.toFixed(4)}` : `$${p.toFixed(2)}`;
}
export function fmtPct(n: number) { return `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`; }
export function fmtVolM(v: number): string {
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000)     return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}
export function scoreBar(s: number) { const f = Math.round(s); return "█".repeat(f) + "░".repeat(10 - f); }

export function hoursAndDays(from: Date): { h: number; d: number; str: string } {
  const ms = Date.now() - from.getTime();
  const h = ms / 3_600_000;
  const d = Math.floor(h / 24);
  const rem = Math.round(h % 24);
  return { h, d, str: d > 0 ? `${d}д ${rem}ч` : `${Math.round(h)}ч` };
}

// ── Hashtag helper ────────────────────────────────────────────────────────────
/** "BTC-USDT" → "#BTC" */
export function tickerTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

export const SENTIMENT_LABELS: Record<string, string> = {
  hidden_accumulation:  "Скрытое накопление",
  bullish_accumulation: "Бычье накопление",
  aggressive_breakout:  "Агрессивный пробой",
  short_squeeze:        "Выдавливание шортов",
  bear_trap:            "Медвежья ловушка",
  anomaly:              "Аномальная активность",
  impulse_breakout:     "Импульсный пробой",
  sharp_impulse:        "Резкий импульс",
  whale_futures:        "Кит + Розница",
  whale_watch:          "Китовое накопление",
  "4h_momentum":        "4h Моментум",
  moonshot_momentum:    "Moonshot Моментум",
  volume_breakout:      "Объёмный пробой",
  volume_flash:         "Объёмная вспышка",
};

/** Returns "Паттерн: <label>" line for follow-up messages, or empty string if unknown. */
export function fmtPattern(t: TrackedSignal): string {
  const label = t.sentiment
    ?? (t.sentimentKey ? SENTIMENT_LABELS[t.sentimentKey] ?? t.sentimentKey : null);
  if (!label) return "";
  const rank = t.sentimentKey === "anomaly"
    ? ((t as unknown as Record<string, unknown>).signalPayload as Record<string, unknown> | null)?.cmcRank
    : null;
  return rank != null ? `<i>Паттерн: ${label} | Ранг #${rank}</i>` : `<i>Паттерн: ${label}</i>`;
}

// ── P&L math ──────────────────────────────────────────────────────────────────

export function computePnl(t: TrackedSignal, price: number): number {
  return ((price - t.entryPrice) / t.entryPrice) * 100;
}

export function computePeakPnl(t: TrackedSignal): number {
  if (!t.peakPrice) return 0;
  return ((t.peakPrice - t.entryPrice) / t.entryPrice) * 100;
}

export function nextMilestone(lastMilestone: number | null, currentPnl: number): number | null {
  const last = lastMilestone ?? 0;
  for (const m of MILESTONES) {
    if (m > last && currentPnl >= m) return m;
  }
  return null;
}

// ── Telegram message builders ─────────────────────────────────────────────────

export function msgVolumeCollapse(t: TrackedSignal, currentPrice: number): string {
  const pnl = ((currentPrice - t.entryPrice) / t.entryPrice) * 100;
  const dur = hoursAndDays(t.detectedAt);
  return [
    `📉 <b>${t.symbol}: Выход по затуханию импульса</b>`,
    ``,
    `Фьюч объём упал ниже 0.2x от среднего — движение выдохлось.`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    `💡 Капитал освобожден для новых сделок.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #volume_collapse`,
  ].filter(Boolean).join("\n");
}

export function msgFirstTarget(t: TrackedSignal, currentPrice: number): string {
  const pnl = computePnl(t, currentPrice);
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🔥 <b>${t.symbol}: Первая цель +${FIRST_TARGET}% достигнута!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `💡 <b>Действия:</b>`,
    `✂️ Зафиксируй часть прибыли (25–50% позиции)`,
    `🛡 Переставь Stop-Loss в безубыток → ${fmtP(t.entryPrice)}`,
    ``,
    `⏳ Следующее уведомление при +${TRAILING_ACTIVATION_PCT}% — активация трейлинга.`,
    `📡 Проверяю каждые 2 минуты.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #in_run`,
  ].filter(Boolean).join("\n");
}

export function msgTrailingActivated(t: TrackedSignal, currentPrice: number, trailingStopLevel: number): string {
  const pnl = computePnl(t, currentPrice);
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🚀 <b>${t.symbol}: Трейлинг активирован!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `🛡 Трейлинг Stop-Loss: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    `📐 Отступ: ${TRAILING_FIXED_PCT}% от пика — стоп тянется вверх автоматически`,
    ``,
    `⚡️ Минимальная фиксация гарантирована на уровне +${TRAILING_FIXED_PCT}%.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #in_run #trailing`,
  ].filter(Boolean).join("\n");
}

export function msgSmallLossStop(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `📉 <b>МАЛЫЙ УБЫТОК: ${t.symbol}</b>`,
    ``,
    `Цена вернулась к точке входа после достижения первой цели, с небольшим убытком.`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Выход: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `💡 Капитал освобожден для новых сделок.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #small_loss`,
  ].filter(Boolean).join("\n");
}

export function msgMilestone(t: TrackedSignal, milestone: number, currentPrice: number, trailingStopLevel: number): string {
  const gain = fmtPct(milestone);
  const emoji = milestone >= 100 ? "🌙" : milestone >= 50 ? "🚀" : "📈";
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  const dur = hoursAndDays(t.detectedAt);
  return [
    `${emoji} <b>MOONSHOT! ${t.symbol}: ${gain}</b>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} → Сейчас: ${fmtP(currentPrice)}`,
    `📊 Текущий профит: <b>${gain}</b>`,
    `⏱ Время в позиции: ${dur.str}`,
    `🛡 Трейлинг Stop-Loss: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    ``,
    `⚡️ Ракета летит — держим до трейлинг-стопа!`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #moonshot`,
  ].filter(Boolean).join("\n");
}

export function msgTrailingStopHit(t: TrackedSignal, currentPrice: number, peakPnl: number, finalPnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🏁 <b>${t.symbol}: Ралли завершено!</b>`,
    ``,
    `📈 Пиковый рост: <b>${fmtPct(peakPnl)}</b>`,
    `💰 Фиксация по трейлингу: <b>${fmtPct(finalPnl)}</b>`,
    `⏳ Длительность сделки: ${dur.str}`,
    t.alphaScore ? `🎯 Alpha Score был: ${t.alphaScore}/10  <code>${scoreBar(t.alphaScore)}</code>` : "",
    fmtPattern(t),
    ``,
    `<i>Мы забрали основное движение!</i>`,
    ``,
    `${tickerTag(t.symbol)} #profit`,
  ].filter(Boolean).join("\n");
}

export function msgStopLoss(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `❌ <b>STOP LOSS: ${t.symbol}</b>`,
    ``,
    `🛑 Стоп-лосс ${STOP_LOSS}% сработал`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)}`,
    `📊 P&L: <b>${fmtPct(pnl)}</b>`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #stop_loss`,
  ].filter(Boolean).join("\n");
}

export function msgBUStop(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  const peakPnl = computePeakPnl(t);
  return [
    `🛡 <b>СТОП В БУ: ${t.symbol}</b>`,
    ``,
    `Позиция закрыта по стопу безубытка.`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)}`,
    `📊 P&L: <b>${fmtPct(pnl)}</b>`,
    peakPnl > 0.5 ? `📈 Пик был: +${peakPnl.toFixed(1)}%` : "",
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    fmtPattern(t),
    `<i>Капитал защищён.</i>`,
    `${tickerTag(t.symbol)} #bu_stop`,
  ].filter(Boolean).join("\n");
}

export function msgPartialTakeProfit(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `📌 <b>${t.symbol}: +${PARTIAL_TARGET}% — переноси стоп в БУ!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `💡 <b>Действия прямо сейчас:</b>`,
    `🛡 Переставь Stop-Loss в безубыток → ${fmtP(t.entryPrice)}`,
    `✂️ Можно зафиксировать 20–25% позиции`,
    ``,
    `🎯 Первая цель +${FIRST_TARGET}% | Трейлинг при +${TRAILING_ACTIVATION_PCT}%`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #partial`,
  ].filter(Boolean).join("\n");
}

export function msgAccumThesisBroken(t: TrackedSignal, currentPrice: number, pnl: number, oiDropPct: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🚫 <b>${t.symbol}: тезис накопления нарушен</b>`,
    ``,
    `📉 OI упал на <b>${oiDropPct.toFixed(1)}%</b> от уровня входа`,
    `<i>Позиции открытые при сигнале — закрыты. Smart money вышел.</i>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} → Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `⚡️ Рекомендуем выйти из позиции.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #cancelled`,
  ].filter(Boolean).join("\n");
}

export function msgAccumVolumeBuilding(t: TrackedSignal, currentPrice: number, pnl: number, volMult: number, spotVol24h: number | null): string {
  const dur = hoursAndDays(t.detectedAt);
  const spotStr = spotVol24h !== null ? `🌐 Спот объём: <b>${fmtVolM(spotVol24h)}</b> (24ч, Binance+Bybit)` : null;
  return [
    `📡 <b>${t.symbol}: фьюч объём оживает в накоплении</b>`,
    ``,
    `📊 Фьюч объём: <b>${volMult.toFixed(1)}x</b> нормы — интерес возвращается`,
    spotStr,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏳ Сигнал ${dur.str} назад`,
    ``,
    `<i>Фьюч объём 2x+ — первый признак выхода из боковика. Слежу дальше.</i>`,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #accumulation`,
  ].filter(Boolean).join("\n");
}

export function msgAccumOiBuilding(t: TrackedSignal, currentPrice: number, pnl: number, oiChange: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `👀 <b>${t.symbol}: OI растёт при боковике</b>`,
    ``,
    `📈 OI: <b>+${oiChange.toFixed(1)}%</b> за 30м — позиции набираются`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏳ Сигнал ${dur.str} назад`,
    ``,
    `<i>Классический скрытый аккумулятор — крупный игрок не торопится.</i>`,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #accumulation`,
  ].filter(Boolean).join("\n");
}

export function msgAccumulationReminder(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  const pnlStr = fmtPct(pnl);
  const pnlEmoji = pnl >= 0 ? "📗" : "📕";
  return [
    `⏳ <b>${t.symbol}: 6ч в накоплении</b>`,
    ``,
    `🕐 Время в позиции: ${dur.str}`,
    `${pnlEmoji} Текущий P&L: <b>${pnlStr}</b>`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)}`,
    ``,
    `<i>Монета продолжает накапливаться. Жду движения до ${MAX_WATCH_DAYS} дней.</i>`,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #accumulation`,
  ].filter(Boolean).join("\n");
}

export function msgAccumulation(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const sign = pnl >= 0 ? "+" : "";
  const dur = hoursAndDays(t.detectedAt);
  return [
    `⏳ <b>ACCUMULATION: ${t.symbol}</b>`,
    ``,
    `💰 ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${sign}${pnl.toFixed(1)}%)`,
    `⏱ Время в позиции: ${dur.str}`,
    `👁 Продолжаю наблюдение до ${MAX_WATCH_DAYS} дней`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #accumulation`,
  ].filter(Boolean).join("\n");
}

export function msgReEntry(t: TrackedSignal, currentPrice: number, volMult: number, spotVol24h: number | null): string {
  const { str } = hoursAndDays(t.detectedAt);
  const spotStr = spotVol24h !== null ? `🌐 Спот объём: <b>${fmtVolM(spotVol24h)}</b> (24ч, Binance+Bybit)` : null;
  return [
    `🔥 <b>${t.symbol}: Второе дыхание!</b>`,
    ``,
    `📅 Сигнал был ${str} назад`,
    `📊 Текущая активность: Фьюч ${volMult.toFixed(1)}x нормы`,
    spotStr,
    `⚡️ Статус: Накопление завершено, ожидается импульс`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)}`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #re_entry`,
  ].filter(Boolean).join("\n");
}

export function msgLateSignal(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `⚠️ <b>${t.symbol}: Запоздалый сигнал</b>`,
    ``,
    `Монета уже двинулась на <b>${fmtPct(pnl)}</b> к моменту обнаружения — движение началось раньше скана.`,
    ``,
    `📌 Цена входа (при сигнале): ${fmtP(t.entryPrice)}`,
    `📈 Текущая цена: ${fmtP(currentPrice)}`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `⚡️ Включен Moonshot Management с трейлинг-стопом ${TRAILING_FIXED_PCT}%.`,
    `⚠️ Входить в позицию не рекомендуется — момент пропущен.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #late_signal #in_run`,
  ].filter(Boolean).join("\n");
}

export function msgBreakeven(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `⚖️ <b>BREAKEVEN: ${t.symbol}</b>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} | Закрытие: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    `📁 Перенесено в архив`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #breakeven`,
  ].filter(Boolean).join("\n");
}

export function msgInvalidated(t: TrackedSignal, currentPrice: number, pnl: number, reason: "oi_drop" | "vol_drop", oiDrop?: number, volMult?: number): string {
  const dur = hoursAndDays(t.detectedAt);
  const reasonText = reason === "oi_drop"
    ? `📉 OI упал на <b>${oiDrop?.toFixed(1)}%</b> от входа — крупный игрок вышел из позиции`
    : `📭 Фьюч объём упал до <b>${volMult?.toFixed(2)}x</b> нормы — катализатор не материализовался`;
  return [
    `🚫 <b>СИГНАЛ ОТМЕНЁН: ${t.symbol}</b>`,
    ``,
    reasonText,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `⚡️ Тезис сделки нарушен — рекомендуем выйти из позиции.`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} #cancelled`,
  ].filter(Boolean).join("\n");
}
