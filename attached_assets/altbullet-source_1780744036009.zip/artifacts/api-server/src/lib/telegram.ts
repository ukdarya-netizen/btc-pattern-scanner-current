import { logger } from "./logger.js";
import type { Signal } from "@workspace/db";
import { db, subscribersTable, settingsTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";
import { getAllWhaleAccumCandidates, getWhaleDataCoverage } from "./whaleTracker.js";
import { buildPositionsStatusText } from "./positionsReport.js";

const TELEGRAM_API = "https://api.telegram.org";

export async function sendMessage(chatId: number | string, text: string): Promise<boolean> {
  if (process.env.NODE_ENV === "development") {
    logger.debug({ chatId, preview: text.slice(0, 80) }, "DEV: Telegram suppressed");
    return false;
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;

  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: false,
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram send failed");
      if (res.status === 403) {
        await db.update(subscribersTable)
          .set({ active: false, unsubscribedAt: new Date() })
          .where(eq(subscribersTable.chatId, Number(chatId)));
      }
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Telegram send error");
    return false;
  }
}

export async function testConnection(): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/getMe`);
    return res.ok;
  } catch {
    return false;
  }
}

export async function getBotInfo(): Promise<{ username?: string; firstName?: string } | null> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/getMe`);
    if (!res.ok) return null;
    const data = await res.json() as { ok: boolean; result: { username?: string; first_name?: string } };
    return { username: data.result.username, firstName: data.result.first_name };
  } catch {
    return null;
  }
}

export async function answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return;
  try {
    await fetch(`${TELEGRAM_API}/bot${token}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ callback_query_id: callbackQueryId, text: text ?? "" }),
    });
  } catch (err) {
    logger.error({ err }, "answerCallbackQuery error");
  }
}

export async function sendMessageWithKeyboard(
  chatId: number | string,
  text: string,
  inlineKeyboard: Array<Array<{ text: string; callback_data?: string; url?: string }>>,
): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }
  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup: { inline_keyboard: inlineKeyboard },
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram sendMessageWithKeyboard failed");
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "sendMessageWithKeyboard error");
    return false;
  }
}

const DIGEST_KEYBOARD = [
  [
    { text: "📅 Недельный",  callback_data: "digest:weekly"  },
    { text: "📆 Месячный",   callback_data: "digest:monthly" },
  ],
  [
    { text: "⚙️ Настройки", callback_data: "settings"       },
  ],
];

export async function registerBotCommands(): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return;
  const commands = [
    { command: "start",      description: "Начать / Подписаться" },
    { command: "prices",     description: "Цены на подписку" },
    { command: "menu",       description: "Меню дайджестов" },
    { command: "status",     description: "Текущие позиции" },
    { command: "whalewatch", description: "Whale Watch анализ" },
    { command: "myid",       description: "Узнать свой Chat ID" },
    { command: "stop",       description: "Отписаться" },
  ];
  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/setMyCommands`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ commands }),
    });
    const data = await res.json() as { ok: boolean; description?: string };
    if (data.ok) {
      logger.info("Bot commands registered with Telegram");
    } else {
      logger.warn({ description: data.description }, "Failed to register bot commands");
    }
  } catch (err) {
    logger.error({ err }, "Error registering bot commands");
  }
}

export async function setWebhook(webhookUrl: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: true,
      }),
    });
    const data = await res.json() as { ok: boolean; description?: string };
    if (!data.ok) {
      logger.warn({ description: data.description }, "Failed to set webhook");
      return false;
    }
    logger.info({ webhookUrl }, "Telegram webhook registered");
    return true;
  } catch (err) {
    logger.error({ err }, "Error setting webhook");
    return false;
  }
}

function formatNumber(n: number, decimals = 2): string {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(2)}B`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(2)}K`;
  return n.toFixed(decimals);
}

export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number | null;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  coinalyzeOiChange?: number | null;
  coinalyzeConfirmed?: boolean;
  isExhaustedSqueeze?: boolean;
  isNewListing?: boolean;
  pumpFromOpen?: number | null;
  candleCount?: number;
  sentiment: string;
  sentimentKey: string;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "5m", "30m", "1h" или комбинация */
  oiTriggerTf?: string;
  /** Значение 5m OI изменения */
  oiChange5m?: number | null;
  /** Значение 1h OI изменения */
  oiChange1h?: number | null;
  /** Значение 4h OI изменения */
  oiChange4h?: number | null;
  /** Значение 24h OI изменения */
  oiChange24h?: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже встречался в сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт (decimal, напр. -0.0004 = -0.04% за 8ч) */
  fundingRate?: number | null;
  /** Mark price (перп) */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Насколько цена уже выросла с момента обнаружения до момента выстрела (%) */
  priceConfirmPct?: number | null;
  /** Анализ стакана BingX: имбаланс бидов/асков, bid-стены */
  obImbalance?: {
    bidAskRatio:       number;
    bidVolumeUsd:      number;
    bias:              "strong_bull" | "bull" | "neutral" | "bear";
    bidWallCount:      number;
    largestBidWallUsd: number;
    largestBidWallPrice: number;
    largestBidWallPct: number;
    scoreBonus:        number;
  } | null;
  /** MTF Spot CVD: 1h/4h таймфреймы не подтверждают — только скальп */
  isScalpOnly?: boolean;
  /** BingX spot market 24h volume (USDT) — ориентир для сравнения с futures */
  spotVol24h?: number | null;
  /** Market cap токена (CoinGecko, USD) — для расчёта % оборачиваемости */
  marketCapUsd?: number | null;
}

/** "BTC-USDT" → "#BTC" */
function tickerTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

export function formatAlphaSignal(s: AlphaResult): string {
  // Метка скорости: сколько ждать движения
  const speedLabel = (() => {
    const key = s.sentimentKey;
    if (key === "moonshot_momentum") {
      return `🚀🚀 <b>РАКЕТА</b> — взрывной рост, ракета уже в полёте`;
    }
    if (key === "volume_flash") {
      return `⚡⚡ <b>ФЛЕШ-ПАМП</b> — объём взорвался, движение прямо сейчас`;
    }
    if (key === "bear_trap" || key === "short_squeeze" || key === "aggressive_breakout" || key === "sharp_impulse") {
      return `🚀 <b>БЫСТРЫЙ ПАМП</b> — движение ожидается в течение 1–4ч`;
    }
    if (key === "hidden_accumulation" || key === "bullish_accumulation") {
      return `⏳ <b>МЕДЛЕННЫЙ ГРАЙНД</b> — накопление, движение может занять 6–24ч`;
    }
    if (key === "anomaly") {
      return `⚠️ <b>АНОМАЛИЯ</b> — нет чёткого паттерна, повышенный риск`;
    }
    if (key === "whale_futures") {
      return `🐳 <b>КИТ + РОЗНИЦА</b> — кит купил спот, розница подтвердила фьючи`;
    }
    if (key === "volume_breakout") {
      return `📊 <b>VOLUME BREAKOUT</b> — объём давит несколько циклов, нет OI-данных`;
    }
    return null;
  })();

  const gradeHeader = s.grade === "super_alpha"
    ? `⚡️⚡️ <b>SUPER BULLET DETECTED: ${s.symbol}</b>`
    : `⚡️ <b>BULLET DETECTED: ${s.symbol}</b>`;

  const priceSign = s.priceChange30m >= 0 ? "+" : "";
  const oiSign = s.oiChangePercent >= 0 ? "+" : "";

  // OI отображение: показываем только подтверждённые ТФ (всегда ≥ 2 кроме fast_track/long TF)
  let oiDisplay: string;
  const tf = s.oiTriggerTf ?? "30m";
  const isFastTrackSignal  = tf.startsWith("fast_track");
  const is4hMomentumSignal = tf === "4h_momentum";
  const isPrescanSignal    = tf === "prescan";
  const triggered = new Set(tf.split("+"));
  const fmtOI = (v: number) => `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`;
  // Показываем ВСЕ доступные ТФ; ✅ — подтверждённые (сработали), просто значение — для контекста
  const fmtTf = (key: string, val: number | null | undefined) =>
    val != null ? (triggered.has(key) ? `✅${key}:${fmtOI(val)}` : `${key}:${fmtOI(val)}`) : null;
  const fmt5m  = fmtTf("5m",  s.oiChange5m);
  const fmt30m = fmtTf("30m", s.coinalyzeOiChange);
  const fmt1h  = fmtTf("1h",  s.oiChange1h);
  const fmt4h  = fmtTf("4h",  s.oiChange4h);
  const fmt24h = fmtTf("24h", s.oiChange24h);
  const allTfParts = [fmt5m, fmt30m, fmt1h, fmt4h, fmt24h].filter(Boolean) as string[];
  const confirmedCount = [triggered.has("5m")  && s.oiChange5m       != null,
                          triggered.has("30m") && s.coinalyzeOiChange != null,
                          triggered.has("1h")  && s.oiChange1h        != null,
                          triggered.has("4h")  && s.oiChange4h        != null,
                          triggered.has("24h") && s.oiChange24h       != null].filter(Boolean).length;
  if (isPrescanSignal) {
    oiDisplay = `📊 Споtvol (нет OI-данных CoinGlass)`;
  } else if (is4hMomentumSignal) {
    oiDisplay = `📈 4h Momentum`;
  } else if (isFastTrackSignal && allTfParts.length === 0) {
    oiDisplay = `⚡ BingX Momentum`;
  } else if (allTfParts.length > 0) {
    const prefix = confirmedCount >= 2 ? `ОИ подтверждён: ` : `ОИ: `;
    oiDisplay = prefix + allTfParts.join(" / ");
  } else {
    // Последний резерв: ни один TF не вернул данные — показываем глобальное значение с TF-меткой
    const tfLabel = tf && tf !== "steady" && !tf.startsWith("fast_track")
      ? ` (${tf})`
      : "";
    oiDisplay = `OI ${oiSign}${s.oiChangePercent.toFixed(1)}%${tfLabel}`;
  }

  // Фьючерсный объём: всегда показываем абсолютный $ + (Xx) если не WF/VB
  const futVolStr = (() => {
    if (s.currentVolume > 0) {
      const abs = `$${formatNumber(s.currentVolume)}`;
      const showMult = s.sentimentKey !== "whale_futures" && s.sentimentKey !== "volume_breakout"
        && s.volumeMultiplier > 0;
      return showMult ? `${abs} (${s.volumeMultiplier.toFixed(1)}x)` : abs;
    }
    return s.volumeMultiplier > 0 ? `${s.volumeMultiplier.toFixed(1)}x` : "—";
  })();
  // Спот-объём: абсолютный $ + % от MCap (если есть), иначе % от фьюч
  const spotVolStr = (() => {
    if (s.spotVol24h == null) return " | ⚠️ нет данных спота";
    if (s.spotVol24h <= 0) return "";
    const abs = `$${formatNumber(s.spotVol24h)}`;
    if (s.marketCapUsd != null && s.marketCapUsd > 0) {
      const pct = (s.spotVol24h / s.marketCapUsd) * 100;
      return ` | Спот ${abs} (${pct.toFixed(1)}% MCap)`;
    }
    if (s.currentVolume > 0) {
      const pct = (s.spotVol24h / s.currentVolume) * 100;
      return ` | Спот ${abs} (${pct.toFixed(0)}% фьюч)`;
    }
    return ` | Спот ${abs}`;
  })();
  const techLine = `🔹 <b>TECH:</b> Фьюч ${futVolStr}${spotVolStr} | ${oiDisplay} | Price ${priceSign}${s.priceChange30m.toFixed(1)}%`;

  // Context line
  let contextLine: string;
  const parts: string[] = [];

  // CoinGlass spot volume — первичное внешнее подтверждение (обязательный gate)
  if (s.spotVol24h != null && s.spotVol24h > 0) {
    const abs = `$${formatNumber(s.spotVol24h)}`;
    if (s.marketCapUsd != null && s.marketCapUsd > 0) {
      const pct = (s.spotVol24h / s.marketCapUsd) * 100;
      parts.push(`📦 Спот ${abs} (${pct.toFixed(1)}% MCap)`);
    } else {
      parts.push(`📦 Спот ${abs}`);
    }
  }

  if (s.cmcAvailable) {
    if (s.cmcRank !== null) {
      parts.push(`#${s.cmcRank} Trending on ${s.cmcSource ?? "CMC"}`);
    } else {
      parts.push(`Not trending on ${s.cmcSource ?? "CMC"}`);
    }
  }

  if (s.coinglassAvailable) {
    if (s.liquidationsUsd !== null && s.liquidationsUsd > 0) {
      const liqStr = `Short Liqs: $${formatNumber(s.liquidationsUsd)}`;
      const multStr = s.liquidationsMultiple !== null ? ` (${s.liquidationsMultiple.toFixed(1)}x avg)` : "";
      parts.push(liqStr + multStr);
    } else {
      parts.push("Liqs: Low");
    }
  }

  // Coinalyze cross-exchange OI confirmation
  if (s.coinalyzeOiChange != null) {
    const sign = s.coinalyzeOiChange >= 0 ? "+" : "";
    const confirmed = s.coinalyzeConfirmed ? "✅" : "⚠️";
    parts.push(`${confirmed} Global OI: ${sign}${s.coinalyzeOiChange.toFixed(1)}% (CoinGlass)`);
  }

  if (parts.length === 0) {
    contextLine = `🔹 <b>CONTEXT:</b> ⛔ Нет спот-данных — сигнал не должен был сработать`;
  } else {
    contextLine = `🔹 <b>CONTEXT:</b> ${parts.join(" | ")}`;
  }

  // Funding rate — отдельная строка, отображается всегда когда есть данные
  let fundingLine = "";
  if (s.fundingRate != null) {
    const fr = s.fundingRate;
    const frPct = (fr * 100).toFixed(4);
    const frSign = fr >= 0 ? "+" : "";
    let frLabel: string;
    if (fr <= -0.0003) {
      frLabel = `💰 Фандинг: ${frSign}${frPct}% — шорты в ловушке, сквиз-давление`;
    } else if (fr <= -0.0001) {
      frLabel = `💰 Фандинг: ${frSign}${frPct}% — шорты платят, позитивно`;
    } else if (fr < 0.0001) {
      frLabel = `⚖️ Фандинг: ${frSign}${frPct}% — нейтрально`;
    } else if (fr < 0.0003) {
      frLabel = `📈 Фандинг: ${frSign}${frPct}% — лонги платят`;
    } else {
      frLabel = `⚠️ Фандинг: ${frSign}${frPct}% — лонги перегреты`;
    }
    if (s.indexPrice != null && s.markPrice != null && s.indexPrice > 0) {
      const premium = ((s.markPrice - s.indexPrice) / s.indexPrice) * 100;
      const premSign = premium >= 0 ? "+" : "";
      frLabel += ` | Базис: ${premSign}${premium.toFixed(3)}%`;
    }
    fundingLine = frLabel;
  }

  // Экстремальный фандинг — отдельная строка-предупреждение
  let extremeFundingLine = "";
  if (s.fundingRate != null && s.fundingRate >= 0.001) {
    extremeFundingLine = `⚠️ <b>ВНИМАНИЕ: Экстремальный фандинг</b> — лонги критически перегреты, риск каскадных ликвидаций`;
  }

  // CVD Дивергенция для Bear Trap — цена падает, но покупатели перевешивают
  const cvdDivergenceLine = (s as any).cvdDivergence
    ? `🎯 <b>CVD Дивергенция:</b> цена падает, но CVD положительный — умные деньги выкупают`
    : "";

  // Scalp Only: спот CVD 1h/4h не подтверждён — риск разворота на старших ТФ
  const scalpOnlyLine = s.isScalpOnly
    ? `⚠️ <b>SCALP ONLY</b> — спот CVD 1h/4h не подтверждён, высокий риск разворота`
    : "";

  // Alpha Score bar: filled blocks out of 10
  const filled = Math.round(s.alphaScore);
  const scoreBar = "█".repeat(filled) + "░".repeat(10 - filled);
  const scoreLine = `🎯 <b>Bullet Score: ${s.alphaScore}/10</b>  <code>${scoreBar}</code>`;

  // Emoji per pattern
  const patternEmoji: Record<string, string> = {
    hidden_accumulation: "💎",
    aggressive_breakout: "🔥",
    bullish_accumulation: "📈",
    short_squeeze:        "💥",
    bear_trap:            "🪤",
    anomaly:              "⚠️",
    sharp_impulse:        "⚡",
    impulse_breakout:     "📊",
    volume_flash:         "⚡⚡",
    moonshot_momentum:    "🚀",
    volume_breakout:      "📊",
  };

  // Russian pattern names
  const patternRuName: Record<string, string> = {
    hidden_accumulation:  "💎 Скрытое накопление — умные деньги загружают позицию тихо",
    aggressive_breakout:  "🔥 Агрессивный пробой — истинный пробой уровня на больших деньгах",
    bullish_accumulation: "📈 Бычье накопление — здоровый тренд, новые лонги заходят в позицию",
    short_squeeze:        "💥 Short Squeeze — шортистов принудительно выбивает по ликвидациям",
    bear_trap:            "🪤 Медвежья ловушка — толпа шортит в пол, крупный выкупает",
    anomaly:              "⚠️ Аномалия — нет чёткого паттерна, повышенный риск",
    sharp_impulse:        "⚡ Острый импульс — резкое движение на объёме",
    impulse_breakout:     "📊 Импульсный пробой — пробой на нарастающем OI",
    volume_flash:         "⚡⚡ Флеш-памп — объём взорвался, скальп прямо сейчас",
    moonshot_momentum:    "🚀 Импульс Ракеты — взрывной рост с подтверждением OI и объёма",
    "4h_momentum":        "🕯 4h Моментум — медленный грайнд, накопление за 4ч+",
    early_ignition:       "🔥 Раннее зажигание — 5m OI взрывается, ловим старт импульса",
    volume_breakout:      "📊 Volume Breakout — устойчивый спот-объём без OI, возможный pump",
  };

  const pEmoji = patternEmoji[s.sentimentKey] ?? "🔹";
  const patternLine = `🏷 <b>Паттерн:</b> ${patternRuName[s.sentimentKey] ?? s.sentiment}`;
  const sentimentLine = `${pEmoji} <b>SENTIMENT:</b> ${s.sentiment}`;
  const actionLine = `⚡ <b>ДЕЙСТВИЕ:</b> ${s.traderAction}`;

  const continuingLine = s.isContinuing
    ? `📡 <i>Продолжает движение (OI ${s.cumulativeOiChange >= 0 ? "+" : ""}${s.cumulativeOiChange.toFixed(1)}% суммарно)</i>`
    : "";

  // Ценовое подтверждение — показываем насколько цена уже прошла до выстрела
  const confirmLine = (s.priceConfirmPct != null && s.priceConfirmPct >= 1)
    ? `✅ <b>Подтверждён:</b> цена уже +${s.priceConfirmPct.toFixed(1)}% с момента обнаружения`
    : "";

  // Повторный сигнал — символ уже был в сигналах за последние 24ч
  const repeatLine = s.isRepeatSignal
    ? `🔁 <i>Повторный сигнал за 24ч — тезис подтвердился снова, вход ещё актуален</i>`
    : "";

  // Exhaustion warning — SHORT_SQUEEZE с CoinGlass OI < -20%
  const exhaustionLine = s.isExhaustedSqueeze
    ? `⚠️ <b>ВНИМАНИЕ:</b> Global OI ${s.coinalyzeOiChange != null ? s.coinalyzeOiChange.toFixed(0) : ""}% — шорты уже выдавлены, вход может быть поздним`
    : "";

  // Slippage warning — цена успела уйти пока шёл CoinGlass batch
  const slippageLine = s.klineSlippage != null && Math.abs(s.klineSlippage) >= 5
    ? `⚠️ <b>ПОЗДНИЙ ВХОД:</b> цена ушла на ${s.klineSlippage >= 0 ? "+" : ""}${s.klineSlippage.toFixed(1)}% пока шёл анализ`
    : "";

  // ── Двойной вход + стоп лосс ─────────────────────────────────────────────────
  // Вход 1: по рынку (50%) — сразу, чтобы не пропустить движение
  // Вход 2: лимиткой -2% (50%) — усредняем если будет откат
  // Стоп: -10% от рыночного входа
  // Исключение: volume_flash (скальп) — только один вход по рынку
  const STOP_PCT   = 10;  // % стоп от рыночного входа (совпадает с watcher.ts STOP_LOSS)
  const LIMIT_PCT  = 2;   // % ниже рынка для лимитки
  const fmtPrice = (p: number) => p < 1 ? p.toFixed(6) : p < 100 ? p.toFixed(4) : p.toFixed(2);
  const marketEntry = s.price;
  const limitEntry  = s.price * (1 - LIMIT_PCT / 100);
  const stopLevel   = s.price * (1 - STOP_PCT / 100);
  let entryBlock: string;
  if (s.sentimentKey === "volume_flash") {
    // Скальп — только рыночный вход, нет смысла ставить лимитку
    entryBlock = [
      `📍 <b>Вход:</b> $${fmtPrice(marketEntry)} по рынку`,
      `🛑 <b>Стоп:</b> $${fmtPrice(stopLevel)} (−${STOP_PCT}%)`,
    ].join("\n");
  } else {
    entryBlock = [
      `📍 <b>Вход 1:</b> $${fmtPrice(marketEntry)} по рынку — 50%`,
      `📍 <b>Вход 2:</b> $${fmtPrice(limitEntry)} лимиткой −${LIMIT_PCT}% — 50%`,
      `🛑 <b>Стоп:</b> $${fmtPrice(stopLevel)} (−${STOP_PCT}% от рынка)`,
    ].join("\n");
  }

  const priceFormatted = fmtPrice(s.price);
  const cgBase = s.symbol.replace("-USDT", "");
  const cgLink = `https://www.coinglass.com/futures/${cgBase}`;
  const linksLine = `📊 <a href="${s.tradingViewUrl}">Chart</a>  |  📈 <a href="${s.bingxUrl}">BingX</a>  |  🔍 <a href="${cgLink}">OI (CoinGlass)</a>  |  💵 $${priceFormatted}`;
  const tagsLine = tickerTag(s.symbol);

  // Order Book Imbalance line — показываем если данные есть и стакан интересный
  let obLine = "";
  if (s.obImbalance && s.obImbalance.bias !== "neutral") {
    const ob = s.obImbalance;
    if (ob.bias === "strong_bull") {
      const wallStr = ob.bidWallCount > 0
        ? ` | 🧱 Стена $${(ob.largestBidWallUsd / 1000).toFixed(0)}k`
        : "";
      obLine = `📚 <b>Стакан:</b> 🟢🟢 Сильный бид (${ob.bidAskRatio.toFixed(1)}:1)${wallStr}`;
    } else if (ob.bias === "bull") {
      obLine = `📚 <b>Стакан:</b> 🟢 Биды доминируют (${ob.bidAskRatio.toFixed(1)}:1)`;
    } else if (ob.bias === "bear") {
      obLine = `📚 <b>Стакан:</b> 🔴 Аски давят (${ob.bidAskRatio.toFixed(1)}:1) — осторожно`;
    }
  }

  return [gradeHeader, patternLine, speedLabel, confirmLine, scalpOnlyLine, scoreLine, techLine, contextLine, fundingLine, extremeFundingLine, cvdDivergenceLine, obLine, sentimentLine, actionLine, ``, entryBlock, ``, repeatLine, exhaustionLine, slippageLine, continuingLine, linksLine, ``, tagsLine]
    .filter(l => l !== undefined && l !== null && l !== "")
    .join("\n");
}

// Cache: @username → numeric chat ID (resolved once via Telegram API, persists for process lifetime)
const _chatIdCache = new Map<string, number>();

async function resolveToNumericId(chatId: string): Promise<number | null> {
  const key = chatId.toLowerCase();
  if (_chatIdCache.has(key)) return _chatIdCache.get(key)!;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/getChat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId }),
    });
    if (!res.ok) return null;
    const data = await res.json() as { ok: boolean; result?: { id: number } };
    if (data.ok && data.result?.id) {
      _chatIdCache.set(key, data.result.id);
      return data.result.id;
    }
  } catch { /* ignore — fall back to string dedup */ }
  return null;
}

export async function getTargets(): Promise<(number | string)[]> {
  const seenNumeric = new Set<number>();
  const seenString = new Set<string>();
  const targets: (number | string)[] = [];

  // Dedup by numeric ID when possible (prevents duplicate sends when TELEGRAM_CHAT_ID
  // is a numeric chat ID and settings.channelId is the same channel as @username)
  const addTarget = async (id: number | string) => {
    if (typeof id === "number") {
      if (!seenNumeric.has(id)) { seenNumeric.add(id); targets.push(id); }
    } else if (id.startsWith("@")) {
      const numId = await resolveToNumericId(id);
      if (numId !== null) {
        if (!seenNumeric.has(numId)) { seenNumeric.add(numId); targets.push(numId); }
      } else {
        const key = id.toLowerCase();
        if (!seenString.has(key)) { seenString.add(key); targets.push(id); }
      }
    } else {
      const key = id.toLowerCase();
      if (!seenString.has(key)) { seenString.add(key); targets.push(id); }
    }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) await addTarget(asNum);
    else if (envId.startsWith("@")) await addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers
  const activeSubscribers = await db.select({ chatId: subscribersTable.chatId })
    .from(subscribersTable)
    .where(eq(subscribersTable.active, true));
  for (const s of activeSubscribers) await addTarget(s.chatId);

  // Always add channelId from settings so the channel receives every message
  // regardless of whether TELEGRAM_CHAT_ID env is set. The dedup logic above
  // (seenNumeric / seenString + resolveToNumericId) prevents duplicate sends
  // when both point to the same destination.
  const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
  const ch = rows[0]?.channelId?.trim();
  if (ch) await addTarget(ch);

  return targets;
}

export async function broadcastBatchAlert(signals: AlphaResult[]): Promise<void> {
  if (signals.length === 0) return;

  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("No Telegram targets to send to");
    return;
  }

  if (signals.length === 0) return;

  // Sort: SUPER ALPHA first, then ALPHA
  const sorted = [...signals].sort((a, b) => {
    if (a.grade === "super_alpha" && b.grade !== "super_alpha") return -1;
    if (b.grade === "super_alpha" && a.grade !== "super_alpha") return 1;
    return 0;
  });

  const superCount  = sorted.filter(s => s.grade === "super_alpha").length;
  const alphaCount  = sorted.filter(s => s.grade === "alpha").length;

  const headerParts: string[] = [];
  if (superCount > 0) headerParts.push(`${superCount} SUPER BULLET`);
  if (alphaCount > 0) headerParts.push(`${alphaCount} BULLET`);
  const text = signals.length === 1
    ? formatAlphaSignal(sorted[0])
    : [
        `🚨 <b>BingX AltBullet — ${headerParts.join(" + ")}</b>`,
        ``,
        sorted.map(formatAlphaSignal).join("\n\n─────────────────────\n\n"),
      ].join("\n");

  logger.info({ count: signals.length, targets: targets.length }, "Broadcasting alpha batch alert");

  for (const chatId of targets) {
    await sendMessage(chatId, text);
    await new Promise(r => setTimeout(r, 50));
  }
}

/** Broadcast a raw pre-formatted text message to all configured Telegram targets */
export async function broadcastRawAlert(text: string): Promise<void> {
  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("broadcastRawAlert: нет получателей");
    return;
  }
  for (const target of targets) {
    try {
      await sendMessage(target, text);
      await new Promise(r => setTimeout(r, 50));
    } catch (err) {
      logger.error({ err, target }, "broadcastRawAlert: не удалось отправить сообщение");
    }
  }
}

// Legacy single-signal broadcast (kept for compatibility)
export async function broadcastSignalAlert(signal: Omit<Signal, "id">): Promise<void> {
  const data: AlphaResult = {
    symbol: signal.symbol,
    grade: (signal.type === "super_alpha" ? "super_alpha" : "alpha") as "alpha" | "super_alpha",
    price: signal.price,
    priceChange30m: signal.priceChangePercent,
    currentVolume: signal.volume24h,
    avgVolume: signal.avgVolume,
    volumeMultiplier: signal.value,
    oiChangePercent: signal.oiChangePercent ?? 0,
    openInterest: signal.openInterest ?? 0,
    cmcRank: null,
    cmcSource: null,
    cmcAvailable: false,
    liquidationsUsd: null,
    liquidationsMultiple: null,
    coinglassAvailable: false,
    sentiment: (signal as any).sentiment ?? "Аномальная активность",
    sentimentKey: (signal as any).sentimentKey ?? "anomaly",
    traderAction: "Наблюдение",
    alphaScore: (signal as any).alphaScore ?? 5,
    isContinuing: false,
    cumulativeOiChange: signal.oiChangePercent ?? 0,
    tradingViewUrl: signal.tradingViewUrl,
    bingxUrl: `https://bingx.com/en/trade/${signal.symbol.replace("-", "")}/`,
  };
  await broadcastBatchAlert([data]);
}

// ── Whale Accumulation Signal ──────────────────────────────────────────────────

// ── Whale Watch 2.0 ───────────────────────────────────────────────────────────

export interface WhaleWatchV2Entry {
  symbol:            string;
  accumulatedCvdUsd: number;
  accumPeriods:      number;
  avgBuyPrice:       number | null;
  marketCapUsd:      number | null;
  accumPct:          number | null;
  priceAtEntry:      number | null;
  lastPrice:         number | null;
  firstSeenAt:       Date;
  status:            string;
}

export function formatWhaleWatchV2Alert(entries: WhaleWatchV2Entry[]): string {
  const lines: string[] = [
    `🐋 <b>WHALE WATCH 2.0 — Spot CVD накопление</b>`,
    ``,
    `Токены с устойчивым спотовым выкупом при плоской цене:`,
    ``,
  ];

  const top = entries.slice(0, 10);
  for (const e of top) {
    const coin = e.symbol.replace("-USDT", "");
    const cvdStr = e.accumulatedCvdUsd >= 1_000_000
      ? `$${(e.accumulatedCvdUsd / 1_000_000).toFixed(1)}M`
      : `$${(e.accumulatedCvdUsd / 1_000).toFixed(0)}K`;
    const accumPctStr = e.accumPct != null ? ` (${e.accumPct.toFixed(2)}% mcap)` : "";
    const priceStr = e.lastPrice && e.priceAtEntry
      ? ` | цена ${e.lastPrice >= e.priceAtEntry ? "+" : ""}${(((e.lastPrice - e.priceAtEntry) / e.priceAtEntry) * 100).toFixed(1)}%`
      : "";
    const statusEmoji = e.status === "breakout" ? "🚀" : "🔵";
    const periodsStr = e.accumPeriods > 0 ? ` | ${e.accumPeriods} периодов` : "";
    lines.push(`${statusEmoji} <b>${coin}</b> — CVD: <b>${cvdStr}${accumPctStr}</b>${priceStr}${periodsStr}`);
  }

  if (entries.length > 10) lines.push(``, `...и ещё ${entries.length - 10} токенов`);

  lines.push(
    ``,
    `⚡️ Это наблюдение, не сигнал входа.`,
    `При пробое появится стандартный альфа-сигнал.`,
    ``,
    `#whale_watch #накопление #spot_cvd`,
  );
  return lines.join("\n");
}

/** Одиночный breakout alert для Whale Watch 2.0 */
export function formatWhaleBreakoutAlert(e: WhaleWatchV2Entry): string {
  const coin = e.symbol.replace("-USDT", "");
  const cvdStr = e.accumulatedCvdUsd >= 1_000_000
    ? `$${(e.accumulatedCvdUsd / 1_000_000).toFixed(1)}M`
    : `$${(e.accumulatedCvdUsd / 1_000).toFixed(0)}K`;
  const accumPctStr = e.accumPct != null ? ` (${e.accumPct.toFixed(2)}% от mcap)` : "";
  const priceFromEntry = e.lastPrice && e.priceAtEntry
    ? (((e.lastPrice - e.priceAtEntry) / e.priceAtEntry) * 100).toFixed(1)
    : null;
  const avgBuyStr = e.avgBuyPrice ? `\n💰 <b>Avg whale buy:</b> ${e.avgBuyPrice.toPrecision(4)}` : "";

  return [
    `🐋🚀 <b>WHALE BREAKOUT — ${coin}/USDT</b>`,
    ``,
    `Накопление перешло в движение цены!`,
    ``,
    `📊 <b>Накоплено CVD:</b> ${cvdStr}${accumPctStr}`,
    `🕐 <b>Периодов накопления:</b> ${e.accumPeriods}`,
    avgBuyStr,
    priceFromEntry ? `📈 <b>Рост от входа:</b> +${priceFromEntry}%` : ``,
    ``,
    `⚡️ Сигнал входа подтверждается. Следи за стандартным альфа-сигналом.`,
    ``,
    `<a href="https://www.tradingview.com/chart/?symbol=BYBIT:${coin}USDT.P">TradingView</a>`,
    ``,
    `#${coin} #whale_breakout #alpha_scanner`,
  ].filter(Boolean).join("\n");
}

export async function broadcastWhaleWatchV2Alert(entries: WhaleWatchV2Entry[]): Promise<void> {
  if (entries.length === 0) return;

  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("No Telegram targets for whale watch v2 alert");
    return;
  }

  const text = formatWhaleWatchV2Alert(entries);
  for (const target of targets) {
    await sendMessage(target, text);
    await new Promise(r => setTimeout(r, 50));
  }
}

/** @deprecated Use broadcastWhaleWatchV2Alert instead */
export async function broadcastWhaleAccumAlert(_signals: unknown[]): Promise<void> {
  // kept for backward compat — no-op
}

// ── Тексты бота ──────────────────────────────────────────────────────────────

const WELCOME_TEXT = [
  `🚀 <b>AltBullet — Твой радар в океане крипты</b>`,
  ``,
  `Хватит заходить в монеты, когда они уже «улетели». AltBullet находит следы крупных игроков (Whales) ДО начала основного движения.`,
  ``,
  `<b>Что ты получаешь внутри:</b>`,
  ``,
  `✅ <b>Whale Watch:</b> Уникальный алгоритм, который видит скрытое накопление китов на споте в течение дней и недель.`,
  `✅ <b>10 торговых паттернов:</b> От Short Squeeze до импульсных пробоев — бот классифицирует каждое движение.`,
  `✅ <b>Анализ реальных денег:</b> Мы смотрим не только на график, но и на Spot CVD, открытый интерес (OI) и ликвидации.`,
  `✅ <b>Умное сопровождение:</b> Бот сам ведет сделку, уведомляет о целях и дает сигнал на выход (Smart Cancel), если кит начал разгружаться.`,
  ``,
  `💎 <b>Доступ ограничен</b>`,
  `Бот работает в закрытом режиме для сохранения эффективности сигналов.`,
  ``,
  `Стань тем, кто покупает у китов, а не об кого они закрываются. Удачной охоты! 🐋🚀`,
].join("\n");

const PAYMENT_KEYBOARD = [
  [{ text: "💳 Оформить подписку", callback_data: "payment_pending" }],
  [{ text: "✍️ Написать админу", url: "https://t.me/darshakl" }],
];

const PRICES_TEXT = [
  `💎 <b>AltBullet — Тарифы</b>`,
  ``,
  `🗓 <b>1 месяц</b> — <b>10 000 ₽</b>`,
  `📅 <b>3 месяца</b> — <b>25 000 ₽</b> <i>(экономия 5 000 ₽)</i>`,
  `🏆 <b>1 год</b> — <b>100 000 ₽</b> <i>(экономия 20 000 ₽)</i>`,
  ``,
  `<b>Что входит во все тарифы:</b>`,
  `• Сигналы 24/7 по 500+ фьючерсным парам`,
  `• 10 паттернов: Short Squeeze, Hidden Accumulation, Breakout и др.`,
  `• 🐋 Whale Watch — скрытое накопление китов`,
  `• Smart Cancel — автоматический выход до стопа`,
  `• Ежедневные + еженедельные отчёты`,
  ``,
  `Для оплаты или вопросов — напиши админу 👇`,
].join("\n");

const ALREADY_SUBSCRIBED_TEXT = [
  `✅ <b>У тебя уже есть доступ!</b>`,
  ``,
  `Сигналы приходят автоматически. Используй /menu для дайджеста.`,
].join("\n");

const ACTIVATION_TEXT = [
  `✅ <b>Оплата получена — доступ открыт!</b>`,
  ``,
  `🚀 <b>AltBullet: Полное руководство для подписчиков</b>`,
  ``,
  `Добро пожаловать в AltBullet — профессиональный инструмент для поиска аномальной активности на крипторынке. Этот бот анализирует тысячи данных в секунду, чтобы найти следы «умных денег» (Whales) до того, как монета улетит в космос.`,
  ``,
  `🔍 <b>1. Список паттернов: Что они значат?</b>`,
  ``,
  `🔴 <b>Short Squeeze</b> — Шортисты набились, цена пошла против. Ликвидации толкают цену вверх. Скальп-лонг.`,
  `🟡 <b>Hidden Accumulation</b> — Кит тихо выкупает лимитками, OI растет, цена стоит. Мощное движение через 6–24ч.`,
  `🟠 <b>Bear Trap</b> — Цена падает, заманивая шортов, киты выкупают. Резкий разворот вверх.`,
  `🔥 <b>Aggressive Breakout</b> — Агрессивные покупатели, объём и цена растут одновременно. Вход по рынку.`,
  `🟢 <b>Bullish Accumulation</b> — Устойчивый рост, подтверждённый набором позиций. Удержание по тренду.`,
  `⚡ <b>Sharp Impulse</b> — Взрывная свеча на огромном объёме. Быстрый вход, короткий стоп.`,
  `🐋 <b>Whale Watch</b> — Серия крупных покупок на споте за дни/недели. Инвестиционный лонг.`,
  ``,
  `🛠 <b>2. Как торговать сигналы?</b>`,
  ``,
  `<b>Вход:</b> Никогда не заходите на всю котлету по рынку. Сетка: 30% по текущей / 40% чуть ниже / 30% у стопа.`,
  ``,
  `<b>Сопровождение — бот делает автоматически:</b>`,
  `1. <b>+5-10%</b> → предложит зафиксировать часть и перенести стоп в БУ`,
  `2. <b>+15%</b> → активируется трейлинг-стоп`,
  `3. <b>Smart Cancel</b> → если кит начал разгружаться — сигнал на выход до стопа`,
  ``,
  `📊 <b>3. Ежедневные отчёты (11:00 МСК)</b>`,
  `Sentiment рынка · Top Gainers · Open Positions`,
  ``,
  `<b>Хэштеги для поиска:</b> #in_run · #moonshot · #whale_watch · #BTC · #ETH`,
  ``,
  `💡 <b>Важно:</b> Фиксируйте части прибыли на целях. Слушайте Smart Cancel — бот видит выход денег раньше вас. Whale Watch отрабатывает дольше, но приносит максимальный профит.`,
  ``,
  `AltBullet — твой радар в океане крипты. Удачной охоты! 🐋🚀`,
].join("\n");

// ── Вспомогательная функция активации подписчика ─────────────────────────────

export async function activateSubscriber(
  chatId: number,
  username: string | null,
  firstName: string | null,
  lastName: string | null,
): Promise<void> {
  await db.insert(subscribersTable).values({
    chatId,
    username,
    firstName,
    lastName,
    active: true,
    subscribedAt: new Date(),
    unsubscribedAt: null,
  }).onConflictDoUpdate({
    target: subscribersTable.chatId,
    set: {
      active: true,
      username,
      firstName,
      lastName,
      unsubscribedAt: null,
    },
  });
}

// ── Webhook handler ───────────────────────────────────────────────────────────

export async function handleWebhookUpdate(update: unknown): Promise<void> {
  const upd = update as {
    message?: {
      chat: { id: number };
      from?: { id: number; username?: string; first_name?: string; last_name?: string };
      text?: string;
    };
    channel_post?: {
      chat: { id: number };
      from?: { id: number; username?: string; first_name?: string; last_name?: string };
      text?: string;
    };
  };

  const msg = upd.message ?? upd.channel_post;
  if (!msg) return;

  // chatId = куда отвечать (группа, канал или личка)
  const chatId = msg.chat.id;
  // userId = кто отправил (личный Telegram ID пользователя)
  // В личке from.id === chat.id, в группе/канале они разные
  const userId = msg.from?.id ?? msg.chat.id;
  const text = msg.text ?? "";
  const command = text.split("@")[0].toLowerCase();

  // Владелец бота: приоритет OWNER_CHAT_ID (личный Telegram ID),
  // если не задан — проверяем TELEGRAM_CHAT_ID (обычно ID канала, не личный).
  const ownerChatIdRaw = process.env.OWNER_CHAT_ID ?? process.env.TELEGRAM_CHAT_ID;
  const ownerChatId = ownerChatIdRaw ? Number(ownerChatIdRaw) : null;
  const isOwner = ownerChatId !== null && userId === ownerChatId;

  // Проверяем статус подписки по личному ID пользователя (не по ID чата/группы)
  const [sub] = await db.select()
    .from(subscribersTable)
    .where(eq(subscribersTable.chatId, userId))
    .limit(1);
  const isSubscriber = sub?.active === true;

  // /myid — доступна всем, без проверки подписки (нужна для первичной настройки)
  if (command === "/myid") {
    await sendMessage(chatId, `🆔 Твой Telegram User ID: <code>${userId}</code>\n\nПередай его администратору для активации.`);
    return;
  }

  if (command === "/start") {
    if (isSubscriber) {
      await sendMessage(chatId, ALREADY_SUBSCRIBED_TEXT);
    } else {
      await sendMessageWithKeyboard(chatId, WELCOME_TEXT, PAYMENT_KEYBOARD);
      logger.info({ chatId, username: msg.chat.username }, "Shown welcome + pay screen");
    }
    return;
  }

  if (command === "/prices" || command === "/pricing") {
    await sendMessageWithKeyboard(chatId, PRICES_TEXT, [
      [{ text: "✍️ Написать админу", url: "https://t.me/darshakl" }],
    ]);
    return;
  }

  // Тестовая команда для владельца: симулирует оплату
  if (command === "/activate_test" && isOwner) {
    await activateSubscriber(userId, msg.from?.username ?? null, msg.from?.first_name ?? null, msg.from?.last_name ?? null);
    await sendMessageWithKeyboard(chatId, ACTIVATION_TEXT, DIGEST_KEYBOARD);
    logger.info({ userId }, "Owner test activation");
    return;
  }

  // Все остальные команды — только для подписчиков (и владельца)
  if (!isSubscriber && !isOwner) {
    await sendMessageWithKeyboard(chatId, WELCOME_TEXT, PAYMENT_KEYBOARD);
    return;
  }

  if (command === "/menu") {
    await sendMessageWithKeyboard(chatId, [
      `📋 <b>Меню дайджестов</b>`,
      ``,
      `Выбери период — получишь статистику прямо сейчас:`,
    ].join("\n"), DIGEST_KEYBOARD);
  } else if (command === "/stop" || command === "/unsubscribe") {
    await db.update(subscribersTable)
      .set({ active: false, unsubscribedAt: new Date() })
      .where(eq(subscribersTable.chatId, userId));

    await sendMessage(chatId, `❌ <b>Unsubscribed.</b>\n\nYou will no longer receive signals.\nSend /start to subscribe again.`);
    logger.info({ userId }, "Subscriber unsubscribed");
  } else if (command === "/status" || command === "/positions") {
    await sendMessage(chatId, `📊 Загружаю позиции...`);
    try {
      const text = await buildPositionsStatusText();
      await sendMessage(chatId, text);
    } catch (err) {
      logger.error({ err }, "positions command error");
      await sendMessage(chatId, `❌ Ошибка при загрузке позиций. Попробуй позже.`);
    }
  } else if (command === "/whalewatch") {
    await sendMessage(chatId, `🐋 Анализирую данные...`);
    try {
      const coverage = await getWhaleDataCoverage();
      const candidates = await getAllWhaleAccumCandidates();

      if (coverage.total === 0 || coverage.ready === 0) {
        await sendMessage(chatId, [
          `🐋 <b>Whale Watch — данных пока недостаточно</b>`,
          ``,
          `Система собирает снимки OI ежедневно.`,
          `Для анализа нужно минимум 14 дней данных.`,
          ``,
          `📊 Токенов с данными: <b>${coverage.total}</b>`,
          `✅ Готовы к анализу (14+ дней): <b>${coverage.ready}</b>`,
          coverage.oldestDate ? `📅 Самые ранние данные: <b>${coverage.oldestDate}</b>` : `📅 Данных пока нет`,
          ``,
          `Первые сигналы появятся через ~14 дней после запуска.`,
          `Каждую субботу в 10:00 МСК отправляется Whale Watch отчёт.`,
        ].join("\n"));
        return;
      }

      if (candidates.length === 0) {
        await sendMessage(chatId, [
          `🐋 <b>Whale Watch — активных накоплений не найдено</b>`,
          ``,
          `📊 Токенов в базе: <b>${coverage.total}</b>`,
          `✅ Проанализировано (14+ дней): <b>${coverage.ready}</b>`,
          ``,
          `Нет токенов с устойчивым ростом OI при плоской цене.`,
          `Обновлённый отчёт — каждую субботу в 10:00 МСК.`,
        ].join("\n"));
        return;
      }

      // Показываем топ-5 кандидатов
      const top5 = candidates.slice(0, 5);
      const lines: string[] = [
        `🐋 <b>Whale Watch — ${candidates.length} токенов в накоплении</b>`,
        ``,
      ];

      for (const c of top5) {
        const coin   = c.symbol.replace("-USDT", "");
        const conf   = c.confidence === "high" ? "🔴 HIGH" : "🟡 MED";
        const pStr   = c.priceChangePct >= 0 ? `+${c.priceChangePct.toFixed(1)}%` : `${c.priceChangePct.toFixed(1)}%`;
        lines.push(`${conf} <b>${coin}</b>`);
        lines.push(`  OI +${c.oiGrowthPct.toFixed(0)}% за ${c.daysTracked}д | цена ${pStr} | постоянство ${c.consistencyPct.toFixed(0)}%`);
        lines.push(``);
      }

      if (candidates.length > 5) {
        lines.push(`...и ещё ${candidates.length - 5} токенов`);
        lines.push(``);
      }

      lines.push(`📊 Всего проанализировано: <b>${coverage.ready}</b> токенов`);
      lines.push(`🕒 Полный отчёт — каждую субботу в 10:00 МСК`);

      await sendMessage(chatId, lines.join("\n"));
    } catch (err) {
      logger.error({ err }, "whalewatch command error");
      await sendMessage(chatId, `❌ Ошибка при анализе. Попробуй позже.`);
    }
  }
}

