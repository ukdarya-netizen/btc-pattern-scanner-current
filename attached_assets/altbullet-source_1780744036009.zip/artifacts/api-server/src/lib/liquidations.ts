import { logger } from "./logger.js";

export interface LiquidationResult {
  liquidationsUsd: number | null;
  avgLiquidationsUsd: number | null;
  multiple: number | null;
  available: boolean;
}

// In-memory store of recent liquidation values per symbol for computing average
const liqHistory = new Map<string, number[]>();
const MAX_HISTORY = 8; // keep last 8 readings (4h at 30m intervals)

// Normalize symbol for Coinglass: BTC-USDT → BTCUSDT
function toCglSymbol(symbol: string): string {
  return symbol.replace("-", "");
}

export async function getLiquidations(symbol: string): Promise<LiquidationResult> {
  const apiKey = process.env.COINGLASS_API_KEY;
  if (!apiKey) {
    return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
  }

  const cglSymbol = toCglSymbol(symbol);

  try {
    // Coinglass liquidation chart for last 30m
    const res = await fetch(
      `https://open-api.coinglass.com/public/v2/liquidation_history?ex=Binance&pair=${cglSymbol}&interval=0.5h&limit=2`,
      {
        headers: {
          "coinglassSecret": apiKey,
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(5000),
      }
    );

    if (!res.ok) {
      return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
    }

    const data = await res.json() as {
      code: string;
      data: {
        shortLiquidationUsd: number;
        longLiquidationUsd: number;
        t: number;
      }[];
    };

    if (data.code !== "0" || !data.data?.length) {
      return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
    }

    // Get the most recent interval's short liquidations
    const latest = data.data[data.data.length - 1];
    const currentLiqUsd = (latest.shortLiquidationUsd ?? 0) + (latest.longLiquidationUsd ?? 0);

    // Track history to compute rolling average
    const history = liqHistory.get(symbol) ?? [];
    if (history.length >= MAX_HISTORY) history.shift();
    history.push(currentLiqUsd);
    liqHistory.set(symbol, history);

    const avgLiq = history.length > 1
      ? history.slice(0, -1).reduce((a, b) => a + b, 0) / (history.length - 1)
      : currentLiqUsd;

    const multiple = avgLiq > 0 ? currentLiqUsd / avgLiq : null;

    return {
      liquidationsUsd: currentLiqUsd,
      avgLiquidationsUsd: avgLiq,
      multiple,
      available: true,
    };
  } catch (err) {
    logger.warn({ symbol, err }, "Coinglass liquidations fetch failed");
    return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
  }
}
