/**
 * CoinGlass — Multi-TimeFrame (MTF) Spot CVD.
 *
 * Fetches spot taker buy/sell flow (5m × 48 candles) from Binance + Bybit
 * and derives spot CVD verdicts across 4 timeframes:
 *
 *   5m  — last candle:              net buy > sell
 *   15m — 3 of last 4 15m periods: majority positive
 *   1h  — last 1h period:           net positive
 *   4h  — full 4h window:           net positive
 *
 * Hard filter (блокировка): 5m OR 15m failed → signal blocked.
 * Trend filter (scalp flag): 1h or 4h failed (but 5m+15m ok) → "Scalp Only".
 * Golden Signal: all 4 TFs positive → no restrictions.
 *
 * Endpoint: GET /api/spot/taker-buy-sell-volume/history
 *   ?symbol=BTCUSDT&exchange=Binance&interval=5m&limit=48
 * Header: CG-API-KEY: <key>
 *
 * Cache: 3 min (5m candles change frequently; fresh data matters).
 * Fallback: if API unavailable → available=false, never blocks signals.
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";

export interface SpotCvdResult {
  /** Last 5m candle: buy > sell */
  cvd5m: boolean | null;
  /** Last 6 × 5m candles (= 30m): net buy > sell */
  cvd30m: boolean | null;
  /** 3 of last 4 15m periods: buy > sell */
  cvd15m_3of4: boolean | null;
  /** Last 1h period: net positive */
  cvd1h: boolean | null;
  /** Full 4h window: net positive */
  cvd4h: boolean | null;
  /** 5m OR 15m failed → block signal entirely (hard gate) */
  hardBlocked: boolean;
  /** 1h or 4h failed (but 5m+15m ok) → mark signal as Scalp Only */
  scalpOnly: boolean;
  /** All 4 TFs positive → strongest confirmation */
  isGolden: boolean;
  available: boolean;
}

const EXCHANGES = ["Binance", "Bybit"] as const;
const CANDLES = 48; // 48 × 5m = 4h of history
const CACHE_TTL = 3 * 60 * 1000;

const cache = new Map<string, { result: SpotCvdResult; ts: number }>();

const volCache = new Map<string, { vol: number; ts: number }>();
const VOL_CACHE_TTL = 30 * 60 * 1000; // 30 min

function toCgSymbol(bingxSymbol: string): string {
  return bingxSymbol.replace("-", "");
}

interface CgCandle {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
}

async function fetchExchange(
  cgSymbol: string,
  exchange: string,
  apiKey: string,
  limit = CANDLES,
): Promise<CgCandle[] | null> {
  const url = new URL("https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history");
  url.searchParams.set("symbol",   cgSymbol);
  url.searchParams.set("exchange", exchange);
  url.searchParams.set("interval", "5m");
  url.searchParams.set("limit",    String(limit));

  try {
    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) {
      reportApiFailure("coinglass", res.status);
      return null;
    }
    const data = await res.json() as { code: string; data?: CgCandle[] };
    if (data.code !== "0" || !data.data?.length) return null;
    reportApiSuccess("coinglass");
    return data.data;
  } catch {
    return null;
  }
}

/**
 * Returns MTF Spot CVD verdict for a BingX symbol.
 * On API failure returns { available: false } — signals are NOT blocked.
 */
export async function getSpotCvdMtf(symbol: string): Promise<SpotCvdResult> {
  const apiKey = process.env.COINGLASS_API_KEY;

  const noData: SpotCvdResult = {
    cvd5m: null, cvd30m: null, cvd15m_3of4: null, cvd1h: null, cvd4h: null,
    hardBlocked: false, scalpOnly: false, isGolden: false, available: false,
  };

  if (!apiKey) return noData;

  const cgSymbol = toCgSymbol(symbol);
  const cached = cache.get(cgSymbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  const [r1, r2] = await Promise.all(
    EXCHANGES.map(ex => fetchExchange(cgSymbol, ex, apiKey)),
  );

  if (!r1 && !r2) {
    cache.set(cgSymbol, { result: noData, ts: Date.now() });
    return noData;
  }

  // Aggregate candles (oldest→newest, slot 0 = oldest, slot CANDLES-1 = freshest)
  const agg: Array<{ buy: number; sell: number }> = Array.from(
    { length: CANDLES },
    () => ({ buy: 0, sell: 0 }),
  );

  for (const candles of [r1, r2]) {
    if (!candles || candles.length === 0) continue;
    // CoinGlass returns oldest→newest; align to right-end of agg array
    const start = Math.max(0, candles.length - CANDLES);
    const offset = CANDLES - (candles.length - start);
    for (let ci = start; ci < candles.length; ci++) {
      const slot = offset + (ci - start);
      const c = candles[ci]!;
      agg[slot]!.buy  += parseFloat(c.taker_buy_volume_usd)  || 0;
      agg[slot]!.sell += parseFloat(c.taker_sell_volume_usd) || 0;
    }
  }

  const validCount = agg.filter(s => s.buy + s.sell > 0).length;
  if (validCount === 0) {
    cache.set(cgSymbol, { result: noData, ts: Date.now() });
    return noData;
  }

  // ── cvd5m: last candle (slot CANDLES-1) ──────────────────────────────────────
  const last = agg[CANDLES - 1]!;
  const cvd5m = last.buy + last.sell > 0 ? last.buy > last.sell : null;

  // ── cvd30m: last 6 candles (slots 42–47 = 30 min) ───────────────────────────
  let cvd30m: boolean | null = null;
  if (validCount >= 6) {
    let buy30 = 0, sell30 = 0;
    for (let i = CANDLES - 6; i < CANDLES; i++) { buy30 += agg[i]!.buy; sell30 += agg[i]!.sell; }
    if (buy30 + sell30 > 0) cvd30m = buy30 > sell30;
  }

  // ── cvd15m_3of4: last 4 groups of 3×5m = 15m each (slots 36–47) ─────────────
  let cvd15m_3of4: boolean | null = null;
  if (validCount >= 6) {
    const positives: boolean[] = [];
    for (let g = 0; g < 4; g++) {
      const s0 = CANDLES - 12 + g * 3;
      let buy = 0, sell = 0;
      for (let j = 0; j < 3; j++) { buy += agg[s0 + j]!.buy; sell += agg[s0 + j]!.sell; }
      if (buy + sell > 0) positives.push(buy > sell);
    }
    if (positives.length >= 3) cvd15m_3of4 = positives.filter(Boolean).length >= 3;
  }

  // ── cvd1h: last 12 candles (slots 36–47) ─────────────────────────────────────
  let cvd1h: boolean | null = null;
  if (validCount >= 12) {
    let buy = 0, sell = 0;
    for (let i = CANDLES - 12; i < CANDLES; i++) { buy += agg[i]!.buy; sell += agg[i]!.sell; }
    if (buy + sell > 0) cvd1h = buy > sell;
  }

  // ── cvd4h: all 48 candles ────────────────────────────────────────────────────
  let cvd4h: boolean | null = null;
  if (validCount >= 24) {
    const totalBuy  = agg.reduce((s, c) => s + c.buy,  0);
    const totalSell = agg.reduce((s, c) => s + c.sell, 0);
    if (totalBuy + totalSell > 0) cvd4h = totalBuy > totalSell;
  }

  // ── MTF verdicts ─────────────────────────────────────────────────────────────
  const hardBlocked = cvd5m === false || cvd15m_3of4 === false;
  const scalpOnly   = !hardBlocked && (cvd1h === false || cvd4h === false);
  const isGolden    = cvd5m === true && cvd15m_3of4 === true && cvd1h === true && cvd4h === true;

  const result: SpotCvdResult = {
    cvd5m, cvd30m, cvd15m_3of4, cvd1h, cvd4h,
    hardBlocked, scalpOnly, isGolden, available: true,
  };

  logger.debug(
    { symbol, cvd5m, cvd30m, cvd15m_3of4, cvd1h, cvd4h, hardBlocked, scalpOnly, isGolden, validSlots: validCount },
    "Spot CVD MTF",
  );

  cache.set(cgSymbol, { result, ts: Date.now() });
  return result;
}

/**
 * Returns the total 24h spot trading volume (USD) for a BingX symbol,
 * aggregated from Binance + Bybit via CoinGlass Standard API.
 *
 * Sums taker_buy_volume_usd + taker_sell_volume_usd across 288 × 5m candles (= 24h).
 * Cache: 30 min.
 * Returns null if API is unavailable — callers should treat null as a hard block.
 */
export async function getCoinglassSpotVolume24h(bingxSymbol: string): Promise<number | null> {
  const apiKey = process.env.COINGLASS_API_KEY;
  if (!apiKey) return null;

  const cgSymbol = toCgSymbol(bingxSymbol);
  const cached = volCache.get(cgSymbol);
  if (cached && Date.now() - cached.ts < VOL_CACHE_TTL) return cached.vol;

  const CANDLES_24H = 288; // 288 × 5m = 24 hours
  const [r1, r2] = await Promise.all(
    EXCHANGES.map(ex => fetchExchange(cgSymbol, ex, apiKey, CANDLES_24H)),
  );

  if (!r1 && !r2) return null;

  let totalVol = 0;
  for (const candles of [r1, r2]) {
    if (!candles) continue;
    for (const c of candles) {
      totalVol += (parseFloat(c.taker_buy_volume_usd) || 0) + (parseFloat(c.taker_sell_volume_usd) || 0);
    }
  }

  if (totalVol === 0) return null;

  volCache.set(cgSymbol, { vol: totalVol, ts: Date.now() });
  logger.debug({ symbol: bingxSymbol, spotVol24h: totalVol.toFixed(0) }, "CoinGlass Spot Vol 24h");
  return totalVol;
}
