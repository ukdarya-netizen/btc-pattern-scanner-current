// ── Watcher constants ─────────────────────────────────────────────────────────

export const PARTIAL_TARGET          = 5;    // % частичная фиксация и перенос стопа в БУ
export const FIRST_TARGET            = 10;   // % первая цель: фиксируем часть, переставляем стоп в БУ
export const TRAILING_ACTIVATION_PCT = 15;   // % от входа: активируем трейлинг
export const TRAILING_FIXED_PCT      = 10;   // % отступ трейлинга от пика (фиксированный)
export const STOP_LOSS               = 10;   // % стоп лосс от входа (только для active до первой цели)
export const ACCUMULATION_H          = 24;   // часов до статуса ACCUMULATION
export const ACCUMULATION_REENTRY_H  = 12;   // часов в статусе accumulation до проверки re-entry
export const ACCUM_REMINDER_H        = 6;    // ч: промежуточное напоминание в статусе accumulation
export const ACCUM_SCOUT_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4ч кулдаун между pre-breakout алертами
export const ACCUM_OI_COOLDOWN_MS   = 2 * 60 * 60 * 1000;  // 2ч кулдаун между OI-алертами
export const MAX_WATCH_DAYS          = 4;    // максимум наблюдения
export const RE_ENTRY_VOL_MULT       = 3;    // объём для RE-ENTRY
export const FAST_CYCLE_MS           = 2 * 60 * 1000; // 2 мин — быстрый цикл для in_run

// Milestones для Moonshot уведомлений (%)
// +25, +50, +100, затем каждые +50 до бесконечности — генерируем первые 20
export const MILESTONES = [25, 50, ...Array.from({ length: 20 }, (_, i) => 100 + i * 50)];
