// ── Scanner pattern detection ─────────────────────────────────────────────────
// Pure functions: sentiment detection, alpha scoring, pattern evaluation.
// No side effects, no DB calls, no in-memory state.

import type { OrderBookAnalysis } from "./bingx.js";

// ── Sentiment types ───────────────────────────────────────────────────────────

export type SentimentKey =
  | "hidden_accumulation"
  | "aggressive_breakout"
  | "short_squeeze"
  | "bullish_accumulation"
  | "bear_trap"
  | "anomaly"
  | "sharp_impulse"
  | "impulse_breakout"
  | "volume_flash"
  | "moonshot_momentum"
  | "4h_momentum"
  | "early_ignition"
  | "whale_futures"
  | "mega_oi"
  | "volume_breakout";

export interface SentimentResult {
  key: SentimentKey;
  label: string;
  traderAction: string;
  /** Does this pattern require OI to be FALLING instead of rising? */
  oiFalling: boolean;
}

// ── Alpha signal result ───────────────────────────────────────────────────────

export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  /** Кросс-биржевое OI изменение от Coinalyze (30m) */
  coinalyzeOiChange: number | null;
  /** Coinalyze подтвердил OI-рост кросс-биржево */
  coinalyzeConfirmed: boolean;
  /** Новый листинг (< 24ч на фьючерсах BingX) */
  isNewListing: boolean;
  /** SHORT_SQUEEZE с Coinalyze OI < -20% — выдавливание шортов уже завершено */
  isExhaustedSqueeze: boolean;
  /** % рост цены от первого открытия фьючерса */
  pumpFromOpen: number | null;
  /** Количество 30м свечей (< 48 = новый) */
  candleCount: number;
  sentiment: string;
  sentimentKey: SentimentKey;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "5m", "30m", "1h" или комбинация */
  oiTriggerTf: string;
  /** Значение 5m OI изменения (для отображения в сигнале) */
  oiChange5m: number | null;
  /** Значение 1h OI изменения (для отображения в сигнале) */
  oiChange1h: number | null;
  /** Значение 4h OI изменения (для отображения в сигнале) */
  oiChange4h: number | null;
  /** Значение 24h OI изменения (для отображения в сигнале) */
  oiChange24h: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже был в отслеживаемых сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт BingX (decimal, напр. -0.0004 = -0.04% за 8ч) */
  fundingRate?: number | null;
  /** Mark price BingX перп */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Анализ стакана BingX: имбаланс бидов/асков, bid-стены */
  obImbalance?: OrderBookAnalysis | null;
  /** Bear Trap CVD дивергенция: цена падает, но покупатели перевешивают → подтверждённая ловушка */
  cvdDivergence?: boolean;
  /** MTF Spot CVD: старшие ТФ (1h/4h) не подтверждают — только скальп */
  isScalpOnly?: boolean;
  /** BingX spot market 24h volume (USDT) — ориентир для сравнения с futures */
  spotVol24h?: number | null;
  /** Market cap токена (CoinGecko, USD) — для расчёта % оборачиваемости */
  marketCapUsd?: number | null;
}

// ── Internal detection result ─────────────────────────────────────────────────

export interface DetectionResult {
  passes: boolean;
  oiChangePercent: number;
  openInterest: number;
  sentiment: SentimentResult;
}

// ── OI caps by timeframe ──────────────────────────────────────────────────────

/**
 * OI кепы зависят от таймфрейма который сработал.
 * 30m OI = 14% это поздно (памп уже идёт). 4h OI = 14% это тихое накопление за часы.
 *
 * triggerTf примеры: "30m", "5m+30m", "1h", "4h", "24h", "steady", "fast_track", "4h_momentum"
 */
export function getOiCaps(triggerTf: string): { hiddenMax: number; bullishMax: number } {
  // Используем \b (word boundary) чтобы "4h_momentum" не совпало с "4h".
  // "4h_momentum" — паттерн цены, не 4h OI → применяем короткий кеп как для 30m.
  if (/\b24h\b/.test(triggerTf)) return { hiddenMax: 30, bullishMax: 50 };
  if (/\b4h\b/.test(triggerTf))  return { hiddenMax: 25, bullishMax: 35 };
  if (/\b1h\b/.test(triggerTf))  return { hiddenMax: 15, bullishMax: 20 };
  // 30m, 5m, steady, fast_track, 4h_momentum, confirm — жёсткий кеп
  return { hiddenMax: 10, bullishMax: 15 };
}

// ── Sentiment detection ───────────────────────────────────────────────────────

/**
 * Determine sentiment pattern based on price, OI change direction/magnitude and volume.
 *
 * Pattern priority (first match wins):
 * 1. Short Squeeze      — OI falling, price sharply up, liq ≥ 2x
 * 2. Silent Whale Accum — OI >= 20%, price absolutely flat
 * 3. Hidden Accumulation A — OI + price moving
 * 4. Hidden Accumulation B — OI + price dip (smart money buying dip)
 * 5. Bear Trap          — OI rising sharply + price drops
 * 6. Aggressive Breakout — price > 3%, vol ≥ 2x, OI rising
 * 7. Bullish Accumulation — OI rising, price positive
 * 8. Anomaly            — fallback
 */
export function detectSentiment(
  priceChange: number,
  oiChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  triggerTf: string = "30m",
): SentimentResult {
  const { bullishMax } = getOiCaps(triggerTf);

  // 1. Short Squeeze: OI falling sharply (shorts force-closed) + price rising + vol spike.
  if (oiChange < -1.5 && priceChange > 2 && volumeMultiplier >= 2) {
    return {
      key: "short_squeeze",
      label: "Short Squeeze",
      traderAction: "SCALP LONG / Фиксация лонга",
      oiFalling: true,
    };
  }

  // 2.5 Silent Whale Accumulation: экстремальный OI + абсолютно плоская цена.
  if (oiChange >= 15 && Math.abs(priceChange) <= 1.5 && volumeMultiplier >= 0.8) {
    return {
      key: "hidden_accumulation",
      label: "Тихое накопление китов",
      traderAction: "LONG (вход в накопление до взрыва, стоп -7%)",
      oiFalling: false,
    };
  }

  // 3A. Подтверждённый разгон: OI + цена уже движется
  if (oiChange >= 8 && priceChange >= 2.0 && priceChange <= 5.0 && volumeMultiplier >= 1.3) {
    return {
      key: "hidden_accumulation",
      label: "Скрытое накопление",
      traderAction: "LONG (вход в начале движения)",
      oiFalling: false,
    };
  }

  // 3B. Дип-выкуп: OI растёт пока цена снижается — умные деньги откупают дип
  if (oiChange >= 8 && priceChange >= -3.0 && priceChange < -0.5 && volumeMultiplier >= 2.0) {
    return {
      key: "hidden_accumulation",
      label: "Скрытое накопление",
      traderAction: "LONG (выкуп дипа, ждать разворота)",
      oiFalling: false,
    };
  }

  // 4. Bear Trap: price drops sharply BUT OI rises strongly = shorts crowding in.
  if (oiChange >= 8 && priceChange < -1.5) {
    return {
      key: "bear_trap",
      label: "Медвежья ловушка",
      traderAction: "LONG при развороте (ждать подтверждение)",
      oiFalling: false,
    };
  }

  // 5. Aggressive Breakout: price > 3% + volume ≥ 2.0x + OI rising (new longs opening).
  if (volumeMultiplier >= 2.0 && priceChange > 3 && oiChange > 0) {
    return {
      key: "aggressive_breakout",
      label: "Агрессивный пробой",
      traderAction: "LONG по тренду (импульс запущен)",
      oiFalling: false,
    };
  }

  // 6. Bullish Accumulation — кеп зависит от ТФ (bullishMax)
  if (priceChange > 1 && oiChange > 3 && oiChange <= bullishMax) {
    return {
      key: "bullish_accumulation",
      label: "Бычье накопление",
      traderAction: "LONG",
      oiFalling: false,
    };
  }

  return {
    key: "anomaly",
    label: "Аномальная активность",
    traderAction: "Наблюдение",
    oiFalling: false,
  };
}

// ── Alpha score ───────────────────────────────────────────────────────────────

/**
 * Score breakdown (max 10):
 *   OI strength     0 – 3.5
 *   Volume          0 – 3.0
 *   Price action    0 – 0.5
 *   CMC trending    0 – 2.0  (flat +2 if any trending entry found)
 *   Liquidations    0 – 2.0  (capped at 10 total)
 *
 * Reference from spec (v3.0):
 *   OI + Vol only       ≈ 4–6
 *   OI + Vol + CMC      ≈ 6–8
 *   OI + Vol + CMC + Liq → 8–10 (SUPER ALPHA)
 */
export function calcAlphaScore(params: {
  oiChange: number;
  volumeMultiplier: number;
  priceChange: number;
  sentimentKey: SentimentKey;
  cmcAvailable: boolean;
  cmcRank: number | null;
  coinglassAvailable: boolean;
  liquidationsMultiple: number | null;
  fundingRate?: number | null;
}): number {
  const absOI = Math.abs(params.oiChange);
  const absPrice = Math.abs(params.priceChange);

  // OI component (0 – 3.5)
  const oiScore =
    absOI >= 20 ? 3.5 :
    absOI >= 15 ? 3.0 :
    absOI >= 10 ? 2.5 :
    absOI >= 7  ? 2.0 :
    absOI >= 5  ? 1.5 :
    absOI >= 3  ? 1.0 : 0.5;

  // Volume component (0 – 3.0)
  const volScore =
    params.volumeMultiplier >= 10 ? 3.0 :
    params.volumeMultiplier >= 7  ? 2.5 :
    params.volumeMultiplier >= 5  ? 2.0 :
    params.volumeMultiplier >= 4  ? 1.5 :
    params.volumeMultiplier >= 3  ? 1.0 : 0.5;

  // Price action (0 – 0.5)
  let priceScore = 0;
  if (params.sentimentKey === "hidden_accumulation") {
    priceScore = absPrice < 1.5 ? 0.5 : 0.25;
  } else {
    priceScore =
      absPrice >= 6 ? 0.5 :
      absPrice >= 4 ? 0.4 :
      absPrice >= 2 ? 0.3 : 0.1;
  }

  // CMC trending: flat +2 if found in any trending position (v3.0 spec)
  const cmcScore = (params.cmcAvailable && params.cmcRank !== null) ? 2.0 : 0;

  // Liquidations (0 – 3.0 для Squeeze/Bear Trap, 0 – 2.0 иначе)
  const isSqueezePattern = params.sentimentKey === "short_squeeze"
                        || params.sentimentKey === "bear_trap";
  let liqScore = 0;
  if (params.coinglassAvailable && params.liquidationsMultiple !== null) {
    const liqCap = isSqueezePattern ? 3.0 : 2.0;
    liqScore = Math.min(liqCap,
      params.liquidationsMultiple >= 5 ? liqCap :
      params.liquidationsMultiple >= 3 ? liqCap * 0.75 :
      params.liquidationsMultiple >= 2 ? liqCap * 0.5 : 0
    );
  }

  // Funding rate bonus/penalty (0 – +1.5 / 0 – -0.5)
  let fundingScore = 0;
  if (params.fundingRate != null) {
    const fr = params.fundingRate;
    const isSqueezeOrTrap = params.sentimentKey === "short_squeeze"
                         || params.sentimentKey === "bear_trap"
                         || params.sentimentKey === "hidden_accumulation";
    if (fr <= -0.0003) {
      fundingScore = isSqueezeOrTrap ? 1.5 : 1.0;
    } else if (fr <= -0.0001) {
      fundingScore = isSqueezeOrTrap ? 0.75 : 0.5;
    } else if (fr >= 0.001) {
      fundingScore = params.sentimentKey === "short_squeeze" ? 1.5 : -0.5;
    } else if (fr >= 0.0005) {
      fundingScore = params.sentimentKey === "short_squeeze" ? 0.75 : -0.5;
    } else if (fr >= 0.0003) {
      fundingScore = params.sentimentKey === "short_squeeze" ? 0.5 : -0.25;
    }
  }

  const raw = oiScore + volScore + priceScore + cmcScore + liqScore + fundingScore;
  return Math.min(10, Math.max(1, Math.round(raw)));
}

// ── Pattern evaluation (pipeline gate) ───────────────────────────────────────

export function evaluatePattern(
  oiChange: number,
  priceChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  settings: { volumeMultiplier: number; oiChangePercent: number },
  triggerTf: string = "30m",
): DetectionResult | null {
  // NOTE: At this point CoinGlass global OI ≥ 5% and Volume ≥ 2x are already
  // confirmed upstream (Steps 1 & 3 of v3.0 pipeline). Pattern evaluation
  // here only assigns the pattern type and applies pattern-specific thresholds.
  const { bullishMax } = getOiCaps(triggerTf);
  const sent = detectSentiment(priceChange, oiChange, volumeMultiplier, liquidationsMultiple, triggerTf);

  // Path A: Rising OI patterns (LONG сигналы)
  if (!sent.oiFalling) {
    if (sent.key === "hidden_accumulation") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

    if (sent.key === "aggressive_breakout") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

    // Bullish Standard: OI ≥ threshold + Vol ≥ threshold + price move + ТФ-зависимый кеп.
    if (oiChange >= settings.oiChangePercent && oiChange <= bullishMax && volumeMultiplier >= settings.volumeMultiplier && Math.abs(priceChange) >= 1) {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }
  }

  // Path B: Falling OI patterns
  if (sent.oiFalling) {
    if (sent.key === "short_squeeze") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }
  }

  // Path C: Bear Trap — OI растёт + цена падает = шорты набираются → потенциальный сквиз
  if (sent.key === "bear_trap") {
    return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
  }

  return null;
}
