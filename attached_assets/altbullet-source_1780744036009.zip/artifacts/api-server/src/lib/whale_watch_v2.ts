/**
 * Whale Watch 2.0 — Spot CVD Accumulation Tracker
 *
 * Логика:
 * 1. Каждые 5 минут (вызывается из scanner) проверяем все токены из prescan-пула.
 * 2. Если Spot CVD 5m > WHALE_CVD_THRESHOLD_PCT × 24h Vol → значимая закупка.
 *    Для BTC/ETH (>$100B mcap) порог снижается до 0.1% от 24h Vol.
 * 3. Токен добавляется в watchlist если:
 *    - Суммарный CVD за последние 24ч > ACCUM_MCAP_PCT × Market Cap
 *    - Цена при этом в диапазоне ±FLAT_PRICE_PCT% (нет уже запущенного пампа)
 * 4. Breakout сигнал (Telegram) если:
 *    - Накопление > BREAKOUT_ACCUM_PCT × McAP
 *    - Цена выросла > BREAKOUT_PRICE_PCT%
 *    - Объём свечи > AVG_15M_VOL_MULT × средний 15m объём
 * 5. Smart Cancel (watcher.ts вызывает checkWhaleSmartCancel):
 *    - CVD за последние 15m упал на > SMART_CANCEL_CVD_DROP_PCT от накопленного
 *    - Цена упала ниже avgBuyPrice − SMART_CANCEL_PRICE_DROP_PCT
 *
 * Market Cap: CoinGecko free API, кэш 24ч.
 * Fallback: если mcap недоступен — используем 24h Vol как прокси (порог от vol).
 */

import { db, whaleWatchlistTable, prescanTrackerTable } from "@workspace/db";
import { eq, sql, gte } from "drizzle-orm";
import { logger } from "./logger.js";
import { getSpotCvdMtf } from "./coinglass_spot_cvd.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";

// ── Параметры ─────────────────────────────────────────────────────────────────
/** Порог «китовой» 5m закупки: net buy CVD > X% от 24h Vol */
const WHALE_CVD_THRESHOLD_PCT = 0.005; // 0.5% от 24h Vol
/** Для mega-cap (mcap > $100B): снижаем порог */
const WHALE_CVD_MEGA_CAP_PCT  = 0.001; // 0.1% от 24h Vol
/** Порог mega-cap в USD */
const MEGA_CAP_USD = 100_000_000_000;
/** Накопление входит в watchlist: CVD > X% от mcap */
const ACCUM_MCAP_PCT = 0.01; // 1% от market cap
/** Flat price gate: цена не должна уйти дальше ±X% от точки входа */
const FLAT_PRICE_PCT = 2.0;
/** Breakout trigger: накоплено X% от mcap и цена двинулась */
const BREAKOUT_ACCUM_PCT = 0.01; // 1%
/** Breakout price: цена выросла как минимум на X% от прайса входа */
const BREAKOUT_PRICE_PCT  = 1.0;
/** Breakout volume: 15m vol > X × средний 15m vol */
const AVG_15M_VOL_MULT = 3.0;
/** Smart Cancel: CVD за 15m упал на X% от накопленного */
const SMART_CANCEL_CVD_DROP_PCT = 0.20; // 20%
/** Smart Cancel: цена упала ниже avgBuyPrice на X% */
const SMART_CANCEL_PRICE_DROP_PCT = 2.0;
/** Expire watchlist entry after X hours with no accumulation */
const EXPIRE_HOURS = 24;
/** Max entries in watchlist to avoid noise */
const MAX_WATCHLIST = 50;

// ── Market Cap Cache (per-symbol, 30 min) ─────────────────────────────────────
const mcapCache = new Map<string, { mcap: number; ts: number }>();
const MCAP_CACHE_TTL = 30 * 60 * 1000; // 30 минут

// ── CoinGlass batch cache ──────────────────────────────────────────────────────
// Источник: /api/futures/coins-markets (~79 futures-listed tokens)
let cgBatchCache: { data: Map<string, number>; ts: number } | null = null;
const CG_BATCH_TTL = 30 * 60 * 1000; // 30 минут

// ── CoinGecko batch cache ──────────────────────────────────────────────────────
// Fallback 1: top-1000 coins by MCap (pages 1–4 × 250).
// Free API, no key, 1h cache — 4 HTTP calls per hour max.
let cgeckoBatchCache: { data: Map<string, number>; ts: number } | null = null;
const CGECKO_BATCH_TTL = 60 * 60 * 1000; // 1 час

// ── CoinPaprika batch cache ────────────────────────────────────────────────────
// Fallback 2: top-2000 coins (much broader coverage of small/mid caps).
// Free API, no key, 25k calls/month limit — 1h cache is safe.
let cpaprikaBatchCache: { data: Map<string, number>; ts: number } | null = null;
const CPAPRIKA_BATCH_TTL = 60 * 60 * 1000; // 1 час

// ── BingX ticker → canonical symbol aliases ────────────────────────────────────
// BingX uses non-standard tickers for some tokens that differ from CoinGecko/CoinPaprika.
// Map: BingX_BASE → lookup_symbol used in external APIs.
const SYMBOL_ALIASES: Record<string, string> = {
  TONCOIN:    "TON",         // The Open Network
  "1000000MOG": "MOG",      // 1 million MOG contract → MOG MCap
  "1000PEPE": "PEPE",       // 1000 PEPE contract → PEPE MCap
  "1000SHIB": "SHIB",       // 1000 SHIB contract
  "1000FLOKI": "FLOKI",     // 1000 FLOKI contract
  "1000BONK": "BONK",       // 1000 BONK contract
  "1000XEC":  "XEC",
  "1000BTT":  "BTT",
  "1000LUNC": "LUNC",
  "1000NEIRO": "NEIRO",
  "100000AIDOGE": "AIDOGE",
  WBTC:       "BTC",        // Wrapped BTC → BTC MCap proxy
};

/**
 * CoinGecko fallback: top-1000 coins by MCap (free API, no key).
 * Fetches 4 pages × 250 = 1000 coins. Cache 1h.
 * Returns Map<UPPERCASE_SYMBOL → market_cap_usd>.
 * If a ticker has multiple coins, keeps the highest-MCap entry (page 1 wins).
 */
async function loadCoinGeckoMarketCaps(): Promise<Map<string, number>> {
  if (cgeckoBatchCache && Date.now() - cgeckoBatchCache.ts < CGECKO_BATCH_TTL) {
    return cgeckoBatchCache.data;
  }

  const map = new Map<string, number>();
  try {
    for (let page = 1; page <= 4; page++) {
      const res = await fetch(
        `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=${page}`,
        {
          headers: { Accept: "application/json" },
          signal: AbortSignal.timeout(10000),
        }
      );
      if (!res.ok) {
        logger.warn({ page, status: res.status }, "CoinGecko MCap: страница не загрузилась");
        reportApiFailure("coingecko", res.status);
        break;
      }
      const data = await res.json() as Array<{ symbol: string; market_cap: number | null }>;
      for (const coin of data) {
        if (!coin.symbol || !coin.market_cap || coin.market_cap <= 0) continue;
        const sym = coin.symbol.toUpperCase();
        if (!map.has(sym)) map.set(sym, coin.market_cap); // page 1 = highest MCap wins for dupe symbols
      }
    }
    cgeckoBatchCache = { data: map, ts: Date.now() };
    logger.info({ symbols: map.size }, "CoinGecko market caps loaded (fallback)");
    if (map.size > 0) reportApiSuccess("coingecko");
  } catch (err) {
    logger.warn({ err }, "CoinGecko MCap batch fetch failed");
    reportApiFailure("coingecko");
  }
  return map;
}

/**
 * CoinPaprika fallback 2: top-2000 coins ranked by MCap (free, no key).
 * Broader coverage than CoinGecko for small/mid caps.
 * Cache 1h — one HTTP call per hour.
 */
async function loadCoinPaprikaMarketCaps(): Promise<Map<string, number>> {
  if (cpaprikaBatchCache && Date.now() - cpaprikaBatchCache.ts < CPAPRIKA_BATCH_TTL) {
    return cpaprikaBatchCache.data;
  }

  const map = new Map<string, number>();
  try {
    const res = await fetch(
      "https://api.coinpaprika.com/v1/tickers?quotes=USD&limit=2000",
      {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(20000),
      }
    );
    if (!res.ok) {
      logger.warn({ status: res.status }, "CoinPaprika MCap: ответ не 200");
      reportApiFailure("coinpaprika", res.status);
      return cpaprikaBatchCache?.data ?? map;
    }
    const data = await res.json() as Array<{ symbol: string; rank: number; quotes?: { USD?: { market_cap?: number } } }>;
    // Sort by rank (lowest = biggest cap) so duplicates: highest-ranked entry wins
    const sorted = [...data].sort((a, b) => (a.rank || 9999) - (b.rank || 9999));
    for (const coin of sorted) {
      if (!coin.symbol) continue;
      const mcap = coin.quotes?.USD?.market_cap;
      if (!mcap || mcap <= 0) continue;
      const sym = coin.symbol.toUpperCase();
      if (!map.has(sym)) map.set(sym, mcap);
    }
    cpaprikaBatchCache = { data: map, ts: Date.now() };
    logger.info({ symbols: map.size }, "CoinPaprika market caps loaded (fallback 2)");
    reportApiSuccess("coinpaprika");
  } catch (err) {
    logger.warn({ err }, "CoinPaprika MCap batch fetch failed");
    reportApiFailure("coinpaprika");
    return cpaprikaBatchCache?.data ?? map;
  }
  return map;
}

/**
 * Загружает market cap для всех ~100 токенов одним запросом к CoinGlass.
 * Кешируется на 30 минут. Возвращает Map<base_symbol → market_cap_usd>.
 */
async function loadCoinGlassMarketCaps(): Promise<Map<string, number>> {
  if (cgBatchCache && Date.now() - cgBatchCache.ts < CG_BATCH_TTL) {
    return cgBatchCache.data;
  }

  const apiKey = process.env.COINGLASS_API_KEY;
  if (!apiKey) return new Map();

  try {
    const res = await fetch("https://open-api-v4.coinglass.com/api/futures/coins-markets", {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return cgBatchCache?.data ?? new Map();

    const json = await res.json() as { code: string; data?: Array<{ symbol: string; market_cap_usd: number }> };
    if (json.code !== "0" || !json.data) return cgBatchCache?.data ?? new Map();

    const map = new Map<string, number>();
    for (const item of json.data) {
      if (item.symbol && item.market_cap_usd > 0) {
        map.set(item.symbol.toUpperCase(), item.market_cap_usd);
      }
    }

    cgBatchCache = { data: map, ts: Date.now() };
    logger.info({ symbols: map.size }, "CoinGlass market caps loaded");
    return map;
  } catch {
    return cgBatchCache?.data ?? new Map();
  }
}

/**
 * Resolves a BingX base symbol to the canonical lookup symbol used in external MCap APIs.
 * Handles contracts like 1000PEPE → PEPE, TONCOIN → TON, etc.
 */
function resolveSymbol(base: string): string {
  return SYMBOL_ALIASES[base] ?? base;
}

/**
 * Ищет MCap по символу во всех трёх источниках (CoinGlass → CoinGecko → CoinPaprika).
 * Применяет алиасы (TONCOIN→TON, 1000PEPE→PEPE и т.д.) перед поиском.
 * Возвращает null если токен не найден ни в одном источнике.
 */
export async function fetchMarketCap(symbol: string): Promise<{ mcap: number; vol24h: number } | null> {
  const base = symbol.replace("-USDT", "").toUpperCase();
  const lookup = resolveSymbol(base);

  // Per-symbol cache keyed on original base (not alias, to avoid cross-contamination)
  const cached = mcapCache.get(base);
  if (cached && Date.now() - cached.ts < MCAP_CACHE_TTL) {
    return { mcap: cached.mcap, vol24h: 0 };
  }

  // Load all three sources in parallel (each has its own internal cache)
  const [cglass, cgecko, cpaprika] = await Promise.all([
    loadCoinGlassMarketCaps(),
    loadCoinGeckoMarketCaps(),
    loadCoinPaprikaMarketCaps(),
  ]);

  const mcap =
    cglass.get(lookup) ??      // 1. CoinGlass (~79 major futures tokens)
    cgecko.get(lookup) ??      // 2. CoinGecko top-1000
    cpaprika.get(lookup) ??    // 3. CoinPaprika top-2000
    null;

  if (mcap) {
    const src = cglass.has(lookup) ? "CoinGlass" : cgecko.has(lookup) ? "CoinGecko" : "CoinPaprika";
    if (src !== "CoinGlass") {
      logger.debug({ symbol: base, lookup, mcap, src }, "MCap via fallback source");
    }
  }

  if (!mcap) return null;

  mcapCache.set(base, { mcap, ts: Date.now() });
  return { mcap, vol24h: 0 };
}

/**
 * Батч market cap для списка символов.
 * Загружает все три источника параллельно (единый кеш), затем резолвит каждый символ.
 */
export async function batchFetchMarketCap(
  symbols: string[]
): Promise<Map<string, { mcap: number; vol24h: number } | null>> {
  const result = new Map<string, { mcap: number; vol24h: number } | null>();
  if (symbols.length === 0) return result;

  const [cglass, cgecko, cpaprika] = await Promise.all([
    loadCoinGlassMarketCaps(),
    loadCoinGeckoMarketCaps(),
    loadCoinPaprikaMarketCaps(),
  ]);

  for (const sym of symbols) {
    const base = sym.replace("-USDT", "").toUpperCase();
    const lookup = resolveSymbol(base);
    const mcap =
      cglass.get(lookup) ??
      cgecko.get(lookup) ??
      cpaprika.get(lookup) ??
      null;
    result.set(sym, mcap ? { mcap, vol24h: 0 } : null);
  }

  return result;
}

// ── 5m Net CVD из SpotCvdMtf ──────────────────────────────────────────────────
// getSpotCvdMtf возвращает cvd5m=boolean, нам нужно абсолютное значение в USD.
// Используем временное внутреннее хранилище — raw net buy от SpotCvd модуля.
// Для расчёта порога используем 24h vol из BingX ticker (уже есть в памяти).

export interface WhaleCvdTick {
  symbol:    string;
  netBuyUsd: number;  // net taker buy - sell за последнюю 5m свечу, USD
  price:     number;
  vol24hUsd: number;  // 24h торговый объём USD (BingX futures или spot proxy)
}

/** In-memory: ключ = symbol, значение = накопленный CVD за текущую сессию (reset every 24h) */
const accumulator = new Map<string, {
  totalNetBuyUsd: number;
  periods:        number;
  sumPriceVol:    number; // Σ(price × netBuy) для взвешенной средней
  sumVol:         number; // Σ(netBuy) для взвешенной средней
  firstPrice:     number;
  lastPrice:      number;
  lastUpdated:    number;
  vol24hUsd:      number;
}>();

/** Сбрасываем накопленные данные для символа */
function resetAccum(symbol: string): void {
  accumulator.delete(symbol);
}

/** Обновляет накопитель для символа. Вызывается при каждом 5m tick. */
export function feedWhaleTick(tick: WhaleCvdTick): void {
  const existing = accumulator.get(tick.symbol);
  const now = Date.now();

  if (!existing) {
    accumulator.set(tick.symbol, {
      totalNetBuyUsd: tick.netBuyUsd,
      periods:        1,
      sumPriceVol:    tick.price * tick.netBuyUsd,
      sumVol:         tick.netBuyUsd,
      firstPrice:     tick.price,
      lastPrice:      tick.price,
      lastUpdated:    now,
      vol24hUsd:      tick.vol24hUsd,
    });
  } else {
    // Сбрасываем если > 24ч без обновления
    if (now - existing.lastUpdated > EXPIRE_HOURS * 60 * 60 * 1000) {
      resetAccum(tick.symbol);
      feedWhaleTick(tick);
      return;
    }
    existing.totalNetBuyUsd += tick.netBuyUsd;
    existing.periods        += 1;
    existing.sumPriceVol    += tick.price * tick.netBuyUsd;
    existing.sumVol         += tick.netBuyUsd;
    existing.lastPrice       = tick.price;
    existing.lastUpdated     = now;
    existing.vol24hUsd       = tick.vol24hUsd;
  }
}

/** Расчёт взвешенной средней цены накопления */
function calcAvgBuyPrice(state: ReturnType<typeof accumulator.get>): number | null {
  if (!state || state.sumVol <= 0) return null;
  return state.sumPriceVol / state.sumVol;
}

// ── Main scan function ────────────────────────────────────────────────────────

export interface WhaleScanInput {
  symbol:   string;
  price:    number;
  vol24hUsd: number;
  /** Net taker buy (USD) за последнюю 5m свечу. Можно передать 0 если нет точных данных. */
  netBuyUsd5m: number;
  /** Средний 15m объём (сумма 3 последних 5m свечей), USD */
  avgVol15mUsd: number;
}

export interface WhaleScanResult {
  symbol:      string;
  isNewEntry:  boolean; // добавлен в watchlist впервые
  isBreakout:  boolean; // условия пробоя выполнены
  accumulated: number;  // accumulated CVD USD
  mcapUsd:     number | null;
  accumPct:    number | null; // accumulated / mcap * 100
  avgBuyPrice: number | null;
}

/**
 * Вызывается из scanner.ts для каждого кандидата.
 * Обновляет watchlist в памяти и в БД.
 * Возвращает breakout флаг если нужно послать сигнал.
 */
export async function runWhaleScan(input: WhaleScanInput): Promise<WhaleScanResult> {
  const { symbol, price, vol24hUsd, netBuyUsd5m, avgVol15mUsd } = input;

  const result: WhaleScanResult = {
    symbol, isNewEntry: false, isBreakout: false,
    accumulated: 0, mcapUsd: null, accumPct: null, avgBuyPrice: null,
  };

  // Получаем market cap
  const marketData = await fetchMarketCap(symbol);
  const mcap = marketData?.mcap ?? null;
  result.mcapUsd = mcap;

  // Порог "китовой" закупки
  const isMegaCap = mcap != null && mcap > MEGA_CAP_USD;
  const thresholdPct = isMegaCap ? WHALE_CVD_MEGA_CAP_PCT : WHALE_CVD_THRESHOLD_PCT;
  const threshold = vol24hUsd * thresholdPct;

  // Обновляем in-memory накопитель если tick значимый
  const isSignificantTick = netBuyUsd5m > threshold;
  if (isSignificantTick) {
    feedWhaleTick({ symbol, netBuyUsd: netBuyUsd5m, price, vol24hUsd });
  } else {
    // Не значимый тик — не накапливаем, но обновляем lastPrice
    const existing = accumulator.get(symbol);
    if (existing) existing.lastPrice = price;
  }

  const state = accumulator.get(symbol);
  if (!state || state.totalNetBuyUsd <= 0) return result;

  const accumulated = state.totalNetBuyUsd;
  const avgBuyPrice = calcAvgBuyPrice(state);
  result.accumulated  = accumulated;
  result.avgBuyPrice  = avgBuyPrice;

  // Порог входа в watchlist
  const accumThreshold = mcap != null
    ? mcap * ACCUM_MCAP_PCT
    : vol24hUsd * 0.05; // fallback: 5% от 24h vol

  result.accumPct = mcap != null ? (accumulated / mcap) * 100 : null;

  // Flat price gate
  const priceChangePct = state.firstPrice > 0
    ? ((price - state.firstPrice) / state.firstPrice) * 100
    : 0;
  const isFlat = Math.abs(priceChangePct) <= FLAT_PRICE_PCT;

  if (accumulated < accumThreshold) return result; // ещё мало накоплено
  if (!isFlat) return result; // цена уже ушла — не накопление

  // Проверяем есть ли уже в watchlist
  const existing = await db.select()
    .from(whaleWatchlistTable)
    .where(eq(whaleWatchlistTable.symbol, symbol))
    .limit(1);

  if (existing.length === 0) {
    // Проверяем лимит watchlist
    const count = await db.execute<{ cnt: string }>(
      sql`SELECT count(*) as cnt FROM whale_watchlist WHERE status IN ('watching','accumulating')`
    );
    const cnt = Number(count.rows[0]?.cnt ?? 0);
    if (cnt >= MAX_WATCHLIST) {
      logger.debug({ symbol, cnt }, "Whale Watch: watchlist full, skipping");
      return result;
    }

    await db.insert(whaleWatchlistTable).values({
      symbol,
      accumulatedCvdUsd: accumulated,
      accumPeriods:      state.periods,
      avgBuyPrice:       avgBuyPrice ?? undefined,
      marketCapUsd:      mcap ?? undefined,
      vol24hUsd:         vol24hUsd,
      priceAtEntry:      state.firstPrice,
      lastPrice:         price,
      status:            "accumulating",
    });
    result.isNewEntry = true;
    logger.info(
      { symbol, accumulated: accumulated.toFixed(0), mcap: mcap?.toFixed(0), accumPct: result.accumPct?.toFixed(2) },
      "🐋 Whale Watch: новый символ добавлен в watchlist"
    );
  } else {
    // Обновляем существующую запись
    await db.update(whaleWatchlistTable).set({
      accumulatedCvdUsd: accumulated,
      accumPeriods:      state.periods,
      avgBuyPrice:       avgBuyPrice ?? undefined,
      lastPrice:         price,
      marketCapUsd:      mcap ?? undefined,
      vol24hUsd:         vol24hUsd,
      status:            "accumulating",
      updatedAt:         new Date(),
    }).where(eq(whaleWatchlistTable.symbol, symbol));
  }

  // ── Breakout check ────────────────────────────────────────────────────────
  const row = existing[0];
  if (row?.breakoutFiredAt) return result; // уже стрельнул

  const breakoutAccumThreshold = mcap != null
    ? mcap * BREAKOUT_ACCUM_PCT
    : vol24hUsd * 0.05;

  const priceFromEntry = row?.priceAtEntry
    ? ((price - row.priceAtEntry) / row.priceAtEntry) * 100
    : priceChangePct;

  const isVolBreakout = avgVol15mUsd > 0 && netBuyUsd5m > avgVol15mUsd * AVG_15M_VOL_MULT;
  const isPriceBreakout = priceFromEntry >= BREAKOUT_PRICE_PCT;
  const isAccumBreakout = accumulated >= breakoutAccumThreshold;

  if (isAccumBreakout && isPriceBreakout && isVolBreakout) {
    await db.update(whaleWatchlistTable).set({
      breakoutFiredAt: new Date(),
      status: "breakout",
      updatedAt: new Date(),
    }).where(eq(whaleWatchlistTable.symbol, symbol));
    result.isBreakout = true;
    logger.info(
      { symbol, accumulated: accumulated.toFixed(0), priceFromEntry: priceFromEntry.toFixed(2) },
      "🐋 Whale Watch: BREAKOUT — накопление привело к движению цены"
    );
  }

  return result;
}

// ── Smart Cancel check ────────────────────────────────────────────────────────

export interface WhaleSmartCancelResult {
  shouldCancel: boolean;
  reason:       string;
}

/**
 * Вызывается из watcher.ts (FastCycle) для активных трекед-сигналов.
 * Проверяет разгрузку кита: CVD за 15m упал или цена ниже avg buy.
 */
export async function checkWhaleSmartCancel(
  symbol:       string,
  currentPrice: number,
  /** Текущий 15m net CVD (USD). Вычисляется из SpotCvd данных. */
  current15mNetCvdUsd: number,
): Promise<WhaleSmartCancelResult> {
  const row = await db.select()
    .from(whaleWatchlistTable)
    .where(eq(whaleWatchlistTable.symbol, symbol))
    .limit(1);

  const noCancel = { shouldCancel: false, reason: "" };
  if (!row[0]?.accumulatedCvdUsd || row[0].accumulatedCvdUsd <= 0) return noCancel;

  const { accumulatedCvdUsd, avgBuyPrice } = row[0];

  // Условие 1: Кит разгружается — CVD за 15m упал > 20% от накопленного
  const cvdDrop = -current15mNetCvdUsd; // если отрицательный CVD = продажи
  if (cvdDrop > accumulatedCvdUsd * SMART_CANCEL_CVD_DROP_PCT) {
    return {
      shouldCancel: true,
      reason: `Whale разгрузка: спот CVD 15m упал на ${(cvdDrop / accumulatedCvdUsd * 100).toFixed(0)}% от накопленного`,
    };
  }

  // Условие 2: Цена упала ниже средней цены закупа кита на 2%
  if (avgBuyPrice && currentPrice < avgBuyPrice * (1 - SMART_CANCEL_PRICE_DROP_PCT / 100)) {
    const dropPct = ((avgBuyPrice - currentPrice) / avgBuyPrice * 100).toFixed(1);
    return {
      shouldCancel: true,
      reason: `Цена ниже avg whale buy (${avgBuyPrice.toPrecision(4)}) на ${dropPct}%`,
    };
  }

  return noCancel;
}

// ── Expire stale watchlist entries ───────────────────────────────────────────

export async function expireStaleWatchlist(): Promise<void> {
  const cutoff = new Date(Date.now() - EXPIRE_HOURS * 60 * 60 * 1000);
  await db.update(whaleWatchlistTable).set({ status: "expired", updatedAt: new Date() })
    .where(sql`status IN ('watching','accumulating') AND updated_at < ${cutoff}`);
}

// ── Weekly Whale Report ───────────────────────────────────────────────────────

export interface WhaleWatchEntry {
  symbol:          string;
  accumulatedCvdUsd: number;
  accumPeriods:    number;
  avgBuyPrice:     number | null;
  marketCapUsd:    number | null;
  accumPct:        number | null;
  priceAtEntry:    number | null;
  lastPrice:       number | null;
  firstSeenAt:     Date;
  status:          string;
}

export async function getWhaleWatchlist(): Promise<WhaleWatchEntry[]> {
  const rows = await db.select().from(whaleWatchlistTable)
    .where(sql`status IN ('watching','accumulating','breakout')`)
    .orderBy(sql`accumulated_cvd_usd DESC`);

  return rows.map(r => ({
    symbol:            r.symbol,
    accumulatedCvdUsd: r.accumulatedCvdUsd,
    accumPeriods:      r.accumPeriods,
    avgBuyPrice:       r.avgBuyPrice ?? null,
    marketCapUsd:      r.marketCapUsd ?? null,
    accumPct:          r.marketCapUsd && r.marketCapUsd > 0
                         ? (r.accumulatedCvdUsd / r.marketCapUsd) * 100
                         : null,
    priceAtEntry:      r.priceAtEntry ?? null,
    lastPrice:         r.lastPrice ?? null,
    firstSeenAt:       r.firstSeenAt,
    status:            r.status,
  }));
}
