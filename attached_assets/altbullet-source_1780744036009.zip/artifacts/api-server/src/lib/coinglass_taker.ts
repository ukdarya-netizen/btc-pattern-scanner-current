/**
 * CoinGlass — кросс-биржевой Taker Buy/Sell Flow.
 *
 * Запрашивает объём агрессивных покупок и продаж за последние 4 свечи по 15m
 * по двум крупным биржам (Binance + Bybit) и агрегирует их.
 *
 * Используется как РАННИЙ ПРЕ-ФИЛЬТР (до детекции паттерна):
 * оба цикла должны показывать нетто-покупки (покупки > продажи два периода подряд).
 * Если продавцы доминируют — рост OI скорее всего от шортов, не от покупателей.
 *
 * Endpoint: GET /api/futures/taker-buy-sell-volume/history
 *   ?symbol=BTCUSDT&exchange=Binance&interval=15m&limit=4
 * Header: CG-API-KEY: <key>
 *
 * План Standard: доступны интервалы 15m, 30m, 1h.
 * Используем 15m — 4 свечи = 1 час истории с детализацией по четвертям.
 * cvdRising2 проверяет что последние 2 свечи (30 мин) показывают устойчивый поток.
 * Кэш: 3 мин (15m свечи обновляются часто, нужна свежесть).
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";

export interface TakerCycle {
  delta:      number;   // buy - sell (USD)
  netBuyPct:  number;   // (buy - sell) / (buy + sell) * 100
}

export interface TakerFlowResult {
  buyUsd:      number;
  sellUsd:     number;
  netBuyPct:   number;        // (buy - sell) / (buy + sell) * 100 — последний цикл
  dominance:   "buy" | "sell" | "neutral";
  available:   boolean;
  exchanges:   string[];      // какие биржи ответили
  cycles:      TakerCycle[];  // [более старый, более новый] — до 2 элементов
  cvdRising2:  boolean;       // оба цикла положительные И второй >= 50% первого
}

const EXCHANGES = ["Binance", "Bybit"] as const;
const CACHE_TTL = 3 * 60 * 1000; // 3 мин — 15m свечи обновляются часто

const cache = new Map<string, { result: TakerFlowResult; ts: number }>();

/** Конвертирует BingX символ в CoinGlass формат: "BTC-USDT" → "BTCUSDT" */
function toCgSymbol(bingxSymbol: string): string {
  return bingxSymbol.replace("-", "");
}

interface CgTakerCandle {
  time:                  number;
  taker_buy_volume_usd:  string;
  taker_sell_volume_usd: string;
}

async function fetchOneExchange(
  cgSymbol: string,
  exchange: string,
  apiKey:   string,
): Promise<CgTakerCandle[] | null> {
  const url = new URL("https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history");
  url.searchParams.set("symbol",   cgSymbol);
  url.searchParams.set("exchange", exchange);
  url.searchParams.set("interval", "15m");
  url.searchParams.set("limit",    "4");   // 4 свечи по 15m = 1 час с детализацией

  try {
    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });

    if (!res.ok) {
      logger.debug({ cgSymbol, exchange, status: res.status }, "CoinGlass taker: request failed");
      reportApiFailure("coinglass", res.status);
      return null;
    }

    const data = await res.json() as { code: string; data?: CgTakerCandle[] };
    if (data.code !== "0" || !data.data?.length) return null;

    reportApiSuccess("coinglass");
    return data.data;
  } catch {
    return null;
  }
}

/**
 * Возвращает агрегированный Taker Buy/Sell Flow за последние 2 часа
 * по Binance + Bybit (2 свечи по 1h). Кэшируется 5 мин.
 *
 * cvdRising2 = true если оба часовых периода показывают нетто-покупки
 * И второй (более свежий) не слабее 50% от первого — устойчивый поток, не разовый всплеск.
 */
export async function getCoinglassTakerFlow(symbol: string): Promise<TakerFlowResult> {
  const apiKey = process.env.COINGLASS_API_KEY;

  const noData: TakerFlowResult = {
    buyUsd:     0,
    sellUsd:    0,
    netBuyPct:  0,
    dominance:  "neutral",
    available:  false,
    exchanges:  [],
    cycles:     [],
    cvdRising2: false,
  };

  if (!apiKey) return noData;

  const cgSymbol = toCgSymbol(symbol);
  const cached   = cache.get(cgSymbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  const responses = await Promise.all(
    EXCHANGES.map(ex => fetchOneExchange(cgSymbol, ex, apiKey)),
  );

  // Агрегируем все 4 свечи по 15m (индекс 0 = старейшая, 3 = свежайшая)
  // CoinGlass возвращает свечи от старых к новым
  const candleCount = 4;
  const aggregated: Array<{ buy: number; sell: number }> = Array.from(
    { length: candleCount },
    () => ({ buy: 0, sell: 0 }),
  );
  const responded: string[] = [];

  for (let ei = 0; ei < EXCHANGES.length; ei++) {
    const candles = responses[ei];
    if (!candles || candles.length === 0) continue;
    responded.push(EXCHANGES[ei]);
    // Берём последние 4 свечи (или меньше если API вернул меньше)
    const start = Math.max(0, candles.length - candleCount);
    for (let ci = start; ci < candles.length; ci++) {
      const slot = ci - start;
      const c = candles[ci]!;
      aggregated[slot]!.buy  += parseFloat(c.taker_buy_volume_usd)  || 0;
      aggregated[slot]!.sell += parseFloat(c.taker_sell_volume_usd) || 0;
    }
  }

  if (responded.length === 0) {
    cache.set(cgSymbol, { result: noData, ts: Date.now() });
    return noData;
  }

  // Строим cycles (только те слоты где есть данные)
  const cycles: TakerCycle[] = aggregated
    .filter(a => a.buy + a.sell > 0)
    .map(a => {
      const total   = a.buy + a.sell;
      const netPct  = total > 0 ? ((a.buy - a.sell) / total) * 100 : 0;
      return { delta: a.buy - a.sell, netBuyPct: netPct };
    });

  // Итоговые цифры берём из последней (самой свежей) свечи
  const last    = aggregated[aggregated.length - 1]!;
  const total   = last.buy + last.sell;
  const netBuyPct = total > 0 ? ((last.buy - last.sell) / total) * 100 : 0;

  const dominance: TakerFlowResult["dominance"] =
    netBuyPct >  2 ? "buy"  :
    netBuyPct < -2 ? "sell" : "neutral";

  // CVD 2-цикла: оба положительные И новый >= 50% от старого (поток устойчив, не ослаб)
  let cvdRising2 = false;
  if (cycles.length >= 2) {
    const older = cycles[cycles.length - 2]!;
    const newer = cycles[cycles.length - 1]!;
    cvdRising2 = older.delta > 0
              && newer.delta > 0
              && newer.delta >= older.delta * 0.5;
  } else if (cycles.length === 1) {
    // Только один цикл — мягкий режим: достаточно что он положительный
    cvdRising2 = cycles[0]!.delta > 0;
  }

  const result: TakerFlowResult = {
    buyUsd:    last.buy,
    sellUsd:   last.sell,
    netBuyPct,
    dominance,
    available: true,
    exchanges: responded,
    cycles,
    cvdRising2,
  };

  logger.debug(
    {
      symbol,
      netBuyPct: netBuyPct.toFixed(1) + "%",
      dominance,
      cvdRising2,
      cycles: cycles.map(c => `${c.netBuyPct.toFixed(1)}%`).join(" → "),
      exchanges: responded,
    },
    "CoinGlass taker flow (15m × 4 candles)",
  );

  cache.set(cgSymbol, { result, ts: Date.now() });
  return result;
}
