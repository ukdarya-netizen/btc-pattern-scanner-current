import { db, trackedSignalsTable } from "@workspace/db";
import type { TrackedSignal } from "@workspace/db";
import { inArray } from "drizzle-orm";
import { getFutureTickers } from "./bingx.js";
import { logger } from "./logger.js";

// ── Format helpers ─────────────────────────────────────────────────────────────

export function fmtP(p: number): string {
  if (p >= 1) return `$${p.toFixed(3)}`;
  if (p >= 0.01) return `$${p.toFixed(4)}`;
  if (p >= 0.001) return `$${p.toFixed(5)}`;
  return `$${p.toFixed(6)}`;
}

export function fmtPct(n: number): string {
  return `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`;
}

function ageLabel(detectedAt: Date): string {
  const h = (Date.now() - detectedAt.getTime()) / 3_600_000;
  if (h < 24) return `${h.toFixed(0)}ч`;
  return `${(h / 24).toFixed(1)}д`;
}

function symBase(symbol: string): string {
  return symbol.replace("-USDT", "");
}

function symTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

function patTag(s: TrackedSignal): string {
  return s.sentimentKey ? ` [${s.sentimentKey}]` : "";
}

function pnlOf(s: TrackedSignal, curPrice: number | undefined): number | null {
  if (!curPrice || !s.entryPrice || s.entryPrice === 0) return null;
  const diff = curPrice - s.entryPrice;
  return (s.isShort ? -diff : diff) / s.entryPrice * 100;
}

function peakPnlOf(s: TrackedSignal): number | null {
  if (!s.peakPrice || !s.entryPrice || s.entryPrice === 0) return null;
  return ((s.peakPrice - s.entryPrice) / s.entryPrice) * 100;
}

// ── Единственный форматтер открытых позиций ───────────────────────────────────
// Чистая функция — принимает готовые данные, не делает запросов к DB/API.
// Используется в: buildPositionsStatusText, sendDailyReport, /status кнопка.
export function formatOpenPositionLines(
  allOpen: TrackedSignal[],
  priceMap: Map<string, number>,
): string[] {
  const lines: string[] = [];

  const inRun    = allOpen.filter(s => s.status === "in_run");
  const watching = allOpen.filter(s =>
    s.status === "active" || s.status === "accumulation" || s.status === "re_entry"
  );

  if (inRun.length > 0) {
    lines.push(`🚀 <b>В полёте (Moonshot) — ${inRun.length}:</b>`);
    for (const s of inRun) {
      const curPrice = priceMap.get(s.symbol);
      const pnl      = pnlOf(s, curPrice);
      const peak     = peakPnlOf(s);
      const priceStr = curPrice && s.entryPrice
        ? ` | ${fmtP(s.entryPrice)} → ${fmtP(curPrice)} (${fmtPct(pnl ?? 0)})`
        : "";
      const peakStr  = peak != null ? ` | Пик: +${peak.toFixed(1)}%` : "";
      const stopStr  = s.trailingStopLevel
        ? ` | Trailing: ${fmtP(s.trailingStopLevel)}`
        : "";
      lines.push(
        `  • <b>${symBase(s.symbol)}</b>${patTag(s)} ${symTag(s.symbol)}${priceStr}${peakStr}${stopStr} | ${ageLabel(s.detectedAt)}`
      );
    }
    lines.push(``);
  }

  if (watching.length > 0) {
    lines.push(`👁 <b>В наблюдении — ${watching.length}:</b>`);
    for (const s of watching) {
      const curPrice = priceMap.get(s.symbol);
      const pnl      = pnlOf(s, curPrice);
      const priceStr = curPrice && s.entryPrice
        ? ` | ${fmtP(s.entryPrice)} → ${fmtP(curPrice)} (${fmtPct(pnl ?? 0)})`
        : "";
      lines.push(
        `  • <b>${symBase(s.symbol)}</b>${patTag(s)} ${symTag(s.symbol)}${priceStr} | ${ageLabel(s.detectedAt)}`
      );
    }
    lines.push(``);
  }

  return lines;
}

// ── Полный статус-текст — рестарт-уведомление, 4ч авто-апдейт, кнопка /status ─
export async function buildPositionsStatusText(): Promise<string> {
  const dbHost = process.env.DATABASE_URL?.match(/@([^/]+)\//)?.[1] ?? "unknown";
  let allOpen = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "re_entry"]));

  logger.info({
    count: allOpen.length,
    statuses: allOpen.map(s => ({ symbol: s.symbol, status: s.status })),
    dbHost,
  }, "buildPositionsStatusText: DEBUG query result");

  // Если получили 0 позиций — перепроверяем через 30с.
  // Причина: под нагрузкой (первый скан 551 токена) pg-pool может вернуть пустой
  // result SET без exception вместо connection timeout. Retry отсеивает ложные нули.
  if (allOpen.length === 0) {
    await new Promise(r => setTimeout(r, 30_000));
    allOpen = await db.select()
      .from(trackedSignalsTable)
      .where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "re_entry"]));
    logger.info({
      count: allOpen.length,
      statuses: allOpen.map(s => ({ symbol: s.symbol, status: s.status })),
      dbHost,
    }, "buildPositionsStatusText: DEBUG retry query result");
  }

  if (allOpen.length === 0) {
    return [
      `📊 <b>Открытых позиций нет</b>`,
      ``,
      `Сканер ищет сигналы в режиме реального времени.`,
      `Сигнал придёт когда условия выполнятся.`,
    ].join("\n");
  }

  const priceMap = new Map<string, number>();
  try {
    const tickers = await getFutureTickers() as { symbol: string; lastPrice: string }[];
    for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
  } catch { /* non-critical — покажем без цен */ }

  const moscowTime = new Date().toLocaleString("ru-RU", {
    timeZone: "Europe/Moscow",
    day: "2-digit", month: "long", hour: "2-digit", minute: "2-digit",
  });

  return [
    `📊 <b>Открытые позиции</b> — <i>${moscowTime} МСК</i>`,
    ``,
    ...formatOpenPositionLines(allOpen, priceMap),
    `📋 Всего открытых: <b>${allOpen.length}</b> | Авто-апдейт каждые 4ч`,
  ].join("\n");
}
