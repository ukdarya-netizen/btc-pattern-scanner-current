import { db, settingsTable, subscribersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { logger } from "./logger.js";
import { getOrderBookAnalysis } from "./bingx.js";
import { sendMessage } from "./telegram.js";

async function getOrderBookTargets(): Promise<(number | string)[]> {
  const targets: (number | string)[] = [];
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);
    if (settings?.channelId) targets.push(settings.channelId);
    const subs = await db.select({ chatId: subscribersTable.chatId })
      .from(subscribersTable)
      .where(eq(subscribersTable.active, true));
    for (const s of subs) targets.push(s.chatId);
  } catch { /* ignore */ }
  return targets;
}

async function scanWatchlistOrderbooks(): Promise<void> {
  logger.info("OrderBook scanner cycle start");
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);
    const watchlist = settings?.watchlist ?? "";
    if (!watchlist.trim()) {
      logger.info("OrderBook scanner: watchlist empty, skipping");
      return;
    }

    const symbols = watchlist.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);
    const targets = await getOrderBookTargets();

    for (const symbol of symbols) {
      try {
        const ob = await getOrderBookAnalysis(symbol, 50);
        if (!ob) continue;

        if (ob.bias === "strong_bull" && ob.largestBidWallUsd > 50_000) {
          const msg = [
            `🐋 <b>Крупная стена в стакане!</b>`,
            `Символ: <b>${symbol}</b>`,
            `Стена: <b>$${Math.round(ob.largestBidWallUsd).toLocaleString("ru")}</b> @ ${ob.largestBidWallPrice}`,
            `Перекос: ${ob.bidAskRatio.toFixed(2)} (Bid/Ask)`,
            `#${symbol.replace("-USDT", "").toLowerCase()} #orderbook_wall`,
          ].join("\n");
          for (const t of targets) {
            await sendMessage(t, msg).catch(() => {});
          }
          logger.info({ symbol, wallUsd: ob.largestBidWallUsd }, "OrderBook: large bid wall detected");
        }
      } catch (err) {
        logger.error({ symbol, err }, "OrderBook scanner: error for symbol");
      }
      await new Promise(r => setTimeout(r, 1000));
    }
  } catch (err) {
    logger.error({ err }, "OrderBook scanner cycle error");
  }
}

export async function startOrderBookScanner(): Promise<void> {
  logger.info("Starting Order Book Scanner (watchlist, 5m)");
  setInterval(() => {
    scanWatchlistOrderbooks().catch(err =>
      logger.error({ err }, "OrderBook scanner interval error")
    );
  }, 5 * 60_000);
  await scanWatchlistOrderbooks();
}
