import crypto from "crypto";

const BINGX_BASE_URL = "https://open-api.bingx.com";

function sign(params: Record<string, string | number>, secret: string): string {
  const queryString = Object.entries(params)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("&");
  return crypto.createHmac("sha256", secret).update(queryString).digest("hex");
}

function buildSignedParams(params: Record<string, string | number>, secret: string): string {
  const timestamp = Date.now();
  const allParams = { ...params, timestamp };
  const signature = sign(allParams, secret);
  const queryString = Object.entries(allParams)
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
    .join("&");
  return `${queryString}&signature=${signature}`;
}

async function bingxGet(path: string, params: Record<string, string | number> = {}, signed = false): Promise<unknown> {
  const apiKey = process.env.BINGX_API_KEY;
  const apiSecret = process.env.BINGX_API_SECRET;

  let qs: string;
  const headers: Record<string, string> = {
    "X-SOURCE-KEY": "AlphaScanner",
  };

  if (signed) {
    if (!apiKey || !apiSecret) throw new Error("BINGX_API_KEY and BINGX_API_SECRET are required");
    headers["X-BX-APIKEY"] = apiKey;
    qs = buildSignedParams(params, apiSecret);
  } else {
    qs = Object.entries(params)
      .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
      .join("&");
  }

  const url = `${BINGX_BASE_URL}${path}${qs ? "?" + qs : ""}`;
  const res = await fetch(url, { headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`BingX API error ${res.status}: ${text}`);
  }
  return res.json();
}

export interface BingXTicker {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  volume: string;
  quoteVolume: string;
  // Available on some BingX endpoints
  bidPrice?: string;
  askPrice?: string;
  openInterestSize?: string; // OI in base asset (if returned by ticker)
}

export interface BingXKline {
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  openTime: number;
  closeTime: number;
}

export interface BingXOpenInterest {
  symbol: string;
  openInterest: string;
  time: number;
}

export interface BingXFundingRate {
  symbol: string;
  lastFundingRate: string;
  nextFundingTime: number;
  markPrice: string;
  indexPrice?: string;
}

export async function getFutureTickers(): Promise<BingXTicker[]> {
  const data = await bingxGet("/openApi/swap/v2/quote/ticker") as { data: BingXTicker[] };
  return data.data ?? [];
}

export async function getFutureTicker(symbol: string): Promise<BingXTicker | null> {
  try {
    const data = await bingxGet("/openApi/swap/v2/quote/ticker", { symbol }) as { data: BingXTicker | BingXTicker[] };
    const result = data.data;
    if (!result) return null;
    return Array.isArray(result) ? (result[0] ?? null) : result;
  } catch {
    return null;
  }
}

export async function getKlines(symbol: string, interval = "5m", limit = 288): Promise<BingXKline[]> {
  const data = await bingxGet("/openApi/swap/v3/quote/klines", { symbol, interval, limit }) as { data: BingXKline[] };
  return data.data ?? [];
}

export async function getOpenInterest(symbol: string): Promise<BingXOpenInterest | null> {
  try {
    const data = await bingxGet("/openApi/swap/v2/quote/openInterest", { symbol }) as { data: BingXOpenInterest };
    return data.data ?? null;
  } catch {
    return null;
  }
}

export async function getFundingRate(symbol: string): Promise<BingXFundingRate | null> {
  try {
    const data = await bingxGet("/openApi/swap/v2/quote/premiumIndex", { symbol }) as { data: BingXFundingRate };
    return data.data ?? null;
  } catch {
    return null;
  }
}

export async function testConnection(): Promise<boolean> {
  try {
    await bingxGet("/openApi/swap/v2/quote/ticker");
    return true;
  } catch {
    return false;
  }
}

// ── Order Book Analysis ───────────────────────────────────────────────────────

export interface OrderBookLevel {
  price: number;
  qty:   number;
  usd:   number; // price × qty
}

export interface OrderBookAnalysis {
  /** Суммарный объём бидов (USD) в топ-N уровнях */
  bidVolumeUsd: number;
  /** Суммарный объём асков (USD) в топ-N уровнях */
  askVolumeUsd: number;
  /** bidVolumeUsd / askVolumeUsd */
  bidAskRatio: number;
  /** Самая крупная стена на биде (USD) */
  largestBidWallUsd: number;
  /** Цена самой крупной bid-стены */
  largestBidWallPrice: number;
  /** Самая крупная bid-стена как % от суммарных бидов */
  largestBidWallPct: number;
  /** Количество уровней с bid > 3× среднего — "кластер стен" */
  bidWallCount: number;
  /** Степень давления: "strong_bull" > 3:1 | "bull" > 1.8:1 | "neutral" | "bear" < 0.6:1 */
  bias: "strong_bull" | "bull" | "neutral" | "bear";
  /** +0..+2 бонус к alpha score */
  scoreBonus: number;
}

/**
 * Fetches order book depth from BingX and computes imbalance metrics.
 * limit=20: достаточно для детекции стен и имбаланса, минимальная нагрузка на API.
 */
export async function getOrderBookAnalysis(symbol: string, limit = 20): Promise<OrderBookAnalysis | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const url = `${BINGX_BASE_URL}/openApi/swap/v2/quote/depth?symbol=${encodeURIComponent(symbol)}&limit=${limit}`;
    const res = await fetch(url, {
      headers: { "X-SOURCE-KEY": "AlphaScanner" },
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;

    const data = await res.json() as {
      data?: {
        bids?: [string, string][];
        asks?: [string, string][];
      };
    };

    const rawBids = data.data?.bids ?? [];
    const rawAsks = data.data?.asks ?? [];
    if (rawBids.length === 0 && rawAsks.length === 0) return null;

    // Parse levels
    const bids: OrderBookLevel[] = rawBids.map(([p, q]) => {
      const price = parseFloat(p); const qty = parseFloat(q);
      return { price, qty, usd: price * qty };
    });
    const asks: OrderBookLevel[] = rawAsks.map(([p, q]) => {
      const price = parseFloat(p); const qty = parseFloat(q);
      return { price, qty, usd: price * qty };
    });

    const bidVolumeUsd = bids.reduce((s, l) => s + l.usd, 0);
    const askVolumeUsd = asks.reduce((s, l) => s + l.usd, 0);
    const bidAskRatio  = askVolumeUsd > 0 ? bidVolumeUsd / askVolumeUsd : 0;

    // Bid wall detection: уровни где объём > 3× среднего
    const avgBidUsd = bids.length > 0 ? bidVolumeUsd / bids.length : 0;
    const wallThreshold = avgBidUsd * 3;
    const bidWalls = bids.filter(l => l.usd >= wallThreshold);

    const largestWall    = bids.reduce((best, l) => l.usd > best.usd ? l : best, { price: 0, qty: 0, usd: 0 });
    const largestBidWallUsd   = largestWall.usd;
    const largestBidWallPrice = largestWall.price;
    const largestBidWallPct   = bidVolumeUsd > 0 ? (largestBidWallUsd / bidVolumeUsd) * 100 : 0;
    const bidWallCount        = bidWalls.length;

    // Bias classification
    const bias: OrderBookAnalysis["bias"] =
      bidAskRatio >= 3.0 ? "strong_bull" :
      bidAskRatio >= 1.8 ? "bull" :
      bidAskRatio <= 0.6 ? "bear" : "neutral";

    // Score bonus: только для bullish bias с реальной глубиной стакана (>$5k)
    const scoreBonus =
      (bias === "strong_bull" && bidWallCount >= 1 && bidVolumeUsd >= 5000) ? 2 :
      (bias === "bull"         && bidVolumeUsd >= 3000)                       ? 1 : 0;

    return {
      bidVolumeUsd, askVolumeUsd, bidAskRatio,
      largestBidWallUsd, largestBidWallPrice, largestBidWallPct,
      bidWallCount, bias, scoreBonus,
    };
  } catch {
    return null;
  }
}

export interface CVDResult {
  buyPct: number;
  sellPct: number;
  cvd: number;
  positive: boolean;
  trades: number;
}

/**
 * Fetch 24h spot volume (quoteVolume in USDT) from BingX spot market.
 * Returns null if the token has no BingX spot listing or the request fails.
 */
export async function getSpotVolume24h(symbol: string): Promise<number | null> {
  try {
    // BingX spot ticker requires "BTC-USDT" format (with dash)
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    const url = `${BINGX_BASE_URL}/openApi/spot/v1/ticker/24hr?symbol=${encodeURIComponent(symbol)}`;
    const res = await fetch(url, {
      headers: { "X-SOURCE-KEY": "AlphaScanner" },
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    // Response: {code: 0, data: [{symbol, quoteVolume, ...}]}
    const json = await res.json() as { data?: Array<{ quoteVolume?: string | number }> };
    const item = json?.data?.[0];
    const vol = parseFloat(String(item?.quoteVolume ?? ""));
    return isNaN(vol) || vol <= 0 ? null : vol;
  } catch {
    return null;
  }
}

export async function fetchCVD(symbol: string, limit = 2000): Promise<CVDResult | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const url = `${BINGX_BASE_URL}/openApi/swap/v2/quote/trades?symbol=${encodeURIComponent(symbol)}&limit=${limit}`;
    const res = await fetch(url, {
      headers: { "X-SOURCE-KEY": "AlphaScanner" },
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    const data = await res.json() as { data?: Array<{ qty: string; isBuyerMaker: boolean }> };
    const trades = data.data;
    if (!trades || trades.length === 0) return null;

    let buyVol = 0, sellVol = 0;
    for (const t of trades) {
      const qty = parseFloat(t.qty);
      if (isNaN(qty)) continue;
      if (t.isBuyerMaker) {
        sellVol += qty;
      } else {
        buyVol += qty;
      }
    }

    const total = buyVol + sellVol;
    if (total === 0) return null;

    const buyPct = (buyVol / total) * 100;
    return {
      buyPct,
      sellPct: 100 - buyPct,
      cvd: buyVol - sellVol,
      positive: buyPct >= 50,
      trades: trades.length,
    };
  } catch {
    return null;
  }
}
