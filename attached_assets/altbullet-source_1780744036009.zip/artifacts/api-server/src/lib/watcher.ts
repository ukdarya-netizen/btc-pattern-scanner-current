import { logger } from "./logger.js";
import { db, trackedSignalsTable, settingsTable, subscribersTable, oiWatchTable, signalsTable, whaleFuturesWatchlistTable, signalWhaleSeedsTable } from "@workspace/db";
import type { TrackedSignal, InsertTrackedSignal, OiWatch, InsertSignal } from "@workspace/db";
import { eq, and, inArray, sql, lt, gte } from "drizzle-orm";
import { getFutureTickers, getOpenInterest, getKlines, fetchCVD, getFundingRate, getOrderBookAnalysis } from "./bingx.js";
import { sendMessage, broadcastBatchAlert, formatAlphaSignal, formatWhaleWatchV2Alert, type AlphaResult } from "./telegram.js";
import { getCoinglassOI, batchGetCoinglassOI } from "./coinglass_oi.js";
import { getCoinglassTakerFlow } from "./coinglass_taker.js";
import { getSpotCvdMtf, getCoinglassSpotVolume24h } from "./coinglass_spot_cvd.js";
import { getWhaleWatchlist, expireStaleWatchlist, fetchMarketCap } from "./whale_watch_v2.js";
import { buildPositionsStatusText, formatOpenPositionLines } from "./positionsReport.js";
import { getSpotPoolEntry } from "./spotPool.js";

import {
    PARTIAL_TARGET, FIRST_TARGET, TRAILING_ACTIVATION_PCT, TRAILING_FIXED_PCT,
    STOP_LOSS, ACCUMULATION_H, ACCUMULATION_REENTRY_H, ACCUM_REMINDER_H,
    ACCUM_SCOUT_COOLDOWN_MS, ACCUM_OI_COOLDOWN_MS, MAX_WATCH_DAYS,
    RE_ENTRY_VOL_MULT, FAST_CYCLE_MS, MILESTONES,
  } from "./watcher-config.js";

// Момент старта процесса — используется для grace period после рестарта.
// В течение RESTART_GRACE_MS stale-cancel (72ч hard max + OI check) не срабатывает:
// FastCycle должен успеть оценить и перевести сигналы в in_run прежде чем их отменять.
const SERVER_STARTED_AT = Date.now();
const RESTART_GRACE_MS = 30 * 60_000; // 30 минут

// ── Telegram helpers ──────────────────────────────────────────────────────────

// Cache: @username → numeric chat ID (resolved once via Telegram API, persists for process lifetime)
const _chatIdCache = new Map<string, number>();

async function resolveToNumericId(chatId: string): Promise<number | null> {
  const key = chatId.toLowerCase();
  if (_chatIdCache.has(key)) return _chatIdCache.get(key)!;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/getChat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId }),
    });
    if (!res.ok) return null;
    const data = await res.json() as { ok: boolean; result?: { id: number } };
    if (data.ok && data.result?.id) {
      _chatIdCache.set(key, data.result.id);
      return data.result.id;
    }
  } catch { /* ignore — fall back to string dedup */ }
  return null;
}
async function getTargets(): Promise<(number | string)[]> {
  const seenNumeric = new Set<number>();
  const seenString = new Set<string>();
  const targets: (number | string)[] = [];

  // Dedup by numeric ID when possible (prevents duplicate sends when TELEGRAM_CHAT_ID
  // is a numeric chat ID and settings.channelId is the same channel as @username)
  const addTarget = async (id: number | string) => {
    if (typeof id === "number") {
      if (!seenNumeric.has(id)) { seenNumeric.add(id); targets.push(id); }
    } else if (id.startsWith("@")) {
      const numId = await resolveToNumericId(id);
      if (numId !== null) {
        if (!seenNumeric.has(numId)) { seenNumeric.add(numId); targets.push(numId); }
      } else {
        const key = id.toLowerCase();
        if (!seenString.has(key)) { seenString.add(key); targets.push(id); }
      }
    } else {
      const key = id.toLowerCase();
      if (!seenString.has(key)) { seenString.add(key); targets.push(id); }
    }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) await addTarget(asNum);
    else if (envId.startsWith("@")) await addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers
  const subs = await db.select({ chatId: subscribersTable.chatId })
    .from(subscribersTable)
    .where(eq(subscribersTable.active, true));
  for (const s of subs) await addTarget(s.chatId);

  // Always add channel_id from settings (dedup via seenNumeric/seenString handles overlaps).
  // Bot chat ID (TELEGRAM_CHAT_ID) and channel (@cryptoaltshero) are different targets.
  const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
  const ch = rows[0]?.channelId?.trim();
  if (ch) await addTarget(ch);

  return targets;
}

export async function broadcast(text: string) {
  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch (err) {
    logger.error({ err }, "broadcast: не удалось получить список получателей");
    return;
  }
  if (targets.length === 0) {
    logger.warn("broadcast: нет получателей — сообщение не отправлено (subscribers пуст, channel_id не задан, TELEGRAM_CHAT_ID не настроен)");
    return;
  }
  for (const t of targets) {
    try {
      await sendMessage(t, text);
    } catch (err) {
      // Ошибка Telegram (таймаут, rate limit и т.д.) не должна ломать весь цикл.
      // Логируем и продолжаем — остальные получатели получат сообщение.
      logger.error({ err, target: t }, "broadcast: не удалось отправить сообщение");
    }
  }
}

/** Admin broadcast — отправляет произвольный текст всем подписчикам (для уведомлений об обновлениях) */
export async function adminBroadcast(text: string): Promise<void> {
  await broadcast(text);
}

async function sendTo(text: string, targetChatId?: number | string): Promise<void> {
  if (targetChatId !== undefined) {
    await sendMessage(targetChatId, text);
  } else {
    await broadcast(text);
  }
}

import {
    fmtP, fmtPct, fmtVolM, scoreBar, hoursAndDays, tickerTag, SENTIMENT_LABELS, fmtPattern,
    computePnl, computePeakPnl, nextMilestone,
    msgVolumeCollapse, msgFirstTarget, msgTrailingActivated, msgSmallLossStop,
    msgMilestone, msgTrailingStopHit, msgStopLoss, msgBUStop, msgPartialTakeProfit,
    msgAccumThesisBroken, msgAccumVolumeBuilding, msgAccumOiBuilding,
    msgAccumulationReminder, msgAccumulation, msgReEntry, msgLateSignal,
    msgBreakeven, msgInvalidated,
  } from "./watcher-formatters.js";

  // ── Whale seed: cancelled signal with OI spike → long-term monitoring ─────────
// Fire-and-forget, non-critical. Called after every cancel where OI was meaningful.
async function maybeSeedWhaleWatch(tracked: TrackedSignal): Promise<void> {
  try {
    // Lookup original OI spike magnitude from linked signal if available
    let oiMagnitude = 0;
    if (tracked.signalId) {
      const [sig] = await db.select({
        cumulativeOiChange: signalsTable.cumulativeOiChange,
        oiChangePercent:    signalsTable.oiChangePercent,
      }).from(signalsTable).where(eq(signalsTable.id, tracked.signalId)).limit(1);
      if (sig) {
        oiMagnitude = sig.cumulativeOiChange ?? sig.oiChangePercent ?? 0;
      }
    }

    // For whale_futures/whale_watch signals without a signalId (manually migrated),
    // use a default magnitude that qualifies them for seeding
    if (!oiMagnitude || oiMagnitude < 3.0) {
      if (tracked.sentimentKey === "whale_futures" || tracked.sentimentKey === "whale_watch") {
        oiMagnitude = 5.0; // Conservative default for known whale signals
      } else {
        return; // Skip non-whale signals with no OI data
      }
    }

    // Deduplicate: only one active seed per symbol
    const existing = await db.select({ id: signalWhaleSeedsTable.id })
      .from(signalWhaleSeedsTable)
      .where(and(
        eq(signalWhaleSeedsTable.symbol, tracked.symbol),
        eq(signalWhaleSeedsTable.status, "watching"),
      ))
      .limit(1);
    if (existing.length > 0) return;

    const expiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000);
    await db.insert(signalWhaleSeedsTable).values({
      symbol:          tracked.symbol,
      trackedSignalId: tracked.id,
      signalId:        tracked.signalId,
      sentimentKey:    tracked.sentimentKey ?? null,
      oiAtSeed:        oiMagnitude,
      priceAtSeed:     tracked.entryPrice,
      expiresAt,
    });
    logger.info({ symbol: tracked.symbol, oiAtSeed: oiMagnitude.toFixed(1) }, "🌱 Whale seed: посеян (OI был значимым)");
  } catch (err) {
    logger.warn({ err, symbol: tracked.symbol }, "🌱 Whale seed: ошибка посева (non-critical)");
  }
}

// ── Add signal to tracker ─────────────────────────────────────────────────────
export async function trackSignal(params: {
  symbol: string;
  signalId: number | null;
  signalType: string;
  sentiment?: string | null;
  sentimentKey?: string | null;
  alphaScore?: number | null;
  entryPrice: number;
  entryOi?: number | null;
  initialStatus?: "active";
}): Promise<"new" | "reentry" | "skip" | false> {
  try {
    const existing = await db.select({
      id:         trackedSignalsTable.id,
      status:     trackedSignalsTable.status,
      entryPrice: trackedSignalsTable.entryPrice,
      signalType: trackedSignalsTable.signalType,
    })
      .from(trackedSignalsTable)
      .where(and(
        eq(trackedSignalsTable.symbol, params.symbol),
        inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run", "re_entry"])
      ))
      .limit(1);

    // Является ли новый сигнал апгрейдом относительно текущего?
    // ghost_pump/ghost_pump_early → alpha/super_alpha: более строгая подтверждённая система
    // Апгрейд: НЕ сбрасываем цену входа и статус — позиция продолжается,
    // но обновляем метаданные (тип, сентимент) чтобы трекер отображал актуальный паттерн.
    const GHOST_TYPES = new Set(["ghost_pump", "ghost_pump_early"]);
    const ALPHA_TYPES = new Set(["alpha", "super_alpha"]);

    if (existing.length > 0) {
      const rec = existing[0];
      const isGhostToAlpha = GHOST_TYPES.has(rec.signalType ?? "") && ALPHA_TYPES.has(params.signalType);

      // in_run: монета уже летит — обновляем метаданные если это апгрейд, иначе пропускаем.
      // В любом случае НЕ посылаем повторный алерт (return "skip").
      if (rec.status === "in_run") {
        if (isGhostToAlpha) {
          await db.update(trackedSignalsTable)
            .set({
              signalId:     params.signalId,
              signalType:   params.signalType,
              sentiment:    params.sentiment    ?? null,
              sentimentKey: params.sentimentKey ?? null,
              alphaScore:   params.alphaScore   ?? null,
              updatedAt:    new Date(),
            })
            .where(eq(trackedSignalsTable.id, rec.id));
          logger.info(
            { symbol: params.symbol, from: rec.signalType, to: params.signalType },
            "📈 trackSignal: ghost_pump in_run → alpha (метаданные обновлены, алерт не дублируем)"
          );
        } else {
          logger.info(
            { symbol: params.symbol, status: rec.status, type: rec.signalType },
            "Already in_run — skipping duplicate alert"
          );
        }
        return "skip"; // позиция уже летит — не дублируем алерт
      }

      // active: позиция уже открыта — НЕ перезаписываем цену входа и НЕ дублируем алерт.
      // Исключение: ghost_pump → alpha апгрейд: обновляем тип и сентимент тихо.
      if (rec.status === "active") {
        if (isGhostToAlpha) {
          await db.update(trackedSignalsTable)
            .set({
              signalId:     params.signalId,
              signalType:   params.signalType,
              sentiment:    params.sentiment    ?? null,
              sentimentKey: params.sentimentKey ?? null,
              alphaScore:   params.alphaScore   ?? null,
              updatedAt:    new Date(),
            })
            .where(eq(trackedSignalsTable.id, rec.id));
          logger.info(
            { symbol: params.symbol, from: rec.signalType, to: params.signalType },
            "📈 trackSignal: ghost_pump active → alpha (метаданные обновлены, алерт не дублируем)"
          );
        } else {
          logger.info(
            { symbol: params.symbol, existingEntry: rec.entryPrice, newPrice: params.entryPrice },
            "Already active — skipping duplicate alert (entry price protected)"
          );
        }
        return "skip"; // позиция уже активна — не дублируем алерт
      }

      // accumulation: монета накапливается давно — новый сигнал означает возобновление
      // импульса, сбрасываем вход на актуальную цену.
      const oldEntry = rec.entryPrice;
      await db.update(trackedSignalsTable)
        .set({
          signalId: params.signalId,
          signalType: params.signalType,
          sentiment: params.sentiment ?? null,
          sentimentKey: params.sentimentKey ?? null,
          alphaScore: params.alphaScore ?? null,
          isShort: false,
          entryPrice: params.entryPrice,
          entryOi: params.entryOi ?? null,
          peakPrice: params.entryPrice,
          trailingStopLevel: null,
          lastMilestone: null,
          status: "active",
          reEntryCount: 0,
          detectedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(trackedSignalsTable.id, rec.id));

      logger.info(
        { symbol: params.symbol, oldEntry, newEntry: params.entryPrice },
        "📍 Signal tracker reset (accumulation → active) — fresh entry price"
      );
      return "reentry";
    }

    // ── Пост-памп фильтр: остаточные индикаторы после отработки сигнала ──────
    // После памп OI/объём/тейкер остаются "задранными" ещё несколько часов.
    // Если монета недавно закрылась, а цена ещё не вернулась к уровню предыдущего входа —
    // это остатки старого памп, не новый сетап → пропускаем.
    // Разрешаем новый сигнал когда цена вернётся в пределы 8% от старого входа.
    if (!params.initialStatus) {
      const postPumpWindow = new Date(Date.now() - 48 * 60 * 60 * 1000);
      const recentlyClosed = await db.select({
        id:         trackedSignalsTable.id,
        status:     trackedSignalsTable.status,
        entryPrice: trackedSignalsTable.entryPrice,
      })
        .from(trackedSignalsTable)
        .where(and(
          eq(trackedSignalsTable.symbol, params.symbol),
          inArray(trackedSignalsTable.status, ["profit", "stop_loss"]),
          gte(trackedSignalsTable.updatedAt, postPumpWindow)
        ))
        .limit(1);

      if (recentlyClosed.length > 0) {
        const prevEntry = Number(recentlyClosed[0].entryPrice);
        const elevationPct = prevEntry > 0
          ? ((params.entryPrice - prevEntry) / prevEntry) * 100
          : 0;
        if (elevationPct > 8) {
          logger.info(
            {
              symbol: params.symbol,
              closedStatus: recentlyClosed[0].status,
              prevEntry,
              currentEntry: params.entryPrice,
              elevationPct: elevationPct.toFixed(1) + "%",
            },
            "🔇 trackSignal: пост-памп — цена ещё задрана выше предыдущего входа, сигнал пропущен"
          );
          return "skip";
        }
      }
    }

    await db.insert(trackedSignalsTable).values({
      symbol: params.symbol,
      signalId: params.signalId,
      signalType: params.signalType,
      sentiment: params.sentiment ?? null,
      sentimentKey: params.sentimentKey ?? null,
      alphaScore: params.alphaScore ?? null,
      isShort: false,
      entryPrice: params.entryPrice,
      entryOi: params.entryOi ?? null,
      peakPrice: params.entryPrice,
      trailingStopLevel: null,
      lastMilestone: null,
      status: params.initialStatus ?? "active",
      reEntryCount: 0,
      detectedAt: new Date(),
      updatedAt: new Date(),
    } as InsertTrackedSignal);

    logger.info({ symbol: params.symbol, price: params.entryPrice }, "📍 Signal added to tracker");
    return "new";
  } catch (err) {
    logger.error({ err, symbol: params.symbol }, "Failed to add signal to tracker");
    return false; // сигнализируем вызывающему — broadcast нельзя делать
  }
}

// ── Startup reset: normalize stale active signals after server restart ─────────
// Если сервер перезагрузился пока монета двигалась — entry price устарел.
// Вместо молчаливого сброса — отправляем уведомление «Пропущено движение»,
// затем сбрасываем entry до текущей цены чтобы сопровождение продолжалось корректно.
async function sendBotRestartNotification(): Promise<void> {
  // ── Шаг 1: атомарный guard с собственным retry (до 5 попыток, 60с) ──────────
  // Guard UPDATE вынесен в отдельный цикл потому что DB connection pool
  // перегружен пока сканер гоняет первую партию (~10 мин). 5×60с = 5 мин окно,
  // но поскольку watcher стартует в t=14мин (после первого скана), в норме
  // первая же попытка должна проходить. Retry — страховка на случай задержки скана.
  let claimed = false;
  for (let guardAttempt = 1; guardAttempt <= 5; guardAttempt++) {
    try {
      const restartThreshold = new Date(Date.now() - 5 * 60 * 1000);
      const rows = await db.update(settingsTable)
        .set({ lastRestartNotifiedAt: new Date() })
        .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_restart_notified_at IS NULL OR last_restart_notified_at < ${restartThreshold})`)
        .returning({ id: settingsTable.id });
      if (rows.length === 0) {
        logger.info("Restart notification skipped — другой процесс уже отправил");
        return;
      }
      claimed = true;
      break;
    } catch (err) {
      logger.warn({ err, guardAttempt }, "Restart notification: guard DB error, retry in 60s");
      if (guardAttempt < 5) await new Promise(r => setTimeout(r, 60_000));
    }
  }
  if (!claimed) {
    logger.error("Restart notification: guard claim failed after 5 attempts — уведомление не отправлено");
    return;
  }

  // ── Шаг 2: отправка с retry ───────────────────────────────────────────────
  // Retry loop: 3 попытки с задержкой 60с.
  // ВАЖНО: buildPositionsStatusText() и getTargets() вызываются ВНУТРИ цикла —
  // при старте DB бывает временно недоступна (connection timeout). Если первая
  // попытка упала из-за DB, вторая через 60с сделает свежий запрос к уже
  // восстановившейся БД. Вынос buildPositionsStatusText() за цикл = тихий провал.
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const text = `🔄 <b>Бот перезапущен. Мониторинг возобновлён.</b>`;

      const targets = await getTargets();
      if (targets.length === 0) {
        logger.warn({ attempt }, "Restart notification: нет получателей — пропускаем");
        return;
      }

      let sent = 0;
      for (const target of targets) {
        try {
          await sendMessage(target, text);
          sent++;
        } catch (err) {
          logger.warn({ err, target, attempt }, "Restart notification: sendMessage failed for target");
        }
      }

      if (sent > 0) {
        logger.info({ sent, total: targets.length }, "🔄 Bot restart notification sent");
        return;
      }
      logger.warn({ attempt, total: targets.length }, "Restart notification: все отправки упали, retry через 60с");
    } catch (err) {
      logger.warn({ err, attempt }, "Restart notification: ошибка (DB/Telegram/getTargets), retry через 60с");
    }

    if (attempt < 3) await new Promise(r => setTimeout(r, 60_000));
  }
  logger.error("🔄 Restart notification: все 3 попытки провалились — уведомление не отправлено");
}

// ── One-time cleanup: закрываем все открытые ghost_pump/anomaly позиции ───────
// Запускается один раз при старте сервера после отключения паттернов.
// После того как все позиции закрыты, функция молчит (нет open ghost_pump → exit).
export async function runGhostPumpCleanup(): Promise<void> {
  const openGhost = await db.select({
    id: trackedSignalsTable.id,
    symbol: trackedSignalsTable.symbol,
    status: trackedSignalsTable.status,
    entryPrice: trackedSignalsTable.entryPrice,
  })
    .from(trackedSignalsTable)
    .where(and(
      inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "re_entry"]),
      inArray(trackedSignalsTable.signalType, ["ghost_pump", "ghost_pump_early"])
    ));

  if (openGhost.length === 0) return;

  logger.info({ count: openGhost.length }, "🧹 Ghost pump cleanup: закрываем открытые позиции");

  const symbols: string[] = [];
  for (const pos of openGhost) {
    try {
      await db.update(trackedSignalsTable).set({
        status: "cancelled",
        exitPrice: pos.entryPrice,
        pnlPercent: 0,
        closedAt: new Date(),
        updatedAt: new Date(),
      }).where(and(
        eq(trackedSignalsTable.id, pos.id),
        inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation"])
      ));
      symbols.push(pos.symbol.replace("-USDT", ""));
    } catch (err) {
      logger.warn({ err, symbol: pos.symbol }, "Ghost pump cleanup: ошибка закрытия");
    }
  }

  if (symbols.length > 0) {
    try {
      const targets = await getTargets();
      const msg = [
        `🧹 <b>Сброс Ghost Pump позиций</b>`,
        ``,
        `Паттерны <b>Ghost Pump</b> и <b>Anomaly</b> отключены — слишком поздний вход, высокий риск.`,
        ``,
        `Закрыты позиции (${symbols.length}):`,
        symbols.map(s => `  • #${s}`).join("\n"),
        ``,
        `Бот продолжает работу по оставшимся паттернам.`,
      ].join("\n");
      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
    } catch (err) {
      logger.warn({ err }, "Ghost pump cleanup: не удалось отправить уведомление");
    }
  }
}

export async function runStartupReset(): Promise<void> {
  // Проверяем и active (стоп-лосс 10%) и in_run (трейлинг стоп / бу-стоп)
  const openSignals = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run"]));

  if (openSignals.length === 0) return;

  // ── Retry: BingX API нестабилен при холодном старте (таймауты, DNS) ──────
  // 3 попытки с экспоненциальной задержкой. Если все упали — логируем и выходим.
  // НЕ молчим: раньше был просто return, что скрывало пропуск стоп-лоссов.
  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fetchOk = false;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      tickers = await getFutureTickers() as any[];
      fetchOk = true;
      break;
    } catch (err) {
      logger.warn({ err, attempt }, `Startup reset: BingX fetch attempt ${attempt}/3 failed`);
      if (attempt < 3) await new Promise(r => setTimeout(r, 3000 * attempt));
    }
  }
  if (!fetchOk) {
    logger.error("Startup reset: все попытки получить цены провалились — стоп-лоссы не проверены");
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  let targets: (number | string)[] = [];
  try { targets = await getTargets(); } catch { /* non-critical */ }

  let resetCount = 0;
  for (const tracked of openSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const base = tracked.symbol.replace("-USDT", "");
    const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

    // ── active: проверка стоп-лосса (-10%) ─────────────────────────────────
    if (tracked.status === "active" && pnl <= -STOP_LOSS) {
      // UPDATE первым — RETURNING гарантирует что только один процесс отправит
      const claimedSL = await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedSL.length === 0) { resetCount++; continue; } // другой процесс уже закрыл
      void maybeSeedWhaleWatch(tracked);
      const msg =
        `🛑 <b>Пропущен стоп-лосс (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Убыток: <b>${pnl.toFixed(1)}%</b>\n\n` +
        `Позиция закрыта по стоп-лоссу.\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} #stop_loss`;

      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      logger.warn(
        { symbol: tracked.symbol, entry: tracked.entryPrice, currentPrice, pnl: pnl.toFixed(1) + "%" },
        "🛑 Startup reset: missed stop-loss (active) — signal closed"
      );
      resetCount++;

    // ── in_run: проверка трейлинг-стопа ────────────────────────────────────
    // После первой цели (+10%) стоп переносится в БУ (entry). Трейлинг (10% от пика)
    // активируется при +15% от входа. Если сервер лежал и цена рухнула — закрываем.
    } else if (tracked.status === "in_run") {
      const peak = tracked.peakPrice ?? currentPrice;
      const peakPnl = computePnl(tracked, peak);
      const trailingActive = peakPnl >= TRAILING_ACTIVATION_PCT;
      const trailingStop = peak * (1 - TRAILING_FIXED_PCT / 100);
      const trailingHit = trailingActive && currentPrice <= trailingStop;
      // Бу-стоп: если трейлинг ещё не активен но цена упала ниже входа — закрываем
      const beStopHit = !trailingActive && currentPrice < tracked.entryPrice;

      if (trailingHit || beStopHit) {
        const finalPnl = ((currentPrice - tracked.entryPrice) / tracked.entryPrice) * 100;
        // beStopHit = price returned to entry → стоп в БУ (считается как прибыль)
        // trailingHit = трейлинг сработал → profit/stop_loss в зависимости от pnl
        const closedStatus = beStopHit ? "bu_stop" : (finalPnl >= 0 ? "profit" : "stop_loss");
        // UPDATE первым — RETURNING гарантирует что только один процесс отправит
        const claimedTr = await db.update(trackedSignalsTable).set({
          status: closedStatus, exitPrice: currentPrice, pnlPercent: finalPnl,
          closedAt: new Date(), updatedAt: new Date(),
        }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'in_run'`)
          .returning({ id: trackedSignalsTable.id });
        if (claimedTr.length === 0) { resetCount++; continue; } // другой процесс уже закрыл
        void maybeSeedWhaleWatch(tracked);
        const msg = trailingHit
          ? `🔴 <b>Пропущен трейлинг-стоп (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `Пик: <b>$${peak.toPrecision(4)}</b> | Трейлинг: <b>$${trailingStop.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #trailing_stop`
          : `🛡 <b>Пропущен стоп в БУ (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n` +
            `<i>Капитал защищён.</i>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #bu_stop`;

        for (const chatId of targets) {
          try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
        }
        logger.warn(
          { symbol: tracked.symbol, entry: tracked.entryPrice, peak, currentPrice, finalPnl: finalPnl.toFixed(1) + "%" },
          trailingHit
            ? "🔴 Startup reset: missed trailing-stop (in_run) — signal closed"
            : "🔴 Startup reset: missed be-stop (in_run) — signal closed"
        );
        resetCount++;
      }

    // ── active: приближается к стоп-лоссу — предупреждаем, но не закрываем ─
    } else if (tracked.status === "active" && pnl <= -5 && pnl > -STOP_LOSS) {
      // Используем lastHourlyAt как guard для этого одноразового предупреждения
      const nearStopThreshold = new Date(Date.now() - 55 * 60 * 1000);
      const claimedNear = await db.update(trackedSignalsTable)
        .set({ lastHourlyAt: new Date() })
        .where(sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastHourlyAt} IS NULL OR ${trackedSignalsTable.lastHourlyAt} < ${nearStopThreshold})`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedNear.length === 0) continue; // другой процесс уже предупредил
      const msg =
        `⚠️ <b>Близко к стоп-лоссу (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `P&L: <b>${pnl.toFixed(1)}%</b> (стоп: −${STOP_LOSS}%)\n\n` +
        `Бот перезапускался — проверьте позицию вручную!\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} #near_stop`;
      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      logger.warn(
        { symbol: tracked.symbol, pnl: pnl.toFixed(1) + "%" },
        "⚠️ Startup reset: position near stop-loss — warning sent"
      );

    // ── active: достигло первой цели пока сервер лежал → переводим в in_run ──
    // ВАЖНО: entryPrice НЕ сбрасываем — это реальная цена входа. Сигнал уже
    // выполнил условие перехода (+10%), поэтому корректный переход — in_run,
    // а не обнуление entry (что скрывает прибыль и ломает трейлинг).
    } else if (tracked.status === "active" && pnl >= FIRST_TARGET) {
      const claimedRun = await db.update(trackedSignalsTable).set({
        status: "in_run", peakPrice: currentPrice,
        updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedRun.length === 0) { resetCount++; continue; } // другой процесс уже перевёл
      const sign = pnl >= 0 ? "+" : "";
      const msg =
        `🚀 <b>Цель достигнута пока бот перезапускался</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Сейчас: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Профит: <b>${sign}${pnl.toFixed(1)}%</b>\n\n` +
        `Сигнал переведён в <b>IN RUN</b>. Стоп перенесён в безубыток.\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} #in_run`;

      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      logger.warn(
        { symbol: tracked.symbol, entry: tracked.entryPrice, currentPrice, pnl: pnl.toFixed(1) + "%" },
        "🚀 Startup reset: first target reached while down — transitioned to in_run"
      );
      resetCount++;
    }
  }

  if (resetCount > 0) {
    logger.info({ resetCount }, "Startup reset complete: missed moves notified, entries normalized");
  } else {
    logger.info("Startup reset: all active signals are fresh (no reset needed)");
  }
}

// ── In-memory cooldown для accumulation scouts (сбрасывается при рестарте) ───
// Структура: Map<signalId, { volBuild: timestampMs, oiBuild: timestampMs }>
const accumScoutCooldowns = new Map<number, { volBuild: number; oiBuild: number; oiDrain: number }>();
// hourlyPositionUpdateAt removed — dedup now via lastHourlyAt in DB (atomic across 2 processes)

// ── Main watcher cycle (every 10 min): scouts active signals ──────────────────
// Обрабатывает OI drain, объём и OI-скауты, re-entry check.
// Stop loss / trailing stop / in_run промоут — только FastCycle (каждые 2 мин).
export async function runWatcherCycle(): Promise<{ checked: number; updated: number }> {
  let accumSignals: (typeof trackedSignalsTable.$inferSelect)[];
  try {
    accumSignals = await db.select()
      .from(trackedSignalsTable)
      .where(inArray(trackedSignalsTable.status, ["active", "accumulation"]));
  } catch (err) {
    logger.warn({ err }, "WatcherCycle: initial fetch failed (DB timeout?), skipping cycle");
    return { checked: 0, updated: 0 };
  }

  if (accumSignals.length === 0) return { checked: 0, updated: 0 };

  logger.info({ count: accumSignals.length }, "Watcher: checking active/accumulation signals");

  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch (err) {
    logger.error({ err }, "Watcher: failed to fetch tickers");
    return { checked: 0, updated: 0 };
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  let updated = 0;

  for (const tracked of accumSignals) {
    try {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const { h: ageHours } = hoursAndDays(tracked.detectedAt);
    const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
    const peakChanged = newPeak !== tracked.peakPrice;

    // 6h напоминание удалено — сопровождение теперь только по триггеру

    // ── OI Drain check: тезис всё ещё в силе? ────────────────────────────────
    // После перехода в accumulation проверяем раз в 4ч: не слился ли OI.
    // OI был причиной сигнала — если он вернулся к норме, а цена нет → выходим.
    // short_squeeze не проверяем: там OI ДОЛЖЕН падать по тезису.
    const scoutNow = Date.now();
    const cooldowns = accumScoutCooldowns.get(tracked.id) ?? { volBuild: 0, oiBuild: 0, oiDrain: 0 };
    const oiDrainCooldownOk = scoutNow - (cooldowns.oiDrain ?? 0) > 4 * 3_600_000;
    const oiFallingPatternAccum = tracked.sentimentKey === "short_squeeze";
    if (oiDrainCooldownOk && !oiFallingPatternAccum && tracked.entryOi && tracked.entryOi > 0) {
      try {
        const oiData = await getOpenInterest(tracked.symbol);
        if (oiData) {
          const currentOi = parseFloat(oiData.openInterest) || 0;
          const oiDropFromEntry = ((tracked.entryOi - currentOi) / tracked.entryOi) * 100;
          // OI слился >20% от входа, а цена не выросла — тезис нарушен.
          // Дополнительный фильтр: CVD 5m + 30m + 1h все отрицательные — разворот подтверждён.
          if (oiDropFromEntry >= 20 && pnl < 3) {
            let cvdConfirmed = false;
            try {
              const cvdCheck = await getSpotCvdMtf(tracked.symbol);
              cvdConfirmed = cvdCheck.available &&
                cvdCheck.cvd5m === false &&
                cvdCheck.cvd30m === false &&
                cvdCheck.cvd1h === false;
            } catch { /* non-critical */ }
            if (!cvdConfirmed) {
              logger.info({ symbol: tracked.symbol, oiDropFromEntry: oiDropFromEntry.toFixed(1), pnl }, "Watcher: OI слился, но CVD не подтвердил — ждём");
              accumScoutCooldowns.set(tracked.id, { ...cooldowns, oiDrain: scoutNow });
              continue;
            }
            const claimedTb = await db.update(trackedSignalsTable).set({
              status: "cancelled", exitPrice: currentPrice, pnlPercent: pnl,
              closedAt: new Date(), updatedAt: new Date(),
            }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active', 'accumulation')`)
              .returning({ id: trackedSignalsTable.id });
            if (claimedTb.length === 0) continue;
            void maybeSeedWhaleWatch(tracked);
            await broadcast(msgAccumThesisBroken(tracked, currentPrice, pnl, oiDropFromEntry));
            logger.info({ symbol: tracked.symbol, oiDropFromEntry: oiDropFromEntry.toFixed(1), pnl }, "Watcher: ACCUM THESIS BROKEN — OI drained + CVD подтверждён 🚫");
            updated++;
            continue;
          }
          // Записываем время последней проверки OI drain (даже если не сработало)
          accumScoutCooldowns.set(tracked.id, { ...cooldowns, oiDrain: scoutNow });
        }
      } catch { /* non-critical */ }
    }

    // ── Accumulation scout: pre-fetch klines (используется и здесь, и в re-entry) ──
    let scoutVolMult = 0;
    let scoutSpotVol: number | null = null;
    try {
      const [klines, spotVol] = await Promise.all([
        getKlines(tracked.symbol, "30m", 21),
        getCoinglassSpotVolume24h(tracked.symbol).catch(() => null),
      ]);
      scoutSpotVol = spotVol;
      if (klines.length >= 5) {
        const current = klines[klines.length - 1];
        const historical = klines.slice(0, -1);
        const close = parseFloat(current.close) || 0;
        const currentVol = (parseFloat(current.volume) || 0) * close;
        const avgVol = historical.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / historical.length;
        scoutVolMult = avgVol > 0 ? currentVol / avgVol : 0;

        // 📡 Объём оживает (2x-3x): ранний сигнал до re-entry порога
        // DB-level guard вместо in-memory: оба процесса разделяют lastVolBuildAt
        if (scoutVolMult >= 2.0 && scoutVolMult < RE_ENTRY_VOL_MULT) {
          const volBuildThreshold = new Date(scoutNow - ACCUM_SCOUT_COOLDOWN_MS);
          const claimedVol = await db.update(trackedSignalsTable)
            .set({ lastVolBuildAt: new Date(scoutNow) })
            .where(sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastVolBuildAt} IS NULL OR ${trackedSignalsTable.lastVolBuildAt} < ${volBuildThreshold})`)
            .returning({ id: trackedSignalsTable.id });
          if (claimedVol.length > 0) {
            await broadcast(msgAccumVolumeBuilding(tracked, currentPrice, pnl, scoutVolMult, scoutSpotVol));
            accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns), volBuild: scoutNow });
            logger.info({ symbol: tracked.symbol, volMult: scoutVolMult.toFixed(2) }, "Watcher: ACCUM VOL BUILDING 📡");
          }
        }
      }
    } catch { /* non-critical */ }

    // 👀 OI растёт при боковике: CoinGlass check с 2ч кулдауном
    // DB-level guard вместо in-memory: оба процесса разделяют lastOiBuildAt
    if (Math.abs(pnl) <= 6) {
      try {
        const oiBuildThreshold = new Date(scoutNow - ACCUM_OI_COOLDOWN_MS);
        const cgOI = await getCoinglassOI(tracked.symbol);
        const oiChange = cgOI.oiChange30m ?? cgOI.oiChange5m ?? null;
        if (cgOI.available && oiChange !== null && oiChange >= 5) {
          const claimedOi = await db.update(trackedSignalsTable)
            .set({ lastOiBuildAt: new Date(scoutNow) })
            .where(sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastOiBuildAt} IS NULL OR ${trackedSignalsTable.lastOiBuildAt} < ${oiBuildThreshold})`)
            .returning({ id: trackedSignalsTable.id });
          if (claimedOi.length > 0) {
            await broadcast(msgAccumOiBuilding(tracked, currentPrice, pnl, oiChange));
            accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns), oiBuild: scoutNow });
            logger.info({ symbol: tracked.symbol, oiChange }, "Watcher: ACCUM OI BUILDING 👀");
          }
        }
      } catch { /* non-critical */ }
    }

    // ── Re-entry check (≥12h in accumulation, 3x объём) ──────────────────────
    const hoursInAccumulation = (Date.now() - tracked.updatedAt.getTime()) / 3_600_000;
    if (hoursInAccumulation >= ACCUMULATION_REENTRY_H && scoutVolMult >= RE_ENTRY_VOL_MULT) {
      // UPDATE первым — RETURNING гарантирует что только один процесс отправит
      const reEntryThreshold = new Date(Date.now() - ACCUMULATION_REENTRY_H * 3_600_000);
      const claimedRE = await db.update(trackedSignalsTable).set({
        status: "active",
        reEntryCount: (tracked.reEntryCount ?? 0) + 1,
        peakPrice: newPeak, updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active', 'accumulation') AND ${trackedSignalsTable.updatedAt} < ${reEntryThreshold}`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedRE.length > 0) {
        await broadcast(msgReEntry(tracked, currentPrice, scoutVolMult, scoutSpotVol));
        logger.info({ symbol: tracked.symbol, volMult: scoutVolMult }, "Watcher: RE-ENTRY 🔄");
        updated++;
      }
      continue;
    }

    // Update peak silently — GREATEST защищает от гонки двух воркер-процессов:
    // оба могут прочитать старое значение одновременно, но SQL max гарантирует
    // что в БД останется наибольший пик.
    if (peakChanged) {
      await db.update(trackedSignalsTable)
        .set({
          peakPrice: sql`GREATEST(COALESCE(${trackedSignalsTable.peakPrice}, ${newPeak}), ${newPeak})`,
          updatedAt: new Date(),
        })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }
    } catch (err) {
      logger.error({ err, symbol: tracked.symbol }, "WatcherCycle: ошибка обработки сигнала (пропускаем)");
    }
  }

  return { checked: accumSignals.length, updated };
}

// ── Daily report (21:00 МСК = 18:00 UTC) ─────────────────────────────────────
export async function sendDailyReport(targetChatId?: number | string, bypassDedupe = false): Promise<void> {
  // Атомарный guard: только один из 2 воркер-процессов отправляет плановый отчёт.
  // bypassDedupe=true используется при ручном вызове через дашборд (кнопка "Daily Report").
  if (!targetChatId && !bypassDedupe) {
    const now = new Date();
    const dedupeWindow = new Date(now.getTime() - 10 * 60 * 1000);
    const claimed = await db.update(settingsTable)
      .set({ lastDailyReportAt: now })
      .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_daily_report_at IS NULL OR last_daily_report_at < ${dedupeWindow})`)
      .returning({ id: settingsTable.id });
    if (claimed.length === 0) {
      logger.info("Daily report: уже отправлен другим процессом — пропускаем");
      return;
    }
  }

  // Берём последние 24 часа чтобы не пропускать сигналы при catch-up после перезапуска
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const allOpen = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run", "re_entry"]));

  const closedToday = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.closedAt} >= ${since}`);

  const profitsToday    = closedToday.filter(s => s.status === "profit");
  const buStopsToday    = closedToday.filter(s => s.status === "bu_stop");
  const stopsToday      = closedToday.filter(s => s.status === "stop_loss");
  const cancelledToday  = closedToday.filter(s => s.status === "cancelled");
  // Fetch live prices for open positions
  const priceMap = new Map<string, number>();
  if (allOpen.length > 0) {
    try {
      const tickers = await getFutureTickers() as any[];
      for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
    } catch { /* non-critical — show without live price */ }
  }

  const lines: string[] = [
    `📊 <b>DAILY REPORT — AltBullet Watcher</b>`,
    `<i>${new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "long", year: "numeric" })}</i>`,
    ``,
  ];

  const symTag  = (symbol: string) => `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
  const symBase = (symbol: string) => symbol.replace("-USDT", "");
  const priceRow = (s: TrackedSignal, curPrice: number | undefined) => {
    if (!s.entryPrice) return "";
    if (!curPrice) return ` | Вход: ${fmtP(s.entryPrice)}`;
    const pnl = ((curPrice - s.entryPrice) / s.entryPrice) * 100;
    const sign = pnl >= 0 ? "+" : "";
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(curPrice)} (${sign}${pnl.toFixed(1)}%)`;
  };
  const priceRowClosed = (s: TrackedSignal) => {
    if (!s.entryPrice) return "";
    const exit = s.exitPrice ?? s.peakPrice;
    if (!exit) return ` | Вход: ${fmtP(s.entryPrice)}`;
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(exit)} (${fmtPct(s.pnlPercent ?? 0)})`;
  };

  const patTag = (s: TrackedSignal) => s.sentimentKey ? ` [${s.sentimentKey}]` : "";

  // Единый форматтер — тот же что в рестарт-уведомлении, /status кнопке и 4ч апдейте
  lines.push(...formatOpenPositionLines(allOpen, priceMap));

  if (profitsToday.length > 0) {
    lines.push(`✅ <b>Закрыто в профит (${profitsToday.length}):</b>`);
    for (const s of profitsToday) {
      lines.push(`  • ${symBase(s.symbol)}${patTag(s)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (buStopsToday.length > 0) {
    lines.push(`🛡 <b>Стоп в БУ (${buStopsToday.length}):</b>`);
    for (const s of buStopsToday) {
      lines.push(`  • ${symBase(s.symbol)}${patTag(s)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (stopsToday.length > 0) {
    lines.push(`❌ <b>Стоп-лосс (${stopsToday.length}):</b>`);
    for (const s of stopsToday) {
      lines.push(`  • ${symBase(s.symbol)}${patTag(s)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (cancelledToday.length > 0) {
    lines.push(`🚫 <b>Отменено сегодня (${cancelledToday.length}):</b>`);
    for (const s of cancelledToday) {
      lines.push(`  • ${symBase(s.symbol)}${patTag(s)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (allOpen.length === 0 && closedToday.length === 0) {
    lines.push(`Сегодня активных сигналов нет.`);
  }

  lines.push(``, `#ежедневный_отчет`);

  await sendTo(lines.join("\n"), targetChatId);

  logger.info("Daily report sent");
}

// ── Weekly digest (09:00 МСК = 06:00 UTC, воскресенье) ───────────────────────
export async function sendWeeklyDigest(targetChatId?: number | string, bypassDedupe = false): Promise<void> {
  if (!targetChatId && !bypassDedupe) {
    const now = new Date();
    const dedupeWindow = new Date(now.getTime() - 10 * 60 * 1000);
    const claimed = await db.update(settingsTable)
      .set({ lastWeeklyDigestAt: now })
      .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_weekly_digest_at IS NULL OR last_weekly_digest_at < ${dedupeWindow})`)
      .returning({ id: settingsTable.id });
    if (claimed.length === 0) {
      logger.info("Weekly digest: уже отправлен другим процессом — пропускаем");
      return;
    }
  }

  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const all = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneWeekAgo}`);

  const profits    = all.filter(s => s.status === "profit");
  const buStops    = all.filter(s => s.status === "bu_stop");
  const stops      = all.filter(s => s.status === "stop_loss");
  const cancelled  = all.filter(s => s.status === "cancelled");
  const accum      = all.filter(s => s.status === "accumulation" || s.status === "re_entry");
  const inRun      = all.filter(s => s.status === "in_run");
  const breakevens = all.filter(s => s.status === "breakeven");

  if (all.length === 0) {
    await sendTo("📊 <b>Еженедельный дайджест</b>\n\nНа этой неделе сигналов не было.", targetChatId);
    return;
  }

  const sorted = [...profits].sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0));
  const medals = ["🥇", "🥈", "🥉"];
  const topProfits = sorted.slice(0, 3);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    const pat = s.sentimentKey ? ` [${s.sentimentKey}]` : "";
    return `${medals[i]} $${s.symbol.replace("-USDT", "")}${pat}${priceStr} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  // TOP ALPHA OF THE WEEK: all signals with >30% profit
  const moonshots = sorted.filter(s => (s.pnlPercent ?? 0) >= 30);
  const moonshotLines = moonshots.map(s => {
    const peak = computePeakPnl(s);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    const pat = s.sentimentKey ? ` [${s.sentimentKey}]` : "";
    return `🚀 ${s.symbol.replace("-USDT", "")}${pat}${priceStr} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`;
  });

  // bu_stop counts as profit for win rate and avg profit calculations
  const winRate = (profits.length + buStops.length + stops.length) > 0
    ? Math.round(((profits.length + buStops.length) / (profits.length + buStops.length + stops.length)) * 100)
    : null;
  const allProfits = [...profits, ...buStops];
  const avgProfit = allProfits.length > 0
    ? allProfits.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) / allProfits.length
    : null;

  const wFmtRow = (s: TrackedSignal) => {
    const base = `$${s.symbol.replace("-USDT", "")}`;
    const pattern = s.sentimentKey ? ` [${s.sentimentKey}]` : "";
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const exitFmt = exit ? fmtP(exit) : null;
    const pnl   = s.pnlPercent ?? 0;
    const sign  = pnl >= 0 ? "+" : "";
    const priceStr = entry && exitFmt ? ` (${entry} → ${exitFmt})` : entry ? ` (Вход: ${entry})` : "";
    return `  • ${base}${pattern}${priceStr} — ${sign}${pnl.toFixed(1)}%`;
  };

  // Stop-loss details
  const stopLines = [...stops]
    .sort((a, b) => (a.pnlPercent ?? 0) - (b.pnlPercent ?? 0))
    .map(s => wFmtRow(s));

  // Cancelled details
  const cancelLines = [...cancelled]
    .sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0))
    .map(s => wFmtRow(s));

  const lines = [
    `🏆 <b>ИТОГИ НЕДЕЛИ: ЛУЧШАЯ АЛЬФА</b>`,
    ``,
    ...(topLines.length > 0 ? topLines : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshotLines.length > 0) {
    lines.push(``, `🌙 <b>TOP ALPHA OF THE WEEK (>+30%):</b>`);
    lines.push(...moonshotLines);
  }

  if (stopLines.length > 0) {
    lines.push(``, `❌ <b>Стоп-лоссы (${stops.length}):</b>`);
    lines.push(...stopLines);
  }

  if (cancelLines.length > 0) {
    lines.push(``, `🚫 <b>Отменённые сигналы (${cancelled.length}):</b>`);
    lines.push(...cancelLines);
  }

  lines.push(
    ``,
    `📊 <b>Статистика:</b>`,
    `✅ Профит: ${profits.length} сигналов`,
    `🛡 Стоп в БУ: ${buStops.length} сигналов`,
    `🚀 В полёте: ${inRun.length} сигналов`,
    `⏳ В накоплении: ${accum.length} сигналов`,
    `❌ Стоп-лосс: ${stops.length} сигналов`,
    `🚫 Отменено: ${cancelled.length} сигналов`,
    `⚖️ Безубыток (7д): ${breakevens.length} сигналов`,
    ...(avgProfit !== null ? [`📈 Средний профит (вкл. БУ): ${fmtPct(avgProfit)}`] : []),
    ...(winRate !== null ? [`🎯 Win Rate (вкл. БУ): ${winRate}%`] : []),
    ``,
    `<i>Мы видим деньги там, где другие видят тишину.</i>`,
    ``,
    `#еженедельный_отчет`,
  );

  await sendTo(lines.join("\n"), targetChatId);

  logger.info({ total: all.length }, "Weekly digest sent");
}

// ── Monthly digest (30 days stats) ───────────────────────────────────────────
export async function sendMonthlyDigest(targetChatId?: number | string): Promise<void> {
  if (!targetChatId) {
    const now = new Date();
    const dedupeWindow = new Date(now.getTime() - 10 * 60 * 1000);
    const claimed = await db.update(settingsTable)
      .set({ lastMonthlyDigestAt: now })
      .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_monthly_digest_at IS NULL OR last_monthly_digest_at < ${dedupeWindow})`)
      .returning({ id: settingsTable.id });
    if (claimed.length === 0) {
      logger.info("Monthly digest: уже отправлен другим процессом — пропускаем");
      return;
    }
  }

  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const all = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneMonthAgo}`);

  const profits    = all.filter(s => s.status === "profit");
  const buStopsM   = all.filter(s => s.status === "bu_stop");
  const stops      = all.filter(s => s.status === "stop_loss");
  const inRun      = all.filter(s => s.status === "in_run");
  const accum      = all.filter(s => s.status === "accumulation" || s.status === "re_entry");
  const breakevens = all.filter(s => s.status === "breakeven");

  if (all.length === 0) {
    await sendTo("📆 <b>Ежемесячный дайджест</b>\n\nЗа последние 30 дней сигналов не было.", targetChatId);
    return;
  }

  const sorted = [...profits].sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0));
  const medals = ["🥇", "🥈", "🥉", "🏅", "🏅"];
  const topProfits = sorted.slice(0, 5);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    const pat = s.sentimentKey ? ` [${s.sentimentKey}]` : "";
    return `${medals[i] ?? "🏅"} $${s.symbol.replace("-USDT", "")}${pat} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  const moonshots = sorted.filter(s => (s.pnlPercent ?? 0) >= 30);
  const winRate = (profits.length + buStopsM.length + stops.length) > 0
    ? Math.round(((profits.length + buStopsM.length) / (profits.length + buStopsM.length + stops.length)) * 100)
    : null;
  const allProfitsM = [...profits, ...buStopsM];
  const avgProfit = allProfitsM.length > 0
    ? allProfitsM.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) / allProfitsM.length
    : null;

  const lines = [
    `📆 <b>ИТОГИ МЕСЯЦА: АЛЬФА-СТАТИСТИКА</b>`,
    `<i>Последние 30 дней</i>`,
    ``,
    ...(topLines.length > 0 ? [`🏆 <b>Топ профитов:</b>`, ...topLines] : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshots.length > 0) {
    lines.push(``, `🚀 <b>Moonshots (>+30%):</b> ${moonshots.length} шт`);
    for (const s of moonshots.slice(0, 5)) {
      const peak = computePeakPnl(s);
      const pat = s.sentimentKey ? ` [${s.sentimentKey}]` : "";
      lines.push(`  • ${s.symbol.replace("-USDT", "")}${pat} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`);
    }
  }

  lines.push(
    ``,
    `📊 <b>Статистика за 30 дней:</b>`,
    `📡 Всего сигналов: ${all.length}`,
    `✅ Профит: ${profits.length}`,
    `🛡 Стоп в БУ: ${buStopsM.length}`,
    `🚀 В полёте: ${inRun.length}`,
    `⏳ В накоплении: ${accum.length}`,
    `❌ Стоп-лосс: ${stops.length}`,
    `⚖️ Безубыток: ${breakevens.length}`,
    ...(avgProfit !== null ? [`📈 Средний профит (вкл. БУ): ${fmtPct(avgProfit)}`] : []),
    ...(winRate !== null ? [`🎯 Win Rate (вкл. БУ): ${winRate}%`] : []),
    ``,
    `#ежемесячный_отчет`,
  );

  await sendTo(lines.join("\n"), targetChatId);

  logger.info({ total: all.length }, "Monthly digest sent");
}

// ── Market Health: OI + Volume snapshot для апдейтов ─────────────────────────
async function fetchMarketHealth(symbol: string): Promise<{ oiPct: number | null; volMult: number | null; fundingRate: number | null; spotVol24h: number | null }> {
  let oiPct: number | null = null;
  let volMult: number | null = null;
  let fundingRate: number | null = null;
  let spotVol24h: number | null = null;
  try {
    const [cgOI, klines, fundingData, spotVol] = await Promise.all([
      getCoinglassOI(symbol).catch(() => null),
      getKlines(symbol, "30m", 6).catch(() => [] as Awaited<ReturnType<typeof getKlines>>),
      getFundingRate(symbol).catch(() => null),
      getCoinglassSpotVolume24h(symbol).catch(() => null),
    ]);
    if (cgOI?.available) {
      oiPct = cgOI.oiChange30m ?? cgOI.oiChange5m ?? null;
    }
    if (klines.length >= 5) {
      const cur = klines[klines.length - 1];
      const hist = klines.slice(0, -1);
      const curVol = (parseFloat(cur.volume) || 0) * (parseFloat(cur.close) || 0);
      const avgVol = hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length;
      volMult = avgVol > 0 ? curVol / avgVol : null;
    }
    if (fundingData?.lastFundingRate != null) {
      fundingRate = parseFloat(fundingData.lastFundingRate);
    }
    spotVol24h = spotVol;
  } catch { /* non-critical */ }
  return { oiPct, volMult, fundingRate, spotVol24h };
}

function buildMarketHealthBlock(
  oiPct: number | null,
  volMult: number | null,
  fundingRate: number | null,
  opts: { showRecommendation?: boolean; spotVol24h?: number | null } = {}
): string {
  const showRec = opts.showRecommendation ?? true;
  const lines: string[] = ["", "📊 <b>Состояние рынка:</b>"];

  if (oiPct !== null) {
    const sign = oiPct >= 0 ? "+" : "";
    if (oiPct >= 3)       lines.push(`📈 OI: ${sign}${oiPct.toFixed(1)}% — позиции набираются ✅`);
    else if (oiPct >= 0)  lines.push(`➡️ OI: ${sign}${oiPct.toFixed(1)}% — стабильно`);
    else if (oiPct >= -5) lines.push(`📉 OI: ${oiPct.toFixed(1)}% — лёгкая разгрузка ⚠️`);
    else                  lines.push(`🔻 OI: ${oiPct.toFixed(1)}% — позиции закрываются ⚠️`);
  }

  if (volMult !== null) {
    if (volMult >= 3)        lines.push(`🔥 Фьюч объём: ${volMult.toFixed(1)}x нормы — горячо`);
    else if (volMult >= 1.5) lines.push(`📊 Фьюч объём: ${volMult.toFixed(1)}x нормы — выше среднего`);
    else if (volMult >= 0.8) lines.push(`➡️ Фьюч объём: ${volMult.toFixed(1)}x нормы — норма`);
    else                     lines.push(`📭 Фьюч объём: ${volMult.toFixed(1)}x нормы — снижается`);
  }

  if (opts.spotVol24h != null) {
    lines.push(`🌐 Спот объём: ${fmtVolM(opts.spotVol24h)} (24ч, Binance+Bybit)`);
  }

  if (fundingRate !== null) {
    const frPct = (fundingRate * 100).toFixed(4);
    const frSign = fundingRate >= 0 ? "+" : "";
    if (fundingRate <= -0.0003)      lines.push(`💰 Фандинг: ${frSign}${frPct}% — шорты в ловушке, сквиз-давление`);
    else if (fundingRate <= -0.0001) lines.push(`💰 Фандинг: ${frSign}${frPct}% — шорты платят, позитивно`);
    else if (fundingRate < 0.0001)   lines.push(`⚖️ Фандинг: ${frSign}${frPct}% — нейтрально`);
    else if (fundingRate < 0.0003)   lines.push(`📈 Фандинг: ${frSign}${frPct}% — лонги платят`);
    else                             lines.push(`⚠️ Фандинг: ${frSign}${frPct}% — лонги перегреты, осторожно`);
  }

  // Итоговая рекомендация — только в hourly-апдейте (showRecommendation=true).
  // В milestone/target-сообщениях НЕ показываем: у них уже есть своя инструкция
  // ("зафиксируй", "переноси стоп"), и добавлять "Держи"/"Рассмотри выход" = конфликт.
  if (showRec) {
    if (oiPct !== null && volMult !== null) {
      const oiGood  = oiPct >= 1;
      const volGood = volMult >= 1.5;
      if (oiGood && volGood)   lines.push(`💪 <b>Держи</b> — оба индикатора подтверждают движение`);
      else if (oiGood)         lines.push(`⏳ <b>Держи</b> — OI строится, фьюч объём немного просел`);
      else if (volGood)        lines.push(`👀 <b>Следи</b> — фьюч объём есть, но OI разгружается`);
      else                     lines.push(`⚠️ <b>Рассмотри выход</b> — импульс угасает`);
    } else if (oiPct !== null) {
      lines.push(oiPct >= 1 ? `💪 <b>Держи</b> — OI подтверждает` : `👀 <b>Следи</b> — OI не растёт`);
    } else if (volMult !== null) {
      lines.push(volMult >= 1.5 ? `💪 <b>Держи</b> — фьюч объём подтверждает` : `👀 <b>Следи</b> — фьюч объём не растёт`);
    }
  }

  if (lines.length <= 1) return ""; // нет данных — не добавляем блок
  return lines.join("\n");
}

// ── Fast cycle (every 2 min): active + in_run for stop-loss / first-target / trailing ──────────
async function runInRunFastCycle(): Promise<void> {
  // Check active, in_run AND re_entry signals every 2 min for fast stop-loss and target detection
  let fastSignals: (typeof trackedSignalsTable.$inferSelect)[] = [];
  // Retry loop: Neon connection pool may be temporarily exhausted by scanner
  // 3 attempts × 5s delay — scanner batch typically releases within ~3s
  let lastFetchErr: unknown = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      fastSignals = await db.select()
        .from(trackedSignalsTable)
        .where(inArray(trackedSignalsTable.status, ["active", "in_run", "re_entry"]));
      lastFetchErr = null;
      break;
    } catch (err) {
      lastFetchErr = err;
      logger.warn({ err, attempt }, `FastCycle: initial fetch attempt ${attempt}/3 failed`);
      if (attempt < 3) await new Promise(r => setTimeout(r, 5_000));
    }
  }
  if (lastFetchErr !== null) {
    logger.error({ err: lastFetchErr }, "FastCycle: initial fetch failed после 3 попыток — пропускаем цикл");
    return;
  }

  logger.info({
    fastSignalsCount: fastSignals.length,
    symbols: fastSignals.map(s => ({ symbol: s.symbol, status: s.status, pnl: s.pnlPercent })),
  }, "DEBUG: fast cycle snapshot");

  logger.info(
    { count: fastSignals.length, symbols: fastSignals.map(s => s.symbol) },
    "FastCycle: начало цикла"
  );
  if (fastSignals.length === 0) return;

  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fastFetchOk = false;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      tickers = await getFutureTickers() as any[];
      fastFetchOk = true;
      break;
    } catch (err) {
      logger.warn({ err, attempt }, `FastCycle: BingX fetch attempt ${attempt}/2 failed`);
      if (attempt < 2) await new Promise(r => setTimeout(r, 3000));
    }
  }
  if (!fastFetchOk) {
    logger.error("FastCycle: не удалось получить цены — стоп-лоссы пропущены в этом цикле");
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  for (const tracked of fastSignals) {
    try {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) {
      // Нет цены в течение >30 минут после обнаружения — монета недоступна на BingX.
      // Авто-отмена с уведомлением. Случай BingX down обработан выше (fastFetchOk gate).
      const ageMs = Date.now() - tracked.detectedAt.getTime();
      const NO_PRICE_CANCEL_MS = 30 * 60_000;
      if (ageMs > NO_PRICE_CANCEL_MS) {
        const claimedNP = await db.update(trackedSignalsTable).set({
          status: "cancelled", closedAt: new Date(), updatedAt: new Date(),
        }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','in_run','re_entry')`)
          .returning({ id: trackedSignalsTable.id });
        if (claimedNP.length > 0) {
          void maybeSeedWhaleWatch(tracked);
          const base = tracked.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;
          const msg = [
            `❌ <b>Позиция отменена — цена недоступна</b>`,
            ``,
            `<b>${tracked.symbol}</b>`,
            `Цена не найдена на BingX более ${Math.round(ageMs / 60_000)}м.`,
            `Монета возможно делистингована или не торгуется на BingX.`,
            ``,
            `<a href="${tvUrl}">График</a>`,
            ``,
            fmtPattern(tracked),
            `${tickerTag(tracked.symbol)} #cancelled`,
          ].filter(Boolean).join("\n");
          const cancelTargets = await getTargets().catch(() => [] as (number | string)[]);
          for (const t of cancelTargets) await sendMessage(t, msg).catch(() => {});
          logger.warn({ symbol: tracked.symbol, ageMin: Math.round(ageMs / 60_000) }, "⚠️ FastCycle: no BingX price — signal auto-cancelled");
        }
      }
      continue;
    }

    const pnl = computePnl(tracked, currentPrice);
    const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
    const peakChanged = newPeak !== tracked.peakPrice;

    logger.info(
      { symbol: tracked.symbol, status: tracked.status, pnl: pnl.toFixed(2), currentPrice, peakChanged },
      "FastCycle: обработка сигнала"
    );

    // Трейлинг активируется только при достижении TRAILING_ACTIVATION_PCT (20%) от входа
    const peakPnlNow = computePnl(tracked, newPeak);
    const prevPeakPnl = tracked.peakPrice ? computePnl(tracked, tracked.peakPrice) : 0;
    const trailingActive = peakPnlNow >= TRAILING_ACTIVATION_PCT;
    const trailingStop = newPeak * (1 - TRAILING_FIXED_PCT / 100);
    // Трейлинг сработал: только если активен и цена пробила уровень вниз
    const trailingHit = trailingActive && currentPrice <= trailingStop;
    // Трейлинг только что активировался в этом цикле (пик пересёк 20%)
    const trailingJustActivated = tracked.status === "in_run"
      && prevPeakPnl < TRAILING_ACTIVATION_PCT
      && peakPnlNow >= TRAILING_ACTIVATION_PCT;

    // ── Сохраняем peak НЕМЕДЛЕННО — до любого continue ──────────────────────
    // Без этого continue в stale-check / OI-extended window пропускают строки
    // 1725-1733 и peak никогда не записывается в БД. Монета бьёт +10%, но
    // следующий цикл читает peak=entry из БД → trailing stop не активируется,
    // milestone не шлётся, сигнал отменяется с peak=entry.
    // GREATEST защищает от гонки двух воркер-процессов.
    if (peakChanged) {
      await db.update(trackedSignalsTable)
        .set({
          peakPrice: sql`GREATEST(COALESCE(${trackedSignalsTable.peakPrice}, ${newPeak}), ${newPeak})`,
          trailingStopLevel: trailingStop,
          updatedAt: new Date(),
        })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }

    const ageMs = Date.now() - tracked.detectedAt.getTime();
    const ageHours = ageMs / 3_600_000;
    const ageDays = ageHours / 24;

    // Hourly update удалён — сопровождение теперь только по триггеру (4h блок ниже)

    // 7d → Breakeven (FastCycle handles this for active/in_run)
    if (ageDays >= MAX_WATCH_DAYS) {
      const claimedBeFast = await db.update(trackedSignalsTable).set({
        status: "breakeven", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','in_run','re_entry')`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedBeFast.length > 0) {
        await broadcast(msgBreakeven(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BREAKEVEN (7d)");
      }
      continue;
    }

    // ── STALE SIGNAL: динамическая авто-отмена на основе OI ─────────────────
    // Логика: НЕ ждём 6-8ч статического окна.
    // С 1ч после входа — проверяем CoinGlass OI каждый цикл (~2 мин).
    // Если OI растёт (+2%+ за 30m/5m) → накопление идёт, продлеваем сигнал.
    // Отменяем ТОЛЬКО когда OI иссяк + рынок мёртв одновременно.
    // Статистика: 0 прибыльных из 98 сигналов где peak < 2% к моменту отмены.
    if (
      tracked.status === "active" &&
      tracked.peakPrice != null &&
      tracked.entryPrice != null &&
      tracked.entryPrice > 0
    ) {
      const peakPct = ((newPeak - tracked.entryPrice) / tracked.entryPrice) * 100;
      if (peakPct < 2.0) {
        // 1ч grace: даём сигналу осесть после входа (PATH A только что выстрелил)
        if (ageHours < 1.0) continue;

        // Hard max-age 72ч: если peak < 2% и сигнал старше 3 дней — отмена без доп. проверок
        // Grace period: в первые 30 мин после рестарта — пропускаем. FastCycle должен
        // успеть перевести сигнал в in_run или обновить peak прежде чем принять решение.
        if (Date.now() - SERVER_STARTED_AT < RESTART_GRACE_MS) {
          logger.info(
            { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
            "⏳ STALE SKIP: restart grace period — stale cancel отложен на 30 мин"
          );
          continue;
        }
        if (ageHours >= 72) {
          const claimedOld = await db.update(trackedSignalsTable).set({
            status: "cancelled",
            exitPrice: currentPrice,
            pnlPercent: pnl,
            closedAt: new Date(),
            updatedAt: new Date(),
          }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`)
            .returning({ id: trackedSignalsTable.id });
          if (claimedOld.length > 0) {
            void maybeSeedWhaleWatch(tracked);
            const { str: oldDur } = hoursAndDays(tracked.detectedAt);
            await broadcast([
              `⏱ <b>${tracked.symbol.replace("-USDT","")}</b> — Сигнал отменён (истёк 72ч лимит)`,
              `Peak < 2% за 3 дня → позиция закрыта принудительно`,
              `Вход: <b>${tracked.entryPrice!.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
              `⏱ Время в позиции: ${oldDur}`,
              ``,
              fmtPattern(tracked),
              `${tickerTag(tracked.symbol)} #stale_cancel #max_age`,
            ].filter(Boolean).join("\n"));
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1), pnl: pnl.toFixed(1) },
              "STALE CANCEL: hard max-age 72ч, peak < 2%"
            );
          }
          continue;
        }

        // ── Шаг 1: проверяем OI — накопление ещё идёт? ───────────────────────
        // Используем oiChange30m как основной (15–30 мин динамика).
        // Fallback на oiChange5m если 30m недоступен.
        // Порог 2%: соответствует "вырос на 2-3% за период ожидания".
        type OiResult = "positive" | "negative" | "error";
        let oiResult: OiResult = "error";
        let freshOiPct: number | null = null;
        try {
          const cgOIFresh = await getCoinglassOI(tracked.symbol);
          freshOiPct = cgOIFresh.oiChange30m ?? cgOIFresh.oiChange5m ?? null;
          if (cgOIFresh.available && freshOiPct !== null) {
            oiResult = freshOiPct >= 2.0 ? "positive" : "negative";
          }
          // available=false или null → error → ждём (не отменяем при недоступности)
        } catch {
          oiResult = "error";
        }

        if (oiResult === "positive") {
          logger.info(
            { symbol: tracked.symbol, ageH: ageHours.toFixed(1), oiPct: freshOiPct?.toFixed(1) },
            "⏳ STALE EXTENDED: OI +2%+ — накопление продолжается, продлеваем"
          );
          continue;
        }
        if (oiResult === "error") {
          logger.info(
            { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
            "⏳ STALE EXTENDED: CoinGlass недоступен — ждём следующего цикла"
          );
          continue;
        }

        // ── Шаг 2: OI иссяк — проверяем рынок перед отменой ─────────────────
        // Объём или стакан ещё живые → ждём ещё один цикл.
        const healthCheck = await fetchMarketHealth(tracked.symbol);
        const obCheck = await getOrderBookAnalysis(tracked.symbol, 20);
        const isVolumeDead = healthCheck.volMult !== null && healthCheck.volMult < 0.5;
        const isBearishOB = obCheck !== null && obCheck.bias === "bear";
        if (!isVolumeDead && !isBearishOB) {
          logger.info(
            { symbol: tracked.symbol, ageH: ageHours.toFixed(1), volMult: healthCheck.volMult, obBias: obCheck?.bias ?? "n/a" },
            "⏳ STALE EXTENDED: OI упал, но объём/стакан ещё держат — продлеваем"
          );
          continue;
        }

        // ── Шаг 3: Smart Cancel Override ─────────────────────────────────────
        // Финальная страховка: strong bid wall или OI за 4ч выше настраиваемого порога.
        try {
          const [scSettings] = await db.select({
            smartCancelOiPct: settingsTable.smartCancelOiPct,
          }).from(settingsTable).limit(1);
          const scOiPct = scSettings?.smartCancelOiPct ?? 5.0;

          const [scOB, scCgOI] = await Promise.all([
            getOrderBookAnalysis(tracked.symbol, 50).catch(() => null),
            getCoinglassOI(tracked.symbol).catch(() => null),
          ]);

          const hasStrongBidWall = scOB?.bias === "strong_bull";
          const oi4h = scCgOI?.oiChange4h ?? null;
          const isOiGrowing4h = oi4h !== null && oi4h >= scOiPct;

          if (hasStrongBidWall || isOiGrowing4h) {
            logger.info(
              {
                symbol: tracked.symbol,
                reason: hasStrongBidWall ? "strong_bid_wall" : "oi_growing_4h",
                obBias: scOB?.bias ?? null,
                oi4h,
                scOiPct,
              },
              "⚡ Smart Cancel Override: отмена предотвращена — бычьи сигналы активны"
            );
            continue;
          }
        } catch (scErr) {
          logger.warn({ err: scErr, symbol: tracked.symbol }, "Smart Cancel: ошибка проверки — продолжаем отмену");
        }

        // ── Отмена: OI + объём + стакан — всё мёртво ─────────────────────────
        const claimedStale = await db.update(trackedSignalsTable).set({
          status: "cancelled",
          exitPrice: currentPrice,
          pnlPercent: pnl,
          closedAt: new Date(),
          updatedAt: new Date(),
        }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`)
          .returning({ id: trackedSignalsTable.id });
        if (claimedStale.length > 0) {
          void maybeSeedWhaleWatch(tracked);
          const { str: staleDur } = hoursAndDays(tracked.detectedAt);
          await broadcast([
            `⏱ <b>${tracked.symbol.replace("-USDT","")}</b> — Сигнал отменён (накопление не подтвердилось)`,
            `OI иссяк, объём и стакан мёртвы → капитал освобождён`,
            `Вход: <b>${tracked.entryPrice.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
            `⏱ Время в позиции: ${staleDur}`,
            ``,
            fmtPattern(tracked),
            `${tickerTag(tracked.symbol)} #stale_cancel`,
          ].filter(Boolean).join("\n"));
          logger.info(
            { symbol: tracked.symbol, ageHours: ageHours.toFixed(1), peakPct: peakPct.toFixed(1) },
            "FastCycle: STALE CANCEL (dynamic OI check, OI+vol+OB dead)"
          );
        }
        continue;
      }
    }

    // BE стоп: active сигнал уже достиг +5% (стоп перенесён), цена вернулась к -10%
    // Позиция была защищена — считается как БУ-стоп (не стоп-лосс)
    if (tracked.status === "active" && (tracked.lastMilestone ?? 0) >= PARTIAL_TARGET && pnl <= -STOP_LOSS) {
      const claimedBEStop = await db.update(trackedSignalsTable).set({
        status: "bu_stop", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedBEStop.length > 0) {
        await broadcast(msgBUStop(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BE STOP (active +5% → back to entry) 🛡");
      }
      continue;
    }

    // Стоп-лосс -10% применяется к ACTIVE и RE_ENTRY (до первой цели)
    if ((tracked.status === "active" || tracked.status === "re_entry") && pnl <= -STOP_LOSS) {
      const claimedSLFast = await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','re_entry')`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedSLFast.length > 0) {
        await broadcast(msgStopLoss(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: STOP LOSS (active/re_entry) ❌");
      }
      continue;
    }

    // Стоп в БУ: in_run, трейлинг ещё не активен, цена вернулась к уровню входа (0%)
    // Позиция защищена — стоп в безубытке считается как прибыль, не как убыток
    if ((tracked.status === "in_run" || tracked.status === "re_entry") && !trailingActive && currentPrice !== undefined && currentPrice <= (tracked.entryPrice ?? 0)) {
      const claimedBU = await db.update(trackedSignalsTable).set({
        status: "bu_stop", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('in_run','re_entry')`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedBU.length > 0) {
        await broadcast(msgBUStop(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BU STOP 🛡");
      }
      continue;
    }

    // Стоп: in_run, трейлинг ещё не активен, цена упала ниже -10% от входа
    // Единый стоп-лосс -10% для всех паттернов и статусов
    if (tracked.status === "in_run" && !trailingActive && pnl <= -STOP_LOSS) {
      const claimedSmallLoss = await db.update(trackedSignalsTable).set({
        status: pnl >= 0 ? "profit" : "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'in_run'`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedSmallLoss.length > 0) {
        await broadcast(msgSmallLossStop(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: SMALL LOSS STOP hit ⚖️");
      }
      continue;
    }

    // ── ТРИГГЕРНОЕ СОПРОВОЖДЕНИЕ ──────────────────────────────────────────────
    // Отправляем ТОЛЬКО когда ситуация реально меняется: OI/объём резко двигается.
    // Нейтральная картина — молчим. Cooldown 4ч между сообщениями одной позиции.
    if ((tracked.status === "active" || tracked.status === "in_run" || tracked.status === "re_entry") && ageMs >= 60 * 60_000) {
      const triggerThreshold = new Date(Date.now() - 4 * 3_600_000 + 5 * 60_000);
      const claimedPeriodic = await db.update(trackedSignalsTable)
        .set({ lastPeriodicUpdateAt: new Date() })
        .where(sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastPeriodicUpdateAt} IS NULL OR ${trackedSignalsTable.lastPeriodicUpdateAt} < ${triggerThreshold})`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedPeriodic.length > 0) {
        try {
          const health4h = await fetchMarketHealth(tracked.symbol);
          const coin = tracked.symbol.replace("-USDT", "");
          const pnlSign = pnl >= 0 ? "+" : "";

          // Сильный бычий сигнал: OI >10% И объём >2x — умные деньги активно закупают
          const oiStrongBull = health4h.oiPct !== null && health4h.oiPct > 10;
          const volConfirmed = health4h.volMult !== null && health4h.volMult >= 2.0;
          // Медвежий сигнал: OI резко падает ИЛИ объём иссяк ИЛИ фандинг уходит в минус
          const oiDraining   = health4h.oiPct !== null && health4h.oiPct < -15;
          const oiFalling    = health4h.oiPct !== null && health4h.oiPct < -5;
          const volDead      = health4h.volMult !== null && health4h.volMult < 0.8;
          const fundingDrain = health4h.fundingRate !== null && health4h.fundingRate < -0.08;

          let holdExitLine: string | null = null;
          if (oiStrongBull && volConfirmed) {
            holdExitLine = `💎 <b>ДЕРЖИ</b> — OI: +${health4h.oiPct!.toFixed(1)}% | Объём: ${health4h.volMult!.toFixed(1)}x — накопление усиливается`;
          } else if (oiDraining || (oiFalling && volDead) || fundingDrain) {
            const reasons: string[] = [];
            if (oiDraining)       reasons.push(`OI просел: ${health4h.oiPct!.toFixed(1)}%`);
            else if (oiFalling)   reasons.push(`OI падает: ${health4h.oiPct!.toFixed(1)}%`);
            if (volDead)          reasons.push(`объём иссяк: ${health4h.volMult!.toFixed(1)}x`);
            if (fundingDrain)     reasons.push(`фандинг: ${health4h.fundingRate!.toFixed(3)}%`);
            holdExitLine = `⚠️ <b>РАССМОТРИ ВЫХОД</b> — ${reasons.join(", ")}`;
          }
          // Нейтральная ситуация → молчим

          if (holdExitLine) {
            const healthBlock4h = buildMarketHealthBlock(health4h.oiPct, health4h.volMult, health4h.fundingRate, { showRecommendation: false, spotVol24h: health4h.spotVol24h });
            const updateMsg = [
              `🔄 <b>${coin}</b> | Вход: ${fmtP(tracked.entryPrice)} → Сейчас: ${fmtP(currentPrice)} (${pnlSign}${pnl.toFixed(1)}%)`,
              ``,
              holdExitLine,
              healthBlock4h,
              `${tickerTag(tracked.symbol)} #position_update`,
            ].filter(Boolean).join("\n");
            await broadcast(updateMsg);
            logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(1), oiPct: health4h.oiPct, volMult: health4h.volMult }, "📊 Trigger update sent");
          } else {
            logger.debug({ symbol: tracked.symbol }, "Trigger check: нейтрально — молчим");
          }
        } catch (err) {
          logger.warn({ err, symbol: tracked.symbol }, "Trigger monitor failed");
        }
      }
    }

    // 24h/48h переход в accumulation удалён — нет спонтанных переходов по времени

    // ── SMART CANCEL v11: Спот CVD 5m + 30m + 1h — все три одновременно минус ──────
    // Единственное основание для отмены. Применяется ко всем паттернам без исключения.
    // Условие: pnl <= -1% (не выбиваем позиции на обычном откате).
    if (tracked.status === "active") {
      try {
        const spotCvdSC = await getSpotCvdMtf(tracked.symbol);
        if (spotCvdSC.available && pnl <= -1) {
          const allThreeNegative =
            spotCvdSC.cvd5m === false &&
            spotCvdSC.cvd30m === false &&
            spotCvdSC.cvd1h === false;
          if (allThreeNegative) {
            const claimedSC = await db.update(trackedSignalsTable).set({
              status: "cancelled", exitPrice: currentPrice, pnlPercent: pnl,
              closedAt: new Date(), updatedAt: new Date(),
            }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} NOT IN ('cancelled','profit','stop_loss','breakeven','bu_stop')`)
              .returning({ id: trackedSignalsTable.id });
            if (claimedSC.length > 0) {
              void maybeSeedWhaleWatch(tracked);
              const base = tracked.symbol.replace("-USDT", "");
              const { str: scDur } = hoursAndDays(tracked.detectedAt);
              await broadcast([
                `🔴 <b>${base}/USDT</b> — Smart Cancel`,
                `Спот CVD 5m + 30m + 1h отрицательные — разворот тренда подтверждён`,
                `Вход: <b>${tracked.entryPrice.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
                `⏱ Время в позиции: ${scDur}`,
                ``,
                fmtPattern(tracked),
                `${tickerTag(tracked.symbol)} #smart_cancel`,
              ].join("\n"));
              logger.info(
                { symbol: tracked.symbol, pnl: pnl.toFixed(1), cvd5m: spotCvdSC.cvd5m, cvd30m: spotCvdSC.cvd30m, cvd1h: spotCvdSC.cvd1h },
                "FastCycle: SMART CANCEL 5m+30m+1h 🔴"
              );
            }
            continue;
          }
        }
      } catch (scErr) {
        logger.debug({ err: scErr, symbol: tracked.symbol }, "Smart Cancel: ошибка — пропускаем");
      }
    }

    // +5%: уведомление о частичной фиксации + переносе стопа в БУ (один раз)
    // Отправляем и продолжаем — в том же цикле может сработать +10%
    // ВАЖНО: нотификация в отдельном try/catch — её ошибка НЕ должна блокировать
    // переход active→in_run (+10%) который идёт следующим в этом же цикле.
    if (tracked.status === "active" && pnl >= PARTIAL_TARGET && (tracked.lastMilestone ?? 0) < PARTIAL_TARGET) {
      const claimed5 = await db.update(trackedSignalsTable).set({
        lastMilestone: PARTIAL_TARGET, peakPrice: newPeak, updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastMilestone} IS NULL OR ${trackedSignalsTable.lastMilestone} < ${PARTIAL_TARGET})`)
        .returning({ id: trackedSignalsTable.id });
      if (claimed5.length > 0) {
        try {
          const health5 = await fetchMarketHealth(tracked.symbol);
          await broadcast(msgPartialTakeProfit(tracked, currentPrice, pnl) + buildMarketHealthBlock(health5.oiPct, health5.volMult, health5.fundingRate, { showRecommendation: false, spotVol24h: health5.spotVol24h }));
          logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(2) }, "FastCycle: PARTIAL TARGET +5% 📌");
        } catch (notifErr) {
          logger.warn({ err: notifErr, symbol: tracked.symbol }, "FastCycle: partial target notification failed (non-critical, continuing to in_run check)");
        }
      }
    }

    // Active → in_run transition (first target)
    if (tracked.status === "active" && pnl >= FIRST_TARGET) {
      const claimedRun = await db.update(trackedSignalsTable).set({
        status: "in_run", peakPrice: newPeak, trailingStopLevel: trailingStop,
        updatedAt: new Date(),
      }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`)
        .returning({ id: trackedSignalsTable.id });
      if (claimedRun.length === 0) continue; // другой процесс уже сделал переход

      // DB уже обновлён в in_run — нотификация в отдельном try/catch, её ошибка не критична
      try {
        const minutesSinceDetection = ageMs / 60000;
        const isLateSignal = minutesSinceDetection < 10 && pnl >= 25;
        if (isLateSignal) {
          await broadcast(msgLateSignal(tracked, currentPrice, pnl));
          logger.info({ symbol: tracked.symbol, pnl, minutesSinceDetection: minutesSinceDetection.toFixed(1) }, "FastCycle: → IN_RUN (late signal) ⚠️");
        } else {
          const health10 = await fetchMarketHealth(tracked.symbol);
          await broadcast(msgFirstTarget(tracked, currentPrice) + buildMarketHealthBlock(health10.oiPct, health10.volMult, health10.fundingRate, { showRecommendation: false, spotVol24h: health10.spotVol24h }));
          logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: → IN_RUN 🚀");
        }
      } catch (notifErr) {
        logger.warn({ err: notifErr, symbol: tracked.symbol }, "FastCycle: in_run notification failed (non-critical, DB already updated)");
      }
      continue;
    }

    // in_run: trailing stop and milestones
    if (tracked.status === "in_run") {
      // Трейлинг только что активировался (пик пересёк +20%)
      if (trailingJustActivated) {
        const claimedTrail = await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date(),
        }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.trailingStopLevel} IS NULL`)
          .returning({ id: trackedSignalsTable.id });
        if (claimedTrail.length === 0) continue; // другой процесс уже активировал трейлинг
        const health15 = await fetchMarketHealth(tracked.symbol);
        await broadcast(msgTrailingActivated(tracked, currentPrice, trailingStop) + buildMarketHealthBlock(health15.oiPct, health15.volMult, health15.fundingRate, { showRecommendation: false, spotVol24h: health15.spotVol24h }));
        logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(2), trailingStop }, "FastCycle: TRAILING ACTIVATED 🚀");
        continue;
      }

      // Трейлинг сработал — фиксируем прибыль
      if (trailingHit && newPeak !== tracked.entryPrice) {
        const peakPnl = computePeakPnl({ ...tracked, peakPrice: newPeak });
        const claimedProfit = await db.update(trackedSignalsTable).set({
          status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
          peakPrice: newPeak, trailingStopLevel: trailingStop,
          closedAt: new Date(), updatedAt: new Date(),
        }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'in_run'`)
          .returning({ id: trackedSignalsTable.id });
        if (claimedProfit.length === 0) continue; // другой процесс уже закрыл
        await broadcast(msgTrailingStopHit(tracked, currentPrice, peakPnl, pnl));
        logger.info({ symbol: tracked.symbol, pnl, peakPnl }, "FastCycle: TRAILING STOP hit 🏁");
        continue;
      }

      const reachedMilestone = nextMilestone(tracked.lastMilestone, pnl);
      if (reachedMilestone) {
        const claimedMs = await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop,
          lastMilestone: reachedMilestone, updatedAt: new Date(),
        }).where(sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastMilestone} IS NULL OR ${trackedSignalsTable.lastMilestone} < ${reachedMilestone})`)
          .returning({ id: trackedSignalsTable.id });
        if (claimedMs.length === 0) continue; // другой процесс уже отправил этот milestone
        const healthMs = await fetchMarketHealth(tracked.symbol);
        await broadcast(msgMilestone(tracked, reachedMilestone, currentPrice, trailingStop) + buildMarketHealthBlock(healthMs.oiPct, healthMs.volMult, healthMs.fundingRate, { showRecommendation: false, spotVol24h: healthMs.spotVol24h }));
        logger.info({ symbol: tracked.symbol, milestone: reachedMilestone }, "FastCycle: MILESTONE 🎯");
        continue;
      }

      if (peakChanged) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
      }
    } else if (peakChanged) {
      // Update peak for active signals silently
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }
    } catch (err) {
      logger.error({ err, symbol: tracked.symbol }, "FastCycle: ошибка обработки сигнала (пропускаем)");
    }
  }
}

// ── OI Watch: message when volume finally confirms ────────────────────────────
function msgOiWatchFired(w: OiWatch, currentPrice: number, volMult: number, priceMovePct: number): string {
  const priceSinceWatch = ((currentPrice - w.priceAtEntry) / w.priceAtEntry * 100);
  const waitMin = Math.round((Date.now() - w.addedAt.getTime()) / 60_000);
  const tag = `#${w.symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
  const priceSign = priceMovePct >= 0 ? "+" : "";
  const pswSign = priceSinceWatch >= 0 ? "+" : "";
  const oiSign = w.oiChange >= 0 ? "+" : "";

  // Формат OI: показываем все доступные ТФ (5m / 30m / 1h)
  const oiParts: string[] = [];
  const fmtOi = (v: number) => `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`;
  if (w.oi5mChange  != null) oiParts.push(`5m:${fmtOi(w.oi5mChange)}`);
  if (w.oi30mChange != null) oiParts.push(`30m:${fmtOi(w.oi30mChange)}`);
  if (w.oi1hChange  != null) oiParts.push(`1h:${fmtOi(w.oi1hChange)}`);
  const oiDisplay = `ОИ: ${oiParts.length > 0 ? oiParts.join(" / ") : `${oiSign}${w.oiChange.toFixed(1)}%`}`;

  return [
    `⚡️ <b>ALPHA DETECTED: ${w.symbol}</b>`,
    ``,
    `🔹 <b>TECH:</b> Фьюч ${volMult.toFixed(1)}x | ${oiDisplay} | Price ${priceSign}${priceMovePct.toFixed(1)}%`,
    ``,
    `💰 <b>Цена:</b> ${fmtP(currentPrice)} | Вход в watch: ${fmtP(w.priceAtEntry)} (${pswSign}${priceSinceWatch.toFixed(1)}%)`,
    ``,
    `🔭 OI Watch: наблюдал <b>${waitMin} мин</b> — фьюч объём подтвердился (${volMult.toFixed(1)}x нормы)`,
    ``,
    `${tag} #oi_watch`,
  ].join("\n");
}

// ── Whale Futures Cycle: checks every 2 min for retail futures confirmation ────
// Phase 1 detection in scanner.ts adds entries. This cycle fires the signal.
// Confirmation: taker netBuyPct >= 15% AND fundingRate >= 0.
export async function runWhaleFuturesCycle(): Promise<void> {
  const now = new Date();

  // Expire stale entries (>72h without confirmation)
  try {
    await db.update(whaleFuturesWatchlistTable)
      .set({ status: "expired" })
      .where(and(eq(whaleFuturesWatchlistTable.status, "watching"), lt(whaleFuturesWatchlistTable.expiresAt, now)));
  } catch { /* non-critical */ }

  const watching = await db.select()
    .from(whaleFuturesWatchlistTable)
    .where(eq(whaleFuturesWatchlistTable.status, "watching"));

  if (watching.length === 0) return;

  const WF_TAKER_BUY_PCT_MIN = 15; // % netBuyPct (taker buy volume dominance)

  for (const entry of watching) {
    try {
      // Update check counter + lastCheckedAt
      await db.update(whaleFuturesWatchlistTable)
        .set({ checkCount: entry.checkCount + 1, lastCheckedAt: now })
        .where(eq(whaleFuturesWatchlistTable.id, entry.id));

      // ── Whale Watch (type='spot') — спот-накопление ───────────────────────────
      if (entry.type === "spot") {
        // Fetch current futures price (used as spot price proxy — same ticker)
        let spotCurrentPrice = entry.priceAtDetection;
        try {
          const tickers = await getFutureTickers();
          const t = tickers.find(x => x.symbol === entry.symbol);
          if (t) spotCurrentPrice = parseFloat(t.lastPrice);
        } catch { /* fallback to detection price */ }

        const priceMovePct = ((spotCurrentPrice - entry.priceAtDetection) / entry.priceAtDetection) * 100;

        // Hard price gates: сигнал невалиден если цена улетела или упала сильно
        if (priceMovePct < -3) { continue; }   // -3% → ждём
        if (priceMovePct > 15) {                // >15% → опоздали, expire
          await db.update(whaleFuturesWatchlistTable)
            .set({ status: "expired" })
            .where(eq(whaleFuturesWatchlistTable.id, entry.id));
          logger.info({ symbol: entry.symbol, priceMovePct }, "WhaleWatchSpot: цена ушла >15% — expire");
          continue;
        }

        // Spot CVD confirmation (no HTTP if Coinglass is down — returns null)
        const spotCvd = await getSpotCvdMtf(entry.symbol).catch(() => null);
        const cvdPositive = spotCvd?.available === true && spotCvd.cvd5m === true;

        // Fire condition (OR): CVD подтверждён повторно ИЛИ цена сдвинулась +1.5%
        const shouldFire = (entry.checkCount >= 1 && cvdPositive) || (priceMovePct >= 1.5);

        if (!shouldFire) {
          logger.debug(
            { symbol: entry.symbol, checkCount: entry.checkCount, cvdPositive, priceMovePct: priceMovePct.toFixed(2) },
            "WhaleWatchSpot: ждём подтверждения"
          );
          continue;
        }

        // ── Atomic claim ───────────────────────────────────────────────────────
        const spotFired = await db.update(whaleFuturesWatchlistTable)
          .set({ status: "fired", firedAt: now })
          .where(and(
            eq(whaleFuturesWatchlistTable.id, entry.id),
            eq(whaleFuturesWatchlistTable.status, "watching"),
          ))
          .returning({ id: whaleFuturesWatchlistTable.id });

        if (spotFired.length === 0) continue; // другой процесс уже забрал

        // ── Telegram spot alert ────────────────────────────────────────────────
        const tvUrl = `https://www.tradingview.com/chart/?symbol=BYBIT:${entry.symbol.replace("-", "")}`;
        const oi = entry.oi1hAtDetection ?? entry.oi30mAtDetection ?? 0;
        const spotText =
          `🐳 <b>Китовое Накопление (Спот)</b>\n` +
          `<b>${entry.symbol}</b> | Цена: <b>$${spotCurrentPrice.toPrecision(4)}</b>` +
          (priceMovePct >= 0.1 ? ` (+${priceMovePct.toFixed(1)}%)` : "") + `\n` +
          `OI при детектировании: <b>${oi >= 0 ? "+" : ""}${oi.toFixed(1)}%</b>\n` +
          `CVD спот: ${cvdPositive ? "✅ положительный" : "🔹 нейтральный"}\n` +
          `Действие: <b>🌱 Спот накопление</b>\n` +
          `<a href="${tvUrl}">TradingView</a>`;

        try {
          await adminBroadcast(spotText);
          logger.info(
            { symbol: entry.symbol, priceMovePct: priceMovePct.toFixed(2), cvdPositive },
            "🐳 WHALE WATCH SPOT: подтверждён → алерт отправлен"
          );
        } catch (err) {
          logger.error({ err, symbol: entry.symbol }, "WhaleWatchSpot: broadcast failed");
        }
        continue;
      }

      // ── Confirmation: retail taker flow + funding rate ────────────────────────
      // Both must be positive to confirm retail is opening long futures positions.
      const [takerFlow, fundingData] = await Promise.allSettled([
        getCoinglassTakerFlow(entry.symbol),
        getFundingRate(entry.symbol),
      ]);

      const taker = takerFlow.status === "fulfilled" ? takerFlow.value : null;
      const funding = fundingData.status === "fulfilled" ? fundingData.value : null;

      const fundingRateVal = funding !== null ? parseFloat(funding.lastFundingRate) : NaN;
      // takerOk: если CoinGlass недоступен (timeout/null) — пропускаем этот фильтр.
      // Все остальные гейты (OI, spotCvd, funding, price, volume) по-прежнему работают.
      // Это предотвращает вечную блокировку watchlist-записей из-за нестабильности CoinGlass API.
      const takerOk   = taker === null // CoinGlass недоступен → degraded mode, пропускаем
        || (typeof taker.netBuyPct === "number" && taker.netBuyPct >= WF_TAKER_BUY_PCT_MIN);
      const fundingOk = !isNaN(fundingRateVal) && fundingRateVal >= 0;

      if (taker === null) {
        logger.info({ symbol: entry.symbol }, "WhaleFutures: CoinGlass taker недоступен — taker-гейт пропущен (degraded mode)");
      }
      logger.debug(
        { symbol: entry.symbol, netBuyPct: taker?.netBuyPct, fundingRate: fundingRateVal, takerOk, fundingOk },
        "WhaleFutures: check"
      );

      if (!takerOk || !fundingOk) continue;

      // ── OI gate (проверяем ДО клейма) ────────────────────────────────────────
      // OI при детектировании должен быть положительным и значимым.
      // Отрицательный OI = открываются ШОРТЫ, а не лонги → expire навсегда.
      // Слабый OI (<1.5%) = недостаточное давление кита → expire навсегда.
      const oiMain = entry.oi1hAtDetection ?? entry.oi30mAtDetection ?? 0;
      if (oiMain < 0) {
        await db.update(whaleFuturesWatchlistTable)
          .set({ status: "expired" })
          .where(eq(whaleFuturesWatchlistTable.id, entry.id));
        logger.info({ symbol: entry.symbol, oiMain }, "WhaleFutures: OI отрицательный (шорты) — сигнал отменён");
        continue;
      }
      if (oiMain < 3.0) {
        await db.update(whaleFuturesWatchlistTable)
          .set({ status: "expired" })
          .where(eq(whaleFuturesWatchlistTable.id, entry.id));
        logger.info({ symbol: entry.symbol, oiMain }, "WhaleFutures: OI слабый (<3.0%) — сигнал отменён");
        continue;
      }

      // ── Fetch price + vol ДО атомарного клейма ───────────────────────────────
      // Price gate должен пройти до того как захватываем запись.
      // Если цена падает → остаёмся в "watching" и проверяем снова через 2 мин.
      const WF_MIN_VOL24H_USD = 1_000_000; // Minimum 24h futures volume to fire signal
      let currentPrice = entry.priceAtDetection;
      let quoteVol24h  = 0;
      try {
        const tickers = await getFutureTickers();
        const t = tickers.find(x => x.symbol === entry.symbol);
        if (t) {
          currentPrice = parseFloat(t.lastPrice);
          quoteVol24h  = parseFloat(t.quoteVolume) || 0;
        }
      } catch { /* use detection price as fallback */ }

      // Skip signals with no meaningful futures volume (protects against ghost/thin markets)
      if (quoteVol24h < WF_MIN_VOL24H_USD) {
        logger.info(
          { symbol: entry.symbol, quoteVol24h, minRequired: WF_MIN_VOL24H_USD },
          "WhaleFutures: skipped — insufficient futures volume"
        );
        continue;
      }

      const priceConfirmPct = ((currentPrice - entry.priceAtDetection) / entry.priceAtDetection) * 100;

      // ── Price gate: цена не должна падать или уйти слишком далеко ───────────
      if (priceConfirmPct < -2) {
        logger.debug(
          { symbol: entry.symbol, priceConfirmPct: priceConfirmPct.toFixed(2) + "%" },
          "WhaleFutures: цена падает >2% — откладываем выстрел до следующего цикла"
        );
        continue; // stays "watching", retries in 2 min
      }
      if (priceConfirmPct > 5) {
        logger.info(
          { symbol: entry.symbol, priceConfirmPct: priceConfirmPct.toFixed(2) + "%" },
          "WhaleFutures: цена ушла >5% — слишком поздно, пропускаем"
        );
        continue; // stays "watching", может выстрелить позже при откате
      }

      // Если запись старше 24ч и цена уже ушла >3% — поезд ушёл, expire
      const ageHours = (now.getTime() - entry.detectedAt.getTime()) / 3_600_000;
      if (ageHours > 24 && priceConfirmPct > 3) {
        await db.update(whaleFuturesWatchlistTable)
          .set({ status: "expired" })
          .where(eq(whaleFuturesWatchlistTable.id, entry.id));
        logger.info({ symbol: entry.symbol, ageHours: ageHours.toFixed(1), priceConfirmPct }, "WhaleFutures: старая запись + цена ушла → expired");
        continue;
      }

      // ── Spot volume gate (ДО атомарного клейма) ─────────────────────────────
      // Кит+Розница: спот-объём >= 0.3% MCap — только процентный порог.
      // Если свежий MCap недоступен — берём из SpotPool кэша (stale, 30 мин).
      // Нет спота → continue (не expired, попробуем в следующем цикле).
      const WF_MIN_SPOT_MCAP_PCT = 0.003; // 0.3%
      const [spotVol24h, wfMcapData] = await Promise.all([
        getCoinglassSpotVolume24h(entry.symbol).catch(() => null),
        fetchMarketCap(entry.symbol).catch(() => null),
      ]);
      const wfMcapUsd = wfMcapData?.mcap ?? getSpotPoolEntry(entry.symbol)?.mcapUsd ?? null;
      if (spotVol24h === null) {
        logger.info({ symbol: entry.symbol }, "WhaleFutures: нет данных спота — пропускаем цикл");
        continue; // stays "watching"
      }
      if (wfMcapUsd === null || spotVol24h < wfMcapUsd * WF_MIN_SPOT_MCAP_PCT) {
        const pct = wfMcapUsd ? (spotVol24h / wfMcapUsd * 100).toFixed(3) : "нет MCap";
        logger.info(
          { symbol: entry.symbol, spotVol24h, wfMcapUsd, pct },
          "WhaleFutures: спот-объём < 0.3% MCap — пропускаем цикл"
        );
        continue; // stays "watching"
      }

      // ── Клеймим атомарно — только после прохождения всех гейтов ─────────────
      // Mark as fired in DB (atomic UPDATE+RETURNING dedup guard)
      const fired = await db.update(whaleFuturesWatchlistTable)
        .set({ status: "fired", firedAt: now })
        .where(and(
          eq(whaleFuturesWatchlistTable.id, entry.id),
          eq(whaleFuturesWatchlistTable.status, "watching"),
        ))
        .returning({ id: whaleFuturesWatchlistTable.id });

      if (fired.length === 0) continue; // Already fired by another process

      // Insert into signals table
      const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BYBIT:${entry.symbol.replace("-", "")}`;
      const bingxUrl       = `https://bingx.com/en-us/perpetual/${entry.symbol}/`;

      let insertedSignalId: number | undefined;
      try {
        const inserted = await db.insert(signalsTable).values({
          symbol:             entry.symbol,
          type:               "alpha",
          value:              oiMain,
          threshold:          2.0,
          price:              currentPrice,
          priceChangePercent: priceConfirmPct,
          volume24h:          quoteVol24h,
          avgVolume:          0,
          openInterest:       null,
          oiChangePercent:    oiMain,
          fundingRate:        isNaN(fundingRateVal) ? null : fundingRateVal,
          tradingViewUrl,
          sentiment:          "Кит + Розница",
          sentimentKey:       "whale_futures",
          alphaScore:         7,
          isContinuing:       false,
          cumulativeOiChange: oiMain,
        }).returning({ id: signalsTable.id });
        insertedSignalId = inserted[0]?.id;
      } catch (err) {
        logger.error({ err, symbol: entry.symbol }, "WhaleFutures: failed to insert signal");
        continue;
      }

      // Track the signal — must succeed before broadcasting
      if (!insertedSignalId) continue;

      let wfTracked: Awaited<ReturnType<typeof trackSignal>> = false;
      try {
        wfTracked = await trackSignal({
          symbol:       entry.symbol,
          signalId:     insertedSignalId,
          signalType:   "alpha",
          sentiment:    "Кит + Розница",
          sentimentKey: "whale_futures",
          alphaScore:   7,
          entryPrice:   currentPrice,
          entryOi:      null,
        });
      } catch (err) {
        logger.warn({ err, symbol: entry.symbol }, "WhaleFutures: trackSignal failed — broadcast отменён");
      }
      if (wfTracked === false || wfTracked === "skip") {
        logger.info({ symbol: entry.symbol, result: wfTracked }, "WhaleFutures: trackSignal вернул skip/false — broadcast пропущен");
        continue;
      }

      // Broadcast via unified Telegram template
      const alphaResult: AlphaResult = {
        symbol:               entry.symbol,
        grade:                "alpha",
        price:                currentPrice,
        priceChange30m:       priceConfirmPct,
        currentVolume:        quoteVol24h,
        avgVolume:            0,
        volumeMultiplier:     quoteVol24h >= 50_000_000 ? 3.0 : quoteVol24h >= 10_000_000 ? 2.0 : 1.0,
        oiChangePercent:      oiMain,
        openInterest:         null,
        cmcRank:              null,
        cmcSource:            null,
        cmcAvailable:         false,
        liquidationsUsd:      null,
        liquidationsMultiple: null,
        coinglassAvailable:   false,
        sentiment:            "Кит + Розница",
        sentimentKey:         "whale_futures",
        traderAction:         "LONG (кит — спот, розница — фьючи, стоп -5%)",
        alphaScore:           7,
        isContinuing:         false,
        cumulativeOiChange:   oiMain,
        tradingViewUrl,
        bingxUrl,
        oiTriggerTf:          "30m+1h",
        oiChange1h:           entry.oi1hAtDetection ?? null,
        fundingRate:          isNaN(fundingRateVal) ? null : fundingRateVal,
        priceConfirmPct:      priceConfirmPct,
        spotVol24h,
        marketCapUsd:         wfMcapUsd,
      };

      try {
        await broadcastBatchAlert([alphaResult]);
        logger.info(
          { symbol: entry.symbol, netBuyPct: taker!.netBuyPct, fundingRate: fundingRateVal, priceConfirmPct: priceConfirmPct.toFixed(2) + "%" },
          "🐳 WHALE FUTURES: подтверждён розницей → сигнал отправлен"
        );
      } catch (err) {
        logger.error({ err, symbol: entry.symbol }, "WhaleFutures: broadcast failed");
      }
    } catch (err) {
      logger.error({ err, symbol: entry.symbol }, "WhaleFutures: check error");
    }
  }
}

// ── Spot Price Tracking: update price snapshots for fired spot entries ────────
// Runs every 2 min alongside fast cycle. No HTTP for symbols already expired.
export async function runWhaleWatchSpotPriceTracking(): Promise<void> {
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  // Only track fired spot entries within last 7 days that still need tracking
  let spotFired: Array<{
    id: number; symbol: string; priceAtDetection: number;
    firedAt: Date | null;
    price24hPct: number | null; price48hPct: number | null; price7dMaxPct: number | null;
  }>;
  try {
    const rows = await db.select({
      id:               whaleFuturesWatchlistTable.id,
      symbol:           whaleFuturesWatchlistTable.symbol,
      priceAtDetection: whaleFuturesWatchlistTable.priceAtDetection,
      firedAt:          whaleFuturesWatchlistTable.firedAt,
      price24hPct:      whaleFuturesWatchlistTable.price24hPct,
      price48hPct:      whaleFuturesWatchlistTable.price48hPct,
      price7dMaxPct:    whaleFuturesWatchlistTable.price7dMaxPct,
    }).from(whaleFuturesWatchlistTable)
      .where(and(
        eq(whaleFuturesWatchlistTable.status, "fired"),
        eq(whaleFuturesWatchlistTable.type, "spot"),
        gte(whaleFuturesWatchlistTable.firedAt!, sevenDaysAgo),
      ));
    spotFired = rows as typeof spotFired;
  } catch (err) {
    logger.warn({ err }, "SpotPriceTracking: DB fetch failed — skip");
    return;
  }

  if (spotFired.length === 0) return;

  // Batch fetch current prices
  let priceMap = new Map<string, number>();
  try {
    const tickers = await getFutureTickers();
    for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice));
  } catch (err) {
    logger.warn({ err }, "SpotPriceTracking: tickers fetch failed — skip");
    return;
  }

  const now = Date.now();
  for (const entry of spotFired) {
    if (!entry.firedAt) continue;
    const currentPrice = priceMap.get(entry.symbol);
    if (!currentPrice || entry.priceAtDetection <= 0) continue;

    const msSinceFired = now - new Date(entry.firedAt).getTime();
    const changePct = ((currentPrice - entry.priceAtDetection) / entry.priceAtDetection) * 100;

    const updates: Partial<{
      price24hPct: number; price48hPct: number; price7dMaxPct: number;
    }> = {};

    // Snapshot at 24h (write once)
    if (msSinceFired >= 24 * 3600_000 && entry.price24hPct == null)
      updates.price24hPct = Number(changePct.toFixed(2));

    // Snapshot at 48h (write once)
    if (msSinceFired >= 48 * 3600_000 && entry.price48hPct == null)
      updates.price48hPct = Number(changePct.toFixed(2));

    // 7d max — always update to running maximum
    const newMax = Math.max(entry.price7dMaxPct ?? -Infinity, changePct);
    if (newMax > (entry.price7dMaxPct ?? -Infinity))
      updates.price7dMaxPct = Number(newMax.toFixed(2));

    if (Object.keys(updates).length === 0) continue;

    try {
      await db.update(whaleFuturesWatchlistTable)
        .set(updates)
        .where(eq(whaleFuturesWatchlistTable.id, entry.id));
    } catch (err) {
      logger.warn({ err, symbol: entry.symbol }, "SpotPriceTracking: update failed");
    }
  }
}

// ── OI Watch Cycle: checks every 2 min for volume/price confirmation ──────────
export async function runOiWatchCycle(): Promise<void> {
  const now = new Date();

  // Expire stale entries
  try {
    await db.update(oiWatchTable)
      .set({ status: "expired" })
      .where(and(eq(oiWatchTable.status, "watching"), lt(oiWatchTable.expiresAt, now)));
  } catch { /* non-critical */ }

  const watching = await db.select()
    .from(oiWatchTable)
    .where(eq(oiWatchTable.status, "watching"));

  if (watching.length === 0) return;

  // Fetch all prices in one call
  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch { return; }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  for (const w of watching) {
    const currentPrice = priceMap.get(w.symbol);
    if (!currentPrice) continue;

    const priceMovePct = ((currentPrice - w.priceAtEntry) / w.priceAtEntry) * 100;

    // ── PATH A: Confirmed signal (vol was already ≥ 2x at scanner time) ────────
    // Full payload stored — re-confirm price didn't collapse, then fire full signal.
    if (w.isVolConfirmed && w.signalPayload) {
      const pathAPayload = w.signalPayload as { alphaResult: any; signalRow: any };
      const pathASentimentKey: string = pathAPayload.alphaResult?.sentimentKey ?? "";

      // ── UNIFIED PRICE CONFIRMATION GATE ──────────────────────────────────────
      // Сигнал публикуется ТОЛЬКО если цена уже реально двинулась с момента обнаружения.
      // Статистика: 0 прибыльных сделок из 98 сигналов где итоговый пик < 3%.
      // Окно мониторинга 90 мин — либо цена подтверждает движение, либо сигнал тихо истекает.
      const PRICE_CONFIRM_PCT: Record<string, number> = {
        bear_trap:            0.8,  // OI растёт при падении цены → CVD дивергенция подтверждает
        short_squeeze:        1.0,  // OI падает + цена летит → быстрый сквиз
        aggressive_breakout:  1.5,  // уже взрывной объём — порог ниже
        sharp_impulse:        1.5,  // импульс на объёме — порог ниже
        impulse_breakout:     1.5,
        early_ignition:       1.5,  // импульсный паттерн — подтверждаем +1.5% за 45 мин
        hidden_accumulation:  2.0,  // detectSentiment уже требует +2% при входе — не удваиваем
        bullish_accumulation: 2.0,
        anomaly:              3.5,  // нет чёткого паттерна → высокий порог
      };
      // 4h_momentum — медленный грайнд уже подтверждён 4ч данными (price4h >= 4%, volMult4h >= 1.2x).
      // Требовать +2% ЕЩЁ в 90 мин = сигнал никогда не стреляет при грайнде.
      // 0.3% = просто проверяем что цена не развернулась в дамп, а движение продолжается.
      const minPriceMove = w.triggerTf === "4h_momentum"
        ? 0.3
        : (PRICE_CONFIRM_PCT[pathASentimentKey] ?? 2.0);

      // Если цена ещё не дошла до порога — ждём следующего цикла (не удаляем запись)
      if (priceMovePct < minPriceMove) {
        logger.debug(
          { symbol: w.symbol, pattern: pathASentimentKey, priceMovePct: priceMovePct.toFixed(1), required: minPriceMove },
          `OI Watch: ждём подтверждения цены — нужно +${minPriceMove}%, сейчас ${priceMovePct.toFixed(1)}%`
        );
        continue;
      }

      // Hard dump cancel: если цена упала > 5% с начала watch — монета не туда идёт
      if (priceMovePct < -5) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info({ symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) }, "OI Watch: отменён (дамп > 5% с начала watch)");
        continue;
      }

      // CVD финальная проверка: если продажи доминируют в момент выстрела — отменяем
      const cvd = await fetchCVD(w.symbol);
      if (cvd && !cvd.positive) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%" },
          "🔴 OI Watch: CVD негативный при выстреле — сигнал отменён"
        );
        continue;
      }
      if (cvd) {
        logger.info(
          { symbol: w.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%" },
          "🟢 OI Watch: CVD подтверждён — стреляем"
        );
      }

      try {
        const payload = w.signalPayload as { alphaResult: any; signalRow: InsertSignal };
        const alphaResult = payload.alphaResult;
        const signalRow   = payload.signalRow;

        // ── Spot volume gate (OI Watch PATH A) ──────────────────────────────────
        // Проверяем спот-объём перед выстрелом — токены без реального спот-рынка
        // не должны попадать к подписчикам даже если OI/объём на фьючах аномальные.
        let paSpotVol24h: number | null = null;
        let paMcapUsdA: number | null = null;
        {
          const [paSpotVol, paMcapRaw] = await Promise.all([
            getCoinglassSpotVolume24h(w.symbol).catch(() => null),
            fetchMarketCap(w.symbol).catch(() => null),
          ]);
          paMcapUsdA = paMcapRaw?.mcap ?? null;
          if (paSpotVol === null) {
            // CoinGlass временно недоступен — не отменяем сигнал, пропускаем spot gate
            logger.warn({ symbol: w.symbol }, "OI Watch PATH A: CoinGlass spot недоступен — degraded mode, spot gate пропущен");
          } else {
            paSpotVol24h = paSpotVol;
            if (paMcapUsdA === null || paSpotVol < paMcapUsdA * 0.0015) {
              await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
              const pct = paMcapUsdA ? (paSpotVol / paMcapUsdA * 100).toFixed(3) : "нет MCap";
              logger.info(
                { symbol: w.symbol, paSpotVol, paMcapUsdA, pct },
                "OI Watch PATH A: спот-объём < 0.15% MCap — сигнал отменён"
              );
              continue;
            }
          }
        }

        // Атомарно захватываем запись ПЕРВЫМ — гарантирует что только один PID
        // вставит сигнал в БД и отправит Telegram (при параллельном деплое).
        // Раньше: insert → trackSignal → claim → broadcast (оба PID вставляли в signals до claim).
        // Теперь: claim → insert → trackSignal → broadcast (только победивший PID пишет в БД).
        const claimedA = await db.update(oiWatchTable)
          .set({ status: "fired", firedAt: new Date() })
          .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
          .returning({ id: oiWatchTable.id });
        if (claimedA.length === 0) continue; // другой PID уже обработал — пропускаем

        // Insert signal to DB (только один PID дошёл до этой строки)
        const [inserted] = await db.insert(signalsTable).values({
          ...signalRow,
          price: currentPrice, // обновляем до текущей рыночной цены
          detectedAt: new Date(),
        }).returning();

        // Start tracking (stop-loss / targets) — проверяем успех
        const tracked = await trackSignal({
          symbol: w.symbol,
          signalId: inserted.id,
          signalType: alphaResult.grade ?? "alpha",
          sentiment: alphaResult.sentiment,
          sentimentKey: alphaResult.sentimentKey,
          alphaScore: alphaResult.alphaScore,
          entryPrice: currentPrice,
          entryOi: alphaResult.openInterest > 0 ? alphaResult.openInterest : null,
        });
        if (tracked === false) {
          logger.error({ symbol: w.symbol }, "PATH A: trackSignal упал — broadcast отменён (слежка не создана)");
          continue;
        }
        if (tracked === "skip") {
          logger.info({ symbol: w.symbol }, "PATH A: монета уже в трекере — broadcast всё равно отправляем (claim атомарный)");
        }

        // Send full Telegram alert — включаем priceConfirmPct: насколько цена уже прошла
        await broadcastBatchAlert([{ ...alphaResult, price: currentPrice, priceConfirmPct: priceMovePct, spotVol24h: paSpotVol24h, marketCapUsd: paMcapUsdA }]);

        logger.info(
          { symbol: w.symbol, grade: alphaResult.grade, alphaScore: alphaResult.alphaScore, priceMovePct: priceMovePct.toFixed(1) },
          "✅ OI Watch → ПОЛНЫЙ СИГНАЛ: подтверждён и отправлен"
        );
      } catch (err) {
        logger.error({ err, symbol: w.symbol }, "OI Watch: ошибка при firing confirmed signal");
      }
      continue; // не падаем в PATH B
    }

    // ── PATH B: Unconfirmed watch (vol was < 2x at scanner time) ────────────────
    // Waiting for volume spike or price breakout to fire a lightweight alert.
    if (priceMovePct < -8) {
      await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
      logger.info({ symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) }, "OI Watch: expired (price dumped)");
      continue;
    }

    // Если цена уже улетела >20% от точки входа в watch — памп уже случился.
    // Входить сейчас = покупать на хае. BLEND: +61% от точки входа → не стреляем.
    if (priceMovePct >= 20) {
      // Атомарно захватываем запись (AND status='watching') — гарантирует что только один
      // процесс отправит уведомление при параллельном запуске двух инстансов во время деплоя.
      const claimed = await db.update(oiWatchTable)
        .set({ status: "expired" })
        .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
        .returning({ id: oiWatchTable.id });
      if (claimed.length === 0) continue; // другой процесс уже обработал
      logger.info(
        { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
        "OI Watch PATH B: expired — памп уже случился (price >= 20% от входа в watch)"
      );
      // Уведомляем — монета улетела пока наблюдали, сигнал упущен
      const coin = w.symbol.replace("-USDT", "");
      const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${coin}USDT.P`;
      await broadcast(
        `👀 <b>#${coin}: ПАМП ПРОПУЩЕН</b>\n\n` +
        `Монета была в наблюдении (OI накапливался), но памп случился раньше чем объём подтвердился.\n\n` +
        `Движение от точки обнаружения: <b>+${priceMovePct.toFixed(1)}%</b>\n` +
        `Точка входа в watch: <b>${w.priceAtEntry.toPrecision(4)}</b>\n` +
        `Сейчас: <b>${currentPrice.toPrecision(4)}</b>\n\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `#${coin} #missed_pump`
      ).catch(() => {});
      continue;
    }

    try {
      const klines = await getKlines(w.symbol, "30m", 7);
      if (klines.length < 5) continue;

      const cur  = klines[klines.length - 1];
      const hist = klines.slice(0, -1);
      const close    = parseFloat(cur.close) || 0;
      const curVol   = (parseFloat(cur.volume) || 0) * close;
      const avgVol   = w.avgVolume
        ?? (hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length);
      if (!avgVol) continue;

      const volMult        = curVol / avgVol;
      const currentPriceMove = ((close - parseFloat(cur.open)) / parseFloat(cur.open)) * 100;
      // Порог объёма PATH B: 2.5x (синхронно с основным сканером).
      // Ключевой фильтр — OI кеп 10% (ниже), а не объём.
      // M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%) — победители с низким объёмом.
      const volThresholdB  = 2.5;
      const volConfirmed   = volMult >= volThresholdB;

      // Если OI отрицательный — накопления нет, это распродажа. Не стреляем.
      if (w.oiChange < 0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.debug({ symbol: w.symbol, oiChange: w.oiChange }, "OI Watch PATH B: OI отрицательный — сигнал отменён");
        continue;
      }

      // OI cap 20%: если OI при добавлении в watch уже был > 20% — это перегретый лонг/ловушка.
      // Данные: OI 25%+ = 0% win rate. AXL(90%), PIPPIN(56%), MOODENG(23%) — все SL.
      // Было 10% — слишком жёстко: PLAYSOUT (11.33%) попал под фильтр и пропустил памп +20%.
      // Поднято до 20% — совпадает с реальными проблемными случаями (23%+).
      if (w.oiChange > 20) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, oiChange: w.oiChange.toFixed(1) + "%" },
          "OI Watch PATH B: OI > 20% — ловушка перегретого лонга, отменяем"
        );
        continue;
      }

      // Если цена уже упала >4% с момента входа в watch — движение идёт против нас.
      // Это либо распродажа, либо OI-рост был за счёт шортов. Отменяем.
      if (priceMovePct < -4.0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
          "OI Watch PATH B: цена упала >4% от входа — сигнал отменён"
        );
        continue;
      }

      // ── ОБЯЗАТЕЛЬНАЯ ПРОВЕРКА: Cross OI должен быть положительным при срабатывании ──
      // Подтягиваем свежие данные CoinGlass — 30m OI отражает текущий импульс.
      // Если он стал отрицательным — накопление завершилось / шорты уже закрыты. Отменяем.
      let cgOI: Awaited<ReturnType<typeof getCoinglassOI>> | null = null;
      try { cgOI = await getCoinglassOI(w.symbol); } catch { /* non-critical */ }

      if (cgOI?.available && cgOI.oiChange30m !== null && cgOI.oiChange30m < 0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, crossOi30m: cgOI.oiChange30m.toFixed(1) + "%" },
          "OI Watch PATH B: Cross OI отрицательный — сигнал отменён"
        );
        continue;
      }

      // ── ФИЛЬТР: для накопления требуем подтверждение ценой ──────────────────────
      // PATH B стреляет когда объём подтвердился. Но для hidden_accumulation этого мало —
      // нужно чтобы цена ТОЖЕ начала двигаться (>= 2%). Иначе это накопление без выстрела.
      // null payload = добавлен из low-vol пути (OI есть, объём не пришёл) = всегда накопление.
      // Токены без движения цены (RARE +0.9%, WAVES +0.76%) остаются в watching до 2h экспайра.
      const pathBSentimentKey = (w.signalPayload as any)?.alphaResult?.sentimentKey ?? null;
      // Аномалия добавлена в список "требует подтверждения ценой" (наравне с накоплением).
      // Данные: anomaly win rate 13%, 9 SL из 15. Без OI-поддержки это просто спайк объёма — шум.
      // Требуем price >= 2% перед выстрелом — хотя бы минимальное подтверждение движения.
      const isAccumPatternB = pathBSentimentKey === "hidden_accumulation"
                           || pathBSentimentKey === "bullish_accumulation"
                           || pathBSentimentKey === "anomaly"
                           || pathBSentimentKey === null;
      const minPriceMoveB = 2.0;

      if (isAccumPatternB && priceMovePct < minPriceMoveB) {
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1), sentimentKey: pathBSentimentKey },
          `OI Watch PATH B: накопление — ждём движения цены >= ${minPriceMoveB}% (держим в watching)`
        );
        continue; // Остаётся в watching, не меняем статус — ждём пока цена тронется
      }

      if (volConfirmed) {
        // ── Spot volume gate (PATH B) ────────────────────────────────────────────
        {
          const [pbSpotVol, pbMcapRaw] = await Promise.all([
            getCoinglassSpotVolume24h(w.symbol).catch(() => null),
            fetchMarketCap(w.symbol).catch(() => null),
          ]);
          const pbMcapUsd = pbMcapRaw?.mcap ?? null;
          if (pbSpotVol === null) {
            // CoinGlass временно недоступен — не отменяем сигнал, пропускаем spot gate
            logger.warn({ symbol: w.symbol }, "OI Watch PATH B: CoinGlass spot недоступен — degraded mode, spot gate пропущен");
          } else if (pbMcapUsd === null || pbSpotVol < pbMcapUsd * 0.0015) {
            await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
            const pct = pbMcapUsd ? (pbSpotVol / pbMcapUsd * 100).toFixed(3) : "нет MCap";
            logger.info(
              { symbol: w.symbol, pbSpotVol, pbMcapUsd, pct },
              "OI Watch PATH B: спот-объём < 0.15% MCap — сигнал отменён"
            );
            continue;
          }
        }

        // Атомарно захватываем запись перед отправкой — защита от дублей при деплое.
        const claimedB = await db.update(oiWatchTable)
          .set({ status: "fired", firedAt: new Date() })
          .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
          .returning({ id: oiWatchTable.id });
        if (claimedB.length === 0) continue; // другой процесс уже обработал

        // Берём свежие спот-данные из пула для обогащения сигнала
        const bpEntry = getSpotPoolEntry(w.symbol);
        const bpSpotVol24h = bpEntry?.spotVol24h ?? null;
        const bpMcapUsd = bpEntry?.mcapUsd ?? null;

        // Если payload с полным AlphaResult сохранён — используем полный формат с OI по ТФ
        if (w.signalPayload) {
          const payload = w.signalPayload as { alphaResult: any; signalRow: any };
          // Обновляем coinalyzeOiChange свежими данными CoinGlass перед отправкой
          const freshCoinalyze = cgOI?.oiChange30m ?? (payload.alphaResult.coinalyzeOiChange ?? null);
          const fullResult = {
            ...payload.alphaResult,
            price: currentPrice,
            volumeMultiplier: volMult,
            priceChange30m: priceMovePct,
            coinalyzeOiChange: freshCoinalyze,
            spotVol24h: payload.alphaResult.spotVol24h ?? bpSpotVol24h,
            marketCapUsd: payload.alphaResult.marketCapUsd ?? bpMcapUsd,
          };
          await broadcastBatchAlert([fullResult]);
        } else {
          // Fallback: payload отсутствует (токен добавлен с низким объёмом без полного скана).
          // Используем уже полученный cgOI (не делаем повторный запрос).
          const base = w.symbol.replace("-USDT", "");
          const tvUrl  = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT`;
          const bingxUrl = `https://bingx.com/en/trade/${base}USDT/`;
          const waitMin = Math.round((Date.now() - w.addedAt.getTime()) / 60_000);

          // Определяем triggerTf — убираем префикс "all+" если был
          const displayTf = w.triggerTf.replace(/^all\+/, "");

          // Если CoinGlass API недоступен (cgOI = null) — используем сохранённое w.oiChange
          // как значение для сработавшего TF, чтобы в сигнале было видно OI по ТФ, а не просто число.
          const storedOi = w.oiChange;
          const cgOi5m  = cgOI?.oiChange5m  ?? (displayTf === "5m"  ? storedOi : null);
          const cgOi30m = cgOI?.oiChange30m ?? (displayTf === "30m" || displayTf === "steady" ? storedOi : null);
          const cgOi1h  = cgOI?.oiChange1h  ?? (displayTf === "1h"  ? storedOi : null);
          const cgOi4h  = cgOI?.oiChange4h  ?? (displayTf === "4h"  ? storedOi : null);
          const cgOi24h = cgOI?.oiChange24h ?? (displayTf === "24h" ? storedOi : null);

          const syntheticResult: Parameters<typeof broadcastBatchAlert>[0][0] = {
            symbol: w.symbol,
            grade: "alpha",
            price: currentPrice,
            priceChange30m: priceMovePct,
            currentVolume: curVol,
            avgVolume: avgVol,
            volumeMultiplier: volMult,
            oiChangePercent: w.oiChange,
            openInterest: null,
            cmcRank: null,
            cmcSource: null,
            cmcAvailable: false,
            liquidationsUsd: null,
            liquidationsMultiple: null,
            coinglassAvailable: cgOI?.available ?? false,
            coinalyzeOiChange: cgOi30m,
            coinalyzeConfirmed: false,
            isNewListing: false,
            isExhaustedSqueeze: false,
            pumpFromOpen: null,
            candleCount: 48,
            sentiment: "🔭 OI Watch",
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            traderAction: `Наблюдал ${waitMin} мин — объём подтвердился`,
            alphaScore: 5,
            isContinuing: false,
            cumulativeOiChange: w.oiChange,
            tradingViewUrl: tvUrl,
            bingxUrl,
            oiTriggerTf: displayTf,
            oiChange5m:  cgOi5m,
            oiChange1h:  cgOi1h,
            oiChange4h:  cgOi4h,
            oiChange24h: cgOi24h,
            spotVol24h:  bpSpotVol24h,
            marketCapUsd: bpMcapUsd,
          };
          await broadcastBatchAlert([syntheticResult]);
        }

        // ── Создаём tracked_signal чтобы вотчер мог сопровождать сигнал ─────────
        // PATH B раньше не создавал запись → не было уведомлений о БУ и milestone.
        // Теперь вставляем сигнал и запускаем tracking, как в PATH A.
        try {
          const base = w.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

          // Используем свежую цену из тикера (currentPrice), а не close из kline!
          // close — это цена закрытия 30м свечи, может быть на 30 минут устаревшей.
          // Ошибка: entryPrice: close → бот считал +11% вместо реального +1%.
          const [inserted] = await db.insert(signalsTable).values({
            symbol: w.symbol,
            type: "alpha",
            value: volMult,       // множитель объёма (как в PATH A), не OI
            threshold: 0,
            price: currentPrice,
            priceChangePercent: priceMovePct,
            volume24h: curVol,
            avgVolume: w.avgVolume ?? 0,
            openInterest: null,
            oiChangePercent: w.oiChange,
            tradingViewUrl: tvUrl,
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            detectedAt: new Date(),
          }).returning();

          // Если памп уже случился до выстрела (priceMovePct > 10%) — используем
          // оригинальную цену обнаружения как точку отсчёта для peakPct и stale cancel.
          // Иначе stale cancel видит peak=0% и отменяет сигнал где уже было +17%.
          const effectiveEntry = priceMovePct > 10 ? w.priceAtEntry : currentPrice;

          await trackSignal({
            symbol: w.symbol,
            signalId: inserted.id,
            signalType: "alpha",
            sentiment: null,
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            alphaScore: null,
            entryPrice: effectiveEntry,
            entryOi: null,
          });

          logger.info(
            { symbol: w.symbol, entryPrice: effectiveEntry, firePriceNow: currentPrice, klinesClose: close, priceMovePct: priceMovePct.toFixed(1) },
            "🔭 OI Watch PATH B: tracked_signal создан — сопровождение активно"
          );
        } catch (trackErr) {
          logger.error({ err: trackErr, symbol: w.symbol }, "OI Watch PATH B: ошибка при создании tracked_signal");
        }

        logger.info(
          { symbol: w.symbol, volMult: volMult.toFixed(2), priceMovePct: priceMovePct.toFixed(1), volConfirmed },
          "🔭➡️🚀 OI Watch FIRED (volume confirmed)"
        );
      }
    } catch (err) {
      logger.debug({ err, symbol: w.symbol }, "OI Watch PATH B: klines fetch failed");
    }
  }
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
let cycleTimer:       NodeJS.Timeout | null = null;
let fastTimer:        NodeJS.Timeout | null = null;
let dailyTimer:       NodeJS.Timeout | null = null;
let weeklyTimer:      NodeJS.Timeout | null = null;
let monthlyTimer:     NodeJS.Timeout | null = null;
let whaleTimer:       NodeJS.Timeout | null = null;
let whaleSatTimer:    NodeJS.Timeout | null = null;
let positionsTimer:   NodeJS.Timeout | null = null;

/** Миллисекунды до следующего HH:MM:00 UTC */
function msUntilUtc(targetHour: number, targetMin: number, targetDayOfWeek?: number): number {
  const now = new Date();
  const next = new Date(now);
  next.setUTCSeconds(0, 0);
  next.setUTCMinutes(targetMin);
  next.setUTCHours(targetHour);

  if (targetDayOfWeek !== undefined) {
    // Воскресенье = 0
    const currentDay = now.getUTCDay();
    let daysUntil = (targetDayOfWeek - currentDay + 7) % 7;
    // Если сегодня целевой день, но время уже прошло — ждём следующей недели
    if (daysUntil === 0 && next.getTime() <= now.getTime()) {
      daysUntil = 7;
    }
    next.setUTCDate(now.getUTCDate() + daysUntil);
  } else {
    // Ежедневно — если уже прошло сегодня, переносим на завтра
    if (next.getTime() <= now.getTime()) {
      next.setUTCDate(next.getUTCDate() + 1);
    }
  }

  return next.getTime() - now.getTime();
}

/** Миллисекунды до следующего 1-го числа месяца в HH:MM UTC */
function msUntilFirstOfMonth(targetHour: number, targetMin: number): number {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, targetHour, targetMin, 0, 0));
  // Если сейчас уже 1-е число и время ещё не наступило — отправляем сегодня
  if (now.getUTCDate() === 1) {
    const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, targetHour, targetMin, 0, 0));
    if (today.getTime() > now.getTime()) return today.getTime() - now.getTime();
  }
  return next.getTime() - now.getTime();
}

// ── Whale Watch 2.0 Jobs ──────────────────────────────────────────────────────

/**
 * Еженедельный отчёт Whale Watch 2.0 (Суббота 10:00 МСК = 07:00 UTC).
 * Показывает текущий watchlist накоплений (Spot CVD-based).
 */
async function runWeeklyWhaleReport(): Promise<void> {
  logger.info("🐋 Weekly Whale Watch 2.0 report started");
  try {
    await expireStaleWatchlist();
    const watchlist = await getWhaleWatchlist();
    if (watchlist.length === 0) {
      await broadcast(`🐋 <b>Whale Watch 2.0 — отчёт за неделю</b>\n\nАктивных накоплений не обнаружено.\nМониторинг продолжается в режиме реального времени.`);
      return;
    }
    const text = formatWhaleWatchV2Alert(watchlist);
    await broadcast(text);
    logger.info({ count: watchlist.length }, "🐋 Weekly whale report sent");
  } catch (err) {
    logger.error({ err }, "🐋 Weekly whale report error");
  }
}

export function startWatcher(): void {
  logger.info("AltBullet Watcher started");

  // Startup reset — проверяем стоп-лоссы и трейлинги пропущенные за время простоя.
  // Запуск 1: через 10с (BingX API ещё может быть холодным — внутри retry 3×3s).
  // Запуск 2: через 3 мин — страховочный прогон если первый упал на API таймауте.
  setTimeout(async () => {
    try { await runStartupReset(); } catch (err) { logger.error({ err }, "Startup reset #1 error"); }
  }, 10_000);
  setTimeout(async () => {
    try { await runStartupReset(); } catch (err) { logger.error({ err }, "Startup reset #2 error"); }
    logger.info("Startup reset #2 complete (safety net)");
  }, 3 * 60_000);

  // Fast cycle every 2 min — active + in_run (stop-loss, first target, trailing)
  // Also runs OI Watch cycle (check for volume confirmation on watch candidates)
  const runFast = async () => {
    if (!fastTimer) return;
    try { await runInRunFastCycle(); } catch (err) { logger.error({ err }, "FastCycle error"); }
    try { await runOiWatchCycle(); } catch (err) { logger.error({ err }, "OiWatchCycle error"); }
    try { await runWhaleFuturesCycle(); } catch (err) { logger.error({ err }, "WhaleFuturesCycle error"); }
    try { await runWhaleWatchSpotPriceTracking(); } catch (err) { logger.error({ err }, "SpotPriceTracking error"); }
    fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  };
  // First fast cycle at 2 min (after startup reset at 5s)
  fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  logger.info({ intervalMin: FAST_CYCLE_MS / 60000 }, "Fast cycle started (active + in_run + OI watch, 2min)");

  // Watcher cycle every 10 min — handles ONLY accumulation signals.
  // Starts at 14 min (NOT 7 min) — первый скан 551 токена занимает ~10мин и
  // исчерпывает Neon connection pool. При старте в 7 мин все DB-запросы (watcher,
  // fastcycle, restart notif, positions) падают с "connection timeout". 14 мин —
  // надёжный зазор после окончания первого скана.
  // Уведомление о рестарте — отправляем ПОСЛЕ завершения первого watcher цикла.
  let restartNotifSent = false;
  const runCycle = async () => {
    if (!cycleTimer) return;
    try {
      const r = await runWatcherCycle();
      logger.info(r, "Watcher cycle complete");
    } catch (err) {
      logger.error({ err }, "Watcher cycle error");
    }
    // Уведомление о рестарте — после первого цикла независимо от его успеха/ошибки.
    if (!restartNotifSent && process.env.NODE_ENV !== "development") {
      restartNotifSent = true;
      sendBotRestartNotification().catch(err => logger.warn({ err }, "Restart notification failed (non-critical)"));
    }
    cycleTimer = setTimeout(runCycle, 10 * 60 * 1000);
  };
  cycleTimer = setTimeout(runCycle, 14 * 60 * 1000);

  // Daily at 22:00 МСК = 19:00 UTC
  const scheduleDaily = () => {
    const ms = msUntilUtc(19, 0);
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Daily report scheduled (22:00 МСК)");
    dailyTimer = setTimeout(async () => {
      try { await sendDailyReport(); } catch (err) { logger.error({ err }, "Daily report error"); }
      scheduleDaily();
    }, ms);
  };
  scheduleDaily();

  // ── Missed-report guard ───────────────────────────────────────────────────────
  // Ловим два случая пропуска:
  // 1. Перезапуск ПОСЛЕ 18:00 UTC сегодня — отчёт за сегодня не отправлен.
  // 2. Перезапуск утром (до 18:00 UTC) — но вчерашний отчёт тоже не отправлен.
  // Задержка 90с: продакшн-DB иногда требует 30–60с на холодный reconnect.
  // При ошибке DB — retry через 60с (до 3 попыток).
  const runDailyGuard = async (attempt = 1): Promise<void> => {
    try {
      const nowUtc = new Date();

      // Порог за сегодня (19:00 UTC = 22:00 МСК)
      const todayReportUtc = new Date(nowUtc);
      todayReportUtc.setUTCHours(19, 0, 0, 0);

      // Порог за вчера (19:00 UTC вчерашнего дня)
      const yesterdayReportUtc = new Date(todayReportUtc);
      yesterdayReportUtc.setUTCDate(yesterdayReportUtc.getUTCDate() - 1);

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastDailyReportAt;

      // Буфер 5 мин: setTimeout может сработать на несколько мс раньше цели →
      // timestamp пишется как 18:59:59.xxx → guard считает вчерашний отчёт пропущенным.
      const REPORT_BUFFER_MS = 5 * 60 * 1000;

      // Пропущен сегодняшний отчёт: уже после 19:00, но не отправляли с 18:55
      const missedToday = nowUtc >= todayReportUtc && (!lastSent || lastSent < new Date(todayReportUtc.getTime() - REPORT_BUFFER_MS));

      // Пропущен вчерашний отчёт: последний раз отправляли раньше 18:55 вчера
      const missedYesterday = !lastSent || lastSent < new Date(yesterdayReportUtc.getTime() - REPORT_BUFFER_MS);

      if (!missedToday && !missedYesterday) {
        logger.info({ lastSent }, "Daily report guard: всё в порядке, пропуска нет");
        return;
      }

      logger.warn(
        { lastSent, nowUtc, missedToday, missedYesterday },
        "Missed daily report detected — sending now"
      );
      await sendDailyReport();
    } catch (err) {
      logger.error({ err, attempt }, "Missed-report guard error");
      if (attempt < 3) {
        logger.info({ nextAttempt: attempt + 1 }, "Missed-report guard: retry in 60s");
        setTimeout(() => runDailyGuard(attempt + 1), 60_000);
      }
    }
  };
  setTimeout(() => runDailyGuard(), 90_000); // 90с после старта — даём DB восстановить соединение

  // ── Missed-weekly guard ───────────────────────────────────────────────────────
  // Если сервер перезапустился в воскресенье после 09:00 МСК (06:00 UTC) и дайджест
  // ещё не был отправлен на этой неделе — отправляем через 120с после старта.
  const runWeeklyGuard = async (attempt = 1): Promise<void> => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDay() !== 0) return; // Не воскресенье — пропускаем

      const thisWeekDigestUtc = new Date(nowUtc);
      thisWeekDigestUtc.setUTCHours(6, 0, 0, 0); // 06:00 UTC = 09:00 МСК

      if (nowUtc < thisWeekDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastWeeklyDigestAt;

      const alreadySentThisWeek = lastSent && lastSent >= thisWeekDigestUtc;
      if (alreadySentThisWeek) {
        logger.info({ lastSent }, "Weekly digest already sent this week — skipping missed-digest check");
        return;
      }

      logger.warn({ lastSent, nowUtc }, "Missed weekly digest detected — sending now");
      await sendWeeklyDigest();
    } catch (err) {
      logger.error({ err, attempt }, "Missed-weekly guard error");
      if (attempt < 3) {
        setTimeout(() => runWeeklyGuard(attempt + 1), 60_000);
      }
    }
  };
  setTimeout(() => runWeeklyGuard(), 120_000); // 120с после старта

  // Weekly Sunday at 09:00 МСК = 06:00 UTC
  const scheduleWeekly = () => {
    const ms = msUntilUtc(6, 0, 0); // 0 = Sunday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Weekly digest scheduled (Вс 09:00 МСК)");
    weeklyTimer = setTimeout(async () => {
      try { await sendWeeklyDigest(); } catch (err) { logger.error({ err }, "Weekly digest error"); }
      scheduleWeekly();
    }, ms);
  };
  scheduleWeekly();

  // ── Missed-monthly guard ──────────────────────────────────────────────────────
  // Если сервер перезапустился 1-го числа после 10:00 МСК (07:00 UTC) и дайджест
  // ещё не был отправлен в этом месяце — отправляем через 90с после старта.
  setTimeout(async () => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDate() !== 1) return; // Не 1-е число — пропускаем

      const thisMonthDigestUtc = new Date(Date.UTC(nowUtc.getUTCFullYear(), nowUtc.getUTCMonth(), 1, 7, 0, 0, 0));
      if (nowUtc < thisMonthDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastMonthlyDigestAt;

      const alreadySentThisMonth = lastSent && lastSent >= thisMonthDigestUtc;
      if (alreadySentThisMonth) {
        logger.info({ lastSent }, "Monthly digest already sent this month — skipping missed-digest check");
        return;
      }

      logger.warn({ lastSent, nowUtc }, "Missed monthly digest detected — sending now");
      await sendMonthlyDigest();
    } catch (err) {
      logger.error({ err }, "Missed-monthly guard error");
    }
  }, 90_000); // 90с после старта

  // Monthly — 1-е число каждого месяца в 10:00 МСК = 07:00 UTC
  // ВНИМАНИЕ: setTimeout имеет лимит ~24.8 дней (2^31 мс). Для месячного таймера
  // это может переполниться (30 дней = 2.6 млрд мс > 2.15 млрд лимита) и вызвать
  // бесконечный цикл (таймер срабатывает немедленно через 1мс).
  // Решение: если до события > 23 дней — планируем промежуточную проверку.
  const MAX_SAFE_TIMEOUT_MS = 23 * 24 * 60 * 60 * 1000; // 23 дня — безопасный максимум
  const scheduleMonthly = () => {
    const ms = msUntilFirstOfMonth(7, 0);
    if (ms > MAX_SAFE_TIMEOUT_MS) {
      // Слишком далеко для одного setTimeout — планируем промежуточную проверку через 23 дня
      logger.info({ nextAt: new Date(Date.now() + ms).toISOString(), retryIn: "23d" }, "Monthly digest: слишком далеко, промежуточная проверка через 23 дня");
      monthlyTimer = setTimeout(scheduleMonthly, MAX_SAFE_TIMEOUT_MS);
      return;
    }
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Monthly digest scheduled (1-е число, 10:00 МСК)");
    monthlyTimer = setTimeout(async () => {
      try { await sendMonthlyDigest(); } catch (err) { logger.error({ err }, "Monthly digest error"); }
      scheduleMonthly();
    }, ms);
  };
  scheduleMonthly();

  // ── Weekly Whale Watch 2.0 report on Saturday 07:00 UTC = 10:00 МСК ─────────
  const scheduleWhaleSaturday = () => {
    const ms = msUntilUtc(7, 0, 6); // 6 = Saturday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "🐋 Weekly Whale Watch 2.0 report scheduled (Сб 10:00 МСК)");
    whaleSatTimer = setTimeout(async () => {
      try { await runWeeklyWhaleReport(); } catch (err) { logger.error({ err }, "🐋 Weekly whale report error"); }
      scheduleWhaleSaturday();
    }, ms);
  };
  scheduleWhaleSaturday();

  // ── Fixed-schedule positions update: 06:00, 10:00, 14:00, 18:00, 22:00 МСК ──
  // = 03:00, 07:00, 11:00, 15:00, 19:00 UTC
  // При рестарте — немедленная отправка + планирование на следующий ближайший слот.
  const POSITIONS_SLOTS_UTC = [3, 7, 11, 15, 19]; // UTC: 03=06МСК 07=10МСК 11=14МСК 15=18МСК 19=22МСК
  const POSITIONS_DEDUP_MS  = 3 * 60 * 60 * 1000 + 50 * 60 * 1000; // 3ч 50мин — чтобы только один процесс отправлял в каждый слот (слоты каждые 4ч)

  const msUntilNextPositionsSlot = (): number => {
    const now = new Date();
    let minMs = Infinity;
    for (const h of POSITIONS_SLOTS_UTC) {
      const candidate = new Date(now);
      candidate.setUTCHours(h, 0, 0, 0);
      let diff = candidate.getTime() - now.getTime();
      if (diff <= 0) diff += 24 * 60 * 60 * 1000; // перенос на следующие сутки
      if (diff < minMs) minMs = diff;
    }
    return minMs;
  };

  // dedupMs: окно дедупликации. Для старта — 5 мин (чтобы не блокировалось предыдущим плановым отчётом).
  // Для плановых отправок — 2 часа (защита от двойного fire из 2 процессов при одновременном срабатывании).
  const sendPositionsUpdate = async (reason: string, dedupMs = POSITIONS_DEDUP_MS): Promise<void> => {
    // Retry loop: Neon DB может быть временно перегружен при старте (scanner batch).
    // 3 попытки × 30с — аналогично sendBotRestartNotification.
    let claimed = false;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const dedupCutoff = new Date(Date.now() - dedupMs);
        const rows = await db.update(settingsTable)
          .set({ lastPositionsReportAt: new Date() })
          .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_positions_report_at IS NULL OR last_positions_report_at < ${dedupCutoff})`)
          .returning({ id: settingsTable.id });
        if (rows.length === 0) {
          logger.info({ reason }, "Positions update skipped (dedup — другой процесс уже отправил)");
          return;
        }
        claimed = true;
        break;
      } catch (err) {
        logger.warn({ err, reason, attempt }, `Positions update: DB claim failed, retry in 30s (attempt ${attempt}/3)`);
        if (attempt < 3) await new Promise(r => setTimeout(r, 30_000));
      }
    }
    if (!claimed) {
      logger.error({ reason }, "Positions update: DB claim failed after 3 attempts — отчёт не отправлен");
      return;
    }
    try {
      const text = await buildPositionsStatusText();
      logger.info({
        positionsCount: (await db.select().from(trackedSignalsTable).where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "re_entry"]))).length,
        text: text.slice(0, 200),
      }, "DEBUG: positions update about to broadcast");
      await broadcast(text);
      logger.info({ reason }, "Positions update broadcast to all subscribers");
    } catch (err) {
      logger.error({ err, reason }, "Positions update: broadcast error");
    }
  };

  const schedulePositions = () => {
    const ms = msUntilNextPositionsSlot();
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt, slots: "03/07/11/15/19 UTC = 06/10/14/18/22 МСК" }, "Next positions update scheduled");
    positionsTimer = setTimeout(async () => {
      if (!positionsTimer) return;
      await sendPositionsUpdate("scheduled");
      schedulePositions();
    }, ms);
  };

  // Startup позиции: независимый таймер, срабатывает через 25 мин после старта.
  // t=0:  сервер запустился
  // t=2:  первый FastCycle
  // t=14: WatcherCycle → sendBotRestartNotification (уведомление о рестарте)
  // t=16: первый скан 2-х воркеров заканчивается (~16+ мин), Neon pool освобождается
  // t=25: этот таймер → отчёт о позициях (надёжный зазор после скана)
  // Dedup 5мин: если плановый слот сработал < 5мин назад — пропускаем.
  if (process.env.NODE_ENV !== "development") {
    setTimeout(() => {
      sendPositionsUpdate("startup-25min", 5 * 60 * 1000).catch(err =>
        logger.warn({ err }, "Startup positions report failed (non-critical)")
      );
    }, 25 * 60 * 1000);
    logger.info("Startup positions report scheduled (t=25min)");
  }

  schedulePositions();
}

// ── Watchdog: следим чтобы сканер не завис ────────────────────────────────────
const WATCHDOG_CHECK_MS        = 10 * 60 * 1000;  // проверяем каждые 10 мин
const WATCHDOG_WARN_MS         = 40 * 60 * 1000;  // тревога если скан не было 40+ мин (цикл ~30 мин)
const WATCHDOG_CRIT_MS         = 70 * 60 * 1000;  // критично если 70+ мин (2+ пропущенных цикла)
const WATCHDOG_COOLDOWN        = 60 * 60 * 1000;  // не спамим чаще раза в час
const WATCHDOG_RESTART_AFTER   = 2;               // авторестарт после N критических алертов подряд
const WATCHDOG_MAX_RESTARTS    = 3;               // max авторестартов за сутки
const WATCHDOG_RESTART_WINDOW  = 24 * 60 * 60 * 1000; // окно для подсчёта рестартов

let watchdogTimer: ReturnType<typeof setTimeout> | null = null;
let watchdogLastAlertAt   = 0;
let watchdogAlertCount    = 0;
let watchdogGetLastScanAt: (() => Date | null) | null = null;
let watchdogRestartScanner: (() => Promise<void>) | null = null;
let watchdogRestartTimestamps: number[] = [];  // история рестартов для rate-limit

async function runWatchdog(): Promise<void> {
  try {
    const now = Date.now();
    const lastScanAtRaw = watchdogGetLastScanAt?.() ?? null;
    const lastScanAt = lastScanAtRaw ? lastScanAtRaw.getTime() : null;
    const staleness  = lastScanAt ? now - lastScanAt : null;

    // Первый скан ещё не прошёл (холодный старт) — даём 5 мин
    if (staleness === null || staleness < WATCHDOG_WARN_MS) {
      watchdogAlertCount = 0;
      watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
      return;
    }

    const cooldownOk = now - watchdogLastAlertAt > WATCHDOG_COOLDOWN;
    if (!cooldownOk) {
      watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
      return;
    }

    // Определяем уровень
    const isCritical = staleness >= WATCHDOG_CRIT_MS;
    const staleMinutes = Math.round(staleness / 60_000);
    watchdogAlertCount++;

    const emoji   = isCritical ? "🔴" : "🟡";
    const level   = isCritical ? "КРИТИЧНО" : "ПРЕДУПРЕЖДЕНИЕ";
    const lastStr = lastScanAt
      ? new Date(lastScanAt).toISOString().replace("T", " ").slice(0, 19) + " UTC"
      : "неизвестно";

    const lines = [
      `${emoji} <b>Watchdog: ${level}</b>`,
      ``,
      `Сканер не делал скан <b>${staleMinutes} мин</b>`,
      `Последний скан: <code>${lastStr}</code>`,
      isCritical
        ? `⚠️ Возможно сканер завис или упал. Проверь сервер.`
        : `Возможно временная задержка. Слежу дальше.`,
      ``,
      `<i>Предупреждение #${watchdogAlertCount}</i>`,
    ];

    const targets = await getTargets().catch(() => [] as (number | string)[]);
    for (const t of targets) {
      await sendMessage(t, lines.join("\n")).catch(() => {});
    }

    watchdogLastAlertAt = now;
    logger.warn({ staleMinutes, isCritical, alertCount: watchdogAlertCount }, "Watchdog alert sent");

    // ── Авторестарт: если критично 2+ алертов подряд и лимит не исчерпан ──
    if (isCritical && watchdogAlertCount >= WATCHDOG_RESTART_AFTER && watchdogRestartScanner) {
      // Rate-limit: не более WATCHDOG_MAX_RESTARTS рестартов за сутки
      watchdogRestartTimestamps = watchdogRestartTimestamps.filter(t => now - t < WATCHDOG_RESTART_WINDOW);
      if (watchdogRestartTimestamps.length < WATCHDOG_MAX_RESTARTS) {
        watchdogRestartTimestamps.push(now);
        logger.warn({ restartCount: watchdogRestartTimestamps.length }, "Watchdog: initiating auto-restart of scanner");
        try {
          await watchdogRestartScanner();
          // Сбрасываем счётчик — даём сканеру прогреться
          watchdogAlertCount = 0;
          watchdogLastAlertAt = now;
          const restartLines = [
            `🔄 <b>Watchdog: авторестарт сканера</b>`,
            ``,
            `Сканер завис на <b>${staleMinutes} мин</b> — выполнен автоматический рестарт.`,
            `Рестартов за 24ч: ${watchdogRestartTimestamps.length}/${WATCHDOG_MAX_RESTARTS}`,
          ];
          for (const t of targets) {
            await sendMessage(t, restartLines.join("\n")).catch(() => {});
          }
          logger.info("Watchdog: scanner restarted successfully");
        } catch (restartErr) {
          logger.error({ err: restartErr }, "Watchdog: auto-restart failed");
        }
      } else {
        logger.error({ restartCount: watchdogRestartTimestamps.length }, "Watchdog: restart limit reached — manual intervention required");
        for (const t of targets) {
          await sendMessage(t, `🚨 <b>Watchdog: лимит рестартов исчерпан</b>\n\nАвторестарт выполнялся ${WATCHDOG_MAX_RESTARTS}x за 24ч, сканер всё равно не работает.\n⚠️ Требуется ручное вмешательство.`).catch(() => {});
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "Watchdog check failed");
  }

  watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
}

export function startWatchdog(
  getLastScanAt: () => Date | null,
  restartScanner?: () => Promise<void>,
): void {
  if (watchdogTimer) return;
  watchdogGetLastScanAt = getLastScanAt;
  watchdogRestartScanner = restartScanner ?? null;
  // Первая проверка через 20 мин после старта — даём боту прогреться
  watchdogTimer = setTimeout(runWatchdog, 20 * 60 * 1000);
  const autoRestart = !!restartScanner;
  logger.info({ checkIntervalMin: 10, warnAfterMin: 40, critAfterMin: 70, autoRestart }, "Watchdog started");
}

/**
 * Одноразовый аудит открытых сигналов (confirming в oi_watch за последние 7 дней).
 * Прогоняет каждый символ через Taker Flow и отправляет сводный отчёт в канал.
 */
export async function runAuditReport(): Promise<void> {
  logger.info("🔍 Audit report started");

  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const entries = await db
    .select({
      symbol:       oiWatchTable.symbol,
      priceAtEntry: oiWatchTable.priceAtEntry,
      addedAt:      oiWatchTable.addedAt,
      sentimentKey: oiWatchTable.sentimentKey,
      oiChange:     oiWatchTable.oiChange,
    })
    .from(oiWatchTable)
    .where(and(
      eq(oiWatchTable.status, "confirming"),
      gte(oiWatchTable.addedAt, sevenDaysAgo),
    ))
    .orderBy(sql`${oiWatchTable.addedAt} DESC`);

  const targets = await getTargets();

  if (targets.length === 0) {
    logger.warn("🔍 Audit: нет активных получателей");
    return;
  }

  if (entries.length === 0) {
    const msg = `🔍 <b>Аудит сигналов</b>\n\nОткрытых сигналов за последние 7 дней не найдено.`;
    for (const t of targets) await sendMessage(t, msg).catch(() => {});
    return;
  }

  // Батч цены из BingX (один запрос на все тикеры)
  let priceMap = new Map<string, number>();
  try {
    const tickers = await getFutureTickers();
    for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
  } catch (err) {
    logger.warn({ err }, "🔍 Audit: BingX tickers failed — prices unavailable");
  }

  type Verdict = "enter" | "wait" | "skip";
  type AuditRow = {
    symbol:      string;
    sentimentKey: string | null;
    entryPrice:  number;
    currentPrice: number;
    pricePct:    number;
    ageH:        number;
    tfNetPct:    number | null;
    tfDominance: "buy" | "sell" | "neutral" | null;
    verdict:     Verdict;
  };

  const rows: AuditRow[] = [];

  for (const entry of entries) {
    const currentPrice = priceMap.get(entry.symbol) ?? 0;
    const entryPrice   = entry.priceAtEntry ?? 0;
    const pricePct     = entryPrice > 0 ? ((currentPrice - entryPrice) / entryPrice) * 100 : 0;
    const ageH         = (Date.now() - new Date(entry.addedAt).getTime()) / 3_600_000;

    // Небольшая задержка чтобы не долбить CoinGlass
    await new Promise(r => setTimeout(r, 200));
    const tf = await getCoinglassTakerFlow(entry.symbol);

    let verdict: Verdict;
    if (pricePct < -15 || (tf.available && tf.dominance === "sell" && tf.netBuyPct < -5)) {
      verdict = "skip";
    } else if (tf.available && tf.dominance === "buy" && tf.netBuyPct > 3 && pricePct < 12 && ageH < 72) {
      verdict = "enter";
    } else {
      verdict = "wait";
    }

    rows.push({
      symbol:       entry.symbol,
      sentimentKey: entry.sentimentKey,
      entryPrice,
      currentPrice,
      pricePct,
      ageH,
      tfNetPct:    tf.available ? tf.netBuyPct : null,
      tfDominance: tf.available ? tf.dominance : null,
      verdict,
    });
  }

  // Сортировка: сначала enter, потом wait, потом skip; внутри — по свежести
  const ORDER: Record<Verdict, number> = { enter: 0, wait: 1, skip: 2 };
  rows.sort((a, b) => ORDER[a.verdict] - ORDER[b.verdict] || a.ageH - b.ageH);

  const enterCount = rows.filter(r => r.verdict === "enter").length;
  const waitCount  = rows.filter(r => r.verdict === "wait").length;
  const skipCount  = rows.filter(r => r.verdict === "skip").length;

  const lines: string[] = [
    `🔍 <b>Аудит открытых сигналов</b>  (7д, ${rows.length} позиций)`,
    `🟢 Войти: ${enterCount}  🟡 Ждать: ${waitCount}  🔴 Пропустить: ${skipCount}`,
    ``,
  ];

  for (const r of rows) {
    const base      = r.symbol.replace("-USDT", "");
    const pctStr    = r.pricePct >= 0 ? `+${r.pricePct.toFixed(1)}%` : `${r.pricePct.toFixed(1)}%`;
    const ageStr    = r.ageH < 24
      ? `${Math.round(r.ageH)}ч`
      : `${(r.ageH / 24).toFixed(0)}д`;
    const tfStr     = r.tfNetPct !== null
      ? `TF ${r.tfNetPct >= 0 ? "+" : ""}${r.tfNetPct.toFixed(0)}%`
      : `TF н/д`;
    const emoji     = r.verdict === "enter" ? "🟢" : r.verdict === "wait" ? "🟡" : "🔴";
    const action    = r.verdict === "enter" ? "ВХОДИТЬ" : r.verdict === "wait" ? "ЖДАТЬ" : "ПРОПУСТИТЬ";
    const pattern   = r.sentimentKey
      ? ` <i>${r.sentimentKey.replace(/_/g, " ")}</i>`
      : "";

    lines.push(`${emoji} <b>${base}</b>${pattern}  ${pctStr}  ${ageStr}  ${tfStr} → <b>${action}</b>`);
  }

  lines.push(
    ``,
    `📅 ${new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} МСК`,
  );

  // Разбиваем на чанки по 4000 символов (лимит Telegram)
  const fullText = lines.join("\n");
  const CHUNK    = 4000;
  const chunks: string[] = [];
  if (fullText.length <= CHUNK) {
    chunks.push(fullText);
  } else {
    const lineArr = lines;
    let cur = "";
    for (const ln of lineArr) {
      if ((cur + "\n" + ln).length > CHUNK) {
        if (cur) chunks.push(cur);
        cur = ln;
      } else {
        cur = cur ? cur + "\n" + ln : ln;
      }
    }
    if (cur) chunks.push(cur);
  }

  for (const target of targets) {
    for (const chunk of chunks) {
      await sendMessage(target, chunk).catch((err: unknown) => {
        logger.warn({ err, target }, "🔍 Audit: ошибка отправки");
      });
    }
  }

  logger.info({ total: rows.length, enter: enterCount, wait: waitCount, skip: skipCount }, "🔍 Audit report sent");
}

export function stopWatcher(): void {
  if (fastTimer)       { clearTimeout(fastTimer);       fastTimer       = null; }
  if (cycleTimer)      { clearTimeout(cycleTimer);      cycleTimer      = null; }
  if (dailyTimer)      { clearTimeout(dailyTimer);      dailyTimer      = null; }
  if (weeklyTimer)     { clearTimeout(weeklyTimer);     weeklyTimer     = null; }
  if (monthlyTimer)    { clearTimeout(monthlyTimer);    monthlyTimer    = null; }
  if (whaleTimer)      { clearTimeout(whaleTimer);      whaleTimer      = null; }
  if (whaleSatTimer)   { clearTimeout(whaleSatTimer);   whaleSatTimer   = null; }
  if (positionsTimer)  { clearTimeout(positionsTimer);  positionsTimer  = null; }
  if (watchdogTimer)   { clearTimeout(watchdogTimer);   watchdogTimer   = null; }
  logger.info("AltBullet Watcher stopped");
}
