/**
 * Coinalyze — кросс-биржевой агрегатор OI.
 * Используется для верификации: если OI растёт не только на BingX, но и по всему рынку —
 * сигнал значительно сильнее (не манипуляция одной биржей).
 *
 * Требует COINALYZE_API_KEY (бесплатный план: 100 req/day).
 * Ключ: https://coinalyze.net/account/
 *
 * Формат символа: BTCUSDT_PERP.A (Bybit) — агрегат без суффикса не поддерживается на free plan.
 * Endpoint: GET /v1/open-interest-history?symbols=...&interval=30min&from=<unix>&to=<unix>
 * Response: [{symbol, history: [{t, o, h, l, c}]}]  (o=open OI, c=close OI)
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";

export interface CoinalyzeOIResult {
  /** Кросс-биржевое изменение OI за 30 минут в % */
  oiChange30m: number | null;
  /** Абсолютное значение OI в USD */
  oiUsd: number | null;
  available: boolean;
  source: "coinalyze";
}

// Кэш для снижения числа запросов (30 мин)
const cache = new Map<string, { result: CoinalyzeOIResult; ts: number }>();
const CACHE_TTL = 30 * 60 * 1000;

// ── Дневной счётчик запросов ─────────────────────────────────────────────────
const DAILY_LIMIT = 90;
let dailyCallCount = 0;
let dailyResetAt = startOfNextDayUtc();

function startOfNextDayUtc(): number {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
  return next.getTime();
}

function checkDailyLimit(): boolean {
  const now = Date.now();
  if (now >= dailyResetAt) {
    logger.info({ prevCount: dailyCallCount }, "Coinalyze daily counter reset");
    dailyCallCount = 0;
    dailyResetAt = startOfNextDayUtc();
  }
  if (dailyCallCount >= DAILY_LIMIT) {
    logger.warn({ dailyCallCount, limit: DAILY_LIMIT }, "Coinalyze daily limit reached — skipping call");
    return false;
  }
  dailyCallCount++;
  return true;
}

/** Возвращает текущее число запросов сегодня и лимит */
export function getCoinalyzeDailyStats(): { used: number; limit: number; remaining: number } {
  return { used: dailyCallCount, limit: DAILY_LIMIT, remaining: Math.max(0, DAILY_LIMIT - dailyCallCount) };
}

/**
 * Нормализует символ BingX в формат Coinalyze с суффиксом Bybit (.A).
 * BTC-USDT → BTCUSDT_PERP.A
 */
function toBingxCoinalyzeSymbol(bingxSymbol: string): string {
  const base = bingxSymbol.replace("-USDT", "");
  return `${base}USDT_PERP.A`;
}

/** Строка без суффикса биржи для map lookup */
function toBaseSymbol(bingxSymbol: string): string {
  const base = bingxSymbol.replace("-USDT", "");
  return `${base}USDT_PERP`;
}

// Тип одной свечи из history
interface OICandle { t: number; o: number; h: number; l: number; c: number; }
// Тип элемента ответа
type CoinalyzeResponse = { symbol: string; history: OICandle[] }[];

/** Строит URL запроса за последний час 30min-свечей */
function buildOIUrl(symbols: string[], apiKey: string): string {
  const to   = Math.floor(Date.now() / 1000);
  const from = to - 3600; // 1 час назад — гарантируем минимум 2 свечи 30min
  const url  = new URL("https://api.coinalyze.net/v1/open-interest-history");
  url.searchParams.set("symbols",  symbols.join(","));
  url.searchParams.set("interval", "30min");
  url.searchParams.set("from",     String(from));
  url.searchParams.set("to",       String(to));
  url.searchParams.set("api_key",  apiKey);
  return url.toString();
}

export async function getCoinalyzeOI(symbol: string): Promise<CoinalyzeOIResult> {
  const apiKey = process.env.COINALYZE_API_KEY;

  const noData: CoinalyzeOIResult = {
    oiChange30m: null,
    oiUsd:       null,
    available:   false,
    source:      "coinalyze",
  };

  if (!apiKey) return noData;

  const cacheKey = toBaseSymbol(symbol);
  const cached   = cache.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  if (!checkDailyLimit()) return noData;

  const cglSymbol = toBingxCoinalyzeSymbol(symbol);

  try {
    const res = await fetch(buildOIUrl([cglSymbol], apiKey), {
      headers: { Accept: "application/json" },
      signal:  AbortSignal.timeout(6000),
    });

    if (!res.ok) {
      logger.warn({ symbol, status: res.status }, "Coinalyze OI request failed");
      reportApiFailure("coinalyze", res.status);
      return noData;
    }

    const data = await res.json() as CoinalyzeResponse;

    if (!Array.isArray(data) || data.length === 0) return noData;

    const entry   = data[0];
    const history = entry?.history;
    if (!history || history.length < 2) return noData;

    const prev = history[history.length - 2].c;
    const curr = history[history.length - 1].c;
    const oiChange30m = prev > 0 ? ((curr - prev) / prev) * 100 : null;

    const result: CoinalyzeOIResult = {
      oiChange30m,
      oiUsd:     curr,
      available: true,
      source:    "coinalyze",
    };

    reportApiSuccess("coinalyze");
    cache.set(cacheKey, { result, ts: Date.now() });
    return result;
  } catch (err) {
    logger.warn({ symbol, err }, "Coinalyze OI fetch error");
    reportApiFailure("coinalyze");
    return noData;
  }
}

// ── 24h OI Change ─────────────────────────────────────────────────────────────
const cache24h = new Map<string, { oiChange24h: number | null; ts: number }>();
const CACHE_24H_TTL = 20 * 60 * 1000; // 20 мин

// Батч-вызов: последний timestamp для rate-limit (не чаще 1 раза в 90 мин на процесс)
let lastBatchFetchAt = 0;
const BATCH_24H_COOLDOWN = 90 * 60 * 1000;

/**
 * Батч-загрузка OI 24h для списка символов — ОДИН запрос к Coinalyze.
 * Результаты сохраняются в cache24h так же, как getCoinalyzeOI24h.
 * Использовать перед per-symbol scan loop чтобы cache уже был тёплым.
 * Считается как 1 daily request независимо от числа символов.
 */
export async function batchGetCoinalyzeOI24h(bingxSymbols: string[]): Promise<void> {
  const apiKey = process.env.COINALYZE_API_KEY;
  if (!apiKey || bingxSymbols.length === 0) return;

  const now = Date.now();
  if (now - lastBatchFetchAt < BATCH_24H_COOLDOWN) return;

  // Фильтруем только символы без свежего кэша
  const stale = bingxSymbols.filter(sym => {
    const k = toBaseSymbol(sym);
    const c = cache24h.get(k);
    return !c || now - c.ts >= CACHE_24H_TTL;
  });
  if (stale.length === 0) return;

  if (!checkDailyLimit()) return;

  lastBatchFetchAt = now;

  const to   = Math.floor(now / 1000);
  const from = to - 86400;
  const coinalyzeSymbols = stale.map(toBingxCoinalyzeSymbol);

  const url = new URL("https://api.coinalyze.net/v1/open-interest-history");
  url.searchParams.set("symbols",  coinalyzeSymbols.join(","));
  url.searchParams.set("interval", "1hour");
  url.searchParams.set("from",     String(from));
  url.searchParams.set("to",       String(to));
  url.searchParams.set("api_key",  apiKey);

  try {
    const res = await fetch(url.toString(), {
      headers: { Accept: "application/json" },
      signal:  AbortSignal.timeout(10000),
    });

    if (!res.ok) {
      reportApiFailure("coinalyze", res.status);
      logger.warn({ status: res.status, count: stale.length }, "Coinalyze batch OI 24h: request failed");
      return;
    }

    const data = await res.json() as CoinalyzeResponse;
    if (!Array.isArray(data)) return;

    let filled = 0;
    for (const entry of data) {
      // symbol из ответа вида "BTCUSDT_PERP.A" — приводим к ключу кэша "BTCUSDT_PERP"
      const cacheKey = entry.symbol.replace(/\.A$/, "");
      const history  = entry.history;
      if (!history || history.length < 2) {
        cache24h.set(cacheKey, { oiChange24h: null, ts: now });
        continue;
      }
      const first = history[0].o;
      const last  = history[history.length - 1].c;
      const oiChange24h = first > 0 ? ((last - first) / first) * 100 : null;
      cache24h.set(cacheKey, { oiChange24h, ts: now });
      filled++;
    }

    reportApiSuccess("coinalyze");
    logger.info(
      { requested: stale.length, filled, dailyUsed: dailyCallCount },
      "🦑 Coinalyze batch OI 24h loaded"
    );
  } catch (err) {
    reportApiFailure("coinalyze");
    logger.warn({ err, count: stale.length }, "Coinalyze batch OI 24h: fetch error");
  }
}

/**
 * Cache-only чтение OI 24h из Coinalyze — без HTTP вызова.
 * Возвращает null если данных нет или кэш устарел.
 * Используется как fallback в per-symbol scan loop без расхода API квоты.
 */
export function getCoinalyzeOI24hCached(bingxSymbol: string): number | null {
  const cacheKey = toBaseSymbol(bingxSymbol);
  const cached = cache24h.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_24H_TTL) return cached.oiChange24h;
  return null;
}

/**
 * Возвращает изменение OI за 24 часа с Coinalyze (hourly candles).
 * Используется для фильтрации аномальных сигналов без роста OI.
 */
export async function getCoinalyzeOI24h(symbol: string): Promise<number | null> {
  const apiKey = process.env.COINALYZE_API_KEY;
  if (!apiKey) return null;

  const cacheKey = toBaseSymbol(symbol);
  const cached = cache24h.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_24H_TTL) return cached.oiChange24h;

  if (!checkDailyLimit()) return null;

  const to   = Math.floor(Date.now() / 1000);
  const from = to - 86400; // 24 часа назад
  const cglSymbol = toBingxCoinalyzeSymbol(symbol);

  const url = new URL("https://api.coinalyze.net/v1/open-interest-history");
  url.searchParams.set("symbols",  cglSymbol);
  url.searchParams.set("interval", "1hour");
  url.searchParams.set("from",     String(from));
  url.searchParams.set("to",       String(to));
  url.searchParams.set("api_key",  apiKey);

  try {
    const res = await fetch(url.toString(), {
      headers: { Accept: "application/json" },
      signal:  AbortSignal.timeout(6000),
    });

    if (!res.ok) {
      reportApiFailure("coinalyze", res.status);
      cache24h.set(cacheKey, { oiChange24h: null, ts: Date.now() });
      return null;
    }

    const data = await res.json() as CoinalyzeResponse;
    if (!Array.isArray(data) || data.length === 0) {
      cache24h.set(cacheKey, { oiChange24h: null, ts: Date.now() });
      return null;
    }

    const history = data[0]?.history;
    if (!history || history.length < 2) {
      cache24h.set(cacheKey, { oiChange24h: null, ts: Date.now() });
      return null;
    }

    const first = history[0].o;           // OI в начале 24ч окна
    const last  = history[history.length - 1].c; // OI сейчас
    const oiChange24h = first > 0 ? ((last - first) / first) * 100 : null;

    reportApiSuccess("coinalyze");
    cache24h.set(cacheKey, { oiChange24h, ts: Date.now() });
    return oiChange24h;
  } catch (err) {
    logger.warn({ symbol, err }, "Coinalyze OI 24h fetch error");
    reportApiFailure("coinalyze");
    cache24h.set(cacheKey, { oiChange24h: null, ts: Date.now() });
    return null;
  }
}

// ── Pool Ranking Cache ────────────────────────────────────────────────────────
interface OIRankEntry { symbol: string; oiUsd: number; }
let poolRankingCache: OIRankEntry[] = [];
let poolRankingCachedAt = 0;
const POOL_CACHE_TTL = 2 * 60 * 60 * 1000; // 2 часа

/**
 * Получить ранжирование символов по абсолютному глобальному OI (USD).
 * Используется для формирования пула 500 монет вместо сортировки по объёму BingX.
 * Кэшируется на 2 часа, чтобы не превышать лимиты API.
 */
export async function getGlobalOIRanking(
  bingxSymbols: string[],
): Promise<OIRankEntry[]> {
  const apiKey = process.env.COINALYZE_API_KEY;
  if (!apiKey || bingxSymbols.length === 0) return [];

  if (poolRankingCache.length > 0 && Date.now() - poolRankingCachedAt < POOL_CACHE_TTL) {
    return poolRankingCache;
  }

  const coinalyzeSymbols = bingxSymbols.map(toBingxCoinalyzeSymbol);
  const batches: string[][] = [];
  for (let i = 0; i < coinalyzeSymbols.length; i += 20) {
    batches.push(coinalyzeSymbols.slice(i, i + 20));
  }

  const results: OIRankEntry[] = [];
  let requestCount = 0;

  for (const batch of batches) {
    try {
      const res = await fetch(buildOIUrl(batch, apiKey), {
        headers: { Accept: "application/json" },
        signal:  AbortSignal.timeout(8000),
      });

      requestCount++;
      if (!res.ok) {
        logger.warn({ status: res.status, batch: batch.length }, "Coinalyze pool ranking batch failed");
        continue;
      }

      const data = await res.json() as CoinalyzeResponse;
      if (!Array.isArray(data)) continue;

      for (const entry of data) {
        const history = entry.history;
        if (!history || history.length === 0) continue;
        const oiUsd    = history[history.length - 1].c ?? 0;
        // Убираем суффикс .A и возвращаем в BingX формат
        const bingxSym = entry.symbol.replace(".A", "").replace("USDT_PERP", "-USDT");
        results.push({ symbol: bingxSym, oiUsd });
      }

      await new Promise(r => setTimeout(r, 150));
    } catch (err) {
      logger.warn({ err }, "Coinalyze pool ranking error");
    }
  }

  results.sort((a, b) => b.oiUsd - a.oiUsd);

  if (results.length > 0) {
    poolRankingCache = results;
    poolRankingCachedAt = Date.now();
    logger.info({ count: results.length, requests: requestCount }, "Coinalyze global OI pool ranking updated");
  } else {
    logger.warn({ requestCount }, "Coinalyze pool ranking returned no data — keeping fallback");
  }

  return results;
}

/**
 * Получить список топ-N монет по изменению OI с Coinalyze.
 * Используется как первичный фильтр перед проверкой на BingX.
 * Возвращает символы в формате BingX (BTC-USDT) с их OI изменением.
 */
export async function getTopOIMovers(
  bingxSymbols: string[],
  minOiChange = 5,
  limit = 20,
): Promise<{ symbol: string; oiChange: number }[]> {
  const apiKey = process.env.COINALYZE_API_KEY;
  if (!apiKey || bingxSymbols.length === 0) return [];

  const coinalyzeSymbols = bingxSymbols.map(toBingxCoinalyzeSymbol);
  const batches: string[][] = [];
  for (let i = 0; i < coinalyzeSymbols.length; i += 20) {
    batches.push(coinalyzeSymbols.slice(i, i + 20));
  }

  const results: { symbol: string; oiChange: number }[] = [];

  for (const batch of batches) {
    try {
      const res = await fetch(buildOIUrl(batch, apiKey), {
        headers: { Accept: "application/json" },
        signal:  AbortSignal.timeout(8000),
      });

      if (!res.ok) continue;

      const data = await res.json() as CoinalyzeResponse;
      if (!Array.isArray(data)) continue;

      for (const entry of data) {
        const history = entry.history;
        if (!history || history.length < 2) continue;
        const prev = history[history.length - 2].c;
        const curr = history[history.length - 1].c;
        if (!prev || prev === 0) continue;

        const oiChange = ((curr - prev) / prev) * 100;
        if (Math.abs(oiChange) >= minOiChange) {
          const bingxSym = entry.symbol.replace(".A", "").replace("USDT_PERP", "-USDT");
          results.push({ symbol: bingxSym, oiChange });
        }
      }

      await new Promise(r => setTimeout(r, 200));
    } catch (err) {
      logger.warn({ err }, "Coinalyze batch OI error");
    }
  }

  return results
    .sort((a, b) => Math.abs(b.oiChange) - Math.abs(a.oiChange))
    .slice(0, limit);
}
