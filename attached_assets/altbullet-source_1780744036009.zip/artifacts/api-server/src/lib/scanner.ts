import { logger } from "./logger.js";
import { getFutureTickers, getFutureTicker, getKlines, getOpenInterest, getFundingRate, testConnection as testBingX, fetchCVD, getOrderBookAnalysis, type BingXTicker, type OrderBookAnalysis } from "./bingx.js";
import { broadcastBatchAlert, broadcastRawAlert, testConnection as testTelegram } from "./telegram.js";
import { trackSignal, broadcast } from "./watcher.js";
import { getTrendingRank } from "./trending.js";
import { getLiquidations } from "./liquidations.js";
import { batchGetCoinglassOI, clearCoinglassOICache, type CoinglassOIResult } from "./coinglass_oi.js";
import { getCoinalyzeOI24h, getCoinalyzeOI24hCached, batchGetCoinalyzeOI24h } from "./coinalyze.js";
import { getCoinglassTakerFlow } from "./coinglass_taker.js";
import { getSpotCvdMtf, getCoinglassSpotVolume24h } from "./coinglass_spot_cvd.js";
import { fetchMarketCap } from "./whale_watch_v2.js";
import { isSpotLiquid, getSpotPoolEntry, triggerRefresh } from "./spotPool.js";
import { db, signalsTable, settingsTable, oiBaselinesTable, oiWatchTable, trackedSignalsTable, prescanTrackerTable, whaleFuturesWatchlistTable, type InsertSignal } from "@workspace/db";
import { gte, gt, lt, sql, eq, and, inArray, isNull, or } from "drizzle-orm";

export interface ScannerState {
  running: boolean;
  lastScanAt: Date | null;
  nextScanAt: Date | null;
  marketsScanned: number;
  scanIntervalMs: number;
  bingxConnected: boolean;
  telegramConnected: boolean;
}

const state: ScannerState = {
  running: false,
  lastScanAt: null,
  nextScanAt: null,
  marketsScanned: 0,
  scanIntervalMs: 600_000,
  bingxConnected: false,
  telegramConnected: false,
};

/**
 * Персистентный кеш глобальных объёмов из CoinGlass (volUsd).
 * Накапливается между сканами — не сбрасывается.
 * Ключ: baseSymbol без USDT (например "DYDX"), значение: volUsd в USD.
 * После 1-го скана используется вместо BingX-объёма для пре-скрина Layer 2.
 */
const cgVolumeCache = new Map<string, number>();

// ── Persistent Pre-screen Tracker ───────────────────────────────────────────
// Ловит Ghost Pump: токены которые стабильно держатся в топ-N prescan 2+ цикла
// без полноценного OI/vol сигнала — ранняя поимка на старте движения.
interface PrescanEntry {
  firstPrice24h: number;   // price24h% при первом появлении в топ-N
  lastPrice24h:  number;   // актуальное price24h% (обновляется каждый цикл)
  firstSeenAt:   number;   // timestamp первого появления
  firstPrice:    number;   // цена при первом появлении (для расчёта реального движения)
  cycleCount:    number;   // сколько циклов подряд в топ-N
  bestRank:      number;   // лучший ранг в топ-N (1 = самый горячий)
  lastScore:     number;   // activity score последнего цикла (тренд)
  firstScore:    number;   // activity score первого цикла (база для тренда)
  lastPrice:     number;   // текущая цена (для алерта)
  lastFiredAt:   number;   // timestamp последнего алерта (кулдаун)
  lastCvdOk?:     boolean; // последняя CVD проверка: cvdRising2 (2 цикла нетто-покупок)
  lastNetBuyPct?: number;  // последний netBuyPct (%) из getCoinglassTakerFlow
  lastOi5m?:      number | null; // OI 5m % из CoinGlass (последний цикл)
  lastOi30m?:     number | null; // OI 30m %
  lastOi1h?:      number | null; // OI 1h %
  lastOi4h?:      number | null; // OI 4h %
  lastOi24h?:     number | null; // OI 24h %
  lastPrice1h?:   number | null; // Изменение цены за последний 1ч (2×30m свечи назад)
}
const prescanTracker = new Map<string, PrescanEntry>();
// Фильтры: топ-10 + 3 цикла подряд (~30 мин) — только горячие токены с устойчивым присутствием
const PERSIST_MIN_CYCLES       = 3;
const PERSIST_MIN_PRICE24H     = 5.0;    // % 24h изменение (стандартный ghost pump)
const PERSIST_MAX_PRICE24H     = 12.0;   // % 24h cap — не стрелять если движение уже случилось
const PERSIST_MAX_RANK         = 30;     // топ-30 (расширено с топ-10)
const PERSIST_COOLDOWN_MS      = 4 * 60 * 60 * 1000; // 4ч между алертами одного токена
// Ранний ghost pump: ловим накопление ДО старта движения
const PERSIST_EARLY_MIN_CYCLES = 2;     // 2 цикла (~20 мин) — раньше стандартного
const PERSIST_EARLY_MAX_RANK   = 10;    // только топ-10 — самые горячие
const PERSIST_EARLY_MAX_PRICE24H = 10.0; // цена ещё не двинулась сильно — накопление

// ── Whale Watch: Real-time accumulation stage tracker ───────────────────────
// Tracks short-term intraday whale buying stages per symbol.
// Signal fires after 3 stages in a 60-min rolling window → PATH A +1% in 60 min.
interface WhaleWatchStageEntry {
  ts: number;
  price: number;
  buyPct: number;
}
interface WhaleWatchPathARecord {
  detectedAt: number;
  priceAt3rd: number;
  expiresAt: number;
}
const whaleWatchStages = new Map<string, WhaleWatchStageEntry[]>();
const whaleWatchPathA  = new Map<string, WhaleWatchPathARecord>();

// ── Filtered Candidates Log: последние отсеянные топ-10 кандидаты ─────────────
interface FilteredCandidateEntry {
  symbol: string;
  reason: string;
  reasonLabel: string;
  oi5m: number | null;
  oi30m: number | null;
  oi1h: number | null;
  oi4h: number | null;
  oi24h: number | null;
  vol: number | null;
  price: number | null;
  filteredAt: number;
}
const filteredLog: FilteredCandidateEntry[] = [];
const MAX_FILTERED_LOG = 50;

// ── In-memory OI Watch confirming fallback ────────────────────────────────────
// Используется когда DB INSERT для confirming-записей падает из-за connection timeout.
// Зеркалирует поля oi_watch таблицы необходимые для логики окна подтверждения.
// TTL: 90 минут — записи старше удаляются при каждом скане.
interface ConfirmingWatchEntry {
  symbol:           string;
  triggerTf:        string;
  oiChange:         number;
  priceAtEntry:     number;
  volumeMultiplier: number;
  sentimentKey:     string | null;
  addedAt:          Date;
  expiresAt:        Date;
  avgVolume:        number;
  oi5mChange:       number | null;
  oi30mChange:      number | null;
  oi1hChange:       number | null;
}
const confirmingWatchMap = new Map<string, ConfirmingWatchEntry>();
const CONFIRMING_WATCH_TTL_MS = 90 * 60 * 1000; // 90 минут

function pushFilteredCandidate(entry: FilteredCandidateEntry): void {
  // Заменяем предыдущую запись для того же символа (оставляем только актуальную)
  const idx = filteredLog.findIndex(e => e.symbol === entry.symbol);
  if (idx !== -1) filteredLog.splice(idx, 1);
  filteredLog.unshift(entry);
  if (filteredLog.length > MAX_FILTERED_LOG) filteredLog.length = MAX_FILTERED_LOG;
}

// ── Whale Watch Stages Persistence ──────────────────────────────────────────
async function saveWhaleWatchStagesToDb(): Promise<void> {
  try {
    const stages: Record<string, WhaleWatchStageEntry[]> = {};
    for (const [sym, entries] of whaleWatchStages) stages[sym] = entries;
    const pathA: Record<string, WhaleWatchPathARecord> = {};
    for (const [sym, entry] of whaleWatchPathA) pathA[sym] = entry;
    await db.update(settingsTable).set({ whaleWatchStagesJson: JSON.stringify({ stages, pathA }) });
  } catch (err) {
    logger.warn({ err }, "saveWhaleWatchStages: failed (non-critical)");
  }
}

async function loadWhaleWatchStagesFromDb(): Promise<void> {
  try {
    const rows = await db.select({ json: settingsTable.whaleWatchStagesJson }).from(settingsTable).limit(1);
    const json = rows[0]?.json;
    if (!json) return;
    const data = JSON.parse(json) as {
      stages: Record<string, WhaleWatchStageEntry[]>;
      pathA: Record<string, WhaleWatchPathARecord>;
    };
    const now = Date.now();
    for (const [sym, entries] of Object.entries(data.stages ?? {})) {
      const fresh = entries.filter(s => now - s.ts < 60 * 60 * 1000);
      if (fresh.length > 0) whaleWatchStages.set(sym, fresh);
    }
    for (const [sym, entry] of Object.entries(data.pathA ?? {})) {
      if (entry.expiresAt > now) whaleWatchPathA.set(sym, entry);
    }
    if (whaleWatchStages.size > 0 || whaleWatchPathA.size > 0)
      logger.info({ symbols: whaleWatchStages.size, pathA: whaleWatchPathA.size }, "🐋 Whale Watch stages restored from DB");
  } catch (err) {
    logger.warn({ err }, "loadWhaleWatchStages: failed (non-critical)");
  }
}

export interface WhaleWatchStateStage {
  symbol:       string;
  stageCount:   number;
  latestBuyPct: number;
  firstStageAt: number;
  latestStageAt: number;
}
export interface WhaleWatchStatePathA {
  symbol:     string;
  detectedAt: number;
  priceAt3rd: number;
  expiresAt:  number;
}

/** Возвращает текущее состояние real-time Whale Watch (этапы + PATH A очередь). */
export function getWhaleWatchState(): { stages: WhaleWatchStateStage[]; pathA: WhaleWatchStatePathA[] } {
  const now = Date.now();
  const stages: WhaleWatchStateStage[] = [];
  for (const [symbol, entries] of whaleWatchStages) {
    const fresh = entries.filter(s => now - s.ts < 60 * 60 * 1000);
    if (fresh.length > 0) {
      stages.push({
        symbol,
        stageCount:    fresh.length,
        latestBuyPct:  fresh[fresh.length - 1].buyPct,
        firstStageAt:  fresh[0].ts,
        latestStageAt: fresh[fresh.length - 1].ts,
      });
    }
  }
  stages.sort((a, b) => b.stageCount - a.stageCount || b.latestStageAt - a.latestStageAt);
  const pathA: WhaleWatchStatePathA[] = [];
  for (const [symbol, entry] of whaleWatchPathA) {
    pathA.push({ symbol, ...entry });
  }
  return { stages, pathA };
}

// ── In-memory state ─────────────────────────────────────────────────────────

/**
 * OI baseline — time-based.
 * Activity-score approach: the same "hot" tokens are scanned every 10 min,
 * so we can build baselines quickly and measure OI delta over ~20-60 min.
 */
interface OIBaseline {
  oi: number;
  takenAt: number;
}
const oiBaseline = new Map<string, OIBaseline>();
// Hot tokens are rescanned every 10 min — measure OI over a ~20-60 min window
const MIN_BASELINE_AGE_MS = 20 * 60 * 1000;   // update baseline no more than once per 20 min
const MAX_BASELINE_AGE_MS = 60 * 60 * 1000;   // baseline older than 60 min is too stale

/** Fetch fresh market price for a symbol at the moment of oiWatchTable insert.
 *  Prevents stale priceAtEntry caused by long scan loops (10-15 min lag). */
async function getFreshPrice(symbol: string, fallback: number): Promise<number> {
  try {
    const ticker = await getFutureTicker(symbol);
    if (ticker) {
      const p = parseFloat((ticker as any).lastPrice);
      if (p > 0) return p;
    }
  } catch { /* non-critical */ }
  return fallback;
}

/** Load OI baselines from DB on startup so restarts don't cause blind spots */
async function loadBaselinesFromDb(): Promise<void> {
  try {
    const rows = await db.select().from(oiBaselinesTable);
    const cutoff = Date.now() - MAX_BASELINE_AGE_MS;
    let loaded = 0;
    for (const row of rows) {
      const takenAt = row.takenAt.getTime();
      if (takenAt >= cutoff) {
        oiBaseline.set(row.symbol, { oi: row.oi, takenAt });
        loaded++;
      }
    }
    logger.info({ loaded, total: rows.length }, "OI baselines loaded from DB");
  } catch (err) {
    logger.warn({ err }, "Failed to load OI baselines from DB — starting fresh");
  }
}

let _lastBaselinePersist = 0;
const BASELINE_PERSIST_INTERVAL_MS = 5 * 60 * 1000; // persist to DB every 5 min

/** Persist changed baselines to DB (called after each scan) */
async function persistBaselinesToDb(): Promise<void> {
  const now = Date.now();
  if (now - _lastBaselinePersist < BASELINE_PERSIST_INTERVAL_MS) return;
  _lastBaselinePersist = now;
  try {
    const values = [...oiBaseline.entries()].map(([symbol, b]) => ({
      symbol,
      oi: b.oi,
      takenAt: new Date(b.takenAt),
    }));
    if (values.length === 0) return;
    await db.insert(oiBaselinesTable)
      .values(values)
      .onConflictDoUpdate({ target: oiBaselinesTable.symbol, set: { oi: sql`excluded.oi`, takenAt: sql`excluded.taken_at` } });
    logger.debug({ count: values.length }, "OI baselines persisted to DB");
  } catch (err) {
    logger.warn({ err }, "Failed to persist OI baselines to DB");
  }
}

// ── Prescan Tracker persistence ───────────────────────────────────────────────

/** On startup: restore prescan entries from DB so cycleCount survives rebuilds.
 *  Entries older than 24h are ignored (stale, token likely cooled down). */
async function loadPrescanFromDb(): Promise<void> {
  try {
    const rows = await db.select().from(prescanTrackerTable);
    const cutoff = Date.now() - 24 * 60 * 60 * 1000; // 24h cutoff
    let loaded = 0;
    for (const row of rows) {
      const updatedAt = row.updatedAt.getTime();
      if (updatedAt < cutoff) continue; // skip stale entries
      prescanTracker.set(row.symbol, {
        firstPrice24h: row.firstPrice24h,
        lastPrice24h:  row.firstPrice24h, // will be updated on next scan
        firstSeenAt:   row.firstSeenAt,
        firstPrice:    row.firstPrice,
        cycleCount:    row.cycleCount,
        bestRank:      row.bestRank,
        lastScore:     row.firstScore,
        firstScore:    row.firstScore,
        lastPrice:     row.firstPrice,    // will be updated on next scan
        lastFiredAt:   row.lastFiredAt,
      });
      loaded++;
    }
    logger.info({ loaded, total: rows.length }, "Prescan tracker loaded from DB");
  } catch (err) {
    logger.warn({ err }, "Failed to load prescan tracker from DB — starting fresh");
  }
}

/** Persist current prescan tracker state to DB (upsert all active entries). */
async function savePrescanToDb(): Promise<void> {
  try {
    const entries = Array.from(prescanTracker.entries());
    if (entries.length === 0) return;
    const now = new Date();
    const values = entries.map(([symbol, e]) => ({
      symbol,
      cycleCount:    e.cycleCount,
      firstSeenAt:   e.firstSeenAt,
      bestRank:      e.bestRank,
      firstPrice:    e.firstPrice,
      firstPrice24h: e.firstPrice24h,
      firstScore:    e.firstScore,
      lastFiredAt:   e.lastFiredAt,
      updatedAt:     now,
    }));
    await db.insert(prescanTrackerTable)
      .values(values)
      .onConflictDoUpdate({
        target: prescanTrackerTable.symbol,
        set: {
          cycleCount:  sql`excluded.cycle_count`,
          bestRank:    sql`excluded.best_rank`,
          lastFiredAt: sql`excluded.last_fired_at`,
          updatedAt:   sql`excluded.updated_at`,
        },
      });
    // Delete DB rows for symbols no longer in prescan (dropped out of top-N)
    const activeSymbols = entries.map(([s]) => s);
    await db.delete(prescanTrackerTable)
      .where(sql`symbol NOT IN (${sql.join(activeSymbols.map(s => sql`${s}`), sql`, `)})`);
    logger.debug({ count: values.length }, "Prescan tracker saved to DB");
  } catch (err) {
    logger.warn({ err }, "Failed to save prescan tracker to DB");
  }
}

interface SymbolSignalState {
  firstSignalAt: Date;
  signalCount: number;
  cumulativeOiChange: number;
}
const signalHistory = new Map<string, SymbolSignalState>();

let scanTimer: ReturnType<typeof setTimeout> | null = null;

// ── Settings ────────────────────────────────────────────────────────────────
async function getSettings() {
  const rows = await db.select().from(settingsTable).limit(1);
  if (rows.length === 0) {
    const inserted = await db.insert(settingsTable).values({
      volumeMultiplier: 3,
      oiChangePercent: 8,
      fundingRateThreshold: 0.0005,
      scanIntervalMs: 300_000,
      telegramEnabled: true,
      maxSymbols: 100,
    }).returning();
    return inserted[0];
  }
  return rows[0];
}

import {
    type SentimentKey, type SentimentResult, type AlphaResult, type DetectionResult,
    getOiCaps, detectSentiment, calcAlphaScore, evaluatePattern,
  } from "./scanner-patterns.js";

  // ── Main scan ────────────────────────────────────────────────────────────────
export async function performScan(): Promise<{ signalsFound: number; marketsScanned: number; durationMs: number }> {
  const startTime = Date.now();
  const settings = await getSettings();

  // Очищаем устаревшие записи signalHistory (TTL: 48 часов).
  // Без TTL история растёт вечно — символы которые давно не скануются остаются в памяти.
  const TTL_MS = 48 * 60 * 60 * 1000;
  for (const [sym, st] of signalHistory.entries()) {
    if (Date.now() - st.firstSignalAt.getTime() > TTL_MS) {
      signalHistory.delete(sym);
    }
  }

  // Sweep: помечаем все OI Watch записи у которых истёк expiresAt.
  // Без этого символы выпавшие из топ-пресскана висят в "watching"/"confirming" вечно.
  try {
    await db.update(oiWatchTable)
      .set({ status: "expired", firedAt: new Date() })
      .where(and(
        inArray(oiWatchTable.status, ["watching", "confirming"]),
        lt(oiWatchTable.expiresAt, new Date()),
      ));
  } catch (err) {
    logger.warn({ err }, "OI Watch expired sweep failed");
  }

  // Очищаем кэш CoinGlass перед каждым сканом — данные всегда свежие
  clearCoinglassOICache();
  logger.info("Starting AltBullet Scanner (5m scan, 30m TF, 5-pattern)...");

  let tickers;
  try {
    tickers = await getFutureTickers();
  } catch (err) {
    logger.error({ err }, "Failed to fetch BingX tickers");
    state.bingxConnected = false;
    return { signalsFound: 0, marketsScanned: 0, durationMs: Date.now() - startTime };
  }
  state.bingxConnected = true;

  // ── Activity-score pre-screening (ALL tokens, 1 API call) ───────────────────
  // Score every USDT token using already-fetched ticker data (free, no extra calls).
  // Hot tokens (big price move + big volume) get deep-scanned every 10 min,
  // so OI baselines build up within 20 min — not 100 min like with rotation.
  //
  // score = abs(priceChange24h%) × log10(quoteVolumeUSD + 1)
  // This ranks: tokens with big price moves in liquid markets first.
  // Exclude index/stock trackers (NCS*, NCC*, symbols with "2USD" — e.g. NCSKSPY2USD-USDT)
  const isCryptoFuture = (symbol: string) => {
    const base = symbol.replace("-USDT", "");
    return !base.includes("2USD") && !base.startsWith("NCS") && !base.startsWith("NCC");
  };

  const scored = tickers
    .filter(t => t.symbol.endsWith("-USDT") && isCryptoFuture(t.symbol))
    .map(t => {
      const pctChange = Math.abs(parseFloat(t.priceChangePercent) || 0);
      const vol = parseFloat(t.quoteVolume) || 0;
      const score = pctChange * Math.log10(vol + 1);
      return { ticker: t, score };
    })
    .sort((a, b) => b.score - a.score);

  // ── Layer 0: user watchlist — always scanned regardless of rank ──────────────
  const watchlistSymbols: string[] = (String(settings.watchlist ?? ""))
    .split(",")
    .map((s: string) => s.trim().toUpperCase())
    .filter((s: string) => s.length > 0)
    .map((s: string) => s.includes("-") ? s : `${s}-USDT`); // auto-append -USDT if missing
  const watchlistSet = new Set(watchlistSymbols);
  const watchlistTickers = tickers.filter(t => watchlistSet.has(t.symbol));
  const watchlistSymbolsFound = new Set(watchlistTickers.map(t => t.symbol));

  // ── Exhausted pump pre-filter (free — BingX ticker data, no extra API calls) ─
  // Монеты с >40% за 24h уже отработали свой памп. Новый сигнал невозможен —
  // это подтверждено паттерном (exhausted pump filter на глубоком скане).
  // Исключаем ЗДЕСЬ чтобы не тратить дорогие слоты CoinGlass API на мёртвые монеты.
  // Исключение: watchlist — пользователь явно хочет их отслеживать.
  const isExhaustedByTicker = (sym: string, pctChange24h: string): boolean => {
    if (watchlistSet.has(sym)) return false;
    return Math.abs(parseFloat(pctChange24h) || 0) > 40;
  };

  // ── Layer 1: top-N by activity score (current hot movers)
  const activityLimit = settings.maxSymbols; // default 50
  const topByActivity = scored
    .filter(s => !isExhaustedByTicker(s.ticker.symbol, s.ticker.priceChangePercent))
    .slice(0, activityLimit)
    .map(s => s.ticker);
  const activeSymbols = new Set(topByActivity.map(t => t.symbol));

  // ── Layer 2: top-200 by volume — BingX только как fallback для первого скана.
  //    После 1-го скана используем cgVolumeCache (global volUsd от CoinGlass):
  //    DYDX с $246M OI и высоким global volume попадёт в пул даже при низком BingX-объёме.
  const useCgVolume = cgVolumeCache.size > 0;
  const topByVolume = [...scored]
    .filter(s => !isExhaustedByTicker(s.ticker.symbol, s.ticker.priceChangePercent))
    .sort((a, b) => {
      const symA = a.ticker.symbol.replace("USDT", "").replace("-", "");
      const symB = b.ticker.symbol.replace("USDT", "").replace("-", "");
      const volA = useCgVolume
        ? (cgVolumeCache.get(symA) ?? cgVolumeCache.get(a.ticker.symbol) ?? (parseFloat(a.ticker.quoteVolume) || 0))
        : (parseFloat(a.ticker.quoteVolume) || 0);
      const volB = useCgVolume
        ? (cgVolumeCache.get(symB) ?? cgVolumeCache.get(b.ticker.symbol) ?? (parseFloat(b.ticker.quoteVolume) || 0))
        : (parseFloat(b.ticker.quoteVolume) || 0);
      return volB - volA;
    })
    .slice(0, 200)
    .map(s => s.ticker)
    .filter(t => !activeSymbols.has(t.symbol) && !watchlistSymbolsFound.has(t.symbol));

  // ── OI Universe Discovery: CoinGlass OI для ВСЕХ ~500 токенов ────────────────
  // Первичный фильтр — OI спайк на любом ТФ. Токены с глобальным ростом OI
  // попадают в пул независимо от объёма на BingX.
  // Standard plan: 300 req/min, 50ms задержка. Холодный старт: ~500 × 50ms ≈ 25с.
  // Кэш TTL 5 мин — повторные обращения в deep scan мгновенны (данные уже в кэше).
  const allBingxSymbols = scored.map(s => s.ticker.symbol);
  logger.info({ count: allBingxSymbols.length }, "OI Universe Discovery: CoinGlass OI для всех токенов...");
  const coinglassOIMap = await batchGetCoinglassOI(allBingxSymbols);

  const tickerBySymbol = new Map(scored.map(s => [s.ticker.symbol, s.ticker]));
  const topByVolumeSet = new Set(topByVolume.map(t => t.symbol));

  const oiMoverTickers: BingXTicker[] = [];
  for (const [sym, oi] of coinglassOIMap.entries()) {
    if (!oi.available) continue;
    if (activeSymbols.has(sym) || watchlistSymbolsFound.has(sym) || topByVolumeSet.has(sym)) continue;
    const hasSpike =
      (oi.oiChange5m  !== null && Math.abs(oi.oiChange5m)  >= 5.0)  ||
      (oi.oiChange30m !== null && Math.abs(oi.oiChange30m) >= 6.0)  ||
      (oi.oiChange1h  !== null && Math.abs(oi.oiChange1h)  >= 3.0)  ||
      (oi.oiChange4h  !== null && Math.abs(oi.oiChange4h)  >= 8.0)  ||
      (oi.oiChange24h !== null && Math.abs(oi.oiChange24h) >= 20.0);
    if (!hasSpike) continue;
    const ticker = tickerBySymbol.get(sym);
    if (!ticker) continue;
    if (isExhaustedByTicker(sym, ticker.priceChangePercent)) continue;
    oiMoverTickers.push(ticker);
  }
  if (oiMoverTickers.length > 0) {
    logger.info(
      { count: oiMoverTickers.length, symbols: oiMoverTickers.slice(0, 10).map(t => t.symbol) },
      "🌐 OI Universe Discovery: найдены OI movers за пределами топ-N BingX"
    );
  }

  const usdtTickers = [...watchlistTickers, ...topByActivity, ...topByVolume, ...oiMoverTickers];
  const scanLimit = activityLimit;

  // ── Spot Pool: запускаем фоновое обновление кэша (non-blocking) ──────────────
  // Первый цикл — кэш холодный, фильтр пропускает оптимистично.
  // Через 30 мин кэш прогреется и ранний фильтр начнёт отсекать неликвид до klines.
  triggerRefresh(usdtTickers.map(t => t.symbol));

  const topScore = scored[0]?.score?.toFixed(1) ?? "0";
  logger.info(
    {
      count: usdtTickers.length,
      watchlist: watchlistTickers.length,
      byActivity: topByActivity.length,
      byVolume: topByVolume.length,
      byOI: oiMoverTickers.length,
      volSource: useCgVolume ? `CoinGlass(cache=${cgVolumeCache.size})` : "BingX(firstRun)",
      totalTokens: scored.length,
      topScore,
      top5: scored.slice(0, 5).map(s => `${s.ticker.symbol}(${s.score.toFixed(1)})`),
      watchlistSymbols: watchlistTickers.map(t => t.symbol),
    },
    "Pre-screened tokens for deep scan"
  );

  // Top-10 pre-screened symbols — любой skip для них логируется на info (не debug)
  const topPrescanSymbols = new Set(scored.slice(0, 10).map(s => s.ticker.symbol));

  // ── Persistent Pre-screen Tracker: обновляем счётчики ───────────────────────
  {
    const nowTs = Date.now();
    const currentTopSymbols = new Set(topByActivity.map(s => s.symbol));

    // Удаляем токены, которые вышли из топ-N в этом цикле
    for (const sym of prescanTracker.keys()) {
      if (!currentTopSymbols.has(sym)) prescanTracker.delete(sym);
    }

    // Обновляем или добавляем токены в топ-N (с трекингом score и ранга)
    for (let rank = 0; rank < scored.slice(0, activityLimit).length; rank++) {
      const s = scored[rank]!;
      const sym = s.ticker.symbol;
      const price24h = Math.abs(parseFloat(s.ticker.priceChangePercent) || 0);
      const lastPrice = parseFloat(s.ticker.lastPrice) || 0;
      const rankOneBased = rank + 1;
      const existing = prescanTracker.get(sym);
      if (existing) {
        existing.cycleCount++;
        existing.lastPrice24h = price24h;
        existing.lastPrice    = lastPrice;
        existing.lastScore    = s.score;
        if (rankOneBased < existing.bestRank) existing.bestRank = rankOneBased;
      } else {
        prescanTracker.set(sym, {
          firstPrice24h: price24h,
          lastPrice24h:  price24h,
          firstSeenAt:   nowTs,
          firstPrice:    lastPrice,
          cycleCount:    1,
          bestRank:      rankOneBased,
          lastScore:     s.score,
          firstScore:    s.score,
          lastPrice:     lastPrice,
          lastFiredAt:   0,
        });
      }
    }
  }

  // Persist prescan state to DB after every cycle so cycleCount survives restarts
  void savePrescanToDb();

  // ── Phase 1: CoinGlass OI universe уже загружен на этапе OI Discovery ────────
  // coinglassOIMap содержит данные для всех ~500 токенов (из кэша или API).
  // Повторного запроса не нужно — данные свежие (только что получены выше).
  const oiMoversCount = oiMoverTickers.length;
  let cgVolCacheUpdated = 0;
  for (const [sym, oi] of coinglassOIMap.entries()) {
    if (oi.cgVolUsd && oi.cgVolUsd > 0) {
      const base = sym.replace(/-?USDT$/i, "").replace(/-/g, "");
      cgVolumeCache.set(base, oi.cgVolUsd);
      cgVolCacheUpdated++;
    }
  }
  logger.info(
    { universe: allBingxSymbols.length, oiMovers: oiMoversCount, scanPool: usdtTickers.length, cgCacheSize: cgVolumeCache.size, cgUpdated: cgVolCacheUpdated },
    "CoinGlass OI universe complete"
  );

  // ── Volume Breakout: persistent pre-screeners with no CoinGlass OI ────────────
  // Catches pure spot-volume driven pumps (e.g. BABYSHARK +80%) that are visible
  // in pre-screen for many cycles but invisible to CoinGlass OI filter.
  // Fires BEFORE Phase 2 (independently of klines/pattern scoring).
  {
    const VB_MIN_CYCLES    = 2;               // ≥2 consecutive cycles in top-N
    const VB_MIN_SCORE     = 200;             // activity score ≥ 200
    const VB_MIN_PRICE24H  = 3;              // 24h price change ≥ 3%
    const VB_MAX_PRICE24H  = 18;             // < 18% (памп раньше уже отыгран)
    const VB_SCORE_GROWTH  = 1.15;           // last score ≥ 115% of first score (growing)
    const VB_MAX_RANK      = 15;             // must have reached top-15 at least once
    const VB_COOLDOWN_MS   = 4 * 60 * 60 * 1000; // 4h cooldown per symbol

    const nowTs       = Date.now();
    const scoredMap   = new Map(scored.map(s => [s.ticker.symbol, s]));
    const vbFired: string[] = [];

    for (const [sym, entry] of prescanTracker.entries()) {
      if (entry.cycleCount < VB_MIN_CYCLES)                                   continue;
      if (entry.lastScore < VB_MIN_SCORE)                                     continue;
      if (entry.lastPrice24h < VB_MIN_PRICE24H || entry.lastPrice24h > VB_MAX_PRICE24H) continue;
      if (entry.lastScore < entry.firstScore * VB_SCORE_GROWTH)               continue;
      if (entry.bestRank > VB_MAX_RANK)                                       continue;
      if (entry.lastFiredAt > 0 && (nowTs - entry.lastFiredAt) < VB_COOLDOWN_MS) continue;

      // Skip if CoinGlass returned strong OI signal — standard flow will fire instead
      const cgOI = coinglassOIMap.get(sym);
      if (cgOI?.available) {
        const hasOISignal =
          Math.abs(cgOI.oiChange5m  ?? 0) >= 5.0 ||
          Math.abs(cgOI.oiChange30m ?? 0) >= 8.0 ||
          Math.abs(cgOI.oiChange1h  ?? 0) >= 6.0;
        if (hasOISignal) continue;
      }

      const scoredEntry = scoredMap.get(sym);
      if (!scoredEntry) continue;

      const currentPrice  = parseFloat(scoredEntry.ticker.lastPrice) || entry.lastPrice;
      const quoteVol      = parseFloat(scoredEntry.ticker.quoteVolume) || 0;
      const scoreGrowthPct = ((entry.lastScore / entry.firstScore) - 1) * 100;
      const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BYBIT:${sym.replace("-", "")}`;
      const bingxUrl       = `https://bingx.com/en-us/perpetual/${sym}/`;

      entry.lastFiredAt = nowTs;
      vbFired.push(sym);

      let insertedId: number | undefined;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          const [ins] = await db.insert(signalsTable).values({
            symbol:             sym,
            type:               "alpha",
            value:              entry.lastScore,
            threshold:          VB_MIN_SCORE,
            price:              currentPrice,
            priceChangePercent: entry.lastPrice24h,
            volume24h:          quoteVol,
            avgVolume:          0,
            openInterest:       null,
            oiChangePercent:    0,
            fundingRate:        null,
            tradingViewUrl,
            sentiment:          "Споtvol без OI",
            sentimentKey:       "volume_breakout",
            alphaScore:         6,
            isContinuing:       false,
            cumulativeOiChange: 0,
          }).returning({ id: signalsTable.id });
          insertedId = ins?.id;
          break;
        } catch (err) {
          if (attempt >= 3) {
            logger.error({ err, sym, attempt }, "VolumeBreakout: insert failed after 3 attempts — signal dropped");
          } else {
            logger.warn({ err, sym, attempt }, "VolumeBreakout: insert failed, retry in 2s");
            await new Promise(r => setTimeout(r, 2_000));
          }
        }
      }

      if (!insertedId) continue;

      // ── Spot volume gate (Volume Breakout) ──────────────────────────────────
      // Блокируем если ОБА условия не выполнены:
      // Спот-объём >= 0.05% MCap — только процентный порог, без фиксированной суммы.
      // Нет MCap данных → блок (нельзя оценить объём без капитализации).
      const VB_MIN_SPOT_MCAP_PCT = 0.0015; // 0.15%
      const [spotVol24h, vbMcapData] = await Promise.all([
        getCoinglassSpotVolume24h(sym).catch(() => null),
        fetchMarketCap(sym).catch(() => null),
      ]);
      const vbMcapUsd = vbMcapData?.mcap ?? null;
      if (spotVol24h === null) {
        logger.info({ sym }, "VolumeBreakout: нет данных спота — сигнал отменён");
        continue;
      }
      {
        const vbMcapAvailable = vbMcapUsd !== null;
        // Degraded mode: если MCap недоступен (CoinGecko timeout) — проверяем abs минимум 500K USDT.
        const vbSpotOk = vbMcapAvailable
          ? spotVol24h >= vbMcapUsd! * VB_MIN_SPOT_MCAP_PCT
          : spotVol24h >= 500_000;
        if (!vbSpotOk) {
          const pct = vbMcapUsd ? (spotVol24h / vbMcapUsd * 100).toFixed(3) : "нет MCap";
          logger.info(
            { sym, spotVol24h, vbMcapUsd, pct, degraded: !vbMcapAvailable },
            vbMcapAvailable
              ? "VolumeBreakout: спот-объём < 0.15% MCap — сигнал отменён"
              : "VolumeBreakout: MCap недоступен, спот < 500K USDT (degraded) — сигнал отменён"
          );
          continue;
        }
        if (!vbMcapAvailable) {
          logger.warn({ sym, spotVol24h }, "VolumeBreakout: MCap недоступен (CoinGecko timeout) — degraded mode, abs 500K пройден");
        }
      }

      // ── CVD Gate (VolumeBreakout) ────────────────────────────────────────────
      // Тот же двойной CVD-гейт что в CONFIRMED FIRE и основном scan loop.
      // Данные недоступны → не блокируем.
      {
        const [vbTf, vbCvd] = await Promise.all([
          getCoinglassTakerFlow(sym).catch(() => null),
          fetchCVD(sym).catch(() => null),
        ]);
        if (vbTf?.available && vbTf.dominance === "sell") {
          logger.info(
            { sym, netBuyPct: vbTf.netBuyPct.toFixed(1) + "%", exchanges: vbTf.exchanges },
            "VolumeBreakout: Taker Flow — продавцы доминируют → сигнал отменён"
          );
          continue;
        }
        if (vbCvd && !vbCvd.positive) {
          logger.info(
            { sym, buyPct: vbCvd.buyPct.toFixed(1) + "%", trades: vbCvd.trades },
            "VolumeBreakout: CVD негативный → сигнал отменён"
          );
          continue;
        }
      }

      let vbTracked: Awaited<ReturnType<typeof trackSignal>> = false;
      try {
        vbTracked = await trackSignal({
          symbol:       sym,
          signalId:     insertedId,
          signalType:   "alpha",
          sentiment:    "Споtvol без OI",
          sentimentKey: "volume_breakout",
          alphaScore:   6,
          entryPrice:   currentPrice,
          entryOi:      null,
        });
      } catch (err) {
        logger.warn({ err, sym }, "VolumeBreakout: trackSignal failed — broadcast отменён");
      }
      if (vbTracked === false || vbTracked === "skip") {
        logger.info({ sym, result: vbTracked }, "VolumeBreakout: trackSignal вернул skip/false — broadcast пропущен");
        continue;
      }

      const alphaResult: AlphaResult = {
        symbol:               sym,
        grade:                "alpha",
        price:                currentPrice,
        priceChange30m:       entry.lastPrice24h,
        currentVolume:        quoteVol,
        avgVolume:            0,
        volumeMultiplier:     entry.lastScore / Math.max(entry.firstScore, 1),
        oiChangePercent:      0,
        openInterest:         0,
        cmcRank:              null,
        cmcSource:            null,
        cmcAvailable:         false,
        liquidationsUsd:      null,
        liquidationsMultiple: null,
        coinglassAvailable:   false,
        coinalyzeOiChange:    null,
        coinalyzeConfirmed:   false,
        isNewListing:         false,
        isExhaustedSqueeze:   false,
        pumpFromOpen:         null,
        candleCount:          0,
        sentiment:            "Споtvol без OI",
        sentimentKey:         "volume_breakout",
        traderAction:         `LONG (спот-объём ${Math.round(scoreGrowthPct)}% рост за ${entry.cycleCount} цикл${entry.cycleCount >= 5 ? "ов" : "а"}, стоп -5%)`,
        alphaScore:           6,
        isContinuing:         false,
        cumulativeOiChange:   0,
        tradingViewUrl,
        bingxUrl,
        oiTriggerTf:          "prescan",
        oiChange5m:           null,
        oiChange1h:           null,
        oiChange4h:           null,
        oiChange24h:          null,
        spotVol24h,
        marketCapUsd:         vbMcapUsd,
      };

      try {
        await broadcastBatchAlert([alphaResult]);
        logger.info(
          {
            sym,
            cycleCount:  entry.cycleCount,
            bestRank:    entry.bestRank,
            score:       entry.lastScore.toFixed(1),
            scoreGrowth: Math.round(scoreGrowthPct) + "%",
            price24h:    entry.lastPrice24h.toFixed(1) + "%",
            hasCG:       cgOI?.available ?? false,
          },
          "📈 VOLUME BREAKOUT: persistent prescan mover — signal fired"
        );
      } catch (err) {
        logger.error({ err, sym }, "VolumeBreakout: broadcast failed");
      }
    }

    if (vbFired.length > 0) {
      void savePrescanToDb();
    }
  }

  // Phase 2: gather alpha candidates (klines + volume + pattern)
  const candidates: {
    symbol: string;
    price: number;
    priceChange30m: number;
    price4hChange: number;      // Изменение цены за 4ч (8×30m) — для пост-памп фильтра
    currentVolume: number;
    avgVolume: number;
    volumeMultiplier: number;
    oiChangePercent: number;    // Best (max abs) из 5m/30m/1h OI — для скоринга
    oiChange5m: number | null;  // Сырое 5m значение — для отображения в сигнале
    oiChange1h: number | null;  // Сырое 1h значение — для отображения в сигнале
    oiChange4h: number | null;  // Сырое 4h значение — для отображения в сигнале
    oiChange24h: number | null; // Сырое 24h значение — для отображения в сигнале
    openInterest: number;       // CoinGlass global OI in USD (or 0)
    sentiment: SentimentResult;
    coinglassOI: CoinglassOIResult;
    oiTriggerTf: string;       // Какой ТФ сработал: "5m", "30m", "5m+30m"
    isRepeatSignal: boolean;   // символ уже был в сигналах за последние 24ч
    isConfirmedFire: boolean;  // из confirming-очереди — пропускаем watching, стреляем сразу
    isScalpOnly: boolean;      // MTF Spot CVD: старшие ТФ (1h/4h) не подтверждают
  }[] = [];

  // Track top-performers for debug log (even if they don't pass)
  const debugTop: { symbol: string; vol: number; cgOI: number | null; price: number }[] = [];

  // TTL-очистка in-memory confirming fallback (записи старше 90 мин удаляем)
  const nowTtl = Date.now();
  for (const [sym, entry] of confirmingWatchMap) {
    if (nowTtl - entry.addedAt.getTime() > CONFIRMING_WATCH_TTL_MS) {
      confirmingWatchMap.delete(sym);
    }
  }

  // Skip reason counters for INFO-level diagnostics
  const skipCount = {
    noKlines: 0,
    exhaustedPump: 0,
    deepNegative: 0,
    noOiNoVol: 0,
    contraSignal: 0,
    lowVolume: 0,
    repeatSignal: 0,
    stalePump: 0,       // exit pump (vol>>OI) / ghost pump guard
    cooldown: 0,        // stop-loss / cancelled / chronic token cooldown
    noConfirming: 0,    // OI Watch confirming window failed / insert failed
    priceTooHigh: 0,    // stale signal (price moved too much) / runaway
    cvdFail: 0,         // CVD негативный (MTF spot CVD, main CVD, confirmed fire)
    takerFail: 0,       // Taker Flow негативный / funding перегрет
    spotFail: 0,        // SpotVol/MCap gate не прошёл
    other: 0,
  };
  let spotFailLogCount = 0; // лимит диагностических логов на цикл

  const now = Date.now();

  // ── Coinalyze batch OI 24h — топ-30 по CoinGlass OI ─────────────────────────
  // Берём топ-30 токенов с наибольшим абс. изменением OI из уже загруженной
  // coinglassOIMap (данные только что получены на этапе OI Universe Discovery).
  // DB-деdup: атомарный UPDATE+RETURNING — только один из двух продакшн-процессов
  // делает запрос к Coinalyze, второй пропускает → нет HTTP 429.
  // Cooldown 90 мин в БД → max ~16 req/day на оба процесса вместе.
  {
    const COINALYZE_COOLDOWN_MS = 90 * 60 * 1000;
    const cooldownThreshold = new Date(now - COINALYZE_COOLDOWN_MS);
    try {
      const claimed = await db.update(settingsTable)
        .set({ lastCoinalyzeBatchAt: new Date() })
        .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_coinalyze_batch_at IS NULL OR last_coinalyze_batch_at < ${cooldownThreshold})`)
        .returning({ id: settingsTable.id });
      if (claimed.length > 0) {
        // Этот процесс владеет запросом — берём топ-30 по максимальному абс. OI change
        const topOiSymbols = [...coinglassOIMap.entries()]
          .filter(([, oi]) => oi.available)
          .sort(([, a], [, b]) => {
            const maxA = Math.max(Math.abs(a.oiChange1h ?? 0), Math.abs(a.oiChange4h ?? 0), Math.abs(a.oiChange24h ?? 0));
            const maxB = Math.max(Math.abs(b.oiChange1h ?? 0), Math.abs(b.oiChange4h ?? 0), Math.abs(b.oiChange24h ?? 0));
            return maxB - maxA;
          })
          .slice(0, 30)
          .map(([sym]) => sym);
        // Добавляем prescan-символы: у них CoinGlass часто таймаутит, а oi24h критичен для скора
        const prescanSymbols = [...prescanTracker.keys()];
        const batchSymbols = [...new Set([...topOiSymbols, ...prescanSymbols])];
        logger.info({ count: batchSymbols.length, prescanExtra: prescanSymbols.length, top5: topOiSymbols.slice(0, 5) }, "🦑 Coinalyze batch: этот процесс делает запрос");
        void batchGetCoinalyzeOI24h(batchSymbols).catch(() => undefined);
      } else {
        logger.info("🦑 Coinalyze batch: другой процесс уже сделал запрос — пропускаем");
      }
    } catch (err) {
      logger.warn({ err }, "Coinalyze batch DB guard failed — пропускаем батч");
    }
  }

  // ── Pre-scan fresh prices для confirming inserts ─────────────────────────────
  // CoinGlass batch уже занял 8+ мин. Kline close = закрытие свечи (0-30 мин назад).
  // Чтобы priceAtEntry в confirming был реальной ценой в момент добавления —
  // берём свежий тикер прямо перед per-symbol loop.
  const confirmPriceMap = new Map<string, number>();
  try {
    const confirmTickers = await getFutureTickers();
    for (const t of confirmTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) confirmPriceMap.set((t as any).symbol, p);
    }
  } catch { /* non-critical — falls back to kline close */ }

  for (const ticker of usdtTickers) {
    const symbol = ticker.symbol;
    try {
      // ── Spot Liquidity Pre-filter ────────────────────────────────────────────
      // Проверяем кэш спот-ликвидности до дорогого klines-запроса.
      // Порог 0.15% MCap — соответствует порогу confirmed_fire.
      // Если данных нет в кэше → пропускаем оптимистично (individual gate поймает).
      if (!isSpotLiquid(symbol, 0.0015)) {
        if (spotFailLogCount < 10) {
          const entry = getSpotPoolEntry(symbol);
          const spotVol24h = entry?.spotVol24h ?? null;
          const mcapUsd    = entry?.mcapUsd    ?? null;
          const reason     = !entry ? "not_cached"
            : spotVol24h === null   ? "no_spot_vol"
            : mcapUsd    === null   ? "no_mcap"
            : `pct_threshold(${(spotVol24h / mcapUsd * 100).toFixed(3)}%)`;
          logger.info({ symbol, spotVol24h, mcapUsd, reason }, "SPOTFAIL detail");
          spotFailLogCount++;
        }
        skipCount.spotFail++;
        continue;
      }

      const klines = await getKlines(symbol, "30m", 49);

      // Требуем минимум 10 свечей для расчёта среднего объёма
      if (klines.length < 10) continue;

      const current = klines[klines.length - 1];
      // v3.0 Step 3: use last 20 candles for average volume (not all 48)
      const historical = klines.slice(-21, -1);

      const close = parseFloat(current.close) || 0;
      const open = parseFloat(current.open) || 0;
      if (!close || !open) continue;

      const currentVol = (parseFloat(current.volume) || 0) * close;
      const avgVol = historical.length > 0
        ? historical.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / historical.length
        : 0;

      if (!avgVol) continue;

      const priceChange = ((close - open) / open) * 100;
      const volMult = currentVol / avgVol;

      // 4h price context: compare current close to close ~8 candles (4h) ago.
      // Используется для пост-памп фильтра в Phase 3.
      const lookback4hIdx = Math.max(0, klines.length - 1 - 8);
      const base4hClose = parseFloat(klines[lookback4hIdx]?.close || "0");
      const price4hChange = base4hClose > 0 ? ((close - base4hClose) / base4hClose) * 100 : 0;

      // 1h price context: compare current close to close 2 candles ago (2×30m = 1h).
      // Хранится в prescanTracker для отображения в воронке сканера.
      const lookback1hIdx = Math.max(0, klines.length - 1 - 2);
      const base1hClose = parseFloat(klines[lookback1hIdx]?.close || "0");
      const price1hChange = base1hClose > 0 ? ((close - base1hClose) / base1hClose) * 100 : null;

      // 4h cumulative volume: средний объём последних 8 свечей (4h) vs базовый avgVol (20 свечей).
      // Используется в 4h Momentum Pattern для обнаружения медленных грайндов.
      const recent8 = klines.slice(-9, -1); // 8×30m = 4h, без текущей свечи
      const vol4hAvg = recent8.length >= 4
        ? recent8.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / recent8.length
        : 0;
      const volMult4h = avgVol > 0 && vol4hAvg > 0 ? vol4hAvg / avgVol : 0;

      // Volume trend: объём за последние 2 закрытые свечи (не текущая).
      // Если хотя бы одна из них >= 1.3x нормы — объём нарастает трендом, не одиночный спайк.
      // Используется как фильтр качества для hidden_accumulation.
      const prev1k = klines[klines.length - 2];
      const prev2k = klines[klines.length - 3];
      const prevVol1 = prev1k ? (parseFloat(prev1k.volume) || 0) * (parseFloat(prev1k.close) || 0) : 0;
      const prevVol2 = prev2k ? (parseFloat(prev2k.volume) || 0) * (parseFloat(prev2k.close) || 0) : 0;
      const prevVol1Mult = avgVol > 0 ? prevVol1 / avgVol : 0;
      const prevVol2Mult = avgVol > 0 ? prevVol2 / avgVol : 0;
      // Тренд объёма: хотя бы одна из 2 предыдущих закрытых свечей тоже была >= 1.3x
      const isVolTrend = prevVol1Mult >= 1.3 || prevVol2Mult >= 1.3;

      // ── PRE-FILTER: Exhausted pump — price up >20% in 24h AND volume now cooling off ──
      // We DON'T block early breakouts (PIPPIN: 24h=0.84% at signal time).
      // Блок поздних входов по 24h цене из BingX — независимо от CoinGlass/Coinalyze.
      // BingX priceChangePercent = изменение за последние 24h, всегда актуально.
      const price24hChange = parseFloat(ticker.priceChangePercent) || 0;

      // ── Sharp Impulse Detection ────────────────────────────────────────────────
      // Паттерн: текущая свеча сама является импульсом (price >= 7% за свечу + vol >= 2x).
      // Примеры: HYPERLANE +20.28% за 15 мин, AXS +12%+. Цена уже улетела, но движение продолжается.
      // Такие сигналы блокируются exhausted pump filter + anti-stale filter — обходим их для этого паттерна.
      // OI 5m/30m > 0 проверяется после получения CoinGlass данных (в det override ниже).
      const isSharpImpulse = priceChange >= 5.0 && volMult >= 3.0;

      // ── Volume Flash Detection ─────────────────────────────────────────────────
      // Паттерн: объём взорвался (>= 6x baseline) + цена начала движение (>= 3%).
      // Ловит начало flash-памп без OI-подтверждения — следуй за деньгами.
      // Примеры: SKYAI +71% за день — объём был аномальным, OI не успел отреагировать.
      // Обходит stale-фильтр: высокий объём = движение ещё идёт (не устаревший сигнал).
      // CVD обязателен (в отличие от прежней версии) — защита от дамп-памп манипуляций.
      const isVolumeFlash = !isSharpImpulse && volMult >= 5.0 && priceChange >= 3.0 && priceChange <= 25.0;

      // 1. Памп уже отыгран: цена выросла 30%+ за 24h И объём остывает (< 2.5x).
      //    Порог 30% (был 20%) — ZEC на +20% за день это тренд, не исчерпанный памп.
      //    Дополнительно: если 4h объём >= 1.3x — монета ещё активна (многодневный тренд), пропускаем.
      //    Исключение: sharp_impulse — свеча сама является импульсом, объём ещё горячий.
      if (!isSharpImpulse && price24hChange > 40 && volMult < 2.5 && volMult4h < 1.3) {
        logger.info({ symbol, price24hChange: price24hChange.toFixed(1) + "%", volMult: volMult.toFixed(2) }, "SKIP: exhausted pump (>40% 24h + vol < 2.5x) — слишком поздно для входа");
        skipCount.exhaustedPump++;
        // Памп уже случился — истекаем все confirming-записи, сигнал теперь бессмысленен
        await db.update(oiWatchTable)
          .set({ status: "expired", firedAt: new Date() })
          .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "confirming")));
        continue;
      }

      // 2. Монета в нисходящем тренде 24h → хвост дампа после пампа, лонги ликвидируются.
      //    Памп был вчера — сегодня монета уже -8% или хуже. Входить = ловить падающий нож.
      if (price24hChange < -8) {
        if (topPrescanSymbols.has(symbol)) {
          logger.info({ symbol, price24hChange: price24hChange.toFixed(1) + "%", prescanTop10: true }, "🚫 TOP-10 SKIP [deepNeg]: цена ниже -8% за 24h — post-dump, входить не стоит");
        } else {
          logger.debug({ symbol, price24hChange: price24hChange.toFixed(1) + "%" }, "SKIP: 24h price deeply negative — post-pump dump");
        }
        skipCount.deepNegative++;
        // Цена упала — сетап сломан, истекаем confirming-записи
        await db.update(oiWatchTable)
          .set({ status: "expired", firedAt: new Date() })
          .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "confirming")));
        continue;
      }

      // ── FAST TRACK: BingX Price + Volume (без CoinGlass) ────────────────────────
      // Если свеча >= 10% И объём >= 7x среднего — сигнал достаточно сильный сам по себе.
      // Это ловит explosive starts (BIO 12:00 МСК: +9.82%, 5.1x vol) без ожидания OI.
      // Пример: при CoinGlass batch = 8 мин, к 12:08 МСК цена уже выросла на 25%.
      const FAST_TRACK_PRICE_PCT = 7.0;  // % свечи для прямого входа
      const FAST_TRACK_VOL_MULT  = 6.0;  // множитель объёма для прямого входа

      // ── PREV CANDLE FAST TRACK: ловим когда большая свеча закрылась между сканами ──
      // Проблема: скан запускается в 05:29, тратит 8 мин на CoinGlass batch.
      // К 05:37 свеча 05:00-05:30 (+28%) уже закрылась, текущая 05:30-06:00 flat (+0.5%).
      // Решение: если ПРЕДЫДУЩАЯ закрытая свеча была fast_track — и цена ещё держится
      // (не откатилась > 5% от закрытия той свечи) — это тоже valid сигнал.
      const prevPriceChange = prev1k
        ? ((parseFloat(prev1k.close) - parseFloat(prev1k.open)) / parseFloat(prev1k.open)) * 100
        : 0;
      const prevClose1 = parseFloat(prev1k?.close || "0");
      const priceFromPrevClose = prevClose1 > 0 ? ((close - prevClose1) / prevClose1) * 100 : 0;
      const isPrevFastTrack = Math.abs(prevPriceChange) >= FAST_TRACK_PRICE_PCT
                           && prevVol1Mult >= FAST_TRACK_VOL_MULT
                           && priceFromPrevClose > -5.0;  // цена ещё держится от закрытия

      const isFastTrack = (Math.abs(priceChange) >= FAST_TRACK_PRICE_PCT && volMult >= FAST_TRACK_VOL_MULT)
                       || isPrevFastTrack;

      // ── MTF SPOT CVD PRE-FILTER (v9) ─────────────────────────────────────────────
      // Первостепенный фильтр: спот должен подтверждать покупки на 5m И 15m (hard gate).
      // Если 1h или 4h в минусе — сигнал помечается как "Scalp Only" (риск разворота).
      // Если CoinGlass недоступен → не блокируем сигнал (graceful fallback).
      // Исключения: Fast Track (цена +10% + 7x vol) и Sharp Impulse (свеча +7%+).
      let spotCvd: Awaited<ReturnType<typeof getSpotCvdMtf>> | null = null;
      let isScalpOnly = false;
      let _wfSpotCvdHardBlocked = false;
      if (!isFastTrack && !isSharpImpulse) {
        spotCvd = await getSpotCvdMtf(symbol);
        if (spotCvd.available && spotCvd.hardBlocked) {
          // Defer continue — whale_futures detection still needs oi values extracted below
          _wfSpotCvdHardBlocked = true;
        }
        if (spotCvd.available) {
          isScalpOnly = spotCvd.scalpOnly;
          logger.debug(
            {
              symbol,
              cvd5m: spotCvd.cvd5m,
              cvd15m_3of4: spotCvd.cvd15m_3of4,
              cvd1h: spotCvd.cvd1h,
              cvd4h: spotCvd.cvd4h,
              scalpOnly: isScalpOnly,
              isGolden: spotCvd.isGolden,
            },
            spotCvd.isGolden
              ? "✅ MTF SPOT CVD: Golden Signal (все 4 ТФ в плюсе)"
              : isScalpOnly
                ? "⚠️ MTF SPOT CVD: 5m+15m ок, но 1h/4h в минусе → Scalp Only"
                : "✅ MTF SPOT CVD: подтверждено",
          );
        }
        const _prescanForCvd = prescanTracker.get(symbol);
        if (_prescanForCvd && spotCvd.available) {
          _prescanForCvd.lastCvdOk = !spotCvd.hardBlocked;
          _prescanForCvd.lastNetBuyPct = spotCvd.cvd5m === true ? 50 : spotCvd.cvd5m === false ? -50 : 0;
        }
      }

      // ── STEP 1: PRIMARY FILTER — CoinGlass глобальный OI (агрегат по всем биржам) ──
      // Проверяем 5 таймфреймов: 5m, 30m, 1h, 4h, 24h.
      // Fast Track символы проходят этот блок без проверки OI.
      const cgOI = coinglassOIMap.get(symbol);

      // ── CoinGlass Timeout Fallback: BingX OI прямой запрос ───────────────────
      // Когда CoinGlass таймаутит по символу (малые токены, rate-limit),
      // вычисляем % изменения OI напрямую из BingX: текущий OI vs сохранённый baseline.
      // Baseline обновляется каждые 20-60 мин → получаем аналог oi30m/oi1h.
      let bingxDirectOIChange: number | null = null;
      if (!cgOI?.available) {
        // Уровень 1: BingX прямой запрос vs baseline (без лимитов, мгновенно)
        const baseline = oiBaseline.get(symbol);
        if (baseline && (Date.now() - baseline.takenAt.getTime()) < MAX_BASELINE_AGE_MS) {
          const bxOI = await getOpenInterest(symbol);
          if (bxOI) {
            const currentOI = parseFloat(bxOI.openInterest);
            if (currentOI > 0 && baseline.oi > 0) {
              bingxDirectOIChange = ((currentOI - baseline.oi) / baseline.oi) * 100;
              logger.info(
                {
                  symbol,
                  currentOI: currentOI.toFixed(0),
                  baselineOI: baseline.oi.toFixed(0),
                  changePct: bingxDirectOIChange.toFixed(1) + "%",
                  baselineAgeMin: ((Date.now() - baseline.takenAt.getTime()) / 60000).toFixed(0),
                },
                "🔄 CG FALLBACK L1: BingX OI прямой запрос (CoinGlass таймаут)"
              );
            }
          }
        }

        // Уровень 2 (Coinalyze fallback) — УДАЛЁН.
        // Per-symbol вызов Coinalyze выжигал 100 req/day в первом же скане
        // при 2 autoscale процессах × 40-60 символов без CoinGlass данных.
        // Coinalyze используется только в Stage 3 для подтверждённых кандидатов.
      }

      const oi5m  = cgOI?.oiChange5m  ?? null;
      const oi30m = cgOI?.oiChange30m ?? (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
      const oi1h  = cgOI?.oiChange1h  ?? (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
      const oi4h  = cgOI?.oiChange4h  ?? null;
      // oi24h: CoinGlass → Coinalyze кэш (без HTTP, батч прогрет выше)
      const oi24h = cgOI?.oiChange24h ?? getCoinalyzeOI24hCached(symbol);

      // Сохраняем live OI TF данные и 1h цену в prescan tracker для отображения в UI
      {
        const _pe = prescanTracker.get(symbol);
        if (_pe) {
          _pe.lastOi5m    = oi5m;
          _pe.lastOi30m   = oi30m;
          _pe.lastOi1h    = oi1h;
          _pe.lastOi4h    = oi4h;
          _pe.lastOi24h   = oi24h;
          _pe.lastPrice1h = price1hChange;
        }
      }

      // ── WHALE FUTURES: одиночная спот-покупка + рост OI → в watchlist ───────────
      // Независимый детектор: записывает потенциальное событие в БД (без немедленного сигнала).
      // Вотчер fast-cycle (2 мин) позже проверяет подтверждение от розницы (taker + funding).
      // Работает даже если spotCvd.hardBlocked — одна крупная 5m свеча = именно нужный паттерн.
      {
        const WF_OI_30M_MIN = 5.0; // % порог роста OI за 30m (оба должны быть ≥ порога)
        const WF_OI_1H_MIN  = 4.0; // % порог роста OI за 1h  (оба должны быть ≥ порога)
        // AND: оба таймфрейма должны подтверждать рост OI (не достаточно одного)
        const wfOiOk   = (oi30m !== null && oi30m >= WF_OI_30M_MIN) && (oi1h !== null && oi1h >= WF_OI_1H_MIN);
        // Требуем устойчивый спот-поток: 5m положительный И хотя бы 15m (3 из 4) или 1h.
        // Один флэш-candle (5m) может быть случайным. Устойчивое давление = реальный кит.
        const wfSpotOk = spotCvd?.available === true
          && spotCvd.cvd5m === true
          && (spotCvd.cvd15m_3of4 === true || spotCvd.cvd1h === true);
        // Цена не должна падать: кит покупает → цена растёт или нейтральна
        const wfPriceOk = priceChange >= 0 && priceChange <= 15 && price24hChange <= 40;
        if (wfSpotOk && wfOiOk && wfPriceOk) {
          const wfExpiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000); // 48h окно
          const wfCooldownSince = new Date(Date.now() - 4 * 60 * 60 * 1000); // 4h кулдаун
          // Async check + insert: не дублируем если символ уже в watchlist (watching или добавлен < 4ч назад)
          (async () => {
            try {
              const existing = await db.select({ id: whaleFuturesWatchlistTable.id })
                .from(whaleFuturesWatchlistTable)
                .where(and(
                  eq(whaleFuturesWatchlistTable.symbol, symbol),
                  or(
                    eq(whaleFuturesWatchlistTable.status, "watching"),
                    gt(whaleFuturesWatchlistTable.detectedAt, wfCooldownSince),
                  ),
                ))
                .limit(1);
              if (existing.length > 0) return; // уже наблюдаем или был добавлен < 4ч назад
              await db.insert(whaleFuturesWatchlistTable).values({
                symbol,
                priceAtDetection: close,
                oi30mAtDetection: oi30m ?? null,
                oi1hAtDetection:  oi1h  ?? null,
                expiresAt: wfExpiresAt,
                status: "watching",
              });
              logger.info(
                { symbol, oi30m: oi30m?.toFixed(1) ?? "n/a", oi1h: oi1h?.toFixed(1) ?? "n/a", price: priceChange.toFixed(1) + "%" },
                "🐳 WHALE FUTURES: спот-покупка + OI рост → добавлен в watchlist (ждём розницу)"
              );
            } catch (err) {
              logger.debug({ err, symbol }, "WhaleFutures: insert error (non-critical)");
            }
          })();
        }
      }

      // ── WHALE WATCH: спот-накопление без явного OI-импульса → мягкий watchlist ───
      // Отдельный детектор (type='spot'). Подтверждение через спот CVD в watcher.ts.
      // Условия мягче Futures: один таймфрейм OI, цена боковая, нет требования Taker Flow.
      {
        const WW_OI_MIN     = 2.0; // % — хватит одного из двух таймфреймов
        const WW_PRICE_MIN  = -1.0;
        const WW_PRICE_MAX  = 3.0;
        const WW_24H_MAX    = 20.0;

        const wwOiOk    = (oi30m !== null && oi30m >= WW_OI_MIN) || (oi1h !== null && oi1h >= WW_OI_MIN);
        const wwSpotOk  = spotCvd?.available === true && spotCvd.cvd5m === true;
        const wwPriceOk = priceChange >= WW_PRICE_MIN && priceChange <= WW_PRICE_MAX && price24hChange <= WW_24H_MAX;

        // Не детектируем если символ уже попал в Futures watchlist (wfSpotOk && wfOiOk уже сработало)
        const alreadyInFutures = wfSpotOk && wfOiOk && wfPriceOk;

        if (wwOiOk && wwSpotOk && wwPriceOk && !alreadyInFutures) {
          const wwExpiresAt     = new Date(Date.now() + 72 * 60 * 60 * 1000); // 72h
          const wwCooldownSince = new Date(Date.now() - 8  * 60 * 60 * 1000); // 8h кулдаун
          (async () => {
            try {
              const existing = await db.select({ id: whaleFuturesWatchlistTable.id })
                .from(whaleFuturesWatchlistTable)
                .where(and(
                  eq(whaleFuturesWatchlistTable.symbol, symbol),
                  or(
                    eq(whaleFuturesWatchlistTable.status, "watching"),
                    gt(whaleFuturesWatchlistTable.detectedAt, wwCooldownSince),
                  ),
                ))
                .limit(1);
              if (existing.length > 0) return;
              await db.insert(whaleFuturesWatchlistTable).values({
                symbol,
                priceAtDetection: close,
                oi30mAtDetection: oi30m ?? null,
                oi1hAtDetection:  oi1h  ?? null,
                expiresAt: wwExpiresAt,
                status: "watching",
                type:   "spot",
              });
              logger.info(
                { symbol, oi30m: oi30m?.toFixed(1) ?? "n/a", oi1h: oi1h?.toFixed(1) ?? "n/a", price: priceChange.toFixed(1) + "%" },
                "🐋 WHALE WATCH: спот CVD + OI → добавлен в watchlist (type=spot)"
              );
            } catch (err) {
              logger.debug({ err, symbol }, "WhaleWatch: insert error (non-critical)");
            }
          })();
        }
      }

      // Apply deferred MTF CVD hard block (was deferred to allow whale_futures detection above)
      if (_wfSpotCvdHardBlocked) {
        if (topPrescanSymbols.has(symbol)) {
          pushFilteredCandidate({ symbol, reason: "cvd_blocked", reasonLabel: "CVD: спот не подтверждает (5m/15m −)", oi5m, oi30m, oi1h, oi4h, oi24h, vol: volMult, price: priceChange, filteredAt: Date.now() });
          logger.info(
            { symbol, prescanTop10: true, cvd5m: spotCvd?.cvd5m, cvd15m_3of4: spotCvd?.cvd15m_3of4,
              oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
            "🚫 TOP-10 SKIP [CVD]: спот не подтверждает покупки (5m или 15m в минусе)",
          );
        } else {
          logger.info(
            { symbol, cvd5m: spotCvd?.cvd5m, cvd15m_3of4: spotCvd?.cvd15m_3of4 },
            "SKIP [MTF SPOT CVD]: спот не подтверждает покупки (5m или 15m в минусе)",
          );
        }
        skipCount.cvdFail++;
        continue;
      }

      // ── WHALE WATCH: Real-time 3-stage accumulation detection ─────────────────
      // Runs for every symbol regardless of OI threshold.
      // Stage conditions: price sideways ≤±0.5% on 30m + OI growing + CVD/taker buy confirms.
      // Signal: 3 stages in 60-min rolling window → PATH A (+1.0% within 60 min).
      // Мегакапы (BTC/ETH/SOL) исключены — у них всегда фоновый OI > 0 и taker buy ≥ 55%,
      // что создаёт постоянный шум без реальной информации об аномальном накоплении.
      {
        const WHALE_WATCH_BLACKLIST = new Set(["BTC-USDT", "ETH-USDT", "SOL-USDT"]);
        const priceIsSideways = Math.abs(priceChange) <= 0.5;
        // Требуем значимый рост OI: ≥0.3% за 5m ИЛИ ≥1.5% за 30m.
        // Исключает фоновый шум крупных монет (SOL/ETH всегда 0.0x%) и случайные флуктуации.
        const oiIsGrowing = (oi5m !== null && oi5m >= 0.3) || (oi30m !== null && oi30m >= 1.5);

        if (priceIsSideways && oiIsGrowing && !WHALE_WATCH_BLACKLIST.has(symbol)) {
          try {
            const cvdData = await fetchCVD(symbol, 500);
            // ТЗ: CVD растёт (лимитный выкуп, buyPct ≥63%) ИЛИ Taker Buy > 70% (агрессивный)
            const takerBuyConfirmed = cvdData !== null && cvdData.buyPct >= 63;

            if (takerBuyConfirmed) {
              const now = Date.now();
              const stages = whaleWatchStages.get(symbol) ?? [];
              const fresh = stages.filter(s => now - s.ts < 60 * 60 * 1000);
              fresh.push({ ts: now, price: close, buyPct: cvdData.buyPct });
              whaleWatchStages.set(symbol, fresh);
              void saveWhaleWatchStagesToDb();

              logger.info(
                { symbol, stages: fresh.length, buyPct: cvdData.buyPct.toFixed(1) + "%", priceChange: priceChange.toFixed(2) + "%" },
                `🐋 WHALE WATCH: этап ${fresh.length}/3 зафиксирован`,
              );

              // Fire alert after 3rd stage (90-min dedup via whaleWatchPathA)
              const existingPathA = whaleWatchPathA.get(symbol);
              const pathAExpired = !existingPathA || Date.now() > existingPathA.expiresAt;
              if (fresh.length >= 3 && pathAExpired) {
                whaleWatchPathA.set(symbol, {
                  detectedAt: now,
                  priceAt3rd: close,
                  expiresAt:  now + 90 * 60 * 1000,
                });
                const base = symbol.replace("-USDT", "");
                const fmtOi = (v: number | null) => v !== null ? `${v > 0 ? "+" : ""}${v.toFixed(1)}%` : null;
                const oiParts = [
                  oi5m  !== null ? `5m:<b>${fmtOi(oi5m)}</b>`  : null,
                  oi30m !== null ? `30m:<b>${fmtOi(oi30m)}</b>` : null,
                  oi1h  !== null ? `1h:<b>${fmtOi(oi1h)}</b>`  : null,
                ].filter(Boolean).join(" / ");
                const msg = [
                  `🐋 <b>WHALE WATCH: ${base}/USDT</b>`,
                  `🏷 <b>Паттерн:</b> Whale Watch (Accumulation)`,
                  ``,
                  `Зафиксировано 3 этапа крупных закупок кита за последние 60 мин.`,
                  ``,
                  `  • Цена: <b>${close.toFixed(4)}</b> (flat ${priceChange.toFixed(2)}%)`,
                  `  • OI: ${oiParts || "—"}`,
                  `  • Taker Buy: <b>${cvdData.buyPct.toFixed(1)}%</b>`,
                  ``,
                  `🎯 Сигнал активен — позиция открыта.`,
                  ``,
                  `🔗 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P">TradingView</a>`,
                  ``,
                  `#${base} #whale_watch`,
                ].join("\n");
                // ── Spot volume gate (Whale Watch) ──────────────────────────────────────
                const [wwSpotVol24h, wwMcapRaw] = await Promise.all([
                  getCoinglassSpotVolume24h(symbol).catch(() => null),
                  fetchMarketCap(symbol).catch(() => null),
                ]);
                const wwMcapUsd = wwMcapRaw?.mcap ?? null;
                const wwMcapAvailable = wwMcapUsd !== null;
                // Degraded mode: если MCap недоступен (CoinGecko timeout) — проверяем abs минимум 500K USDT.
                const wwSpotOk = wwSpotVol24h !== null && (
                  wwMcapAvailable
                    ? wwSpotVol24h >= wwMcapUsd! * 0.003
                    : wwSpotVol24h >= 500_000
                );
                if (!wwSpotOk) {
                  const pct = (wwSpotVol24h !== null && wwMcapUsd) ? (wwSpotVol24h / wwMcapUsd * 100).toFixed(3) : "нет MCap";
                  logger.info({ symbol, wwSpotVol24h, wwMcapUsd, pct, degraded: !wwMcapAvailable },
                    wwSpotVol24h === null
                      ? "WHALE WATCH: нет данных спота — сигнал отменён"
                      : wwMcapAvailable
                        ? "WHALE WATCH: спот-объём < 0.3% MCap — сигнал отменён"
                        : "WHALE WATCH: MCap недоступен, спот < 500K USDT (degraded) — сигнал отменён");
                  whaleWatchPathA.delete(symbol);
                } else {
                if (!wwMcapAvailable && wwSpotVol24h !== null) {
                  logger.warn({ symbol, wwSpotVol24h }, "WHALE WATCH: MCap недоступен (CoinGecko timeout) — degraded mode, abs 500K пройден");
                }
                try {
                  const [whaleSig] = await db.insert(signalsTable).values({
                    symbol,
                    type:               "whale_watch",
                    value:              oi5m ?? 0,
                    threshold:          0,
                    price:              close,
                    priceChangePercent: priceChange,
                    volume24h:          currentVol,
                    avgVolume:          avgVol,
                    tradingViewUrl:     `https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P`,
                    sentiment:          `WHALE WATCH | 3 этапа за 60 мин | OI 5m: ${(oi5m ?? 0).toFixed(1)}% | Taker: ${cvdData.buyPct.toFixed(1)}%`,
                    sentimentKey:       "whale_watch",
                    detectedAt:         new Date(),
                  }).returning();

                  const trackedResult = await trackSignal({
                    symbol,
                    signalId:      whaleSig?.id ?? null,
                    signalType:    "whale_watch",
                    sentiment:     `WHALE WATCH | 3 этапа | OI 5m: ${(oi5m ?? 0).toFixed(1)}% | Taker: ${cvdData.buyPct.toFixed(1)}%`,
                    sentimentKey:  "whale_watch",
                    entryPrice:    close,
                  });
                  if (trackedResult === "new" || trackedResult === "reentry") {
                    await broadcast(msg);
                    logger.info({ symbol, stages: fresh.length, priceAt3rd: close }, "🐋 WHALE WATCH: 3 этапа → сигнал активен, TG отправлен");
                  } else {
                    logger.info({ symbol, trackedResult }, "🐋 WHALE WATCH: 3 этапа — сигнал уже активен, TG пропущен");
                  }
                } catch (err) {
                  logger.warn({ err, symbol }, "WHALE WATCH: ошибка отправки алерта");
                }
                } // end spot ok else
              }
            }
          } catch (err) {
            logger.debug({ err, symbol }, "WHALE WATCH: ошибка CVD fetch (non-critical)");
          }
        }

      }

      // Пороги — дифференцированные по ТФ:
      // 5m: 5.0% (ловим начало импульса), 30m: 6.0%, 1h: 6% (исключаем флэт-шум),
      // 4h: 8% (медленное накопление за несколько часов), 24h: 20% (крупная капитализация)
      const OI_THRESH_5M  = 5.0;
      const OI_THRESH_30M = 6.0;
      const OI_THRESH_1H  = 3.0;  // снижен с 6% — 1h OI 3%+ уже значимое движение
      const OI_THRESH_4H  = 8.0;
      const OI_THRESH_24H = 20.0;
      // Требуем ПОЛОЖИТЕЛЬНЫЙ OI — отрицательный означает закрытие позиций/окончание движения.
      // Исключение short_squeeze обрабатывается отдельным детектором через hasShortTfOiDrop.
      const t5   = oi5m  !== null && oi5m  >= OI_THRESH_5M;
      const t30  = oi30m !== null && oi30m >= OI_THRESH_30M;
      const t1h  = oi1h  !== null && oi1h  >= OI_THRESH_1H;
      const t4h  = oi4h  !== null && oi4h  >= OI_THRESH_4H;
      const t24h = oi24h !== null && oi24h >= OI_THRESH_24H;

      // ── ФИЛЬТР: памп уже был — кросс-биржевой OI (CoinGlass, агрегат всех бирж) ──
      //
      // CoinGlass = агрегат Binance + Bybit + OKX + BingX + др. → это глобальный сигнал,
      // не привязан к одной бирже. Два случая:
      //
      // A) CoinGlass вернул 24h OI < -15% → шорты закрывались весь день → памп отыгран.
      if (oi24h !== null && oi24h < -15) {
        if (topPrescanSymbols.has(symbol)) {
          pushFilteredCandidate({ symbol, reason: "oi_24h_drop", reasonLabel: "OI 24h < -15% (памп отыгран)", oi5m, oi30m, oi1h, oi4h, oi24h, vol: volMult, price: priceChange, filteredAt: Date.now() });
          logger.info(
            { symbol, prescanTop10: true, oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a", oi1h: oi1h?.toFixed(1) ?? "n/a", oi24h: oi24h.toFixed(1) + "%", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
            "🚫 TOP-10 SKIP [OI-24h]: памп уже был — CoinGlass 24h OI < -15%"
          );
        } else {
          logger.debug(
            { symbol, oi24h: oi24h.toFixed(1) + "%" },
            "SKIP: памп уже был — CoinGlass 24h OI < -15% (глобальный агрегат)"
          );
        }
        skipCount.contraSignal++;
        continue;
      }

      // B) CoinGlass покрывает монету, но 24h поле отсутствует (null) — типично для малых токенов.
      //    В этом случае смотрим краткосрочные TF: если ВСЕ доступные (5m, 30m, 1h) отрицательные
      //    → OI падает по всему фронту → выдавливание лонгов / пост-памп дамп.
      if (cgOI?.available && oi24h === null) {
        const shortTfValues = [oi5m, oi30m, oi1h].filter(v => v !== null) as number[];
        const allNegative = shortTfValues.length >= 2 && shortTfValues.every(v => v < -2);
        if (allNegative) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
            "SKIP: 24h OI недоступен, но все краткосрочные TF отрицательные — OI падает по всему фронту"
          );
          skipCount.contraSignal++;
          continue;
        }
      }

      // "Steady Accumulation": 5m И 30m — умеренный но одновременный рост OI + цена во флэте.
      // Ловит скрытое накопление где ни один ТФ не пробивает порог, но оба показывают рост.
      // Примеры: oi5m=3%, oi30m=4.5% при priceChange=0.3% → крупный игрок набирает позицию тихо.
      const tSteady = !t5 && !t30 && !t1h && !t4h && !t24h
                   && oi5m  !== null && oi5m  >= 3.0
                   && oi30m !== null && oi30m >= 4.0
                   && Math.abs(priceChange) <= 2.0
                   && volMult >= 1.2;

      // Multi-TF confirmation:
      // — Короткие ТФ (5m, 30m) должны подтверждать друг друга — одиночный всплеск на 5m или 30m шум.
      // — Длинные ТФ (1h ≥6%, 4h ≥8%, 24h ≥20%) достаточно сильны и проходят поодиночке.
      const shortTfsConfirmed = t5 && t30;
      const longTfPass        = t1h || t4h || t24h;
      // anyOiPass: либо CoinGlass дал данные, либо BingX прямой фолбэк сработал
      const hasFallbackOI = bingxDirectOIChange !== null;
      const anyOiPass = (cgOI?.available || hasFallbackOI) && (shortTfsConfirmed || longTfPass || tSteady);

      // ── Фильтр: короткие ТФ + противоречие длинных ────────────────────────────
      // Если сработали только 5м+30м, но 4h или 24h OI глубоко в минусе —
      // весь день шли продажи/выход из позиций, краткосрочный всплеск ложный.
      // short_squeeze здесь невозможен: требует отрицательного OI (hasShortTfOiDrop),
      // тогда как shortTfsConfirmed требует положительного OI ≥5%/6% — взаимоисключение.
      if (shortTfsConfirmed && !longTfPass) {
        if (oi24h !== null && oi24h < -10) {
          if (topPrescanSymbols.has(symbol)) {
            pushFilteredCandidate({ symbol, reason: "oi_contra_24h", reasonLabel: "5m+30m ок, OI 24h < -10% (дневной слив)", oi5m, oi30m, oi1h, oi4h, oi24h, vol: volMult, price: priceChange, filteredAt: Date.now() });
            logger.info(
              { symbol, prescanTop10: true, oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a", oi1h: oi1h?.toFixed(1) ?? "n/a", oi24h: oi24h.toFixed(1) + "%", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
              "🚫 TOP-10 SKIP [OI-contra]: 5м+30м ок, но 24ч OI < -10% — дневной слив"
            );
          } else {
            logger.debug({ symbol, oi24h: oi24h.toFixed(1) + "%" }, "SKIP: 5м+30м ок, но 24ч OI < -10% — дневной слив");
          }
          skipCount.contraSignal++;
          continue;
        }
        if (oi4h !== null && oi4h < -5) {
          if (topPrescanSymbols.has(symbol)) {
            pushFilteredCandidate({ symbol, reason: "oi_contra_4h", reasonLabel: "5m+30m ок, OI 4h < -5% (4ч продажи)", oi5m, oi30m, oi1h, oi4h, oi24h, vol: volMult, price: priceChange, filteredAt: Date.now() });
            logger.info(
              { symbol, prescanTop10: true, oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a", oi1h: oi1h?.toFixed(1) ?? "n/a", oi4h: oi4h.toFixed(1) + "%", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
              "🚫 TOP-10 SKIP [OI-contra]: 5м+30м ок, но 4ч OI < -5% — последние 4ч продажи"
            );
          } else {
            logger.debug({ symbol, oi4h: oi4h.toFixed(1) + "%" }, "SKIP: 5м+30м ок, но 4ч OI < -5% — последние 4ч продажи");
          }
          skipCount.contraSignal++;
          continue;
        }
      }

      // ── 4h Momentum Pattern: медленный грайнд за несколько часов ─────────────────
      // Ловит монеты которые растут постепенно (+8-20% за 4h) с повышенным объёмом,
      // но без взрывной одиночной свечи. Пример: BLEND, LYN.
      // Средний объём последних 8 свечей (4h) должен быть 1.5x выше базовой нормы.
      // Порог снижен: 4% (был 8%) — ZEC за 4ч может расти на 3-5%, а не 8-20%.
      // volMult4h снижен: 1.2x (был 1.5x) — медленный тренд не даёт взрывного объёма.
      // Этот паттерн теперь покрывает и многодневные гринды (ZEC-тип), и внутридневные.
      const is4hMomentum = !anyOiPass
                        && price4hChange >= 3.0
                        && volMult4h >= 1.2
                        && priceChange > -2                        // текущая свеча не разворачивается
                        && oi1h !== null && oi1h >= 2.0            // 1h OI минимум 2% — деньги реально заходят
                        && (oi5m  === null || oi5m  > 0)          // 5m OI не уходит в минус
                        && (oi30m === null || oi30m > 0)          // 30m OI не уходит в минус
                        && (oi4h  === null || oi4h  > 0)          // 4h OI не уходит в минус
                        && (oi24h === null || oi24h > 0);         // 24h OI не уходит в минус

      // ── Early Ignition: 5m OI spike + 30m накопление + 1h глобальный интерес ──
      // Ловим начало импульса ДО того как он стал очевидным.
      // CVD > 0 уже проверен выше (cvdPre.cvdRising2 — обязательная покупательская динамика).
      // oi30m >= 15% = прокси "суммарный рост OI за последние 15-30 мин".
      const isEarlyIgnition = anyOiPass
                           && oi5m  !== null && oi5m  >= 8.0
                           && oi30m !== null && oi30m >= 8.0
                           && oi1h  !== null && oi1h  >= 3.0
                           && priceChange >= 1.0
                           && volMult >= 5.0;

      // ── Mega-OI: экстремальный OI 30m+1h при минимальном объёме ─────────────
      // Кит заходит через деривативы, объём спота спит — ONG-кейс.
      // OI 30m ≥ 35% + OI 1h ≥ 30% = масштаб движения не оставляет сомнений.
      // Объём ≥ 0.9x = хотя бы чуть жизни (фильтр мусора).
      // Цена: от –3% (выкуп дипа) до +8% (ещё не улетело).
      const isMegaOI = cgOI?.available === true
                    && oi30m !== null && oi30m >= 25.0
                    && oi1h  !== null && oi1h  >= 20.0
                    && volMult >= 1.5
                    && priceChange >= -3.0
                    && priceChange <= 6.0;

      // ── Байпас для cg_timeout/cg_building записей в очереди подтверждения ──────
      // Эти символы пропустили OI-фильтр (CG timeout или OI ниже порога), но уже
      // добавлены в confirming-очередь. Позволяем им дойти до confirming-блока (строка ~1426).
      const cgFallbackConfirmingRows = await db.select({ id: oiWatchTable.id })
        .from(oiWatchTable)
        .where(and(
          eq(oiWatchTable.symbol, symbol),
          eq(oiWatchTable.status, "confirming"),
          inArray(oiWatchTable.triggerTf, ["cg_timeout", "cg_building", "dark_flow"])
        ))
        .limit(1);
      const isCgFallbackConfirming = cgFallbackConfirmingRows.length > 0;

      if (!isFastTrack && !anyOiPass && !is4hMomentum && !isCgFallbackConfirming) {
        // ── FALLBACK: топ-50 активных токенов с недоступным или строящимся OI ─────
        // A) CG timeout (available=false): batch-запрос падает для TAG → добавляем в
        //    confirming-очередь. Те же 2ч ожидание что и у всех остальных сигналов.
        //    OI-фильтр не применяется (CG недоступен), но retrace/runaway/price+2% работают.
        // B) CG вернул данные но OI ниже порога на 2+ TF («строится»).
        //    Кейс: SKYAI/4USD — OI 3-4% на 5m+30m вместо 6% порога.
        if (activeSymbols.has(symbol)) {
          const cgTimeoutFallback = !cgOI?.available
                                 && volMult >= 2.0
                                 && priceChange > -5
                                 && priceChange < 25;
          const buildingTfCount = cgOI?.available
            ? [oi5m, oi30m, oi1h].filter(v => v !== null && v >= 2.0).length
            : 0;
          const cgBuildingFallback = cgOI?.available && buildingTfCount >= 2 && !anyOiPass;

          // ── DARK FLOW: устойчивая аномальная активность без следа в OI ──────────
          // CoinGlass ЕСТЬ данные, но OI не растёт ни на одном ТФ (в отличие от cg_building).
          // Монета 5+ сканов подряд (~25 мин) в топ-N пре-скрина с объёмом >= 2x.
          // BEAT-кейс: весь день #1 в пре-скрине (score 270-609), OI CG < 5%, сигнала нет.
          const dfTracker = prescanTracker.get(symbol);
          const darkFlowTrigger = cgOI?.available          // CG есть — не timeout
            && !cgBuildingFallback                        // OI даже слабо не строится
            && !anyOiPass                                 // OI не прошёл ни один порог
            && (dfTracker?.cycleCount ?? 0) >= 3         // 3+ сканов подряд в топ-N
            && volMult >= 2.0                            // объём подтверждён (2x+)
            && Math.abs(priceChange) < 25                // цена в разумном диапазоне
            && price24hChange < 15;                      // блок если 24h уже +15% — памп отыгран

          if (cgTimeoutFallback || cgBuildingFallback || darkFlowTrigger) {
            // Не дублируем если символ уже в очереди (watching или confirming)
            const alreadyQueued = await db.select({ id: oiWatchTable.id })
              .from(oiWatchTable)
              .where(and(
                eq(oiWatchTable.symbol, symbol),
                inArray(oiWatchTable.status, ["watching", "confirming"])
              ))
              .limit(1);

            if (alreadyQueued.length === 0) {
              const watchTf = cgTimeoutFallback ? "cg_timeout" : cgBuildingFallback ? "cg_building" : "dark_flow";
              const watchOi = oi30m ?? oi5m ?? oi1h ?? 0;
              try {
                await db.insert(oiWatchTable).values({
                  symbol,
                  triggerTf: watchTf,
                  oiChange: watchOi,
                  priceAtEntry: await getFreshPrice(symbol, close),
                  volumeMultiplier: volMult,
                  sentimentKey: null,
                  status: "confirming",           // тот же путь что у всех → 2ч окно
                  addedAt: new Date(),
                  expiresAt: new Date(Date.now() + (watchTf === "dark_flow" ? 3 : 6) * 60 * 60 * 1000), // dark_flow: 3ч; cg_timeout/cg_building: 6ч
                  avgVolume: avgVol,
                  isVolConfirmed: false,
                  oi5mChange:  oi5m,
                  oi30mChange: oi30m,
                  oi1hChange:  oi1h,
                });
                logger.info(
                  { symbol, reason: watchTf, vol: volMult.toFixed(1) + "x", price: priceChange.toFixed(1) + "%", buildingTfs: buildingTfCount, prescanCycles: dfTracker?.cycleCount ?? 0 },
                  watchTf === "dark_flow"
                    ? "🌑 DARK FLOW: устойчивая активность без OI — добавлен в confirming-очередь"
                    : "👁 ACTIVITY WATCH: топ-активный кандидат добавлен в 2ч confirming-очередь"
                );
              } catch { /* duplicate or db error — non-critical */ }
            }
          }
        }

        if (topPrescanSymbols.has(symbol)) {
          pushFilteredCandidate({ symbol, reason: "oi_filter", reasonLabel: "OI ниже порога (ни один TF не прошёл)", oi5m, oi30m, oi1h, oi4h, oi24h, vol: volMult, price: priceChange, filteredAt: Date.now() });
          logger.info(
            {
              symbol,
              prescanTop10: true,
              vol:    volMult.toFixed(2) + "x",
              vol4h:  volMult4h.toFixed(2) + "x",
              price:  priceChange.toFixed(2) + "%",
              price4h: price4hChange.toFixed(1) + "%",
              oi5m:   oi5m  !== null ? oi5m.toFixed(2)  + "%" : "n/a",
              oi30m:  oi30m !== null ? oi30m.toFixed(2) + "%" : "n/a",
              oi1h:   oi1h  !== null ? oi1h.toFixed(2)  + "%" : "n/a",
              oi4h:   oi4h  !== null ? oi4h.toFixed(2)  + "%" : "n/a",
              oi24h:  oi24h !== null ? oi24h.toFixed(2) + "%" : "n/a",
              cgAvail: cgOI?.available ?? false,
              thresholds: `5m≥5% 30m≥6% 1h≥3% 4h≥8% 24h≥20%`,
            },
            "🚫 TOP-10 SKIP [OI]: не прошёл OI-фильтр — ни один таймфрейм не достиг порога"
          );
        } else {
          logger.debug(
            {
              symbol,
              vol:      volMult.toFixed(2) + "x",
              vol4h:    volMult4h.toFixed(2) + "x",
              price:    priceChange.toFixed(2) + "%",
              price4h:  price4hChange.toFixed(1) + "%",
              oi5m:  oi5m?.toFixed(2)  ?? "n/a",
              oi30m: oi30m?.toFixed(2) ?? "n/a",
              oi1h:  oi1h?.toFixed(2)  ?? "n/a",
            },
            "SKIP: недостаточно объёма или движения цены (vol < 1.0x или price < 2.5%)"
          );
        }
        skipCount.noOiNoVol++;
        continue;
      }

      // Какой ТФ сработал (OI path) или fast_track (BingX path)
      let oiTriggerTf: string;
      let cgOIChange: number;

      if (is4hMomentum && !anyOiPass && !isFastTrack) {
        // 4h Momentum Pattern — медленный грайнд за несколько часов
        oiTriggerTf = "4h_momentum";
        cgOIChange = 0;
        logger.info(
          { symbol, price4h: price4hChange.toFixed(1) + "%", vol4h: volMult4h.toFixed(2) + "x", price: priceChange.toFixed(1) + "%" },
          "📈 4H MOMENTUM: медленный грайнд — 4h рост + повышенный средний объём"
        );
      } else if (isFastTrack && !anyOiPass) {
        // Чистый Fast Track — OI не сработал, но свеча + объём сильные
        oiTriggerTf = isPrevFastTrack && !(Math.abs(priceChange) >= FAST_TRACK_PRICE_PCT && volMult >= FAST_TRACK_VOL_MULT)
          ? "fast_track_prev"   // сработала предыдущая свеча (HIVE-кейс)
          : "fast_track";
        cgOIChange = 0;
        logger.info(
          {
            symbol,
            price:      priceChange.toFixed(1) + "%",
            vol:        volMult.toFixed(1) + "x",
            prevPrice:  prevPriceChange.toFixed(1) + "%",
            prevVol:    prevVol1Mult.toFixed(1) + "x",
            isPrevCandle: isPrevFastTrack && oiTriggerTf === "fast_track_prev",
          },
          "⚡ FAST TRACK: BingX price+vol bypass CoinGlass gate"
        );
      } else if (isEarlyIgnition) {
        // Early Ignition — 5m+30m+1h OI spike + vol 5x + price 2%+
        oiTriggerTf = "early_ignition";
        cgOIChange = oi5m!; // 5m OI — основной триггер
        logger.info(
          {
            symbol,
            oi5m:  oi5m!.toFixed(1) + "%",
            oi30m: oi30m!.toFixed(1) + "%",
            oi1h:  oi1h!.toFixed(1) + "%",
            vol:   volMult.toFixed(1) + "x",
            price: priceChange.toFixed(1) + "%",
          },
          "🔥 EARLY IGNITION: 5m OI spike + sustained accumulation + 5x vol — ловим старт"
        );
      } else if (isMegaOI) {
        // Mega-OI — экстремальный 30m+1h OI при минимальном объёме
        oiTriggerTf = "mega_oi";
        cgOIChange = oi30m!; // 30m OI — основной триггер
        logger.info(
          {
            symbol,
            oi30m: oi30m!.toFixed(1) + "%",
            oi1h:  oi1h!.toFixed(1) + "%",
            vol:   volMult.toFixed(1) + "x",
            price: priceChange.toFixed(1) + "%",
          },
          "🐋 MEGA-OI: экстремальный OI 30m+1h при низком объёме — кит в деривативах"
        );
      } else if (tSteady) {
        // Steady Accumulation — 5m + 30m одновременно, цена flat
        oiTriggerTf = "steady";
        cgOIChange = oi30m!; // берём 30m как основное значение для скоринга
        logger.info(
          { symbol, oi5m: oi5m!.toFixed(1) + "%", oi30m: oi30m!.toFixed(1) + "%", price: priceChange.toFixed(1) + "%" },
          "🔍 STEADY ACCUM: Multi-TF OI convergence + flat price"
        );
      } else {
        // Стандартный CoinGlass OI путь (или fast_track + OI — берём OI для скоринга)
        const triggeredTfs = [
          t5   && "5m",
          t30  && "30m",
          t1h  && "1h",
          t4h  && "4h",
          t24h && "24h",
        ].filter(Boolean) as string[];
        const fallbackSuffix = hasFallbackOI && !cgOI?.available ? "+bingx_direct" : "";
        oiTriggerTf = isFastTrack ? "fast_track+" + triggeredTfs.join("+") + fallbackSuffix : triggeredTfs.join("+") + fallbackSuffix;

        const cand5m  = t5   ? Math.abs(oi5m!)  : 0;
        const cand30m = t30  ? Math.abs(oi30m!) : 0;
        const cand1h  = t1h  ? Math.abs(oi1h!)  : 0;
        const cand4h  = t4h  ? Math.abs(oi4h!)  : 0;
        const cand24h = t24h ? Math.abs(oi24h!) : 0;
        const bestAbs = Math.max(cand5m, cand30m, cand1h, cand4h, cand24h);
        cgOIChange = bestAbs === cand5m  && t5   ? oi5m!
                   : bestAbs === cand30m && t30  ? oi30m!
                   : bestAbs === cand1h  && t1h  ? oi1h!
                   : bestAbs === cand4h  && t4h  ? oi4h!
                   : oi24h!;
      }

      // ── STEP 2: LIQUIDITY FILTER — Global Vol24h / OI USD > 0.1 (не «мёртвые» монеты) ──
      const oiUsd = cgOI?.oiUsd;
      const cgVolUsd = cgOI?.cgVolUsd;
      const vol24hUSD = parseFloat(ticker.quoteVolume) || 0;

      if (!isFastTrack && oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
        const turnoverRatio = cgVolUsd / oiUsd;
        if (turnoverRatio < 0.1) {
          logger.debug({ symbol, turnoverRatio: turnoverRatio.toFixed(3), cgVol: cgVolUsd, oiUsd }, "SKIP: low global turnover ratio (cgVol/OI < 0.1)");
          skipCount.other++;
          continue;
        }
      }

      // ── Ликвидность: относительные фильтры покрывают без абсолютных порогов ───
      // Все фильтры ниже — относительные (volMult, OI%, turnoverRatio, спред).
      // Абсолютных долларовых порогов нет: $15M для BTC — песчинка,
      // $15M для микрокапа — всё что есть. Мёртвые монеты отсеиваются спредом
      // (≥0.5% → пропустить) и volMult (2.5x своей базы).

      // ── FILTER: Exit pump — объём в 4x+ раз больше OI = поздний сброс, не органика ──
      if (!isFastTrack && oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
        const volToOi = cgVolUsd / oiUsd;
        if (volToOi > 4.0) {
          logger.debug({ symbol, volToOi: volToOi.toFixed(2) }, "SKIP: exit pump — объём >> OI (4x+)");
          skipCount.stalePump++;
          continue;
        }
      }

      // Debug tracking (для лог-сводки по итогам цикла)
      debugTop.push({ symbol, vol: volMult, cgOI: cgOIChange || null, price: priceChange });

      // ── FILTER: Spread — узкий спред (< 0.5%) если BingX возвращает bid/ask ────
      const bid = parseFloat(ticker.bidPrice ?? "0") || 0;
      const ask = parseFloat(ticker.askPrice ?? "0") || 0;
      if (bid > 0 && ask > 0) {
        const spreadPct = (ask - bid) / ask * 100;
        if (spreadPct >= 0.5) {
          logger.debug({ symbol, spread: spreadPct.toFixed(3) }, "SKIP: spread >= 0.5%");
          skipCount.other++;
          continue;
        }
      }

      // ── STEP 3: VOLUME FILTER — подтверждение интереса ──────────────────────────
      // Логика порогов объёма:
      //
      // A) "High OI Quiet" — OI ≥ 20% (24h) или ≥ 12% (4h) И цена ≤ 1.5% flat.
      //    Крупный игрок набирает позицию тихо в течение часов/суток.
      //    Порог: 1.8x — минимальное подтверждение объёмом (было 1.0x — слишком много шума).
      //
      // B) "Steady Accum" — 5m+30m одновременно + flat price (мульти-ТФ паттерн).
      //    Порог: 1.8x
      //
      // C) Стандартный путь (импульс, пробой, шорт-сквиз): единый порог 1.0x
      const isHighOiQuiet = Math.abs(priceChange) <= 1.5
                         && ((t24h && Math.abs(oi24h!) >= 20) || (t4h && Math.abs(oi4h!) >= 12));

      // Экстремальный вариант: OI 4h >= 20% или 24h >= 20% + цена плоская.
      // Китовое накопление — объёмный спайк по определению НЕ придёт в фазе накопления.
      // Снижаем порог до 0.9x — достаточно нормального торгового объёма.
      const isExtremeOiQuiet = isHighOiQuiet && (
        (t4h && Math.abs(oi4h!) >= 20) || (t24h && Math.abs(oi24h!) >= 20)
      );

      // "Медленное бычье накопление" — цена тихо ползёт вверх (1–8%) при наличии OI.
      // NEAR, GRASS, BLEND/LYN-тип: OI копится несколько часов, объём умеренный (1–2x).
      // Стандартный порог 2.5x их режет. Снижаем до 1.5x при bullish slow accum.
      // Условие: цена 1–8% (есть движение, но не взрыв) + хотя бы один OI ТФ сработал.
      const isBullishSlowAccum = priceChange >= 1 && priceChange <= 8
                              && (t5 || t30 || t1h || t4h || t24h);

      // Порог объёма:
      // - extreme OI quiet (накопление китов): 0.9x
      // - bullish slow accum (медленный бычий): 1.5x
      // - стандарт: 2.5x
      // Победители с НИЗКИМ объёмом: M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%), BNLIFE(0.99x, +3.3%).
      const volThreshold = isExtremeOiQuiet ? 0.9 : isBullishSlowAccum ? 1.5 : 2.5;

      // 4h Momentum: 30m объём может быть умеренным (1.2-2x) — монета идёт несколько часов/дней.
      // Условие достаточности: 4h объём >= 1.2x (проверено в is4hMomentum).
      // isCgFallbackConfirming: у символа уже есть запись в confirming-очереди
      // с trigger_tf="cg_building"/"cg_timeout" — даём ей дойти до confirming-блока
      // даже при объёме < 2.5x (без этого bypass символ уходит в OI Watch path
      // и никогда не достигает строки ~1684 с проверкой confirming-записи).
      if (volMult < volThreshold && !is4hMomentum && !isCgFallbackConfirming && !isMegaOI) {
        // ── OI WATCH: OI сработал, но объём ещё не подтянулся ────────────────────
        // Вместо того чтобы просто пропустить, ставим монету на наблюдение.
        // Критерии добавления в watch:
        //   1. OI уверенно сработал (хоть один ТФ)
        //   2. Объём пока ниже порога (иначе бы уже дали сигнал)
        //   3. Цена ещё не улетела (< 25% на текущей свече) — зарождение, не поздний вход
        //   4. Не новый листинг (у них своя логика Short Sniper)
        // t24h включён: монеты с устойчивым 24h накоплением (RECALL-тип) тоже попадают в OI Watch
        const oiTriggeredStrongly = cgOI?.available && (t5 || t30 || t1h || t24h);
        const priceNotYetExploded = Math.abs(priceChange) < 25;
        if (oiTriggeredStrongly && priceNotYetExploded && avgVol > 0) {
          try {
            // Изменение 2: если ВСЕ доступные TF OI положительные — используем
            // пониженный порог объёма в OI Watch (кодируем в triggerTf как "all+{tf}")
            const availableOis = [oi5m, oi30m, oi1h, oi4h, oi24h].filter(v => v !== null) as number[];
            const allAvailablePositive = availableOis.length >= 2 && availableOis.every(v => v > 0);
            const baseTf    = t5 ? "5m" : t30 ? "30m" : "1h";
            const triggerTf = allAvailablePositive ? `all+${baseTf}` : baseTf;
            const triggerOi = t5 ? oi5m! : t30 ? oi30m! : oi1h!;
            const expiresAt = new Date(Date.now() + 2 * 3600 * 1000); // +2h

            // Upsert: обновляем только активные watching записи, иначе вставляем новую
            const existing = await db.select({ id: oiWatchTable.id, status: oiWatchTable.status })
              .from(oiWatchTable)
              .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "watching")))
              .limit(1);

            if (existing.length > 0) {
              // Обновляем OI значение (накапливается)
              await db.update(oiWatchTable)
                .set({ oiChange: triggerOi, volumeMultiplier: volMult, expiresAt })
                .where(eq(oiWatchTable.id, existing[0].id));
            } else if (existing.length === 0) {
              await db.insert(oiWatchTable).values({
                symbol,
                triggerTf,
                oiChange: triggerOi,
                priceAtEntry: await getFreshPrice(symbol, close),
                volumeMultiplier: volMult,
                sentimentKey: null,
                status: "watching",
                addedAt: new Date(),
                expiresAt,
                avgVolume: avgVol,
                oi5mChange:  oi5m,
                oi30mChange: oi30m,
                oi1hChange:  oi1h,
              });
              logger.info(
                { symbol, triggerTf, oiChange: triggerOi.toFixed(2) + "%", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
                "👁 OI WATCH: добавлен кандидат (OI есть, объём ещё не подтянулся)"
              );
            }
          } catch (err) {
            logger.warn({ err, symbol }, "OI Watch insert failed");
          }
        }
        logger.debug(
          { symbol, volMult: volMult.toFixed(2), threshold: volThreshold, isHighOiQuiet, isSteady: tSteady },
          "SKIP: volume below threshold"
        );
        skipCount.lowVolume++;
        continue;
      }

      if (isHighOiQuiet) {
        logger.info(
          { symbol, oi24h: oi24h?.toFixed(1) + "%", oi4h: oi4h?.toFixed(1) + "%", price: priceChange.toFixed(1) + "%", vol: volMult.toFixed(1) + "x" },
          "🏦 HIGH OI QUIET: Large OI + flat price — hidden accumulation/distribution"
        );
      }

      // ── MOONSHOT: предварительная синхронная проверка (до stale filter) ─────────
      // Нужна чтобы ракеты с ценой 15–44% не отфильтровались по stale threshold.
      // Полная проверка (с orderbook) — ниже, после stale filter.
      const isPotentialMoonshot =
        volMult    >= (settings.moonshotVolMult    ?? 5.0) &&
        priceChange >= (settings.moonshotPriceChange ?? 15.0) &&
        cgOIChange  >= (settings.moonshotOiChange   ?? 10.0);

      // ── STEP 4: ANTI-STALE FILTER ─────────────────────────────────────────────
      // Если CoinGlass batch занял 8+ минут и монета уже двинулась на >= 20%
      // за последние 2 свечи (60 мин) — это запоздалый сигнал, пропускаем.
      // Исключение: sharp_impulse — свеча сама и есть начало движения, фильтр неприменим.
      // Исключение: volume_flash — объём 10x+ = движение ещё активно, не устаревший сигнал.
      // Исключение: moonshot_momentum — ракета на взлёте, stale filter неприменим.
      // (было 3 свечи / 15% — слишком агрессивно, пропускали вторые волны)
      const STALE_LOOKBACK  = 2; // свечи назад (2 × 30m = 60 мин)
      const STALE_THRESHOLD = 45; // % порог "уже поздно" (увеличено для ракет типа SUP/OWL)
      const staleRefIdx = klines.length - 1 - STALE_LOOKBACK;
      if (!isSharpImpulse && !isVolumeFlash && !isPotentialMoonshot && staleRefIdx >= 0) {
        const staleRefClose = parseFloat(klines[staleRefIdx].close) || 0;
        if (staleRefClose > 0) {
          const staleMove = Math.abs((close - staleRefClose) / staleRefClose * 100);
          if (staleMove >= STALE_THRESHOLD) {
            logger.info(
              { symbol, staleMove: staleMove.toFixed(1) + "%", lookbackCandles: STALE_LOOKBACK },
              "SKIP: stale signal — price already moved too much in last 3 candles"
            );
            skipCount.priceTooHigh++;
            continue;
          }
        }
      }

      // ── PATTERN EVALUATION (CoinGlass OI + Volume + Price) ────────────────────
      let det = evaluatePattern(cgOIChange, priceChange, volMult, null, settings, oiTriggerTf);

      // ── 🚀 MOONSHOT MOMENTUM: наивысший приоритет (переопределяет evaluatePattern) ──
      // Условия: объём ≥5x + цена ≥15% + OI ≥10% + нет крупных стен на продажу.
      // Игнорирует стандартные ограничения: STALE_THRESHOLD, MAX_RUNAWAY_PCT.
      if (isPotentialMoonshot) {
        try {
          const moonOB = await getOrderBookAnalysis(symbol, 50).catch(() => null);
          const askWallThreshold = settings.moonshotAskWallUsd ?? 50_000;
          const hasStrongAskWall =
            moonOB?.bias === "strong_bear" &&
            (moonOB?.largestAskWallUsd ?? 0) >= askWallThreshold;

          logger.info(
            {
              symbol,
              volMult: volMult.toFixed(1) + "x",
              priceChange: priceChange.toFixed(1) + "%",
              cgOIChange: cgOIChange.toFixed(1) + "%",
              obBias: moonOB?.bias ?? "n/a",
              askWallUsd: moonOB?.largestAskWallUsd ?? null,
              hasStrongAskWall,
            },
            "🚀 MOONSHOT MOMENTUM: условия проверены"
          );

          if (!hasStrongAskWall) {
            det = {
              passes: true,
              oiChangePercent: cgOIChange,
              openInterest: 0,
              sentiment: {
                key: "moonshot_momentum",
                label: "Импульс Ракеты",
                traderAction: "LONG по тренду (ракета запущена)",
                oiFalling: false,
              },
            };
          } else {
            logger.info({ symbol, askWallUsd: moonOB?.largestAskWallUsd }, "🚀 MOONSHOT: крупная стена на продажу — пропускаем");
          }
        } catch (moonErr) {
          logger.warn({ err: moonErr, symbol }, "MOONSHOT: ошибка orderbook — используем стандартный паттерн");
        }
      }

      // ── ФИЛЬТР: hidden_accumulation — требуем объёмный тренд (не одиночный спайк) ──
      // Одна свеча с высоким объёмом может быть шумом (арбитраж, вынос стопов).
      // Если предыдущие 2 закрытые свечи тоже показывают объём >= 1.3x — это ТРЕНД покупок.
      // Данные: SYN (vol=8x но prevVol была нормальная) — убираем такие сигналы.
      // Исключение: isExtremeOiQuiet — при тихом накоплении китов объёмного тренда
      // по определению нет. Сигнал — сам OI, а не объём. Фильтр неприменим.
      if (det?.sentiment.key === "hidden_accumulation" && !isVolTrend && !isExtremeOiQuiet) {
        logger.debug(
          { symbol, prevVol1: prevVol1Mult.toFixed(2) + "x", prevVol2: prevVol2Mult.toFixed(2) + "x" },
          "SKIP: hidden_accum — нет объёмного тренда (предыдущие свечи < 1.3x нормы)"
        );
        det = null;
      }

      // ── MTF SPOT CVD: hidden_accumulation требует подтверждения 1h + 4h ──────────
      // Накопление должно быть видно на старших ТФ спота — иначе шум деривативов.
      if (det?.sentiment.key === "hidden_accumulation" && spotCvd?.available) {
        if (spotCvd.cvd1h === false || spotCvd.cvd4h === false) {
          logger.debug(
            { symbol, cvd1h: spotCvd.cvd1h, cvd4h: spotCvd.cvd4h },
            "SKIP: hidden_accumulation — спот CVD 1h/4h не подтверждают накопление"
          );
          det = null;
        }
      }

      // ── ФИЛЬТР: устаревший Short Squeeze ─────────────────────────────────────
      // Если OI упал только на 4h/24h, но на 5m/30m нейтральный → сквиз был вчера,
      // не сейчас. Заходить в хвост пампа — опасно. Убираем такие сигналы.
      if (det?.sentiment.key === "short_squeeze") {
        const hasShortTfOiDrop = (oi5m !== null && oi5m < -1.5) || (oi30m !== null && oi30m < -1.5);
        if (!hasShortTfOiDrop) {
          logger.info(
            { symbol, cgOIChange: cgOIChange.toFixed(1), oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a" },
            "SKIP: устаревший Short Squeeze — падение OI только на 4h/24h, на 5m/30m уже нейтрально"
          );
          det = null;
        }
      }

      // ── MTF SPOT CVD: short_squeeze требует активных покупок на 5m ─────────────
      // Шорты должны закрываться об реальный лимитный спрос — проверяем спот 5m.
      if (det?.sentiment.key === "short_squeeze" && spotCvd?.available) {
        if (spotCvd.cvd5m === false) {
          logger.debug(
            { symbol, cvd5m: spotCvd.cvd5m },
            "SKIP: short_squeeze — нет покупок на споте (5m CVD отрицательный)"
          );
          det = null;
        }
      }

      // Override: Steady Accumulation — 5m+30m одновременный рост + цена flat.
      // С новой философией (только подтверждённые покупки) — НЕ стреляем напрямую при flat цене.
      // Вместо этого добавляем в OI Watch: когда цена тронется на 2%+ — PATH B выстрелит.
      // tSteady попадает сюда с volMult >= 2.5 (иначе ушёл бы в OI Watch раньше).
      if (!det && tSteady) {
        try {
          const existingWatch = await db.select({ id: oiWatchTable.id })
            .from(oiWatchTable)
            .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "watching")))
            .limit(1);
          if (existingWatch.length === 0) {
            await db.insert(oiWatchTable).values({
              symbol,
              triggerTf: "5m+30m",
              oiChange: oi30m!,
              priceAtEntry: await getFreshPrice(symbol, close),
              volumeMultiplier: volMult,
              sentimentKey: null,
              status: "watching",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + 2 * 3600 * 1000),
              avgVolume: avgVol,
              oi5mChange:  oi5m,
              oi30mChange: oi30m,
              oi1hChange:  oi1h,
            });
            logger.info(
              { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), vol: volMult.toFixed(2) },
              "👁 STEADY ACCUM → OI Watch: flat цена, ждём подтверждения движения"
            );
          }
        } catch (err) {
          logger.warn({ err, symbol }, "tSteady OI Watch insert failed");
        }
        // Не устанавливаем det — продолжаем без прямого сигнала
      }

      // Sharp Impulse override: свеча является взрывным импульсом (≥7% за свечу, объём ≥2x).
      // Перезаписываем любой паттерн — исключение из stale + exhausted фильтров уже выдано выше.
      // CVD-фильтр ниже остаётся — подтверждение покупательского давления обязательно.
      // OI 5m/30m должен быть положительным — деньги реально заходят в импульс (не просто цена).
      // Funding-фильтр (> 0.06%) применяется в Phase 3 после получения данных BingX.
      if (isSharpImpulse) {
        const sharpOiValid = (oi5m !== null && oi5m > 0) || (oi30m !== null && oi30m > 0);
        if (!sharpOiValid) {
          logger.info(
            { symbol, priceChange: priceChange.toFixed(1) + "%", oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a" },
            "SKIP sharp_impulse: OI 5m/30m не положительный — нет реальных денег в импульсе, возможен шорт-памп"
          );
          skipCount.other++;
          continue;
        }
        det = {
          passes: true,
          oiChangePercent: cgOIChange || 0,
          openInterest: 0,
          sentiment: {
            key: "sharp_impulse",
            label: "Резкий импульс",
            traderAction: "LONG (вход на продолжение импульса, стоп -7%)",
            oiFalling: false,
          },
        };
        logger.info(
          { symbol, priceChange: priceChange.toFixed(1) + "%", volMult: volMult.toFixed(1) + "x", oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a" },
          "⚡ SHARP IMPULSE: взрывная свеча + OI подтверждён — обход stale + exhausted фильтров"
        );
      }

      // Volume Flash override: аномальный объём (>= 6x) + цена движется (3–45%).
      // Перезаписывает любой другой паттерн — как sharp_impulse.
      // Обходит stale-фильтр (выше) — высокий объём говорит что движение ещё активно.
      // Обходит OI-требование — ловим flash-памп без накопления открытого интереса.
      // CVD НЕ обходит (новая логика) — проверяется в общем потоке выше.
      if (isVolumeFlash) {
        det = {
          passes: true,
          oiChangePercent: cgOIChange || 0,
          openInterest: 0,
          sentiment: {
            key: "volume_flash",
            label: "Объёмная вспышка",
            traderAction: "SCALP LONG (следуй за объёмом, стоп -5%)",
            oiFalling: false,
          },
        };
        logger.info(
          { symbol, volMult: volMult.toFixed(1) + "x", priceChange: priceChange.toFixed(1) + "%" },
          "⚡⚡ VOLUME FLASH: аномальный объём без OI-паттерна — обход stale фильтра"
        );
      }

      // ── 4H MOMENTUM: evaluatePattern возвращает null при cgOIChange=0 ────────────
      // Паттерн основан на цене и объёме за 4ч, не на мгновенном OI-спайке.
      // Без этого блока 4H MOMENTUM детектируется, логируется, но никогда не стреляет.
      if (!det && is4hMomentum) {
        det = {
          passes: true,
          oiChangePercent: 0,
          openInterest: 0,
          sentiment: {
            key: "bullish_accumulation",
            label: "4H Грайнд",
            traderAction: "LONG (медленный тренд, стоп -5%)",
            oiFalling: false,
          },
        };
      }

      // Early Ignition override: перезаписываем sentiment после обычной детекции.
      // det уже установлен (OI прошёл) — сохраняем passes/oiChange, меняем только метку.
      if (isEarlyIgnition && det) {
        det = {
          ...det,
          sentiment: {
            key: "early_ignition",
            label: "Раннее зажигание",
            traderAction: "LONG (ранний импульс, стоп -7%)",
            oiFalling: false,
          },
        };
      }

      // Mega-OI override: экстремальный OI bypass — устанавливаем det если его нет.
      // Обычный evaluatePattern мог вернуть null (bullishMax кап превышен, vol низкий).
      // При OI 30m ≥ 35% + 1h ≥ 30% — сигнал обязателен, кап снимаем вручную.
      if (isMegaOI && !det) {
        det = {
          passes: true,
          oiChangePercent: oi30m!,
          openInterest: 0,
          sentiment: {
            key: "mega_oi",
            label: "Мега-OI накопление",
            traderAction: "LONG (кит в деривативах, стоп -7%)",
            oiFalling: false,
          },
        };
      } else if (isMegaOI && det) {
        det = {
          ...det,
          sentiment: {
            key: "mega_oi",
            label: "Мега-OI накопление",
            traderAction: "LONG (кит в деривативах, стоп -7%)",
            oiFalling: false,
          },
        };
      }

      if (!det) continue;

      // ── КУЛДАУН по символу после отмены/стоп-лосса ──────────────────────────
      // cancelled: 6ч — сигнал истёк (не стоп), токен может снова накапливаться.
      //   Было 24ч — слишком долго: PLAYSOUT отменился за дип, через 6ч уже памп.
      // stop_loss: 24ч — добавочный кулдаун (плюс отдельный 3-дневный бан ниже).
      // Защита от NULL closed_at (баг в старых записях): используем detectedAt как запасное.
      {
        const recentCancelled = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "cancelled"),
              or(
                gte(trackedSignalsTable.closedAt, new Date(Date.now() - 6 * 60 * 60 * 1000)),
                and(isNull(trackedSignalsTable.closedAt), gte(trackedSignalsTable.detectedAt, new Date(Date.now() - 6 * 60 * 60 * 1000))),
              ),
            )
          )
          .limit(1);
        if (recentCancelled.length > 0) {
          logger.debug({ symbol }, "SKIP: кулдаун 6ч — недавний cancelled по этому символу");
          skipCount.cooldown++;
          continue;
        }

        const recentStopLoss = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "stop_loss"),
              or(
                gte(trackedSignalsTable.closedAt, new Date(Date.now() - 24 * 60 * 60 * 1000)),
                and(isNull(trackedSignalsTable.closedAt), gte(trackedSignalsTable.detectedAt, new Date(Date.now() - 24 * 60 * 60 * 1000))),
              ),
            )
          )
          .limit(1);
        if (recentStopLoss.length > 0) {
          logger.debug({ symbol }, "SKIP: кулдаун 24ч — недавний stop_loss по этому символу");
          skipCount.cooldown++;
          continue;
        }
      }

      // ── ХРОНИЧЕСКИЙ ТОКЕН: hidden_accumulation без результата 4 дня → 72ч блок ──
      // WAVES: 2 недели повторяющихся hidden_accumulation без движения цены.
      // Если за последние 4 дня было 2+ отмены hidden_accumulation — токен мёртв.
      // Не давать ему снова заходить в систему раньше чем через 72ч.
      {
        const since4d = new Date(Date.now() - 4 * 24 * 60 * 60 * 1000);
        const since72h = new Date(Date.now() - 72 * 60 * 60 * 1000);
        const chronicCancels = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .innerJoin(signalsTable, eq(signalsTable.id, trackedSignalsTable.signalId))
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "cancelled"),
              eq(signalsTable.sentimentKey, "hidden_accumulation"),
              gte(trackedSignalsTable.closedAt, since4d),
            )
          );
        if (chronicCancels.length >= 2) {
          // Проверяем, не было ли профита за последние 72ч (если был — не блокируем)
          const recentProfit = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                eq(trackedSignalsTable.status, "profit"),
                gte(trackedSignalsTable.closedAt, since72h),
              )
            )
            .limit(1);
          if (recentProfit.length === 0) {
            logger.info(
              { symbol, chronicCancels: chronicCancels.length },
              "SKIP: хронический токен — 2+ отмены hidden_accumulation за 4 дня без профита (блок 72ч)"
            );
            skipCount.cooldown++;
            continue;
          }
        }
      }

      // ── ПОВТОРНЫЙ СИГНАЛ: был ли символ в сигналах за последние 24ч ──────────
      // После кулдауна сигнал всё равно может прийти повторно — помечаем его.
      // Бот добавит пометку: "Символ уже был в сигналах — тезис подтвердился снова".
      let isRepeatSignal = false;
      {
        const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
        const prev = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              gte(trackedSignalsTable.detectedAt, since24h),
            )
          )
          .limit(1);
        isRepeatSignal = prev.length > 0;
        if (isRepeatSignal) {
          logger.debug({ symbol }, "REPEAT: символ уже был в сигналах за 24ч — пометим в сообщении");
        }
      }

      // ── БЛОКИРОВКА: cooldown после стоп-лосса (3 дня) ───────────────────────
      // Если монета получила стоп-лосс в последние 3 дня — она, скорее всего, в
      // нисходящем тренде (пост-памп распродажа). Повторный сигнал будет ложным.
      // Пример: MAGMA стоп 24 апр → новый сигнал 26 апр = заход в нисходящий тренд.
      {
        const since3d = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000);
        const recentSL = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "stop_loss"),
              gte(trackedSignalsTable.closedAt, since3d),
            )
          )
          .limit(1);
        if (recentSL.length > 0) {
          logger.info({ symbol }, "SKIP: стоп-лосс cooldown (3 дня) — не входим в нисходящий тренд");
          skipCount.cooldown++;
          continue;
        }
      }

      // OI теперь бонус, а не ворота — отрицательный OI на отдельных ТФ не блокирует сигнал.
      // Исключение 1: если CoinGlass покрывает монету И все краткосрочные ТФ глубоко отрицательные
      // — это явный пост-памп дамп, входить опасно.
      if (cgOI?.available) {
        const shortTfValues = [oi5m, oi30m, oi1h].filter(v => v !== null) as number[];
        const allDeeplyNegative = shortTfValues.length >= 2 && shortTfValues.every(v => v < -3);
        if (allDeeplyNegative) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
            "SKIP: все краткосрочные OI глубоко отрицательные (< -3%) — пост-памп дамп"
          );
          skipCount.contraSignal++;
          continue;
        }
      }

      // ── ОКНО ПОДТВЕРЖДЕНИЯ: 60 минут для всех паттернов ──────────────────────
      // Идея: засёк рост OI → подожди 1 час → проверь что OI всё ещё растёт → сигнал.
      // Это отсекает flash-пампы (OI резко растёт и тут же падает за 10-15 минут).
      // Настоящее накопление держит OI положительным часами.
      //
      // Проверки на 60-й минуте:
      //   • свежий OI (cgOIChange) < -3%   → OI иссяк, накопление закончилось → отмена
      //   • цена откатилась > 5% от точки   → ложный сигнал → отмена
      //   • цена улетела > 20% вверх         → вход слишком дорогой → отмена
      //   • всё остальное                    → СИГНАЛ
      //
      // Исключения: sharp_impulse / volume_flash работают на скорости — ждать 60 мин нельзя.
      if (!isSharpImpulse && !isVolumeFlash) {
        // Время ожидания зависит от ТФ: 4h/24h уже подтверждают многочасовое накопление,
        // долго ждать смысла нет. 30m/5m спайки требуют полного часа проверки.
        // Увеличено с 4ч до 6ч: теперь окно подтверждения 2ч + запас ещё 4ч наблюдения.
        const CONFIRM_EXPIRE_MS = 6 * 60 * 60 * 1000;
        // MAX_RETRACE_PCT определяется ниже — после того как известен тип паттерна (entryTf / sentimentKey).
        const OI_DRAIN_PCT      = -3.0;

        const dbConfirmingRows = await db.select()
          .from(oiWatchTable)
          .where(and(
            eq(oiWatchTable.symbol, symbol),
            eq(oiWatchTable.status, "confirming"),
          ))
          .limit(1);

        // Мержим DB + in-memory fallback (DB приоритет при дубликатах)
        let confirmingEntry: typeof dbConfirmingRows = dbConfirmingRows;
        if (confirmingEntry.length === 0) {
          const memEntry = confirmingWatchMap.get(symbol);
          if (memEntry && memEntry.expiresAt > new Date()) {
            confirmingEntry = [{
              id:               -1,
              symbol:           memEntry.symbol,
              triggerTf:        memEntry.triggerTf,
              oiChange:         memEntry.oiChange,
              priceAtEntry:     memEntry.priceAtEntry,
              volumeMultiplier: memEntry.volumeMultiplier,
              sentimentKey:     memEntry.sentimentKey,
              status:           "confirming",
              addedAt:          memEntry.addedAt,
              expiresAt:        memEntry.expiresAt,
              avgVolume:        memEntry.avgVolume,
              oi5mChange:       memEntry.oi5mChange,
              oi30mChange:      memEntry.oi30mChange,
              oi1hChange:       memEntry.oi1hChange,
              firedAt:          null,
            } as typeof dbConfirmingRows[0]];
          }
        }

        if (confirmingEntry.length > 0) {
          const entry = confirmingEntry[0];
          const ageMs = Date.now() - new Date(entry.addedAt).getTime();
          const priceFromDetection = ((close - entry.priceAtEntry) / entry.priceAtEntry) * 100;

          // drift4h: изменение цены за последние 4 часа (скользящее окно).
          // Используется вместо priceFromDetection для CONFIRM WAIT — чтобы старые
          // записи (7+ дней в очереди) не блокировались устаревшей точкой входа.
          // 30m свечи → 4h = 8 свечей назад. Берём close той свечи как базу.
          const kline4hAgo = klines.length >= 9 ? klines[klines.length - 9] : klines[0];
          const price4hAgo = parseFloat(kline4hAgo?.close ?? "0") || entry.priceAtEntry;
          const drift4h = price4hAgo > 0
            ? ((close - price4hAgo) / price4hAgo) * 100
            : priceFromDetection;

          // Время ожидания определяется по ТФ сохранённому в записи очереди.
          // ВАЖНО: проверяем через \b (word boundary), чтобы "4h_momentum" не совпало с "4h".
          // "4h_momentum" — это паттерн цены за 4ч, не 4h OI → должен ждать 60 мин.
          // "4h", "fast_track+4h", "5m+4h" — реальные 4h OI → 15 мин достаточно.
          const entryTf = entry.triggerTf ?? "30m";
          const is4hOI  = /\b4h\b/.test(entryTf);   // "4h" как отдельное слово, не в "4h_momentum"
          const is24hOI = /\b24h\b/.test(entryTf);
          const is1hOI  = /\b1h\b/.test(entryTf);
          // Быстрые паттерны живут 1-4ч — 2ч окно убивает их (движение уже заканчивается).
          // Для них: 30 мин подтверждения + повышенный MAX_RUNAWAY_PCT (breakout ≠ поздний вход).
          const isFastPattern = [
            "aggressive_breakout", "sharp_impulse", "volume_flash",
            "short_squeeze", "bear_trap",
          ].includes(entry.sentimentKey ?? "");
          const isSlowPattern = [
            "hidden_accumulation",
            "bullish_accumulation",
          ].includes(entry.sentimentKey ?? "");
          const isMoonshot = entry.sentimentKey === "moonshot_momentum";
          const is4hMomentum = entryTf === "4h_momentum";
          // MAX_RUNAWAY_PCT: для накопления 10%, для breakout 25%, для moonshot 100% (ракета не останавливается).
          const MAX_RUNAWAY_PCT = isMoonshot ? 100.0 : isFastPattern ? 25.0 : 10.0;
          // MAX_RETRACE_PCT: разный порог для разных типов паттернов.
          // Быстрые (breakout/squeeze): -10% — жёсткий стоп, движение краткосрочное.
          // Медленные (4h_momentum, накопление): -25% — перед памп нормальны глубокие шейк-ауты.
          // OPENEDEN: дал -18-20% откат перед памп +52%. PLAYSOUT: -16% перед +20%.
          const MAX_RETRACE_PCT = isFastPattern ? -10.0 : (is4hMomentum || isSlowPattern || is24hOI) ? -25.0 : -10.0;
          // Удвоенные окна подтверждения: монета должна удержать накопление дольше.
          // Слабые кандидаты (OI иссякает или цена откатывается) отсеиваются ДО сигнала.
          const CONFIRM_WINDOW_MS =
            (is4hOI || is24hOI) ? 30 * 60 * 1000    // 30 мин: 4h/24h OI — уже подтверждены долгим накоплением
            : is1hOI            ? 60 * 60 * 1000    // 60 мин: 1h OI
            : isFastPattern     ? 30 * 60 * 1000    // 30 мин: быстрые паттерны (breakout/squeeze/flash)
            : is4hMomentum      ? 60 * 60 * 1000    // 60 мин: 4h_momentum — грайнд уже идёт, не нужно 2ч
                                : 2 * 60 * 60 * 1000; // 2 часа: 30m/5m/steady/bingx — накопление требует времени
          const waitMin = Math.round(CONFIRM_WINDOW_MS / 60000);

          if (isSlowPattern) {
            // Триггер для медленных паттернов: пробой локального хая ИЛИ всплеск объема
            const recentHighs = klines.slice(-9, -1).map(k => parseFloat(k.high) || 0);
            const recentHigh = Math.max(...recentHighs);
            const breakout = recentHigh > 0 && close > recentHigh * 1.005; // Пробой на 0.5% выше хая

            // Дополнительный триггер: всплеск объема на текущей свече (> 3x от avgVolume)
            const currentVolume = parseFloat(klines[klines.length - 1].volume);
            const avgVol = entry.avgVolume; // Используем avgVolume из oiWatchTable
            const volumeSpike = (avgVol ?? 0) > 0 && currentVolume > (avgVol ?? 0) * 3.0;

            if (!breakout && !volumeSpike) {
              logger.debug(
                { symbol, close, recentHigh, gap: ((close / recentHigh - 1) * 100).toFixed(2) + "%", currentVolume, avgVol },
                "⏳ SLOW PATTERN: ждём пробоя локального хая ИЛИ всплеска объема"
              );
              continue;
            }

            logger.info(
              { symbol, close, recentHigh, currentVolume, avgVol, trigger: breakout ? "breakout" : "volume_spike" },
              "✅ SLOW PATTERN: пробой локального хая ИЛИ всплеск объема — сигнал разрешён"
            );
            // Триггер сработал — проверяем OI и даём сигнал через стандартные проверки ниже
          }

          // ── 4h_momentum: условие вместо таймера ─────────────────────────────────
          // Тренд — это не ОИ-импульс. Нет смысла ждать 2 часа.
          // Условие для сигнала: цена не откатилась от точки детекции (держится выше -3%)
          // И прошёл хотя бы 1 скан (30 мин — чтобы не стрелять в ту же секунду).
          // Если цена ушла ниже -3% — тренд сломан, отменяем запись.
          if (entryTf === "4h_momentum") {
            if (priceFromDetection < -3.0) {
              await db.update(oiWatchTable)
                .set({ status: "expired", firedAt: new Date() })
                .where(eq(oiWatchTable.id, entry.id));
              logger.info(
                { symbol, drift: priceFromDetection.toFixed(1) + "%" },
                "❌ 4H MOMENTUM: цена откатила от точки входа — тренд сломан"
              );
              skipCount.noConfirming++;
              continue;
            }
            if (ageMs < 30 * 60 * 1000) {
              logger.debug(
                { symbol, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%" },
                "⏳ 4H MOMENTUM: ждём минимум 1 скан (30 мин)"
              );
              continue;
            }
            // Цена держится + прошёл 1 скан → сигнал
            logger.info(
              { symbol, drift: priceFromDetection.toFixed(1) + "%", ageMin: (ageMs / 60000).toFixed(1) },
              "✅ 4H MOMENTUM: цена держится — сигнал разрешён"
            );
            // Проваливаемся к финальным проверкам (runaway/stale cancel и выдача)
          }

          if (!isSlowPattern && entryTf !== "4h_momentum" && ageMs < CONFIRM_WINDOW_MS) {
            // Ещё в окне наблюдения. Ранняя отмена если OI уже иссяк или цена рухнула.
            const earlyOIDrain  = cgOI?.available && cgOIChange < OI_DRAIN_PCT;
            const earlyRetrace  = priceFromDetection < MAX_RETRACE_PCT;
            // OI перестал строиться: был >= 5%, упал ниже 2% — накопление завершилось
            const earlyOIFaded  = cgOI?.available && cgOIChange < 2.0 && (entry.oiChange ?? 0) >= 5.0;
            if (earlyOIDrain || earlyRetrace || earlyOIFaded) {
              await db.update(oiWatchTable)
                .set({ status: "expired", firedAt: new Date() })
                .where(eq(oiWatchTable.id, entry.id));
              logger.info(
                { symbol, tf: entryTf, ageMin: (ageMs / 60000).toFixed(1), oi: cgOIChange.toFixed(1) + "%", drift: priceFromDetection.toFixed(1) + "%" },
                earlyOIDrain  ? "❌ CONFIRM EARLY CANCEL: OI иссяк до окончания ожидания"
                : earlyOIFaded ? "❌ CONFIRM EARLY CANCEL: OI перестал строиться (< 2%) — накопление завершилось"
                               : "❌ CONFIRM EARLY CANCEL: цена откатилась > 5% — ложный сигнал"
              );
              skipCount.noConfirming++;
              continue;
            }
            logger.debug(
              { symbol, tf: entryTf, waitMin, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%", freshOI: cgOIChange.toFixed(1) + "%" },
              `⏳ CONFIRMING: ждём ${waitMin} мин. OI держится.`
            );
            continue;
          }

          // Окно закрылось — финальные проверки

          if (cgOI?.available && cgOIChange < OI_DRAIN_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, freshOI: cgOIChange.toFixed(1) + "%" },
              `❌ CONFIRM FAILED: ${waitMin} мин прошло, но OI упал — накопление закончилось`
            );
            skipCount.noConfirming++;
            continue;
          }

          // OI перестал строиться: был >= 5% при добавлении, теперь ниже 2% — накопление завершилось
          if (cgOI?.available && cgOIChange < 2.0 && (entry.oiChange ?? 0) >= 5.0) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, currentOI: cgOIChange.toFixed(1) + "%", entryOI: (entry.oiChange ?? 0).toFixed(1) + "%" },
              "❌ CONFIRM EXPIRED: OI перестал строиться — накопление завершилось"
            );
            skipCount.noConfirming++;
            continue;
          }

          if (priceFromDetection < MAX_RETRACE_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%" },
              `❌ CONFIRM FAILED: цена откатилась > 5% за ${waitMin} мин — ложный сигнал`
            );
            skipCount.noConfirming++;
            continue;
          }

          if (priceFromDetection > MAX_RUNAWAY_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%" },
              `❌ CONFIRM SKIP: цена ушла > ${MAX_RUNAWAY_PCT}% вверх — вход слишком поздний`
            );
            skipCount.priceTooHigh++;
            continue;
          }

          // Ждём реального начала роста — не входим если цена ещё в минусе или флэте.
          // ZBT-кейс: цена -2.5% → в допуске [-5%..+10%] → сигнал стрелял → вход на дне.
          // ZETA/ATOM/CRV-кейс: цена +0.5% → signal fire → сразу разворот → peak=0% → stale cancel.
          // Исключение: 4h_momentum — тренд идёт часами, не нужен дополнительный +2%.
          // Исключение: 24h OI — долгосрочное накопление, достаточно любого начала роста.
          // Исключение: dark_flow — активность без OI, сигнал основан на объёме/пре-скрине.
          //   Для него достаточно что цена не рухнула > -5% от точки входа.
          const MIN_POSITIVE_DRIFT = (entryTf === "4h_momentum" || is24hOI) ? 0.5
                                   : entryTf === "dark_flow" ? -5.0
                                   : 2.0;
          // Двойной ценовой гейт:
          // 1. drift4h < MIN_POSITIVE_DRIFT — 4h скользящее окно ещё не показало движение.
          // 2. priceFromDetection < 1.0 — цена ещё не выросла на +1% от точки входа в очередь.
          // VVV/AIXBT/PYTH-кейс: drift4h мог быть +2.5% (общий 4h импульс), но
          // priceFromDetection=+0.2% — сигнал стрелял в TG без реального роста.
          // Держим в PRE-BREAKOUT пока цена не подтвердит +1% от priceAtEntry.
          if (drift4h < MIN_POSITIVE_DRIFT || priceFromDetection < 1.0) {
            // ── PRE-BREAKOUT: OI + объём подтверждены, но цена ещё не двинулась ─────
            // Используем drift4h (скользящее окно 4h) вместо priceFromDetection,
            // чтобы старые записи (7+ дней) не блокировались устаревшей ценой входа.
            // GENIUS: oi4h=82%, drift=-6%, 30ч ожидания → памп без сигнала.
            // IN:     oi4h=52%, drift=-12%, 8.5ч ожидания → то же.
            // Условия: 2+ ч в очереди, OI или объём подтверждены, не рухнула, не стрелял раньше.
            // dark_flow: используем volMult >= 2.0 вместо cgOIChange (OI в CG не видно),
            //            порог краша шире (-10% вместо -5%, т.к. MAX_RETRACE у dark_flow = -10%).
            const isDarkFlow = entryTf === "dark_flow";
            const alreadyPreFired = !!(entry.signalPayload as any)?.preBreakoutFiredAt;
            const preBreakoutOiOk = isDarkFlow
              ? volMult >= 2.0       // dark_flow: объём вместо OI
              : cgOIChange >= 10.0;  // нормальный: CG OI >= 10%
            const preBreakoutMaxCrash = isDarkFlow ? -10.0 : -5.0;
            if (
              !alreadyPreFired &&
              ageMs  >= 2 * 60 * 60 * 1000 &&   // 2+ часа ожидания
              preBreakoutOiOk &&                 // OI или объём подтверждён
              volMult    >= 1.5  &&              // объём подтверждён в любом случае
              priceFromDetection > preBreakoutMaxCrash  // цена не рухнула
            ) {
              // Помечаем запись — больше не стреляем pre_breakout из этого entry
              await db.update(oiWatchTable)
                .set({ signalPayload: { ...((entry.signalPayload as any) ?? {}), preBreakoutFiredAt: new Date().toISOString() } })
                .where(eq(oiWatchTable.id, entry.id));

              const base = symbol.replace("-USDT", "");
              const oi4hStr = cgOI?.oiChange4h != null ? `  • OI 4h: <b>+${cgOI.oiChange4h.toFixed(1)}%</b>` : "";
              const preMsg = isDarkFlow ? [
                `🌑 <b>DARK FLOW: ${base}/USDT</b>`,
                ``,
                `Устойчивая активность без следа в OI — цена <b>не двинулась</b>`,
                ``,
                `  • Объём: <b>${volMult.toFixed(1)}x</b>`,
                `  • OI CoinGlass: <b>${cgOIChange > 0 ? "+" : ""}${cgOIChange.toFixed(1)}%</b> (ниже порога)`,
                `  • Дрейф от входа: <b>${priceFromDetection.toFixed(1)}%</b>`,
                `  • В confirming-очереди: <b>${Math.round(ageMs / 60000)} мин</b>`,
                ``,
                `💡 Умные деньги вне OI-радара — жди пробой или объёмный всплеск`,
                ``,
                `🔗 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P">TradingView</a>`,
                ``,
                `#${base} #dark_flow`,
              ].join("\n") : [
                `🔍 <b>PRE-BREAKOUT: ${base}/USDT</b>`,
                ``,
                `OI и объём подтверждены — цена ещё <b>не двинулась</b>`,
                ``,
                `  • OI (global): <b>+${cgOIChange.toFixed(1)}%</b>`,
                oi4hStr || null,
                `  • Объём: <b>${volMult.toFixed(1)}x</b>`,
                `  • Дрейф от входа: <b>${priceFromDetection.toFixed(1)}%</b>`,
                `  • В очереди: <b>${Math.round(ageMs / 60000)} мин</b>`,
                ``,
                `💡 Накопление без старта — жди пробой или объёмный всплеск`,
                ``,
                `🔗 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P">TradingView</a>`,
                ``,
                `#${base} #pre_breakout`,
              ].filter(l => l !== null).join("\n");

              // ── Spot volume gate (Pre-Breakout / Dark Flow) ─────────────────────────
              const [pbSpotVol24h, pbMcapRaw] = await Promise.all([
                getCoinglassSpotVolume24h(symbol).catch(() => null),
                fetchMarketCap(symbol).catch(() => null),
              ]);
              const pbMcapUsd = pbMcapRaw?.mcap ?? null;
              const pbMcapAvailable = pbMcapUsd !== null;
              const tag = isDarkFlow ? "DARK FLOW" : "PRE-BREAKOUT";
              // Degraded mode: если MCap недоступен (CoinGecko timeout) — проверяем abs минимум 500K USDT.
              const pbSpotOk = pbSpotVol24h !== null && (
                pbMcapAvailable
                  ? pbSpotVol24h >= pbMcapUsd! * 0.0015
                  : pbSpotVol24h >= 500_000
              );
              if (!pbSpotOk) {
                const pct = (pbSpotVol24h !== null && pbMcapUsd) ? (pbSpotVol24h / pbMcapUsd * 100).toFixed(3) : "нет MCap";
                logger.info({ symbol, pbSpotVol24h, pbMcapUsd, pct, degraded: !pbMcapAvailable },
                  pbSpotVol24h === null
                    ? `${tag}: нет данных спота — сигнал отменён`
                    : pbMcapAvailable
                      ? `${tag}: спот-объём < 0.15% MCap — сигнал отменён`
                      : `${tag}: MCap недоступен, спот < 500K USDT (degraded) — сигнал отменён`);
              } else {
              if (!pbMcapAvailable && pbSpotVol24h !== null) {
                logger.warn({ symbol, pbSpotVol24h }, `${tag}: MCap недоступен (CoinGecko timeout) — degraded mode, abs 500K пройден`);
              }
              try {
                // Telegram не шлём — ждём полного подтверждения тихо (без спама отменами)
                logger.info(
                  { symbol, tf: entryTf, oi: cgOIChange.toFixed(1) + "%", vol: volMult.toFixed(1) + "x", drift: priceFromDetection.toFixed(1) + "%", ageMin: Math.round(ageMs / 60000) },
                  isDarkFlow
                    ? "🌑 DARK FLOW: устойчивая активность → в трекер (без TG, ждём подтверждение)"
                    : "🔍 PRE-BREAKOUT: OI+объём подтверждены → в трекер (без TG, ждём движение цены)"
                );
                // Сигнал ещё не подтверждён — ждём движение цены (не создаём запись в трекере)
              } catch (err) {
                logger.warn({ err, symbol }, "PRE-BREAKOUT: ошибка отправки алерта");
              }
              } // end spot ok else
            }

            logger.info(
              { symbol, tf: entryTf, drift4h: drift4h.toFixed(1) + "%", driftFromEntry: priceFromDetection.toFixed(1) + "%", ageMin: (ageMs / 60000).toFixed(0) },
              "⏳ CONFIRM WAIT: цена ещё не в росте — ждём старта движения"
            );
            continue; // не отменяем, просто ждём — expire случится через 6ч если роста не будет
          }

          // Ghost pump guard: 24h памп >30% с остывающим объёмом (< 2.5x) =
          // торговая возможность уже случилась ДО нашего сигнала.
          // Глобальный exhausted pump check ловит >40%, но для confirming-блока строже:
          // токен мог попасть в очередь на старте памп (price ~0%), к моменту подтверждения
          // уже +35% → priceFromDetection всё ещё мал (считается от priceAtEntry, не от дня),
          // поэтому MAX_RUNAWAY_PCT не срабатывает. Ghost pump guard закрывает этот зазор.
          if (price24hChange > 30 && volMult < 2.5) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            confirmingWatchMap.delete(symbol); // убираем из памяти при истечении
            logger.info(
              { symbol, tf: entryTf, price24hChange: price24hChange.toFixed(1) + "%", volMult: volMult.toFixed(2), drift: priceFromDetection.toFixed(1) + "%" },
              "❌ GHOST PUMP: 24h рост >30% + объём остыл — памп случился до сигнала, пропускаем"
            );
            skipCount.stalePump++;
            continue;
          }

          // ✅ OI держится, цена пошла вверх — сигнал подтверждён
          await db.update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(eq(oiWatchTable.id, entry.id));
          confirmingWatchMap.delete(symbol); // убираем из памяти при выстреле
          logger.info(
            { symbol, tf: entryTf, waitMin, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%", freshOI: cgOIChange.toFixed(1) + "%" },
            `✅ CONFIRMED: OI держится ${waitMin} мин, цена стабильна — сигнал разрешён`
          );
          // Помечаем что кандидат пришёл из confirming-очереди — финальный цикл
          // пропустит watching-очередь и выстрелит напрямую (без PATH A задержки).
          (det as any).__isConfirmedFire = true;
        } else {
          // Первый раз видим — сохраняем реальный ТФ, чтобы знать сколько ждать
          const confirmAddedAt  = new Date();
          const confirmExpiresAt = new Date(Date.now() + CONFIRM_EXPIRE_MS);
          // Получаем свежую цену заранее — нужна и для DB, и для in-memory fallback
          let confirmPrice = close;
          try { confirmPrice = await getFreshPrice(symbol, close); } catch { /* use close */ }

          try {
            await db.insert(oiWatchTable).values({
              symbol,
              triggerTf: oiTriggerTf,
              oiChange: cgOIChange,
              priceAtEntry: confirmPrice,
              volumeMultiplier: volMult,
              sentimentKey: det.sentiment.key,
              status: "confirming",
              addedAt: confirmAddedAt,
              expiresAt: confirmExpiresAt,
              avgVolume: avgVol,
              oi5mChange:  oi5m,
              oi30mChange: oi30m,
              oi1hChange:  oi1h,
            });
            // DB INSERT удался — убираем из памяти если там был стейл
            confirmingWatchMap.delete(symbol);
            const waitMin =
              (oiTriggerTf.includes("24h") || oiTriggerTf.includes("4h")) ? 15
              : oiTriggerTf.includes("1h") ? 30 : 60;
            logger.info(
              { symbol, tf: oiTriggerTf, waitMin, price: priceChange.toFixed(1) + "%", oi: cgOIChange.toFixed(1) + "%", pattern: det.sentiment.key },
              `🕐 QUEUED: первое обнаружение — ждём ${waitMin} мин подтверждения OI`
            );
          } catch (err) {
            logger.warn({ err, symbol }, "confirming OI Watch insert failed — saving to in-memory fallback");
            // Сохраняем в памяти — следующий скан найдёт запись и продолжит окно подтверждения
            confirmingWatchMap.set(symbol, {
              symbol,
              triggerTf:        oiTriggerTf,
              oiChange:         cgOIChange,
              priceAtEntry:     confirmPrice,
              volumeMultiplier: volMult,
              sentimentKey:     det.sentiment.key,
              addedAt:          confirmAddedAt,
              expiresAt:        confirmExpiresAt,
              avgVolume:        avgVol,
              oi5mChange:       oi5m,
              oi30mChange:      oi30m,
              oi1hChange:       oi1h,
            });
            skipCount.other++;
          }
          continue;
        }
      }

      logger.info(
        {
          symbol,
          globalOI: cgOIChange.toFixed(1) + "%",
          bingxOI: cgOI?.bingxOiChange30m != null ? cgOI.bingxOiChange30m.toFixed(1) + "%" : "n/a",
          vol: volMult.toFixed(1) + "x",
          price: priceChange.toFixed(1) + "%",
          pattern: det.sentiment.key,
        },
        "CoinGlass OI + Volume PASSED → candidate"
      );

      // cgOI может быть undefined для fast_track/4h_momentum — используем минимальный fallback
      const safeOI: CoinglassOIResult = cgOI ?? {
        available: false, source: "coinglass", oiUsd: 0,
        oiChange5m: null, oiChange30m: 0,
        oiChange1h: null, oiChange4h: null, oiChange24h: null,
        bingxOiChange30m: null, cgVolUsd: null,
      };

      candidates.push({
        symbol,
        price: close,
        priceChange30m: priceChange,
        price4hChange,
        currentVolume: currentVol,
        avgVolume: avgVol,
        volumeMultiplier: volMult,
        oiChangePercent: cgOIChange,
        oiChange5m: oi5m,
        oiChange1h: oi1h,
        oiChange4h: oi4h,
        oiChange24h: oi24h,
        openInterest: safeOI.oiUsd ?? 0,
        sentiment: det.sentiment,
        coinglassOI: safeOI,
        oiTriggerTf,
        isRepeatSignal,
        isConfirmedFire: (det as any).__isConfirmedFire === true,
        isScalpOnly,
      });
    } catch (err) {
      logger.warn({ symbol, err }, "Error scanning symbol");
    }
    await new Promise(r => setTimeout(r, 100));
  }

  // Log top-5 by volume among those that passed CoinGlass OI filter
  const top5 = [...debugTop]
    .sort((a, b) => b.vol - a.vol)
    .slice(0, 5);
  if (top5.length > 0) {
    logger.info(
      {
        top5: top5.map(d => ({
          symbol: d.symbol,
          vol: d.vol.toFixed(1) + "x",
          globalOI: d.cgOI != null ? d.cgOI.toFixed(1) + "%" : "n/a",
          price: d.price.toFixed(2) + "%",
        }))
      },
      "Top-5 (CoinGlass OI passed) by volume this cycle"
    );
  }

  logger.info({
    confirmingMapSize: confirmingWatchMap.size,
    confirmingMapSymbols: [...confirmingWatchMap.keys()],
    candidatesCount: candidates.length,
    skipped: skipCount,
  }, "DEBUG: scan cycle snapshot");

  if (candidates.length === 0) {
    const nowNoCandidates = new Date();
    state.lastScanAt = nowNoCandidates;
    state.marketsScanned = usdtTickers.length;
    logger.info(
      {
        marketsScanned: usdtTickers.length,
        oiMovers: oiMoversCount,
        topActive: scanLimit,
        skipped: {
          exhaustedPump: skipCount.exhaustedPump,
          deepNeg:       skipCount.deepNegative,
          noOiNoVol:     skipCount.noOiNoVol,
          lowVolume:     skipCount.lowVolume,
          stalePump:     skipCount.stalePump,
          cooldown:      skipCount.cooldown,
          noConfirming:  skipCount.noConfirming,
          priceTooHigh:  skipCount.priceTooHigh,
          cvdFail:       skipCount.cvdFail,
          takerFail:     skipCount.takerFail,
          spotFail:      skipCount.spotFail,
          contra:        skipCount.contraSignal,
          other:         skipCount.other,
        },
      },
      "No candidates this cycle (CoinGlass OI + Volume filters)"
    );
    await persistBaselinesToDb();
    // Persist lastScanAt for cross-process status (fire-and-forget)
    db.update(settingsTable)
      .set({ scannerLastScanAt: nowNoCandidates })
      .catch((err: unknown) => logger.warn({ err }, "Failed to persist scannerLastScanAt (no-candidates)"));
    return { signalsFound: 0, marketsScanned: usdtTickers.length, durationMs: Date.now() - startTime };
  }

  // ── FRESH PRICE FETCH ───────────────────────────────────────────────────────
  // CoinGlass batch занял 8+ мин. Klines были взяты в начале скана, поэтому
  // base.price = закрытие свечи из прошлого. Перечитываем текущую цену для
  // каждого кандидата, чтобы трекер и Telegram показывали реальную точку входа.
  const freshPriceMap = new Map<string, number>();
  try {
    const freshTickers = await getFutureTickers();
    for (const t of freshTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) freshPriceMap.set((t as any).symbol, p);
    }
    logger.info({ fetched: freshPriceMap.size }, "Fresh ticker prices fetched for candidate entry pricing");
  } catch (err) {
    logger.warn({ err }, "Failed to fetch fresh ticker prices — using kline close as fallback");
  }

  logger.info({ count: candidates.length }, "Phase 3: grade + score for CoinGlass OI candidates...");

  // Phase 3: grade + score (CoinGlass OI already confirmed in Phase 1)
  const alphaResults: AlphaResult[] = [];
  const signalsToInsert: InsertSignal[] = [];

  for (const base of candidates) {
    const { symbol } = base;

    // CoinGlass OI data already fetched in batch — use directly
    const coinglassOI = base.coinglassOI;
    const coinalyzeOiChange = coinglassOI.oiChange30m; // global aggregate
    const coinalyzeConfirmed = true; // all candidates already passed CoinGlass OI filter

    const [trending, liquidations, fundingData] = await Promise.all([
      getTrendingRank(symbol),
      getLiquidations(symbol),
      getFundingRate(symbol),
    ]);

    const fundingRate = fundingData?.lastFundingRate != null ? parseFloat(fundingData.lastFundingRate) : null;
    const markPrice  = fundingData?.markPrice  != null ? parseFloat(fundingData.markPrice)  : null;
    const indexPrice = fundingData?.indexPrice != null ? parseFloat(fundingData.indexPrice) : null;

    if (fundingRate != null) {
      logger.info(
        { symbol, fundingRate: (fundingRate * 100).toFixed(4) + "%" },
        fundingRate <= -0.0003 ? "💰 Глубоко отрицательный фандинг — шорты в ловушке"
          : fundingRate <= -0.0001 ? "💰 Фандинг отрицательный — шорты платят"
          : fundingRate >= 0.0003  ? "⚠️ Фандинг сильно положительный — лонги перегреты"
          : "⚖️ Фандинг нейтральный"
      );
    }

    // ── Sharp Impulse: Funding Gate ──────────────────────────────────────────────
    // Если фандинг > 0.06% — рынок критически перегрет лонгами, вход опасен.
    // Если фандинг < 0 — шорты платят → дополнительное топливо для импульса (входим).
    if (base.sentimentKey === "sharp_impulse" && fundingRate !== null && fundingRate > 0.0006) {
      logger.info(
        { symbol, fundingRate: (fundingRate * 100).toFixed(4) + "%" },
        "SKIP sharp_impulse: фандинг > 0.06% — рынок перегрет лонгами, риск разворота"
      );
      skipCount.takerFail++;
      continue;
    }

    // Re-detect sentiment now that we have liquidation data.
    // Исключение: early_ignition / mega_oi — detectSentiment не знает эти ключи и вернёт
    // aggressive_breakout/hidden_accumulation, затирая нашу метку. Сохраняем base.sentiment.
    const finalSentiment = (base.oiTriggerTf === "early_ignition" || base.oiTriggerTf === "mega_oi")
      ? base.sentiment
      : detectSentiment(
          base.priceChange30m,
          base.oiChangePercent,
          base.volumeMultiplier,
          liquidations.multiple ?? null,
          base.oiTriggerTf,
        );

    // ── STEP 5: Alpha Score (1–10) ──────────────────────────────────────────────
    const alphaScore = calcAlphaScore({
      oiChange: base.oiChangePercent,
      volumeMultiplier: base.volumeMultiplier,
      priceChange: base.priceChange30m,
      sentimentKey: finalSentiment.key,
      cmcAvailable: trending.available,
      cmcRank: trending.rank,
      coinglassAvailable: liquidations.available,
      liquidationsMultiple: liquidations.multiple,
      fundingRate,
    });

    // ── STEP 5: Grading ──────────────────────────────────────────────────────────
    // super_alpha — Score ≥ 8 И OI подтвердили 2+ таймфрейма, OR глобальный OI ≥ 15%
    // alpha       — стандартный сигнал (OI сработал на 1+ ТФ)

    // Считаем количество OI таймфреймов которые сработали для этого кандидата
    const oiTfCount = base.oiTriggerTf === "steady"               ? 2
      : base.oiTriggerTf.startsWith("fast_track")
        ? base.oiTriggerTf.split("+").slice(1).length
        : base.oiTriggerTf.split("+").length;

    // Grade будет обновлён после OB анализа (finalAlphaScore) — здесь предварительное значение
    let grade: "alpha" | "super_alpha" =
      (alphaScore >= 8 && oiTfCount >= 2) || Math.abs(base.oiChangePercent) >= 15 ? "super_alpha"
      : "alpha";

    // ── FILTER: Anomaly pattern отключён — убрали из ростера (высокий риск, нет edge) ─
    if (finalSentiment.key === "anomaly") {
      skipCount.other++;
      continue;
    }

    // (оставлено для совместимости с оставшимися проверками ниже — фактически недостижимо)
    if (finalSentiment.key === "anomaly" && base.price4hChange > 10 && base.oiTriggerTf !== "4h_momentum") {
      logger.info(
        { symbol, price4hChange: base.price4hChange.toFixed(1) + "%" },
        "SKIP: аномалия в пост-памп контексте — цена +>10% за 4ч"
      );
      skipCount.other++;
      continue;
    }

    // ── FILTER: Аномалия — проверяем OI за 24ч по Coinalyze (приоритет) или CoinGlass ──
    // Если OI за 24ч нулевой, отрицательный или нет данных — сигнал не выпускать.
    // Coinalyze (hourly candles, реальные биржевые данные) имеет приоритет над CoinGlass.
    if (finalSentiment.key === "anomaly") {
      const caOi24h = await getCoinalyzeOI24h(symbol);
      // Используем Coinalyze если данные есть, иначе CoinGlass 24h
      const oi24h = caOi24h !== null ? caOi24h : base.oiChange24h;
      const source = caOi24h !== null ? "Coinalyze" : (base.oiChange24h !== null ? "CoinGlass" : "нет данных");
      if (oi24h === null || oi24h <= 0) {
        const oi24hStr = oi24h !== null ? oi24h.toFixed(1) + "%" : "нет данных";
        logger.info(
          { symbol, oi24h: oi24hStr, source },
          "SKIP anomaly: OI 24ч не растёт — нет накопления"
        );
        skipCount.other++;
        continue;
      }
      logger.info({ symbol, oi24h: oi24h.toFixed(1) + "%", source }, "anomaly: OI 24ч растёт — пропускаем фильтр");
    }

    // ── TAKER FLOW FILTER: кросс-биржевой buy/sell баланс (Binance + Bybit, 4h) ──
    // Логика разная по паттерну:
    //   short_squeeze     — инвертировано: sell доминирование ОК (шорты давят → есть кого сжимать)
    //   anomaly           — строго: net buy должен быть > 10% (нет OI/vol — только taker подтверждает)
    //   impulse, breakout — умеренно: net buy > 5%
    //   остальные         — любое buy доминирование (> 0%)
    // Если данные недоступны — не блокируем (не наказываем за отсутствие данных).
    {
      const tf = await getCoinglassTakerFlow(symbol);

      if (tf.available) {
        const key = finalSentiment.key;

        // short_squeeze: продавцы давят → шорты копятся → есть потенциал сжатия
        if (key === "short_squeeze") {
          if (tf.dominance === "buy" && tf.netBuyPct > 15) {
            logger.info(
              { symbol, netBuyPct: tf.netBuyPct.toFixed(1) + "%", exchanges: tf.exchanges },
              "SKIP short_squeeze: покупатели уже доминируют +15% — шорты не давят, squeeze маловероятен"
            );
            skipCount.takerFail++;
            continue;
          }
        }
        // anomaly: строго — net buy > 10% (нет OI/vol, только taker подтверждает)
        // Если токен держится в prescan топ-30 три и более циклов — снижаем порог до 5%
        // (prescan-персистентность = дополнительное подтверждение паттерна)
        else if (key === "anomaly") {
          const prescanEntry = prescanTracker.get(symbol);
          const prescanConfirmed = prescanEntry != null
            && prescanEntry.cycleCount >= PERSIST_MIN_CYCLES
            && prescanEntry.bestRank <= PERSIST_MAX_RANK;
          const anomalyThreshold = prescanConfirmed ? 5 : 10;

          if (tf.netBuyPct <= anomalyThreshold) {
            logger.info(
              { symbol, netBuyPct: tf.netBuyPct.toFixed(1) + "%", dominance: tf.dominance,
                exchanges: tf.exchanges, threshold: anomalyThreshold, prescanConfirmed },
              "SKIP anomaly: Taker Flow не подтверждает покупки"
            );
            skipCount.takerFail++;
            continue;
          }
          logger.info(
            { symbol, netBuyPct: tf.netBuyPct.toFixed(1) + "%", exchanges: tf.exchanges,
              prescanConfirmed, threshold: anomalyThreshold },
            "✅ anomaly Taker Flow подтверждён"
          );
        }
        // impulse/breakout: net buy порог зависит от паттерна.
        // aggressive_breakout: снижен до 2% — ловим пробой раньше, до экстремальных значений.
        // sharp_impulse / impulse_breakout: остаётся 5% — сильный импульс требует сильного потока.
        else if (["impulse_breakout", "sharp_impulse", "aggressive_breakout"].includes(key)) {
          const breakoutThreshold = key === "aggressive_breakout" ? 2 : 5;
          if (tf.netBuyPct <= breakoutThreshold) {
            logger.info(
              { symbol, key, netBuyPct: tf.netBuyPct.toFixed(1) + "%", dominance: tf.dominance, exchanges: tf.exchanges, threshold: breakoutThreshold },
              `SKIP breakout: Taker Flow слабый (нужно >${breakoutThreshold}% net buy)`
            );
            skipCount.takerFail++;
            continue;
          }
        }
        // остальные long-паттерны: любое net buy (> 0%)
        else if (tf.dominance === "sell") {
          logger.info(
            { symbol, key, netBuyPct: tf.netBuyPct.toFixed(1) + "%", exchanges: tf.exchanges },
            "SKIP: Taker Flow — продавцы доминируют, OI растёт от шортов"
          );
          skipCount.takerFail++;
          continue;
        }
      } else {
        logger.debug({ symbol }, "Taker Flow: данные недоступны — фильтр пропущен");
      }
    }

    // ── CVD Filter: третье подтверждение — покупатели должны доминировать ────────
    const cvd = await fetchCVD(symbol);
    if (cvd) {
      if (!cvd.positive) {
        logger.info(
          { symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", trades: cvd.trades },
          "🔴 CVD негативный — продажи доминируют, пропускаем сигнал"
        );
        skipCount.cvdFail++;
        continue;
      }
      logger.info(
        { symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", trades: cvd.trades },
        "🟢 CVD позитивный — покупатели доминируют"
      );
    } else {
      logger.warn({ symbol }, "CVD: не удалось получить данные — пропускаем проверку");
    }

    // ── STEP 6: Order Book Imbalance (стакан BingX) ──────────────────────────────
    // Запрашиваем только для финальных кандидатов (прошли CVD и все фильтры).
    // Буллиш стакан → бонус до +2 к alpha score.
    const obImbalance = await getOrderBookAnalysis(symbol, 20);
    let finalAlphaScore = alphaScore;

    if (obImbalance) {
      finalAlphaScore = Math.min(10, alphaScore + obImbalance.scoreBonus);

      const biasLabel = obImbalance.bias === "strong_bull" ? "🟢🟢 STRONG BULL" :
                        obImbalance.bias === "bull"         ? "🟢 BULL" :
                        obImbalance.bias === "bear"         ? "🔴 BEAR" : "⚪ NEUTRAL";

      logger.info({
        symbol,
        bidAskRatio:  obImbalance.bidAskRatio.toFixed(2),
        bidVolumeUsd: obImbalance.bidVolumeUsd.toFixed(0),
        askVolumeUsd: obImbalance.askVolumeUsd.toFixed(0),
        bidWalls:     obImbalance.bidWallCount,
        largestWall:  `$${obImbalance.largestBidWallUsd.toFixed(0)} @ ${obImbalance.largestBidWallPrice}`,
        bias:         biasLabel,
        scoreBonus:   obImbalance.scoreBonus > 0 ? `+${obImbalance.scoreBonus}` : "0",
      }, "📚 Order book analysis");
    } else {
      logger.warn({ symbol }, "📚 Order book: данные недоступны");
    }

    // Пересчёт grade с учётом OB бонуса
    if (obImbalance && obImbalance.scoreBonus > 0) {
      if ((finalAlphaScore >= 8 && oiTfCount >= 2) || Math.abs(base.oiChangePercent) >= 15) {
        grade = "super_alpha";
      }
    }

    // State tracking
    const prevState = signalHistory.get(symbol);
    const isContinuing = !!prevState;
    const cumulativeOiChange = prevState
      ? prevState.cumulativeOiChange + base.oiChangePercent
      : base.oiChangePercent;

    signalHistory.set(symbol, {
      firstSignalAt: prevState?.firstSignalAt ?? new Date(),
      signalCount: (prevState?.signalCount ?? 0) + 1,
      cumulativeOiChange,
    });

    const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${symbol.replace("-", "")}`;
    const bingxUrl = `https://bingx.com/en/trade/${symbol.replace("-", "")}/`;

    // Используем свежую цену (текущий рынок), а не закрытие kline 8 мин назад.
    // Это предотвращает ситуацию когда трекер видит "вход" по старой цене
    // и сразу стреляет milestone 25%/50% потому что рынок уже ушёл.
    const freshPrice = freshPriceMap.get(symbol) ?? base.price;
    const klineSlippage = base.price > 0 ? ((freshPrice - base.price) / base.price) * 100 : 0;
    if (Math.abs(klineSlippage) >= 3) {
      logger.info(
        { symbol, klineClose: base.price, freshPrice, slippage: klineSlippage.toFixed(1) + "%" },
        "⚠️ Entry price slippage since kline fetch — using fresh price"
      );
    }

    alphaResults.push({
      symbol,
      grade,
      price: freshPrice,
      priceChange30m: base.priceChange30m,
      currentVolume: base.currentVolume,
      avgVolume: base.avgVolume,
      volumeMultiplier: base.volumeMultiplier,
      oiChangePercent: base.oiChangePercent,
      openInterest: base.openInterest,
      cmcRank: trending.rank,
      cmcSource: trending.source,
      cmcAvailable: trending.available,
      liquidationsUsd: liquidations.liquidationsUsd,
      liquidationsMultiple: liquidations.multiple,
      coinglassAvailable: liquidations.available,
      coinalyzeOiChange,
      coinalyzeConfirmed,
      isNewListing: false,
      isExhaustedSqueeze: false,
      pumpFromOpen: null,
      candleCount: 48,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      traderAction: finalSentiment.traderAction,
      isContinuing,
      cumulativeOiChange,
      tradingViewUrl,
      bingxUrl,
      oiTriggerTf: base.oiTriggerTf,
      oiChange5m: base.oiChange5m,
      oiChange1h: base.oiChange1h,
      oiChange4h: base.oiChange4h,
      oiChange24h: base.oiChange24h,
      klineSlippage,
      isRepeatSignal: base.isRepeatSignal,
      fundingRate,
      markPrice,
      indexPrice,
      obImbalance,
      cvdDivergence: finalSentiment.key === "bear_trap" && (cvd?.positive ?? false) && base.priceChange30m < 0,
      isScalpOnly: base.isScalpOnly,
      alphaScore: finalAlphaScore,
    });

    signalsToInsert.push({
      symbol,
      type: grade,
      value: base.volumeMultiplier,
      threshold: settings.volumeMultiplier,
      price: freshPrice,
      priceChangePercent: base.priceChange30m,
      volume24h: base.currentVolume,
      avgVolume: base.avgVolume,
      openInterest: base.openInterest,
      oiChangePercent: base.oiChangePercent,
      fundingRate: fundingRate ?? null,
      tradingViewUrl,
      cmcRank: trending.rank ?? null,
      cmcSource: trending.source ?? null,
      liquidationsUsd: liquidations.liquidationsUsd ?? null,
      liquidationsMultiple: liquidations.multiple ?? null,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      alphaScore,
      isContinuing,
      cumulativeOiChange,
      detectedAt: new Date(),
    });

    logger.info(
      { symbol, grade, alphaScore, pattern: finalSentiment.key },
      `✅ ${grade.toUpperCase()} score=${alphaScore}`
    );
  }

  // ── Символы из confirming-очереди — стреляем немедленно без watching ────────
  // Они уже провели 30-120 мин в confirming. Putting them back in watching
  // creates a second 90-min window with a strict price gate that often kills them.
  const confirmedFireSet = new Set(
    candidates.filter(c => c.isConfirmedFire).map(c => c.symbol)
  );

  // ── Route signals through OI Watch (two-stage confirmation) ─────────────────
  // alpha/super_alpha: isVolConfirmed=true, 30-90 min window — fire as soon as conditions hold
  // confirmed_fire:    already in confirming queue → insert + track + broadcast immediately

  for (let i = 0; i < alphaResults.length; i++) {
    const res = alphaResults[i];
    const sig = signalsToInsert[i];
    try {
      // ── DIRECT FIRE: кандидат из confirming-очереди ────────────────────────
      // Пропускаем watching-очередь — сигнал уже подтверждён confirming-циклом.
      // Раньше: confirming → candidates → watching → PATH A (90мин + price gate) → пропуск.
      // Теперь: confirming → candidates → СРАЗУ insert + trackSignal + broadcast.
      if (confirmedFireSet.has(res.symbol)) {
        try {
          // ── Spot volume gate ─────────────────────────────────────────────────
          // Спот-объём >= 0.15% MCap — только процентный порог.
          // Нет спота или нет MCap данных → блок.
          const ALPHA_MIN_SPOT_MCAP_PCT = 0.0015; // 0.15%
          const [spotVol24h, mcapData] = await Promise.all([
            getCoinglassSpotVolume24h(res.symbol).catch(() => null),
            fetchMarketCap(res.symbol).catch(() => null),
          ]);
          // Если свежий MCap недоступен — берём из SpotPool кэша (stale, обновляется каждые 30 мин).
          // MCap меняется медленно, % от MCap работает корректно даже со вчерашними данными.
          const marketCapUsd = mcapData?.mcap ?? getSpotPoolEntry(res.symbol)?.mcapUsd ?? null;
          const cfMcapAvailable = marketCapUsd !== null;
          if (spotVol24h === null) {
            logger.info({ symbol: res.symbol }, "CONFIRMED FIRE: нет данных спота — сигнал отменён");
            skipCount.spotFail++;
            continue;
          }
          {
            // Degraded mode: если MCap недоступен (CoinGecko timeout) — проверяем abs минимум 500K USDT.
            const cfSpotOk = cfMcapAvailable
              ? spotVol24h >= marketCapUsd! * ALPHA_MIN_SPOT_MCAP_PCT
              : spotVol24h >= 500_000;
            if (!cfSpotOk) {
              const pct = marketCapUsd ? (spotVol24h / marketCapUsd * 100).toFixed(3) : "нет MCap";
              logger.info(
                { symbol: res.symbol, spotVol24h, marketCapUsd, pct, degraded: !cfMcapAvailable },
                cfMcapAvailable
                  ? "CONFIRMED FIRE: спот-объём < 0.15% MCap — сигнал отменён"
                  : "CONFIRMED FIRE: MCap недоступен, спот < 500K USDT (degraded) — сигнал отменён"
              );
              skipCount.spotFail++;
              continue;
            }
            if (!cfMcapAvailable) {
              logger.warn({ symbol: res.symbol, spotVol24h }, "CONFIRMED FIRE: MCap недоступен (CoinGecko timeout) — degraded mode, abs 500K пройден");
            }
          }

          // ── CVD Gate (confirmed fire) ─────────────────────────────────────────
          // CONFIRMED FIRE обходил CVD-проверку (continue выше). Применяем те же
          // правила что в основном цикле (строки ~3182, ~3252).
          // Данные недоступны → не блокируем (маленькие кап-токены не всегда есть на CG/BingX).
          {
            const [cfTf, cfCvd] = await Promise.all([
              getCoinglassTakerFlow(res.symbol).catch(() => null),
              fetchCVD(res.symbol).catch(() => null),
            ]);
            const cfKey = res.sentimentKey ?? "";
            // Taker Flow: продавцы доминируют → шорты давят, не покупатели
            if (cfTf?.available) {
              const isShortSqueeze = cfKey === "short_squeeze";
              if (!isShortSqueeze && cfTf.dominance === "sell") {
                logger.info(
                  { symbol: res.symbol, netBuyPct: cfTf.netBuyPct.toFixed(1) + "%", exchanges: cfTf.exchanges },
                  "CONFIRMED FIRE: Taker Flow — продавцы доминируют, OI от шортов → сигнал пропущен"
                );
                skipCount.takerFail++;
                continue;
              }
            }
            // BingX CVD: прямые сделки — покупатели должны доминировать
            if (cfCvd && !cfCvd.positive) {
              logger.info(
                { symbol: res.symbol, buyPct: cfCvd.buyPct.toFixed(1) + "%", trades: cfCvd.trades },
                "CONFIRMED FIRE: CVD негативный — продажи доминируют → сигнал пропущен"
              );
              skipCount.cvdFail++;
              continue;
            }
          }

          let inserted: typeof signalsTable.$inferSelect | undefined;
          for (let attempt = 1; attempt <= 3; attempt++) {
            try {
              const [ins] = await db.insert(signalsTable).values({
                ...sig,
                detectedAt: new Date(),
              }).returning();
              inserted = ins;
              break;
            } catch (err) {
              if (attempt >= 3) {
                logger.error({ err, symbol: res.symbol, attempt }, "CONFIRMED FIRE: signal insert failed after 3 attempts — signal dropped");
              } else {
                logger.warn({ err, symbol: res.symbol, attempt }, "CONFIRMED FIRE: signal insert failed, retry in 2s");
                await new Promise(r => setTimeout(r, 2_000));
              }
            }
          }
          if (!inserted) { skipCount.noConfirming++; continue; }
          const tracked = await trackSignal({
            symbol: res.symbol,
            signalId: inserted.id,
            signalType: res.grade ?? "alpha",
            sentiment: res.sentiment,
            sentimentKey: res.sentimentKey,
            alphaScore: res.alphaScore,
            entryPrice: res.price,
            entryOi: res.openInterest > 0 ? res.openInterest : null,
          });
          if (tracked === false) {
            logger.error({ symbol: res.symbol }, "CONFIRMED FIRE: trackSignal упал — broadcast отменён");
            continue;
          }
          if (tracked === "skip") {
            logger.info({ symbol: res.symbol }, "CONFIRMED FIRE: монета уже в трекере — broadcast всё равно отправляем (claim атомарный)");
          }
          await broadcastBatchAlert([{ ...res, spotVol24h, marketCapUsd }]);
          logger.info(
            { symbol: res.symbol, grade: res.grade, pattern: res.sentimentKey },
            "✅ CONFIRMED FIRE: сигнал выдан напрямую (без watching-очереди)"
          );
        } catch (err) {
          logger.error({ err, symbol: res.symbol }, "CONFIRMED FIRE: ошибка при выстреле");
        }
        continue; // не создаём watching entry для этого символа
      }

      const payload = { alphaResult: res, signalRow: sig };

      // 4h_momentum  — медленный грайнд, 90 мин недостаточно. Даём 4ч окно.
      // early_ignition — импульсный паттерн, 45 мин (быстрее стандартных 90).
      // mega_oi — кит в деривативах, движение может быть отложенным. 60 мин.
      const watchWindowMin = res.oiTriggerTf === "4h_momentum"    ? 240
        : res.oiTriggerTf === "early_ignition" ? 45
        : res.oiTriggerTf === "mega_oi"        ? 60
        : 90;
      const expiresAt = new Date(Date.now() + watchWindowMin * 60 * 1000);
      const triggerTf = res.oiTriggerTf;
      const isVolConfirmed = true;

      const existing = await db.select({ id: oiWatchTable.id, status: oiWatchTable.status })
        .from(oiWatchTable)
        .where(and(eq(oiWatchTable.symbol, res.symbol), eq(oiWatchTable.status, "watching")))
        .limit(1);

      if (existing.length > 0) {
        await db.update(oiWatchTable)
          .set({
            oiChange: res.oiChangePercent,
            volumeMultiplier: res.volumeMultiplier,
            priceAtEntry: res.price,
            expiresAt,
            isVolConfirmed,
            signalPayload: payload as any,
          })
          .where(eq(oiWatchTable.id, existing[0].id));
        logger.info(
          { symbol: res.symbol, grade: res.grade, vol: res.volumeMultiplier.toFixed(1) + "x" },
          "👁 OI Watch: обновлён свежими данными"
        );
      } else {
        await db.insert(oiWatchTable).values({
          symbol: res.symbol,
          triggerTf,
          oiChange: res.oiChangePercent,
          priceAtEntry: await getFreshPrice(res.symbol, res.price),
          volumeMultiplier: res.volumeMultiplier,
          sentimentKey: res.sentimentKey,
          status: "watching",
          addedAt: new Date(),
          expiresAt,
          avgVolume: res.avgVolume,
          isVolConfirmed,
          signalPayload: payload as any,
        });
        logger.info(
          { symbol: res.symbol, grade: res.grade, alphaScore: res.alphaScore, vol: res.volumeMultiplier.toFixed(1) + "x" },
          "👁 OI Watch: сигнал в очереди — сработает через 2 мин если условия сохранятся"
        );
      }
    } catch (err) {
      logger.warn({ err, symbol: res.symbol }, "Ошибка при постановке сигнала в OI Watch");
    }
  }

  const totalSignals = alphaResults.length;
  const scanAt = new Date();
  state.lastScanAt = scanAt;
  state.marketsScanned = usdtTickers.length;

  const durationMs = Date.now() - startTime;
  logger.info(
    {
      signalsFound: totalSignals,
      alphaCount: alphaResults.filter(r => r.grade === "alpha").length,
      superAlphaCount: alphaResults.filter(r => r.grade === "super_alpha").length,
      marketsScanned: usdtTickers.length,
      durationMs,
    },
    "Scan complete"
  );

  // Persist lastScanAt cross-process: both workers can read current scan time from DB
  db.update(settingsTable)
    .set({ scannerLastScanAt: scanAt })
    .catch((err: unknown) => logger.warn({ err }, "Failed to persist scannerLastScanAt"));

  // ── Ghost Pump: ОТКЛЮЧЁН ─────────────────────────────────────────────────────
  // Паттерн убран из ростера: слишком поздний вход, движение уже случилось к моменту сигнала.
  // prescanTracker.clear() также убран — он мешал Volume Breakout накапливать cycleCount между циклами.

  // Persist OI baselines to DB every 5 min so restarts don't lose context
  await persistBaselinesToDb();

  return { signalsFound: totalSignals, marketsScanned: usdtTickers.length, durationMs };
}

/**
 * Вычисляет задержку до следующего выровненного интервала скана.
 * Например, при интервале 30 мин и текущем времени HH:17:xx →
 * следующий скан будет ровно в HH:30:00 (+ 2с), а не HH:17+30=HH:47.
 * Это устраняет drift: каждый скан попадает в начало 30-минутной свечи.
 */
function msUntilNextBoundary(intervalMs: number): number {
  const now = Date.now();
  const msSinceEpoch = now % intervalMs;
  const msToNext = intervalMs - msSinceEpoch;
  // Добавляем 2 секунды, чтобы гарантированно попасть в новую свечу
  return msToNext + 2000;
}

async function scheduledScan() {
  if (!state.running) return;
  try {
    await performScan();
  } catch (err) {
    logger.error({ err }, "Scheduled scan error");
  }
  // Reschedule ALWAYS — even if getSettings() fails (DB hiccup).
  // Without this guard the scan loop dies silently on any transient DB error.
  if (state.running) {
    try {
      const settings = await getSettings();
      state.scanIntervalMs = settings.scanIntervalMs;
    } catch (err) {
      logger.warn({ err }, "Failed to load settings for reschedule — keeping current interval");
    }
    const delay = msUntilNextBoundary(state.scanIntervalMs);
    state.nextScanAt = new Date(Date.now() + delay);
    scanTimer = setTimeout(scheduledScan, delay);
    logger.info({ nextScanIn: `${Math.round(delay / 1000)}s`, nextScanAt: state.nextScanAt }, "Next scan scheduled");
  }
}

export async function startScanner(): Promise<void> {
  if (state.running) return;
  state.running = true;
  logger.info("AltBullet Scanner started (5-Pattern, 5m scan, 30m TF)");

  state.bingxConnected = await testBingX();
  state.telegramConnected = await testTelegram();

  // Restore OI baselines from DB so restarts don't cause a blind period
  await loadBaselinesFromDb();
  // Restore Whale Watch stages so real-time accumulation survives restarts
  await loadWhaleWatchStagesFromDb();
  // Restore prescan tracker so cycleCount / firstSeenAt survive rebuilds
  await loadPrescanFromDb();

  const settings = await getSettings();
  state.scanIntervalMs = settings.scanIntervalMs;

  await performScan();

  const delay = msUntilNextBoundary(settings.scanIntervalMs);
  state.nextScanAt = new Date(Date.now() + delay);
  scanTimer = setTimeout(scheduledScan, delay);
  logger.info({ nextScanIn: `${Math.round(delay / 1000)}s`, nextScanAt: state.nextScanAt }, "Next scan scheduled");
}

export async function stopScanner(): Promise<void> {
  state.running = false;
  state.nextScanAt = null;
  if (scanTimer) {
    clearTimeout(scanTimer);
    scanTimer = null;
  }
  logger.info("Scanner stopped");
}

export async function getScannerState(): Promise<ScannerState & { totalSignals: number; signalsToday: number }> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [totalResult, todayResult, settingsRow] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(signalsTable).then(r => r[0]),
    db.select({ count: sql<number>`count(*)` }).from(signalsTable).where(gte(signalsTable.detectedAt, today)).then(r => r[0]),
    db.select({ scannerLastScanAt: settingsTable.scannerLastScanAt, scanIntervalMs: settingsTable.scanIntervalMs })
      .from(settingsTable).limit(1).then(r => r[0] ?? null),
  ]);

  // Cross-process fallback: if this worker has no scanner, read lastScanAt from DB
  let effectiveLastScanAt = state.lastScanAt;
  let effectiveRunning = state.running;
  const intervalMs = settingsRow?.scanIntervalMs ?? state.scanIntervalMs;

  if (!effectiveLastScanAt && settingsRow?.scannerLastScanAt) {
    effectiveLastScanAt = settingsRow.scannerLastScanAt;
    // Infer running: scanner is alive if last scan was within 2.5× the interval
    const ageMs = Date.now() - settingsRow.scannerLastScanAt.getTime();
    effectiveRunning = ageMs < intervalMs * 2.5;
  }

  return {
    ...state,
    lastScanAt: effectiveLastScanAt,
    running: effectiveRunning,
    scanIntervalMs: intervalMs,
    totalSignals: Number(totalResult?.count ?? 0),
    signalsToday: Number(todayResult?.count ?? 0),
  };
}

/** Synchronous getter — safe to pass as a callback without circular import issues */
export function getLastScanAt(): Date | null {
  return state.lastScanAt;
}

/** Returns current scanner candidates: prescan hot list + OI watch queue */
export async function getScannerCandidates(): Promise<{
  prescan: Array<{
    symbol: string;
    cycleCount: number;
    bestRank: number;
    lastPrice24h: number;
    lastPrice: number;
    lastScore: number;
    firstSeenAt: number;
    lastCvdOk?: boolean | null;
    lastNetBuyPct?: number | null;
    lastOi5m?: number | null;
    lastOi30m?: number | null;
    lastOi1h?: number | null;
    lastOi4h?: number | null;
    lastOi24h?: number | null;
    lastPrice1h?: number | null;
    priceMovePct?: number | null;
  }>;
  oiWatch: Array<{
    id: number;
    symbol: string;
    status: string;
    triggerTf: string;
    oiChange: number;
    priceAtEntry: number;
    volumeMultiplier: number;
    sentimentKey: string | null;
    addedAt: string;
    expiresAt: string;
    oi5m: number | null;
    oi30m: number | null;
    oi1h: number | null;
  }>;
  filtered: Array<{
    symbol: string;
    reason: string;
    reasonLabel: string;
    oi5m: number | null;
    oi30m: number | null;
    oi1h: number | null;
    oi4h: number | null;
    oi24h: number | null;
    vol: number | null;
    price: number | null;
    filteredAt: number;
  }>;
}> {
  // Dual-process resilience: prescanTracker is in-memory per-worker.
  // If this worker hasn't scanned yet, fall back to persisted DB rows.
  let prescan: Array<{
    symbol: string; cycleCount: number; bestRank: number;
    lastPrice24h: number; lastPrice: number; lastScore: number;
    firstSeenAt: number; lastCvdOk?: boolean | null; lastNetBuyPct?: number | null;
    lastOi5m?: number | null; lastOi30m?: number | null; lastOi1h?: number | null;
    lastOi4h?: number | null; lastOi24h?: number | null; lastPrice1h?: number | null;
    priceMovePct?: number | null;
  }>;

  // Fetch active tracked symbols to exclude from prescan display
  const activeTrackedRows = await db
    .select({ symbol: trackedSignalsTable.symbol })
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run", "re_entry"]));
  const activeTrackedSet = new Set(activeTrackedRows.map(r => r.symbol));

  if (prescanTracker.size > 0) {
    prescan = Array.from(prescanTracker.entries())
      .filter(([symbol]) => !activeTrackedSet.has(symbol))
      .map(([symbol, e]) => ({
        symbol,
        cycleCount:    e.cycleCount,
        bestRank:      e.bestRank,
        lastPrice24h:  e.lastPrice24h,
        lastPrice:     e.lastPrice,
        lastScore:     e.lastScore,
        firstSeenAt:   e.firstSeenAt,
        lastCvdOk:     e.lastCvdOk,
        lastNetBuyPct: e.lastNetBuyPct,
        lastOi5m:      e.lastOi5m  ?? null,
        lastOi30m:     e.lastOi30m ?? null,
        lastOi1h:      e.lastOi1h  ?? null,
        lastOi4h:      e.lastOi4h  ?? null,
        lastOi24h:     e.lastOi24h ?? null,
        lastPrice1h:   e.lastPrice1h ?? null,
        priceMovePct:  e.firstPrice > 0
          ? ((e.lastPrice - e.firstPrice) / e.firstPrice * 100)
          : null,
      }))
      .sort((a, b) => b.lastScore - a.lastScore);
  } else {
    // Fallback: read from DB (OI/CVD live fields unavailable, но символы покажем)
    const dbRows = await db.select().from(prescanTrackerTable)
      .orderBy(sql`first_score DESC`)
      .limit(200);
    prescan = dbRows.filter(r => !activeTrackedSet.has(r.symbol)).map(r => ({
      symbol:        r.symbol,
      cycleCount:    r.cycleCount,
      bestRank:      r.bestRank,
      lastPrice24h:  r.firstPrice24h,
      lastPrice:     r.firstPrice,
      lastScore:     r.firstScore,
      firstSeenAt:   r.firstSeenAt,
      lastCvdOk:     null,
      lastNetBuyPct: null,
      lastOi5m:      null,
      lastOi30m:     null,
      lastOi1h:      null,
      lastOi4h:      null,
      lastOi24h:     null,
      lastPrice1h:   null,
      priceMovePct:  null,
    }));
  }

  const watching = await db
    .select({
      id:               oiWatchTable.id,
      symbol:           oiWatchTable.symbol,
      status:           oiWatchTable.status,
      triggerTf:        oiWatchTable.triggerTf,
      oiChange:         oiWatchTable.oiChange,
      priceAtEntry:     oiWatchTable.priceAtEntry,
      volumeMultiplier: oiWatchTable.volumeMultiplier,
      sentimentKey:     oiWatchTable.sentimentKey,
      addedAt:          oiWatchTable.addedAt,
      expiresAt:        oiWatchTable.expiresAt,
      oi5mChange:       oiWatchTable.oi5mChange,
      oi30mChange:      oiWatchTable.oi30mChange,
      oi1hChange:       oiWatchTable.oi1hChange,
    })
    .from(oiWatchTable)
    .where(and(
      inArray(oiWatchTable.status, ["watching", "confirming"]),
      gt(oiWatchTable.expiresAt, new Date()),
    ))
    .orderBy(oiWatchTable.addedAt);

  const oiWatch = watching.map(r => ({
    id:               r.id,
    symbol:           r.symbol,
    status:           r.status,
    triggerTf:        r.triggerTf,
    oiChange:         r.oiChange,
    priceAtEntry:     r.priceAtEntry,
    volumeMultiplier: r.volumeMultiplier,
    sentimentKey:     r.sentimentKey ?? null,
    addedAt:          r.addedAt.toISOString(),
    expiresAt:        r.expiresAt.toISOString(),
    oi5m:             r.oi5mChange ?? null,
    oi30m:            r.oi30mChange ?? null,
    oi1h:             r.oi1hChange ?? null,
  }));

  const filtered = filteredLog.map(e => ({ ...e }));

  return { prescan, oiWatch, filtered };
}
