import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scannerRouter from "./scanner.js";
import signalsRouter from "./signals.js";
import settingsRouter from "./settings.js";
import subscribersRouter from "./subscribers.js";
import trackerRouter from "./tracker.js";
const router: IRouter = Router();

router.use(healthRouter);
router.use(scannerRouter);
router.use(signalsRouter);
router.use(settingsRouter);
router.use(subscribersRouter);
router.use(trackerRouter);

export default router;
