import { Router } from "express";
import { db, signalsTable, trackedSignalsTable, signalWhaleSeedsTable } from "@workspace/db";
import { desc, eq, gte, sql, and } from "drizzle-orm";
import { getTableColumns } from "drizzle-orm";

const router = Router();

router.get("/signals", async (req, res) => {
  try {
    const limit  = Math.min(parseInt(req.query.limit  as string ?? "50") || 50, 200);
    const offset = Math.max(parseInt(req.query.offset as string ?? "0")  || 0, 0);
    const type   = req.query.type   as string | undefined;
    const status = req.query.status as string | undefined;

    const conditions: ReturnType<typeof eq>[] = [];

    if (type && type !== "all") {
      conditions.push(
        eq(signalsTable.type, type as "volume_spike" | "oi_increase" | "funding_rate" | "strict_alpha" | "alpha" | "super_alpha" | "short_sniper")
      );
    }

    // Status filter via correlated subquery
    if (status && status !== "all") {
      if (status === "active") {
        conditions.push(sql`(
          SELECT COALESCE(status, 'active') FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        ) IN ('active', 'accumulation', 're_entry')` as any);
      } else {
        conditions.push(sql`(
          SELECT status FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        ) = ${status}` as any);
      }
    }

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const signals = await db
      .select({
        ...getTableColumns(signalsTable),
        // Tracker status fields
        trackedStatus: sql<string | null>`(
          SELECT status FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        )`,
        trackedPnl: sql<number | null>`(
          SELECT pnl_percent FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        )`,
        // Tracker position fields
        trackedEntryPrice: sql<number | null>`(
          SELECT entry_price FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        )`,
        trackedPeakPrice: sql<number | null>`(
          SELECT peak_price FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        )`,
        trackedTrailingStop: sql<number | null>`(
          SELECT trailing_stop_level FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        )`,
        trackedExitPrice: sql<number | null>`(
          SELECT exit_price FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        )`,
        trackedIsShort: sql<boolean>`COALESCE((
          SELECT is_short FROM tracked_signals ts
          WHERE ts.signal_id = ${signalsTable.id}
          ORDER BY ts.id DESC LIMIT 1
        ), false)`,
        // Whale seed flag
        isWhaleSeed: sql<boolean>`EXISTS (
          SELECT 1 FROM signal_whale_seeds
          WHERE signal_id = ${signalsTable.id}
        )`,
      })
      .from(signalsTable)
      .where(where)
      .orderBy(desc(signalsTable.detectedAt))
      .limit(limit)
      .offset(offset);

    const [totalResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(where);

    res.json({
      signals: signals.map(s => ({
        ...s,
        detectedAt:          s.detectedAt.toISOString(),
        trackedStatus:       s.trackedStatus  ?? null,
        trackedPnl:          s.trackedPnl     ?? null,
        trackedEntryPrice:   s.trackedEntryPrice  ?? null,
        trackedPeakPrice:    s.trackedPeakPrice   ?? null,
        trackedTrailingStop: s.trackedTrailingStop ?? null,
        trackedExitPrice:    s.trackedExitPrice   ?? null,
        trackedIsShort:      Boolean(s.trackedIsShort),
        isWhaleSeed:         Boolean(s.isWhaleSeed),
      })),
      total: Number(totalResult.count),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get signals");
    res.status(500).json({ error: "Failed to get signals" });
  }
});

router.get("/signals/summary", async (req, res) => {
  try {
    const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(signalsTable);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [todayResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(gte(signalsTable.detectedAt, today));

    const [strictAlphaResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(and(eq(signalsTable.type, "strict_alpha"), gte(signalsTable.detectedAt, today)));

    const [strictAlphaTotalResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(eq(signalsTable.type, "strict_alpha"));

    const topSymbolsRaw = await db.select({
      symbol: signalsTable.symbol,
      count: sql<number>`count(*)`,
    })
      .from(signalsTable)
      .where(and(eq(signalsTable.type, "strict_alpha"), gte(signalsTable.detectedAt, today)))
      .groupBy(signalsTable.symbol)
      .orderBy(desc(sql`count(*)`))
      .limit(5);

    res.json({
      totalSignals: Number(totalResult.count),
      signalsToday: Number(todayResult.count),
      strictAlphaToday: Number(strictAlphaResult.count),
      strictAlphaTotal: Number(strictAlphaTotalResult.count),
      volumeSpikes: Number(strictAlphaResult.count),
      oiIncreases: 0,
      fundingRateAlerts: 0,
      topSymbols: topSymbolsRaw.map(r => ({ symbol: r.symbol, count: Number(r.count) })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get signals summary");
    res.status(500).json({ error: "Failed to get signals summary" });
  }
});

router.get("/signals/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid signal ID" });
      return;
    }

    const [signal] = await db.select().from(signalsTable).where(eq(signalsTable.id, id)).limit(1);

    if (!signal) {
      res.status(404).json({ error: "Signal not found" });
      return;
    }

    res.json({ ...signal, detectedAt: signal.detectedAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get signal");
    res.status(500).json({ error: "Failed to get signal" });
  }
});

export default router;
