import { Router } from "express";
import { db, trackedSignalsTable, signalWhaleSeedsTable } from "@workspace/db";
import type { TrackedSignal } from "@workspace/db";
import { desc, eq, gte, and, inArray, sql } from "drizzle-orm";
import { runWatcherCycle, sendWeeklyDigest, sendDailyReport, adminBroadcast } from "../lib/watcher.js";
import { buildPositionsStatusText } from "../lib/positionsReport.js";
import { getFutureTickers } from "../lib/bingx.js";
import { getCoinglassSpotVolume24h } from "../lib/coinglass_spot_cvd.js";
import { batchFetchMarketCap } from "../lib/whale_watch_v2.js";
import { logger } from "../lib/logger.js";
import { TRAILING_ACTIVATION_PCT, TRAILING_FIXED_PCT } from "../lib/watcher-config.js";

const router = Router();

const OPEN_STATUSES = ["active", "in_run", "accumulation", "re_entry"] as const;

// GET /api/tracker — list tracked signals
router.get("/tracker", async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const limit = Math.min(parseInt(req.query.limit as string ?? "100") || 100, 200);

    const where = status && status !== "all"
      ? eq(trackedSignalsTable.status, status as any)
      : undefined;

    const signals = await db.select()
      .from(trackedSignalsTable)
      .where(where)
      .orderBy(desc(trackedSignalsTable.detectedAt))
      .limit(limit);

    // For open positions fetch live prices from BingX to compute real-time PnL
    const priceMap = new Map<string, number>();
    const hasOpen = signals.some(s => OPEN_STATUSES.includes(s.status as any));
    if (hasOpen) {
      try {
        const tickers = await getFutureTickers() as { symbol: string; lastPrice: string }[];
        for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
      } catch { /* non-critical — show without live price */ }
    }

    res.json({
      signals: signals.map(s => {
        const base = {
          ...s,
          detectedAt: s.detectedAt.toISOString(),
          updatedAt:  s.updatedAt.toISOString(),
          closedAt:   s.closedAt?.toISOString() ?? null,
        };
        if (OPEN_STATUSES.includes(s.status as any) && s.entryPrice != null) {
          const currentPrice = priceMap.get(s.symbol) ?? null;
          const entry = Number(s.entryPrice);
          const livePnl = currentPrice && entry > 0
            ? Math.round(((currentPrice - entry) / entry) * 10000) / 100
            : null;
          // Live peak = max(current price, stored peak) so dashboard always reflects reality
          const dbPeak = s.peakPrice != null ? Number(s.peakPrice) : null;
          const livePeak = currentPrice
            ? (dbPeak && dbPeak > currentPrice ? dbPeak : currentPrice)
            : dbPeak;
          const peakPnl = livePeak && entry > 0
            ? ((livePeak - entry) / entry) * 100
            : 0;
          // Trailing stop: activated once peak PnL >= TRAILING_ACTIVATION_PCT
          const liveTrailingStop = peakPnl >= TRAILING_ACTIVATION_PCT && livePeak
            ? Math.round(livePeak * (1 - TRAILING_FIXED_PCT / 100) * 1e8) / 1e8
            : null;
          return {
            ...base,
            pnlPercent: livePnl,
            currentPrice,
            peakPrice: livePeak,
            trailingStopLevel: liveTrailingStop ?? s.trailingStopLevel,
          };
        }
        return base;
      }),
      total: signals.length,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch tracked signals" });
  }
});

// GET /api/tracker/journal — full trading journal data
// Optional query param: ?from=YYYY-MM-DD
//   - Open signals (active/accumulation/in_run/re_entry): always counted without date filter
//   - Closed signals (profit/stop_loss/cancelled/breakeven): filtered by closed_at >= from
router.get("/tracker/journal", async (req, res) => {
  try {
    const fromParam = req.query.from as string | undefined;
    const fromDate  = fromParam ? new Date(fromParam) : null;
    // closedFilter applies only to closed signals — filter by when they CLOSED, not when detected
    const closedFilter = fromDate ? gte(trackedSignalsTable.closedAt, fromDate) : undefined;

    // 1a. Open signals — always count ALL open regardless of period filter
    const openStatusRows = await db.select({
      status: trackedSignalsTable.status,
      count: sql<number>`count(*)::int`,
    })
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run", "re_entry"]))
    .groupBy(trackedSignalsTable.status);

    const byOpen: Record<string, number> = {};
    for (const row of openStatusRows) {
      byOpen[row.status ?? "unknown"] = row.count;
    }
    const active = (byOpen["active"] ?? 0) + (byOpen["accumulation"] ?? 0) + (byOpen["in_run"] ?? 0) + (byOpen["re_entry"] ?? 0);

    // 1b. Closed signals — filter by closedAt >= from
    const closedStatusRows = await db.select({
      status: trackedSignalsTable.status,
      count: sql<number>`count(*)::int`,
      avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
    })
    .from(trackedSignalsTable)
    .where(and(
      inArray(trackedSignalsTable.status, ["profit", "stop_loss", "cancelled", "breakeven", "bu_stop"]),
      closedFilter,
    ))
    .groupBy(trackedSignalsTable.status);

    const byStatus: Record<string, { count: number; avgPnl: number | null }> = {};
    for (const row of closedStatusRows) {
      byStatus[row.status ?? "unknown"] = { count: row.count, avgPnl: row.avgPnl != null ? Number(row.avgPnl) : null };
    }

    const profit    = byStatus["profit"]?.count    ?? 0;
    const stopLoss  = byStatus["stop_loss"]?.count  ?? 0;
    const cancelled = byStatus["cancelled"]?.count  ?? 0;
    const breakeven = byStatus["breakeven"]?.count  ?? 0;
    const buStop    = byStatus["bu_stop"]?.count    ?? 0;
    const total     = active + profit + stopLoss + cancelled + breakeven + buStop;
    const closed    = profit + stopLoss + breakeven + buStop;
    // Win rate = (profit + buStop) / (profit + buStop + stopLoss) — buStop считается как выигрыш (защищённая позиция)
    const winRateDenominator = profit + buStop + stopLoss;
    const winRate   = winRateDenominator > 0 ? Math.round(((profit + buStop) / winRateDenominator) * 100) : null;
    const avgProfit = byStatus["profit"]?.avgPnl ?? null;
    const avgLoss   = byStatus["stop_loss"]?.avgPnl ?? null;

    // 2. Best / worst trade — filter by closedAt >= from
    const bestRows = await db.select({
      symbol: trackedSignalsTable.symbol,
      pnl: trackedSignalsTable.pnlPercent,
      sentimentKey: trackedSignalsTable.sentimentKey,
    })
    .from(trackedSignalsTable)
    .where(and(eq(trackedSignalsTable.status, "profit"), closedFilter))
    .orderBy(desc(trackedSignalsTable.pnlPercent))
    .limit(1);

    const worstRows = await db.select({
      symbol: trackedSignalsTable.symbol,
      pnl: trackedSignalsTable.pnlPercent,
      sentimentKey: trackedSignalsTable.sentimentKey,
    })
    .from(trackedSignalsTable)
    .where(and(eq(trackedSignalsTable.status, "stop_loss"), closedFilter))
    .orderBy(trackedSignalsTable.pnlPercent)
    .limit(1);

    // 3. Per-pattern breakdown — closed signals only, filtered by closedAt >= from
    const patternRows = await db.select({
      sentimentKey: trackedSignalsTable.sentimentKey,
      status: trackedSignalsTable.status,
      count: sql<number>`count(*)::int`,
      avgPnl:  sql<number>`round(avg(pnl_percent)::numeric, 2)`,
      avgPeak: sql<number>`round(avg((peak_price - entry_price) / nullif(entry_price, 0) * 100)::numeric, 2)`,
    })
    .from(trackedSignalsTable)
    .where(and(inArray(trackedSignalsTable.status, ["profit", "stop_loss", "cancelled", "breakeven", "bu_stop"]), closedFilter))
    .groupBy(trackedSignalsTable.sentimentKey, trackedSignalsTable.status);

    const patternMap = new Map<string, { profit: number; stopLoss: number; cancelled: number; breakeven: number; buStop: number; totalPnl: number; pnlCount: number; totalPeak: number; peakCount: number }>();
    for (const row of patternRows) {
      const key = row.sentimentKey ?? "unknown";
      if (!patternMap.has(key)) patternMap.set(key, { profit: 0, stopLoss: 0, cancelled: 0, breakeven: 0, buStop: 0, totalPnl: 0, pnlCount: 0, totalPeak: 0, peakCount: 0 });
      const p = patternMap.get(key)!;
      if (row.status === "profit")         p.profit    += row.count;
      else if (row.status === "stop_loss") p.stopLoss  += row.count;
      else if (row.status === "cancelled") p.cancelled += row.count;
      else if (row.status === "breakeven") p.breakeven += row.count;
      else if (row.status === "bu_stop")   p.buStop    += row.count;
      if (row.avgPnl  != null) { p.totalPnl  += Number(row.avgPnl)  * row.count; p.pnlCount  += row.count; }
      if (row.avgPeak != null) { p.totalPeak += Number(row.avgPeak) * row.count; p.peakCount += row.count; }
    }

    const byPattern = Array.from(patternMap.entries()).map(([key, p]) => {
      const patTotal   = p.profit + p.stopLoss + p.cancelled + p.breakeven + p.buStop;
      const patWrDenom = p.profit + p.buStop + p.stopLoss;
      return {
        sentimentKey: key,
        total:    patTotal,
        profit:   p.profit,
        stopLoss: p.stopLoss,
        cancelled: p.cancelled,
        buStop:   p.buStop,
        winRate:  patWrDenom > 0 ? Math.round(((p.profit + p.buStop) / patWrDenom) * 100) : null,
        avgPnl:   p.pnlCount  > 0 ? Math.round((p.totalPnl  / p.pnlCount)  * 10) / 10 : null,
        avgPeak:  p.peakCount > 0 ? Math.round((p.totalPeak / p.peakCount) * 10) / 10 : null,
      };
    }).sort((a, b) => b.total - a.total);

    // 4. Per-token breakdown — closed signals only, filtered by closedAt >= from
    const tokenRows = await db.execute(
      fromDate
        ? sql`
          SELECT
            symbol,
            COUNT(*)::int                                                                         AS total,
            COUNT(*) FILTER (WHERE status = 'profit')::int                                       AS profit,
            COUNT(*) FILTER (WHERE status = 'stop_loss')::int                                    AS stop_loss,
            COUNT(*) FILTER (WHERE status = 'cancelled')::int                                    AS cancelled,
            COUNT(*) FILTER (WHERE status = 'breakeven')::int                                    AS breakeven,
            ROUND(AVG(pnl_percent)::numeric, 2)                                                  AS avg_pnl,
            ROUND(MAX(pnl_percent)::numeric, 2)                                                  AS best_pnl,
            ROUND(AVG((peak_price - entry_price) / NULLIF(entry_price, 0) * 100)::numeric, 2)   AS avg_peak,
            MODE() WITHIN GROUP (ORDER BY sentiment_key)                                         AS main_pattern
          FROM tracked_signals
          WHERE status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
            AND closed_at >= ${fromDate}
          GROUP BY symbol
          ORDER BY total DESC
        `
        : sql`
          SELECT
            symbol,
            COUNT(*)::int                                                                         AS total,
            COUNT(*) FILTER (WHERE status = 'profit')::int                                       AS profit,
            COUNT(*) FILTER (WHERE status = 'stop_loss')::int                                    AS stop_loss,
            COUNT(*) FILTER (WHERE status = 'cancelled')::int                                    AS cancelled,
            COUNT(*) FILTER (WHERE status = 'breakeven')::int                                    AS breakeven,
            ROUND(AVG(pnl_percent)::numeric, 2)                                                  AS avg_pnl,
            ROUND(MAX(pnl_percent)::numeric, 2)                                                  AS best_pnl,
            ROUND(AVG((peak_price - entry_price) / NULLIF(entry_price, 0) * 100)::numeric, 2)   AS avg_peak,
            MODE() WITHIN GROUP (ORDER BY sentiment_key)                                         AS main_pattern
          FROM tracked_signals
          WHERE status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
          GROUP BY symbol
          ORDER BY total DESC
        `
    );

    const byToken = (tokenRows.rows as Record<string, unknown>[]).map(r => {
      const tok_profit = Number(r.profit)    || 0;
      const tok_stop   = Number(r.stop_loss) || 0;
      const tok_wrDenom = tok_profit + tok_stop;
      return {
        symbol:      r.symbol as string,
        total:       Number(r.total),
        profit:      tok_profit,
        stopLoss:    tok_stop,
        cancelled:   Number(r.cancelled) || 0,
        winRate:     tok_wrDenom > 0 ? Math.round((tok_profit / tok_wrDenom) * 100) : null,
        avgPnl:      r.avg_pnl  != null ? Number(r.avg_pnl)  : null,
        bestPnl:     r.best_pnl != null ? Number(r.best_pnl) : null,
        avgPeak:     r.avg_peak != null ? Number(r.avg_peak) : null,
        mainPattern: (r.main_pattern as string) ?? null,
      };
    });

    // 5. Recent closed trades (last 50) with entry conditions
    const tradeRows = await db.execute(
      fromDate
        ? sql`
          SELECT
            ts.id, ts.symbol, ts.status, ts.sentiment_key,
            ts.entry_price, ts.exit_price,
            ROUND(ts.pnl_percent::numeric, 2)                                               AS pnl_percent,
            ROUND(((ts.peak_price - ts.entry_price)/NULLIF(ts.entry_price,0)*100)::numeric, 2) AS peak_pct,
            ts.detected_at, ts.closed_at,
            ROUND(EXTRACT(EPOCH FROM (COALESCE(ts.closed_at, NOW()) - ts.detected_at))/3600, 1) AS hours_held,
            s.oi_change_percent,
            s.cumulative_oi_change,
            ROUND((s.volume_24h / NULLIF(s.avg_volume, 0))::numeric, 1) AS vol_mult,
            s.alpha_score,
            s.price_change_percent AS px_24h
          FROM tracked_signals ts
          LEFT JOIN signals s ON ts.signal_id = s.id
          WHERE ts.status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
            AND ts.closed_at >= ${fromDate}
          ORDER BY ts.closed_at DESC
          LIMIT 50
        `
        : sql`
          SELECT
            ts.id, ts.symbol, ts.status, ts.sentiment_key,
            ts.entry_price, ts.exit_price,
            ROUND(ts.pnl_percent::numeric, 2)                                               AS pnl_percent,
            ROUND(((ts.peak_price - ts.entry_price)/NULLIF(ts.entry_price,0)*100)::numeric, 2) AS peak_pct,
            ts.detected_at, ts.closed_at,
            ROUND(EXTRACT(EPOCH FROM (COALESCE(ts.closed_at, NOW()) - ts.detected_at))/3600, 1) AS hours_held,
            s.oi_change_percent,
            s.cumulative_oi_change,
            ROUND((s.volume_24h / NULLIF(s.avg_volume, 0))::numeric, 1) AS vol_mult,
            s.alpha_score,
            s.price_change_percent AS px_24h
          FROM tracked_signals ts
          LEFT JOIN signals s ON ts.signal_id = s.id
          WHERE ts.status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
          ORDER BY ts.closed_at DESC NULLS LAST
          LIMIT 50
        `
    );

    const trades = (tradeRows.rows as Record<string, unknown>[]).map(r => ({
      id:           r.id,
      symbol:       r.symbol,
      status:       r.status,
      sentimentKey: r.sentiment_key,
      entryPrice:   r.entry_price   != null ? Number(r.entry_price)   : null,
      exitPrice:    r.exit_price    != null ? Number(r.exit_price)    : null,
      pnlPercent:   r.pnl_percent   != null ? Number(r.pnl_percent)   : null,
      peakPct:      r.peak_pct      != null ? Number(r.peak_pct)      : null,
      detectedAt:   r.detected_at,
      closedAt:     r.closed_at     ?? null,
      hoursHeld:    r.hours_held    != null ? Number(r.hours_held)    : null,
      oiChangePct:  r.oi_change_percent   != null ? Number(r.oi_change_percent)   : null,
      cumulativeOi: r.cumulative_oi_change != null ? Number(r.cumulative_oi_change) : null,
      volMult:      r.vol_mult      != null ? Number(r.vol_mult)      : null,
      alphaScore:   r.alpha_score   != null ? Number(r.alpha_score)   : null,
      px24h:        r.px_24h        != null ? Number(r.px_24h)        : null,
    }));

    res.json({
      summary: {
        total, profit, stopLoss, cancelled, breakeven, buStop, active, winRate, avgProfit, avgLoss,
        bestTrade:  bestRows[0]  ? { symbol: bestRows[0].symbol,  pnl: Number(bestRows[0].pnl),  sentimentKey: bestRows[0].sentimentKey  ?? null } : null,
        worstTrade: worstRows[0] ? { symbol: worstRows[0].symbol, pnl: Number(worstRows[0].pnl), sentimentKey: worstRows[0].sentimentKey ?? null } : null,
      },
      byPattern,
      byToken,
      trades,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch journal");
    res.status(500).json({ error: "Failed to fetch journal" });
  }
});

// GET /api/tracker/monthly-stats — stats grouped by calendar month
router.get("/tracker/monthly-stats", async (req, res) => {
  try {
    const rows = await db.execute(sql`
      SELECT
        TO_CHAR(detected_at, 'YYYY-MM') AS month,
        COUNT(*)::int                                                                     AS total,
        COUNT(*) FILTER (WHERE status = 'profit')::int                                   AS profit,
        COUNT(*) FILTER (WHERE status = 'stop_loss')::int                                AS stop_loss,
        COUNT(*) FILTER (WHERE status = 'cancelled')::int                                AS cancelled,
        COUNT(*) FILTER (WHERE status = 'breakeven')::int                                AS breakeven,
        COUNT(*) FILTER (WHERE status = 'bu_stop')::int                                  AS bu_stop,
        ROUND(AVG(pnl_percent) FILTER (WHERE status = 'profit')::numeric, 2)             AS avg_profit,
        ROUND(AVG(pnl_percent) FILTER (WHERE status = 'stop_loss')::numeric, 2)          AS avg_loss,
        ROUND(AVG((peak_price - entry_price) / NULLIF(entry_price, 0) * 100)
              FILTER (WHERE status IN ('profit','stop_loss'))::numeric, 2)               AS avg_peak,
        MAX(pnl_percent) FILTER (WHERE status = 'profit')                                AS best_pnl,
        MIN(pnl_percent) FILTER (WHERE status = 'stop_loss')                             AS worst_pnl
      FROM tracked_signals
      WHERE status IN ('profit','stop_loss','cancelled','breakeven','bu_stop')
      GROUP BY TO_CHAR(detected_at, 'YYYY-MM')
      ORDER BY month DESC
    `);

    const months = (rows.rows as Record<string, unknown>[]).map(r => {
      const profit   = Number(r.profit   ?? 0);
      const stopLoss = Number(r.stop_loss ?? 0);
      const buStopM  = Number(r.bu_stop  ?? 0);
      const closed   = profit + stopLoss + Number(r.breakeven ?? 0) + buStopM;
      const winRateDenom = profit + buStopM + stopLoss;
      const winRate  = winRateDenom > 0 ? Math.round(((profit + buStopM) / winRateDenom) * 100) : null;

      const [year, mon] = String(r.month).split("-");
      const monthLabel = new Date(Number(year), Number(mon) - 1, 1)
        .toLocaleDateString("ru-RU", { month: "long", year: "numeric" });

      return {
        month:     r.month    as string,
        label:     monthLabel,
        total:     Number(r.total     ?? 0),
        profit,
        stopLoss,
        cancelled: Number(r.cancelled ?? 0),
        breakeven: Number(r.breakeven ?? 0),
        winRate,
        avgProfit: r.avg_profit != null ? Number(r.avg_profit) : null,
        avgLoss:   r.avg_loss   != null ? Number(r.avg_loss)   : null,
        avgPeak:   r.avg_peak   != null ? Number(r.avg_peak)   : null,
        bestPnl:   r.best_pnl   != null ? Number(r.best_pnl)   : null,
        worstPnl:  r.worst_pnl  != null ? Number(r.worst_pnl)  : null,
      };
    });

    res.json({ months });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch monthly stats");
    res.status(500).json({ error: "Failed to fetch monthly stats" });
  }
});

// GET /api/tracker/stats — summary stats (all-time + current month)
router.get("/tracker/stats", async (req, res) => {
  try {
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    const [rows, monthRows] = await Promise.all([
      db.select({
        status: trackedSignalsTable.status,
        count: sql<number>`count(*)::int`,
        avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
      }).from(trackedSignalsTable).groupBy(trackedSignalsTable.status),

      db.select({
        status: trackedSignalsTable.status,
        count: sql<number>`count(*)::int`,
        avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
      }).from(trackedSignalsTable)
        .where(gte(trackedSignalsTable.closedAt, monthStart))
        .groupBy(trackedSignalsTable.status),
    ]);

    const stats: Record<string, { count: number; avgPnl: number | null }> = {};
    for (const row of rows) stats[row.status] = { count: row.count, avgPnl: row.avgPnl };

    const monthStats: Record<string, { count: number; avgPnl: number | null }> = {};
    for (const row of monthRows) monthStats[row.status] = { count: row.count, avgPnl: row.avgPnl };

    const total = rows.reduce((s, r) => s + r.count, 0);
    const profits  = stats["profit"]?.count  ?? 0;
    const stops    = stats["stop_loss"]?.count ?? 0;
    const winRate  = (profits + stops) > 0 ? Math.round((profits / (profits + stops)) * 100) : null;
    const avgProfit = stats["profit"]?.avgPnl != null ? Number(stats["profit"].avgPnl) : null;
    const avgLoss   = stats["stop_loss"]?.avgPnl != null ? Number(stats["stop_loss"].avgPnl) : null;

    // Month-only derived stats
    const mProfits = monthStats["profit"]?.count ?? 0;
    const mStops   = monthStats["stop_loss"]?.count ?? 0;
    const monthWinRate  = (mProfits + mStops) > 0 ? Math.round((mProfits / (mProfits + mStops)) * 100) : null;
    const monthAvgProfit = monthStats["profit"]?.avgPnl != null ? Number(monthStats["profit"].avgPnl) : null;
    const monthAvgLoss   = monthStats["stop_loss"]?.avgPnl != null ? Number(monthStats["stop_loss"].avgPnl) : null;

    res.json({ stats, total, winRate, avgProfit, avgLoss, monthStats, monthWinRate, monthAvgProfit, monthAvgLoss });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch tracker stats" });
  }
});

// POST /api/tracker/import — bulk-insert tracked positions (migration/admin tool)
// Body: { positions: Array<{ symbol, sentimentKey, isShort?, entryPrice, detectedAt, status? }> }
router.post("/tracker/import", async (req, res) => {
  try {
    const { positions } = req.body as {
      positions: Array<{
        symbol: string;
        sentimentKey: string;
        isShort?: boolean;
        entryPrice: number;
        detectedAt: string;
        status?: string;
      }>;
    };
    if (!Array.isArray(positions) || positions.length === 0) {
      return res.status(400).json({ error: "positions array required" });
    }
    const now = new Date();
    const inserted: string[] = [];
    const skipped: string[] = [];
    for (const p of positions) {
      // Skip if already open for this symbol
      const existing = await db.select({ id: trackedSignalsTable.id })
        .from(trackedSignalsTable)
        .where(and(
          eq(trackedSignalsTable.symbol, p.symbol),
          inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "re_entry"])
        ))
        .limit(1);
      if (existing.length > 0) { skipped.push(p.symbol); continue; }
      await db.insert(trackedSignalsTable).values({
        symbol: p.symbol,
        signalType: "strict_alpha",
        sentimentKey: p.sentimentKey,
        isShort: p.isShort ?? false,
        entryPrice: p.entryPrice,
        status: (p.status ?? "active") as any,
        detectedAt: new Date(p.detectedAt),
        updatedAt: now,
      });
      inserted.push(p.symbol);
    }
    req.log.info({ inserted, skipped }, "tracker/import: positions imported");
    res.json({ ok: true, inserted, skipped });
  } catch (err) {
    req.log.error({ err }, "tracker/import failed");
    res.status(500).json({ error: "Import failed" });
  }
});

// POST /api/tracker/run-cycle — manually trigger watcher cycle
router.post("/tracker/run-cycle", async (req, res) => {
  try {
    const result = await runWatcherCycle();
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ error: "Watcher cycle failed" });
  }
});

// POST /api/tracker/notify — admin broadcast custom message to all subscribers
router.post("/tracker/notify", async (req, res) => {
  try {
    const { text } = req.body as { text?: string };
    if (!text) return res.status(400).json({ error: "text required" });
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Broadcast failed" });
  }
});

// POST /api/tracker/weekly-digest — send weekly digest now (manual, bypass dedupe)
router.post("/tracker/weekly-digest", async (req, res) => {
  try {
    await sendWeeklyDigest(undefined, true);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Weekly digest failed" });
  }
});

// POST /api/tracker/daily-digest — send daily report now (manual, bypass dedupe)
router.post("/tracker/daily-digest", async (req, res) => {
  try {
    await sendDailyReport(undefined, true);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Daily report failed" });
  }
});

// POST /api/tracker/positions-update — send positions status to all subscribers now
router.post("/tracker/positions-update", async (req, res) => {
  try {
    const text = await buildPositionsStatusText();
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Positions update failed" });
  }
});

// ── POST /api/tracker/spot-audit ──────────────────────────────────────────────
// Прогоняет все открытые сигналы через спот-фильтр (% от MCap).
// Отменяет те, где данные есть и объём ниже порога.
// Отправляет сводку в Telegram и возвращает JSON с результатами.
router.post("/tracker/spot-audit", async (req, res) => {
  try {
    const OPEN_STATUSES = ["active", "in_run", "accumulation", "re_entry"] as const;
    // Спот-объём >= MIN_PCT * MCap — только процентный порог, без фиксированной суммы.
    // Нет MCap данных → блок.
    const MIN_PCT_ALPHA  = 0.0005; // 0.05% MCap — стандартные паттерны
    const MIN_PCT_WHALE  = 0.003;  // 0.30% MCap — whale_futures / whale_watch

    // 1. Все открытые позиции
    const open = await db.select()
      .from(trackedSignalsTable)
      .where(inArray(trackedSignalsTable.status, [...OPEN_STATUSES]));

    if (open.length === 0) {
      await adminBroadcast(
        `🔍 <b>Аудит спот-фильтра</b>\n\nОткрытых позиций нет — нечего проверять.`
      );
      return res.json({ ok: true, total: 0, cancelled: 0, passed: 0, noData: 0 });
    }

    // 2. Получаем текущие цены для P&L
    const priceMap = new Map<string, number>();
    try {
      const tickers = await getFutureTickers() as { symbol: string; lastPrice: string }[];
      for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
    } catch { /* skip */ }

    // 3. Спот-объёмы — параллельно (BingX, без rate limit проблем)
    //    MCap — одним батч-запросом к CoinGecko (экономим rate limit)
    type AuditRow = {
      sig:          TrackedSignal;
      spotVol24h:   number | null;
      marketCapUsd: number | null;
      spotPct:      number | null;
      minPct:       number;
      verdict:      "cancel" | "pass" | "no_data";
    };

    const symbols = open.map(s => s.symbol);

    // Параллельно: все spot vol + один батч mcap запрос
    const [spotVolMap, mcapMap] = await Promise.all([
      Promise.all(symbols.map(sym =>
        getCoinglassSpotVolume24h(sym).catch(() => null)
          .then(vol => [sym, vol] as [string, number | null])
      )).then(entries => new Map(entries)),
      batchFetchMarketCap(symbols),
    ]);

    const rows: AuditRow[] = open.map(sig => {
      const minPct       = sig.sentimentKey === "whale_futures" ? MIN_PCT_WHALE : MIN_PCT_ALPHA;
      const spotVol24h   = spotVolMap.get(sig.symbol) ?? null;
      const mcapData     = mcapMap.get(sig.symbol) ?? null;
      const marketCapUsd = mcapData?.mcap ?? null;
      const spotPct      = (spotVol24h != null && marketCapUsd != null && marketCapUsd > 0)
        ? (spotVol24h / marketCapUsd) * 100
        : null;

      // Только процентный порог от MCap — нет MCap данных → no_data (не отменяем).
      let verdict: AuditRow["verdict"] = "no_data";
      if (spotVol24h !== null && marketCapUsd !== null) {
        const pctOk = spotPct !== null && spotPct >= (minPct * 100);
        verdict = pctOk ? "pass" : "cancel";
      }

      return { sig, spotVol24h, marketCapUsd, spotPct, minPct, verdict };
    });

    // 4. Отмена: массовый UPDATE
    const toCancel = rows.filter(r => r.verdict === "cancel");
    if (toCancel.length > 0) {
      await db.update(trackedSignalsTable)
        .set({ status: "cancelled", closedAt: new Date(), updatedAt: new Date() })
        .where(inArray(trackedSignalsTable.id, toCancel.map(r => r.sig.id)));
      logger.info(
        { cancelled: toCancel.map(r => r.sig.symbol) },
        "spot-audit: принудительно отменены сигналы с низким спот-объёмом"
      );
    }

    // 5. Telegram сводка
    const now = new Date();
    const moscowTime = now.toLocaleString("ru-RU", {
      timeZone: "Europe/Moscow",
      day: "2-digit", month: "long", hour: "2-digit", minute: "2-digit",
    });

    function fmtP(p: number): string {
      if (p >= 1) return `$${p.toFixed(3)}`;
      if (p >= 0.01) return `$${p.toFixed(4)}`;
      return `$${p.toFixed(5)}`;
    }
    function computePnl(sig: TrackedSignal, curPrice: number): number {
      if (!sig.entryPrice || sig.entryPrice === 0) return 0;
      const diff = curPrice - sig.entryPrice;
      return (sig.isShort ? -diff : diff) / sig.entryPrice * 100;
    }

    const lines: string[] = [
      `🔍 <b>Аудит спот-фильтра</b> — <i>${moscowTime} МСК</i>`,
      ``,
      `Проверено позиций: <b>${open.length}</b>`,
      ``,
    ];

    // Отменённые
    if (toCancel.length > 0) {
      lines.push(`❌ <b>Закрыты принудительно — ${toCancel.length}</b>`);
      for (const r of toCancel) {
        const coin    = r.sig.symbol.replace("-USDT", "");
        const pctStr  = r.spotPct != null ? `${r.spotPct.toFixed(1)}% MCap` : "?% MCap";
        const reqStr  = `${(r.minPct * 100).toFixed(0)}%`;
        const curPrice = priceMap.get(r.sig.symbol);
        const pnl      = curPrice ? computePnl(r.sig, curPrice) : null;
        const pnlStr   = pnl != null ? ` | P&L: ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%` : "";
        lines.push(`  • <b>${coin}</b> — спот ${pctStr} (нужно ≥${reqStr})${pnlStr}`);
      }
      lines.push(``);
    }

    // Прошли фильтр
    const passed = rows.filter(r => r.verdict === "pass");
    if (passed.length > 0) {
      lines.push(`✅ <b>Прошли фильтр — ${passed.length}</b>`);
      for (const r of passed) {
        const coin     = r.sig.symbol.replace("-USDT", "");
        const pctStr   = r.spotPct != null ? `${r.spotPct.toFixed(1)}% MCap` : "";
        const curPrice = priceMap.get(r.sig.symbol);
        const pnl      = curPrice ? computePnl(r.sig, curPrice) : null;
        const pnlStr   = pnl != null ? ` | ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%` : "";
        const priceStr = curPrice ? ` | ${fmtP(r.sig.entryPrice ?? 0)} → ${fmtP(curPrice)}` : "";
        lines.push(`  • <b>${coin}</b> — ${pctStr}${priceStr}${pnlStr}`);
      }
      lines.push(``);
    }

    // Нет данных (не блокировали — но сообщаем)
    const noData = rows.filter(r => r.verdict === "no_data");
    if (noData.length > 0) {
      lines.push(`⚠️ <b>Нет данных MCap — ${noData.length} (не тронуты)</b>`);
      for (const r of noData) {
        const coin = r.sig.symbol.replace("-USDT", "");
        lines.push(`  • <b>${coin}</b>`);
      }
      lines.push(``);
    }

    lines.push(`📋 Итог: закрыто <b>${toCancel.length}</b>, активно <b>${passed.length + noData.length}</b>`);

    await adminBroadcast(lines.join("\n"));

    // После аудита — сразу отправить актуальный список позиций
    try {
      const posText = await buildPositionsStatusText();
      await adminBroadcast(posText);
    } catch (err) {
      logger.warn({ err }, "spot-audit: не удалось отправить список позиций после аудита");
    }

    res.json({
      ok: true,
      total: open.length,
      cancelled: toCancel.length,
      passed: passed.length,
      noData: noData.length,
      cancelledSymbols: toCancel.map(r => r.sig.symbol),
      passedSymbols:    passed.map(r => r.sig.symbol),
      noDataSymbols:    noData.map(r => r.sig.symbol),
    });
  } catch (err) {
    logger.error({ err }, "spot-audit: ошибка");
    res.status(500).json({ error: "Spot audit failed" });
  }
});

// ── POST /api/tracker/backfill-whale-seeds ────────────────────────────────────
// Разовый бэкфилл: засевает все исторические отменённые сигналы с OI ≥3%
// которые ещё не имеют активного сида в signal_whale_seeds.
router.post("/tracker/backfill-whale-seeds", async (req, res) => {
  try {
    const rows = await db.execute(sql`
      SELECT
        ts.id                   AS tracked_id,
        ts.symbol,
        ts.signal_id,
        ts.sentiment_key,
        ts.entry_price,
        ts.closed_at,
        COALESCE(s.cumulative_oi_change, s.oi_change_percent, 0) AS oi_magnitude
      FROM tracked_signals ts
      LEFT JOIN signals s ON s.id = ts.signal_id
      WHERE ts.status = 'cancelled'
        AND ts.signal_id IS NOT NULL
        AND COALESCE(s.cumulative_oi_change, s.oi_change_percent, 0) >= 3.0
        AND NOT EXISTS (
          SELECT 1 FROM signal_whale_seeds w
          WHERE w.symbol = ts.symbol AND w.status = 'watching'
        )
      ORDER BY ts.closed_at DESC
    `);

    const candidates = rows.rows as {
      tracked_id: number; symbol: string; signal_id: number;
      sentiment_key: string | null; entry_price: number;
      closed_at: string; oi_magnitude: number;
    }[];

    let seeded = 0;
    for (const c of candidates) {
      const closedAt = new Date(c.closed_at);
      const expiresAt = new Date(closedAt.getTime() + 90 * 24 * 60 * 60 * 1000);
      if (expiresAt < new Date()) continue; // уже истёк бы

      // повторная проверка дедупликации (для гонок)
      const existing = await db.select({ id: signalWhaleSeedsTable.id })
        .from(signalWhaleSeedsTable)
        .where(and(
          eq(signalWhaleSeedsTable.symbol, c.symbol),
          eq(signalWhaleSeedsTable.status, "watching"),
        )).limit(1);
      if (existing.length > 0) continue;

      await db.insert(signalWhaleSeedsTable).values({
        symbol:          c.symbol,
        trackedSignalId: c.tracked_id,
        signalId:        c.signal_id,
        sentimentKey:    c.sentiment_key ?? null,
        oiAtSeed:        c.oi_magnitude,
        priceAtSeed:     c.entry_price,
        seededAt:        closedAt,
        expiresAt,
      });
      seeded++;
    }

    req.log.info({ total: candidates.length, seeded }, "🌱 Whale backfill complete");
    res.json({ ok: true, candidates: candidates.length, seeded });
  } catch (err) {
    req.log.error({ err }, "Whale backfill failed");
    res.status(500).json({ error: "Backfill failed" });
  }
});

// GET /api/tracker/whale-seeds — cancelled signals seeded for whale watch
router.get("/tracker/whale-seeds", async (req, res) => {
  try {
    const rows = await db.execute(sql`
      SELECT
        s.id, s.symbol, s.sentiment_key,
        ROUND(s.oi_at_seed::numeric, 2)    AS oi_at_seed,
        s.price_at_seed,
        s.seeded_at, s.expires_at, s.status,
        ROUND(s.oi_growth_pct::numeric, 2) AS oi_growth_pct,
        s.last_checked_at,
        ROUND(EXTRACT(EPOCH FROM (NOW() - s.seeded_at))/86400, 1) AS days_since_seeded
      FROM signal_whale_seeds s
      WHERE s.status = 'watching'
      ORDER BY s.seeded_at DESC
      LIMIT 100
    `);

    const seeds = (rows.rows as Record<string, unknown>[]).map(r => ({
      id:              r.id,
      symbol:          r.symbol,
      sentimentKey:    r.sentiment_key   ?? null,
      oiAtSeed:        r.oi_at_seed      != null ? Number(r.oi_at_seed)      : null,
      priceAtSeed:     r.price_at_seed   != null ? Number(r.price_at_seed)   : null,
      seededAt:        r.seeded_at,
      expiresAt:       r.expires_at,
      status:          r.status,
      oiGrowthPct:     r.oi_growth_pct   != null ? Number(r.oi_growth_pct)   : null,
      lastCheckedAt:   r.last_checked_at ?? null,
      daysSinceSeeded: r.days_since_seeded != null ? Number(r.days_since_seeded) : 0,
    }));

    res.json({ seeds, total: seeds.length });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch whale seeds");
    res.status(500).json({ error: "Failed to fetch whale seeds" });
  }
});

// GET /api/tracker/whale-watch-spot-stats — spot signal performance stats
router.get("/tracker/whale-watch-spot-stats", async (req, res) => {
  try {
    const rows = await db.execute(sql`
      SELECT
        id, symbol,
        detected_at, fired_at,
        price_at_detection,
        ROUND(price_24h_pct::numeric, 2)   AS price_24h_pct,
        ROUND(price_48h_pct::numeric, 2)   AS price_48h_pct,
        ROUND(price_7d_max_pct::numeric, 2) AS price_7d_max_pct
      FROM whale_futures_watchlist
      WHERE type = 'spot' AND status = 'fired'
      ORDER BY fired_at DESC
      LIMIT 100
    `);

    const signals = (rows.rows as Record<string, unknown>[]).map(r => ({
      id:               r.id,
      symbol:           r.symbol as string,
      detectedAt:       r.detected_at,
      firedAt:          r.fired_at,
      priceAtDetection: r.price_at_detection != null ? Number(r.price_at_detection) : null,
      price24hPct:      r.price_24h_pct      != null ? Number(r.price_24h_pct)      : null,
      price48hPct:      r.price_48h_pct      != null ? Number(r.price_48h_pct)      : null,
      price7dMaxPct:    r.price_7d_max_pct   != null ? Number(r.price_7d_max_pct)   : null,
    }));

    // Aggregate stats (only from signals with at least 24h data)
    const withData = signals.filter(s => s.price24hPct != null);
    const total = signals.length;
    const withStats = withData.length;
    const WIN_THRESHOLD = 5; // 5% = win
    const wins24h = withData.filter(s => (s.price24hPct ?? 0) >= WIN_THRESHOLD).length;
    const wins48h = withData.filter(s => (s.price48hPct ?? 0) >= WIN_THRESHOLD).length;
    const wins7d  = withData.filter(s => (s.price7dMaxPct ?? 0) >= WIN_THRESHOLD).length;

    const avg = (arr: number[]) => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null;
    const avg24h    = avg(withData.map(s => s.price24hPct!));
    const avg48h    = avg(withData.filter(s => s.price48hPct != null).map(s => s.price48hPct!));
    const avg7dMax  = avg(withData.filter(s => s.price7dMaxPct != null).map(s => s.price7dMaxPct!));

    res.json({
      total,
      withStats,
      winRate24h:  withStats > 0 ? Math.round((wins24h / withStats) * 100) : null,
      winRate48h:  withStats > 0 ? Math.round((wins48h / withStats) * 100) : null,
      winRate7d:   withStats > 0 ? Math.round((wins7d  / withStats) * 100) : null,
      avg24hPct:   avg24h   != null ? Number(avg24h.toFixed(2))   : null,
      avg48hPct:   avg48h   != null ? Number(avg48h.toFixed(2))   : null,
      avg7dMaxPct: avg7dMax != null ? Number(avg7dMax.toFixed(2)) : null,
      signals,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch whale-watch-spot-stats");
    res.status(500).json({ error: "Failed to fetch whale-watch-spot-stats" });
  }
});

// Немедленно отправляет актуальный список открытых позиций в Telegram.
router.post("/tracker/send-positions", async (req, res) => {
  try {
    const text = await buildPositionsStatusText();
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "send-positions: ошибка");
    res.status(500).json({ error: "Send positions failed" });
  }
});

export default router;
