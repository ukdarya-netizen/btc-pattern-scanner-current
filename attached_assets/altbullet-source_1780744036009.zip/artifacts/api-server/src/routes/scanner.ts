import { Router } from "express";
import {
  getScannerState,
  startScanner,
  stopScanner,
  performScan,
  getScannerCandidates,
} from "../lib/scanner.js";
import { sendDailyReport, sendWeeklyDigest, runAuditReport } from "../lib/watcher.js";
import { getApiConnected } from "../lib/apiHealth.js";

const router = Router();

router.get("/scanner/status", async (req, res) => {
  try {
    const state = await getScannerState();
    res.json({
      running: state.running,
      lastScanAt: state.lastScanAt?.toISOString() ?? null,
      nextScanAt: state.nextScanAt?.toISOString() ?? null,
      totalSignals: state.totalSignals,
      signalsToday: state.signalsToday,
      marketsScanned: state.marketsScanned,
      telegramConnected: state.telegramConnected,
      bingxConnected: state.bingxConnected,
      coinglassConnected:   getApiConnected("coinglass"),
      coinalyzeConnected:   getApiConnected("coinalyze"),
      coinGeckoConnected:   getApiConnected("coingecko"),
      coinPaprikaConnected: getApiConnected("coinpaprika"),
      scanIntervalMs: state.scanIntervalMs,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get scanner status");
    res.status(500).json({ error: "Failed to get scanner status" });
  }
});

router.post("/scanner/start", async (req, res) => {
  try {
    await startScanner();
    res.json({ success: true, message: "Scanner started" });
  } catch (err) {
    req.log.error({ err }, "Failed to start scanner");
    res.status(500).json({ success: false, message: "Failed to start scanner" });
  }
});

router.post("/scanner/stop", async (req, res) => {
  try {
    await stopScanner();
    res.json({ success: true, message: "Scanner stopped" });
  } catch (err) {
    req.log.error({ err }, "Failed to stop scanner");
    res.status(500).json({ success: false, message: "Failed to stop scanner" });
  }
});

router.post("/scanner/scan-now", async (req, res) => {
  try {
    const result = await performScan();
    res.json({
      success: true,
      signalsFound: result.signalsFound,
      marketsScanned: result.marketsScanned,
      durationMs: result.durationMs,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to run scan");
    res.status(500).json({ success: false, signalsFound: 0, marketsScanned: 0, durationMs: 0 });
  }
});

router.get("/scanner/candidates", async (req, res) => {
  try {
    const data = await getScannerCandidates();
    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get scanner candidates");
    res.status(500).json({ error: "Failed to get scanner candidates" });
  }
});

// Ручная отправка отчётов (для восстановления пропущенных)
router.post("/reports/send-daily", async (req, res) => {
  try {
    await sendDailyReport();
    res.json({ success: true, message: "Daily report sent" });
  } catch (err) {
    req.log.error({ err }, "Failed to send daily report");
    res.status(500).json({ success: false, message: "Failed to send daily report" });
  }
});

router.post("/reports/send-weekly", async (req, res) => {
  try {
    await sendWeeklyDigest();
    res.json({ success: true, message: "Weekly digest sent" });
  } catch (err) {
    req.log.error({ err }, "Failed to send weekly digest");
    res.status(500).json({ success: false, message: "Failed to send weekly digest" });
  }
});

router.post("/scanner/audit", async (req, res) => {
  try {
    res.json({ success: true, message: "Audit started — отчёт придёт в канал через ~1-2 мин" });
    // Запускаем после ответа клиенту (не блокируем HTTP)
    runAuditReport().catch((err: unknown) => {
      req.log.error({ err }, "Audit report failed");
    });
  } catch (err) {
    req.log.error({ err }, "Failed to trigger audit");
    res.status(500).json({ success: false, message: "Failed to trigger audit" });
  }
});

export default router;
