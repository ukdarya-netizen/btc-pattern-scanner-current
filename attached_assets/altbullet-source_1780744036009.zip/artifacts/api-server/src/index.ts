import app from "./app";
import { logger } from "./lib/logger";
import { pool, db, settingsTable } from "@workspace/db";
import { setWebhook, registerBotCommands } from "./lib/telegram.js";
import { startScanner, stopScanner, getLastScanAt } from "./lib/scanner.js";
import { startWatcher, startWatchdog, broadcast } from "./lib/watcher.js";
import { lt, sql as drizzleSql } from "drizzle-orm";

async function runStartupMigration() {
  try {
    // Добавляем колонку scanner_last_scan_at если ещё нет (идемпотентно)
    await db.execute(drizzleSql`ALTER TABLE settings ADD COLUMN IF NOT EXISTS scanner_last_scan_at TIMESTAMP`);

    // Обновляем порог OI с 5% → 8% для сокращения отмен по слабым сигналам
    const updated = await db.update(settingsTable)
      .set({ oiChangePercent: 8 })
      .where(lt(settingsTable.oiChangePercent, 8))
      .returning({ oiChangePercent: settingsTable.oiChangePercent });
    if (updated.length > 0) logger.info({ newThreshold: 8 }, "Startup migration: oiChangePercent обновлён до 8%");
  } catch (err) {
    logger.warn({ err }, "Startup migration: ошибка (non-critical)");
  }
}


// ── pg Pool error handler ──────────────────────────────────────────────────────
// Neon serverless периодически рвёт idle-соединения. Без обработчика 'error'
// Node.js бросает uncaughtException и процесс может упасть.
// Pool автоматически создаёт новое соединение при следующем запросе.
pool.on("error", (err) => {
  logger.warn({ err: String(err) }, "pg pool: idle client error (Neon closed connection) — pool will reconnect automatically");
});

// ── Глобальная защита от падения процесса ─────────────────────────────────────
// Без этого Node.js завершает процесс при любом необработанном промисе/исключении.
process.on("unhandledRejection", (reason, promise) => {
  logger.error({ reason, promise: String(promise) }, "⚠️ Unhandled promise rejection — caught, server stays alive");
});

process.on("uncaughtException", (err) => {
  logger.error({ err }, "⚠️ Uncaught exception — caught, server stays alive");
});

// ── Graceful shutdown при деплое (SIGTERM от Replit) ──────────────────────────
// Останавливаем планировщик сканера, даём текущим операциям завершиться (10 сек),
// затем выходим чисто — без обрыва на середине скана или отправки Telegram.
let isShuttingDown = false;
async function gracefulShutdown(signal: string) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  logger.info({ signal }, "Graceful shutdown: получен сигнал, останавливаем сканер...");
  try {
    await stopScanner();
  } catch { /* non-critical */ }
  // Ждём 5 секунд чтобы текущие DB/Telegram операции завершились
  await new Promise(resolve => setTimeout(resolve, 5_000));
  logger.info("Graceful shutdown: завершено, выходим");
  process.exit(0);
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT",  () => gracefulShutdown("SIGINT"));

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Webhook регистрируем ТОЛЬКО в production.
  // В dev-режиме dev-домен (.replit.dev) умирает при idle и перебивает
  // продакшн-webhook, из-за чего бот теряет все апдейты от Telegram.
  const domains = process.env.REPLIT_DOMAINS;
  if (domains && process.env.NODE_ENV !== "development") {
    const domain = domains.split(",")[0].trim();
    const webhookUrl = `https://${domain}/api/telegram/webhook`;
    const ok = await setWebhook(webhookUrl);
    if (ok) {
      logger.info({ webhookUrl }, "Telegram webhook registered");
    } else {
      logger.warn("Failed to register Telegram webhook — bot subscriptions may not work");
    }
    await registerBotCommands();
  } else if (process.env.NODE_ENV === "development") {
    logger.info("DEV mode — webhook registration skipped (production webhook preserved)");
  } else {
    logger.info("REPLIT_DOMAINS not set, skipping webhook registration");
  }

  // One-time migration: перенос позиций из dev в prod (30.05.2026)
  if (process.env.NODE_ENV !== "development") {
    runStartupMigration().catch(() => {/* logged inside */});
  }

  // В dev-режиме сканер и watcher НЕ запускаются — только production.
  // Причина: dev-инстанс подключён к тем же BingX API ключам и той же сети,
  // что и prod. Если оба экземпляра сканируют одновременно, они детектируют
  // сигналы в разное время и пишут в разные БД (dev vs prod).
  // Результат: дашборд (dev) и Telegram (prod) показывают разные позиции.
  // В dev нужно только разрабатывать код — реальный трейдинг идёт через prod.
  if (process.env.NODE_ENV === "development") {
    logger.info("DEV mode — scanner NOT started; watcher started (Telegram suppressed)");
    // Watcher runs in dev to keep signal statuses accurate (stop_loss / profit / cancelled).
    // All Telegram sends are suppressed via sendMessage() guard in telegram.ts.
    startWatcher();
  } else {
    // Auto-start scanner on server boot
    startScanner().catch(err => logger.error({ err }, "Failed to auto-start scanner"));

    // Auto-start alpha watcher
    startWatcher();

    // Auto-start watchdog — alerts if stale, auto-restarts scanner after 2+ critical cycles
    const restartScanner = async () => {
      await stopScanner();
      await startScanner();
    };
    startWatchdog(getLastScanAt, restartScanner);
  }

  // Startup notification отправляется из sendBotRestartNotification() через 3 мин —
  // с контекстом открытых сигналов и DB-дедупликацией. Дублировать здесь не нужно.
});
