import { Link, useLocation } from "wouter";
import { Activity, Settings, Terminal, Users, Target, ScanSearch, Waves } from "lucide-react";
import { cn } from "@/lib/utils";
import { useGetScannerStatus, getGetScannerStatusQueryKey } from "@workspace/api-client-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: apiStatus } = useGetScannerStatus({ query: { queryKey: getGetScannerStatusQueryKey(), refetchInterval: 30_000 } });

  const navItems = [
    {
      href: "/tracker",
      label: "Открытые позиции",
      sub: "мониторинг ТП / стопов",
      icon: Target,
    },
    {
      href: "/",
      label: "Обзор",
      sub: "общая статистика",
      icon: Activity,
    },
    {
      href: "/candidates",
      label: "Сканер",
      sub: "кандидаты текущего цикла",
      icon: ScanSearch,
    },
    {
      href: "/whale-watch",
      label: "Накопление китов",
      sub: "долгосрочный OI-рост",
      icon: Waves,
    },
    {
      href: "/subscribers",
      label: "Подписчики",
      sub: "кто получает алерты",
      icon: Users,
    },
    {
      href: "/settings",
      label: "Настройки",
      sub: "пороги и конфиги",
      icon: Settings,
    },
  ];

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Terminal className="w-5 h-5 text-primary mr-3" />
          <span className="font-bold text-lg tracking-wider text-primary">ALT<span className="text-foreground">BULLET</span></span>
        </div>
        
        <nav className="flex-1 py-4 px-3 space-y-0.5">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link key={item.href} href={item.href} className="block">
                <div
                  className={cn(
                    "flex items-start px-3 py-2.5 text-sm font-medium transition-colors border border-transparent",
                    isActive 
                      ? "bg-primary/10 text-primary border-primary/20" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  <Icon className="w-4 h-4 mr-3 mt-0.5 shrink-0" />
                  <div className="flex flex-col">
                    <span>{item.label}</span>
                    <span className={cn(
                      "text-xs font-normal",
                      isActive ? "text-primary/60" : "text-muted-foreground/60"
                    )}>{item.sub}</span>
                  </div>
                </div>
              </Link>
            );
          })}
        </nav>
        
        <div className="p-4 border-t border-border text-xs text-muted-foreground space-y-1.5">
          {(() => {
            const scannerRunning = apiStatus?.running;
            return ([
              { label: "BingX",       ok: scannerRunning == null ? undefined : scannerRunning ? apiStatus?.bingxConnected : null },
              { label: "Telegram",    ok: scannerRunning == null ? undefined : scannerRunning ? apiStatus?.telegramConnected : null },
              { label: "CoinGlass",   ok: apiStatus?.coinglassConnected },
              { label: "Coinalyze",   ok: apiStatus?.coinalyzeConnected },
              { label: "CoinGecko",   ok: apiStatus?.coinGeckoConnected },
              { label: "CoinPaprika", ok: apiStatus?.coinPaprikaConnected },
            ] as { label: string; ok: boolean | null | undefined }[]).map(({ label, ok }) => (
              <div key={label} className="flex items-center justify-between">
                <span>{label}</span>
                <span className="flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${ok == null ? "bg-zinc-600" : ok ? "bg-green-500" : "bg-red-500"}`} />
                  <span className={ok == null ? "text-zinc-500" : ok ? "text-green-400" : "text-red-400"}>
                    {ok == null ? (ok === undefined ? "..." : "—") : ok ? "OK" : "ERR"}
                  </span>
                </span>
              </div>
            ));
          })()}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="h-16 flex items-center justify-between px-8 border-b border-border bg-card/50">
          <h1 className="text-xl font-semibold capitalize">
            {navItems.find(item => item.href === location)?.label || "Terminal"}
          </h1>
          <div className="text-xs text-muted-foreground flex items-center space-x-4">
            <span>SYS_TIME: {new Date().toISOString().split('T')[1].split('.')[0]} UTC</span>
          </div>
        </header>
        
        <div className="flex-1 overflow-auto p-8 bg-background">
          {children}
        </div>
      </main>
    </div>
  );
}
