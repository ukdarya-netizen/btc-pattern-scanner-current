import { Badge } from "@/components/ui/badge";

const SENTIMENT_CONFIG: Record<string, { label: string; className: string }> = {
  hidden_accumulation: {
    label: "Скрытое накопление",
    className: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  },
  aggressive_breakout: {
    label: "Агрессивный пробой",
    className: "bg-orange-500/15 text-orange-300 border-orange-500/30",
  },
  short_squeeze: {
    label: "Short Squeeze",
    className: "bg-red-500/15 text-red-300 border-red-500/30",
  },
  distribution: {
    label: "Дистрибуция",
    className: "bg-yellow-500/15 text-yellow-300 border-yellow-500/30",
  },
  bullish_accumulation: {
    label: "Бычье накопление",
    className: "bg-green-500/15 text-green-300 border-green-500/30",
  },
  bearish_pressure: {
    label: "Медвежье давление",
    className: "bg-red-500/10 text-red-400 border-red-500/20",
  },
  listing_reversal: {
    label: "🆕 Листинг-Разворот",
    className: "bg-red-600/20 text-red-300 border-red-600/40",
  },
  anomaly: {
    label: "Аномалия",
    className: "bg-muted/30 text-muted-foreground border-border",
  },
};

export function SentimentBadge({
  sentimentKey,
  label,
}: {
  sentimentKey: string;
  label?: string;
}) {
  const config = SENTIMENT_CONFIG[sentimentKey] ?? SENTIMENT_CONFIG.anomaly;
  return (
    <Badge
      variant="outline"
      className={`font-mono rounded-none text-xs whitespace-nowrap ${config.className}`}
    >
      {label ?? config.label}
    </Badge>
  );
}
