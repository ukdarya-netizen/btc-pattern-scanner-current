import { useGetSubscribers, useGetSubscriberStats, getGetSubscribersQueryKey, getGetSubscriberStatsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, UserCheck, UserX, TrendingUp } from "lucide-react";

export default function Subscribers() {
  const { data, isLoading } = useGetSubscribers({ query: { queryKey: getGetSubscribersQueryKey(), refetchInterval: 30000 } });
  const { data: stats } = useGetSubscriberStats({ query: { queryKey: getGetSubscriberStatsQueryKey(), refetchInterval: 30000 } });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wider">TELEGRAM SUBSCRIBERS</h2>
        <p className="text-xs text-muted-foreground">People who sent /start to your bot</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">TOTAL</p>
                <p className="text-3xl font-bold mt-2">{stats?.total ?? 0}</p>
              </div>
              <div className="p-2 bg-muted text-primary"><Users className="w-5 h-5" /></div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">ACTIVE</p>
                <p className="text-3xl font-bold mt-2 text-green-500">{stats?.active ?? 0}</p>
              </div>
              <div className="p-2 bg-muted text-green-500"><UserCheck className="w-5 h-5" /></div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">NEW TODAY</p>
                <p className="text-3xl font-bold mt-2 text-violet-400">{stats?.newToday ?? 0}</p>
              </div>
              <div className="p-2 bg-muted text-violet-400"><TrendingUp className="w-5 h-5" /></div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">UNSUBSCRIBED</p>
                <p className="text-3xl font-bold mt-2 text-muted-foreground">{stats?.inactive ?? 0}</p>
              </div>
              <div className="p-2 bg-muted text-muted-foreground"><UserX className="w-5 h-5" /></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-4">
          <CardTitle className="text-lg font-medium">SUBSCRIBER LIST</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground">LOADING...</div>
          ) : data?.subscribers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-muted-foreground space-y-2">
              <Users className="w-8 h-8 opacity-30" />
              <p className="text-sm">No subscribers yet.</p>
              <p className="text-xs">Share your bot link so people can subscribe.</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-card border-b border-border">
                <tr className="text-muted-foreground text-left">
                  <th className="px-4 py-3 font-medium">CHAT ID</th>
                  <th className="px-4 py-3 font-medium">USERNAME</th>
                  <th className="px-4 py-3 font-medium">NAME</th>
                  <th className="px-4 py-3 font-medium">STATUS</th>
                  <th className="px-4 py-3 font-medium">SUBSCRIBED</th>
                </tr>
              </thead>
              <tbody>
                {data?.subscribers.map((sub) => (
                  <tr key={sub.chatId} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3 font-mono text-muted-foreground">{sub.chatId}</td>
                    <td className="px-4 py-3 font-medium">
                      {sub.username ? `@${sub.username}` : <span className="text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3">
                      {[sub.firstName, sub.lastName].filter(Boolean).join(" ") || <span className="text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3">
                      {sub.active ? (
                        <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20 font-mono rounded-none text-xs">ACTIVE</Badge>
                      ) : (
                        <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20 font-mono rounded-none text-xs">STOPPED</Badge>
                      )}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">
                      {new Date(sub.subscribedAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
