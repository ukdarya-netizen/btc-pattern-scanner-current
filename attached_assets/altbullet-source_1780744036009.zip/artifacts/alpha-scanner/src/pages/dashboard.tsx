import React, { useState } from "react";
import {
  useGetScannerStatus, useGetSignalsSummary,
  useStartScanner, useStopScanner, useScanNow,
  useGetSubscriberStats, useGetTrackerJournal, useGetTrackerMonthlyStats,
  getGetScannerStatusQueryKey, getGetSignalsSummaryQueryKey, getGetSubscriberStatsQueryKey,
  getGetTrackerJournalQueryKey, getGetTrackerMonthlyStatsQueryKey,
  type JournalPatternRow, type JournalTokenRow, type JournalTrade, type MonthlyStatRow,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Square, Zap, Activity, BarChart3, Users, TrendingUp, TrendingDown, Trophy, AlertTriangle, Calendar, BookOpen, Archive } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

// ─── constants ────────────────────────────────────────────────────────────────

const CURRENT_PERIOD_FROM = "2026-06-01";

const PATTERN_LABELS: Record<string, string> = {
  hidden_accumulation: "Hidden Accum",
  bullish_accumulation: "Bull Accum",
  aggressive_breakout: "Aggr Break",
  short_squeeze: "Short Squeeze",
  bear_trap: "Bear Trap",
  bearish_pressure: "Bear Pressure",
  anomaly: "Anomaly",
  impulse_breakout: "Impulse Break",
  sharp_impulse: "Sharp Impulse",
  whale_futures: "Whale Futures",
  volume_breakout: "Vol Breakout",
  distribution: "Distribution",
  whale_watch: "Whale Watch",
  mexc_pump: "MEXC Pump",
  unknown: "Unknown",
};

// ─── helpers ──────────────────────────────────────────────────────────────────

function patLabel(key: string | null | undefined) {
  return PATTERN_LABELS[key ?? "unknown"] ?? key ?? "—";
}

function fmtPnl(v: number | null | undefined, decimals = 1) {
  if (v == null) return "—";
  return `${v >= 0 ? "+" : ""}${v.toFixed(decimals)}%`;
}

function fmtPx(v: number | null | undefined) {
  if (v == null) return "—";
  return `$${v < 1 ? v.toFixed(5) : v.toFixed(4)}`;
}

function fmtDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "short" }) +
    " " + d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
}

function StatusBadge({ status }: { status: string }) {
  if (status === "profit")    return <span className="text-green-400 font-bold text-[10px]">✅ PROFIT</span>;
  if (status === "stop_loss") return <span className="text-red-400  font-bold text-[10px]">❌ STOP</span>;
  if (status === "cancelled") return <span className="text-zinc-400 font-bold text-[10px]">🚫 CANCEL</span>;
  if (status === "breakeven") return <span className="text-yellow-400 font-bold text-[10px]">↔ BEVEN</span>;
  return <span className="text-blue-400 font-bold text-[10px]">{status.toUpperCase()}</span>;
}

function WinRateBar({ winRate, profit, stopLoss }: { winRate: number | null; profit: number; stopLoss: number }) {
  const total = profit + stopLoss;
  if (!total) return null;
  const pct = winRate ?? 0;
  return (
    <div className="mt-1 w-full h-1.5 bg-red-900/40 rounded-none overflow-hidden">
      <div className="h-full bg-green-500 transition-all" style={{ width: `${pct}%` }} />
    </div>
  );
}

// ─── tab nav ──────────────────────────────────────────────────────────────────

type Tab = "overview" | "stats" | "archive" | "journal";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "overview", label: "Обзор",              icon: Activity   },
  { id: "journal",  label: "Дневник трейдера",   icon: BookOpen   },
  { id: "archive",  label: "Архив статистики",   icon: Archive    },
];

function TabNav({ active, onChange }: { active: Tab; onChange: (t: Tab) => void }) {
  return (
    <div className="flex border-b border-border gap-0">
      {TABS.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium tracking-wider transition-colors
            ${active === id
              ? "border-b-2 border-primary text-primary -mb-px"
              : "text-muted-foreground hover:text-foreground"
            }`}
        >
          <Icon className="w-3.5 h-3.5" />
          {label.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

// ─── main component ───────────────────────────────────────────────────────────

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<Tab>("overview");

  const { data: status }       = useGetScannerStatus({ query: { queryKey: getGetScannerStatusQueryKey(), refetchInterval: 5000 } });
  const { data: summary }      = useGetSignalsSummary({ query: { queryKey: getGetSignalsSummaryQueryKey(), refetchInterval: 10000 } });
  const { data: subStats }     = useGetSubscriberStats({ query: { queryKey: getGetSubscriberStatsQueryKey(), refetchInterval: 30000 } });
  const { data: journalAll }   = useGetTrackerJournal(undefined, { query: { queryKey: getGetTrackerJournalQueryKey(), refetchInterval: 30000 } });
  const { data: journalCur }   = useGetTrackerJournal(
    { from: CURRENT_PERIOD_FROM },
    { query: { queryKey: getGetTrackerJournalQueryKey({ from: CURRENT_PERIOD_FROM }), refetchInterval: 30000 } }
  );
  const { data: monthlyStats } = useGetTrackerMonthlyStats({ query: { queryKey: getGetTrackerMonthlyStatsQueryKey(), refetchInterval: 60000 } });

  const startScanner = useStartScanner();
  const stopScanner  = useStopScanner();
  const scanNow      = useScanNow();

  return (
    <div className="space-y-4">
      <TabNav active={tab} onChange={setTab} />

      {/* ── Tab: Обзор + Общая статистика ── */}
      {tab === "overview" && (
        <div className="space-y-6">
          {/* Scanner controls */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-card border border-border px-4 py-2">
                <span className="text-sm font-medium text-muted-foreground">STATUS:</span>
                {status?.running ? (
                  <span className="flex items-center text-green-500 font-bold text-sm">
                    <span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse" />RUNNING
                  </span>
                ) : (
                  <span className="flex items-center text-red-500 font-bold text-sm">
                    <span className="w-2 h-2 rounded-full bg-red-500 mr-2" />STOPPED
                  </span>
                )}
              </div>
              <div className="flex space-x-2">
                {status?.running ? (
                  <Button variant="destructive" size="sm" onClick={() => stopScanner.mutate(undefined, { onSuccess: () => queryClient.invalidateQueries() })} disabled={stopScanner.isPending} className="border border-destructive">
                    <Square className="w-4 h-4 mr-2" /> STOP
                  </Button>
                ) : (
                  <Button variant="default" size="sm" onClick={() => startScanner.mutate(undefined, { onSuccess: () => queryClient.invalidateQueries() })} disabled={startScanner.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                    <Play className="w-4 h-4 mr-2" /> START
                  </Button>
                )}
                <Button variant="outline" size="sm" onClick={() => scanNow.mutate(undefined, { onSuccess: () => queryClient.invalidateQueries() })} disabled={scanNow.isPending || !status?.running}>
                  <Zap className="w-4 h-4 mr-2" /> FORCE SCAN
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-x-5 gap-y-1 text-sm">
              {(() => {
                const running = status?.running;
                return ([
                  { label: "BINGX",       ok: running == null ? undefined : running ? status?.bingxConnected : null },
                  { label: "TELEGRAM",    ok: running == null ? undefined : running ? status?.telegramConnected : null },
                  { label: "COINGLASS",   ok: status?.coinglassConnected },
                  { label: "COINALYZE",   ok: status?.coinalyzeConnected },
                  { label: "COINGECKO",   ok: status?.coinGeckoConnected },
                  { label: "COINPAPRIKA", ok: status?.coinPaprikaConnected },
                ] as { label: string; ok: boolean | null | undefined }[]).map(({ label, ok }) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <span className="text-muted-foreground">{label}:</span>
                    <span className={`flex items-center gap-1 ${ok == null ? "text-zinc-500" : ok ? "text-green-500" : "text-red-500"}`}>
                      <span className={`w-1.5 h-1.5 rounded-full inline-block ${ok == null ? "bg-zinc-600" : ok ? "bg-green-500" : "bg-red-500"}`} />
                      {ok == null ? (ok === undefined ? "..." : "—") : ok ? "OK" : "ERR"}
                    </span>
                  </div>
                ));
              })()}
            </div>
          </div>

          {/* Signal counters */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard title="СИГНАЛОВ СЕГОДНЯ"    value={summary?.signalsToday ?? 0}     icon={Zap}       color="text-blue-300" />
            <StatCard title="ВСЕГО СИГНАЛОВ"      value={summary?.totalSignals ?? 0}      icon={BarChart3} color="text-blue-500" />
            <StatCard title="РЫНКОВ СКАНИРУЕТСЯ"  value={status?.marketsScanned || 0}     icon={Activity}  color="text-green-500" />
            <StatCard title="ПОДПИСЧИКОВ"         value={subStats?.active || 0}           icon={Users}     color="text-violet-400"
              subtitle={subStats ? `+${subStats.newToday} сегодня` : undefined} />
          </div>

          {/* Current period stats */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t border-border">
            <Calendar className="w-3.5 h-3.5" />
            <span>Общая статистика с <span className="text-foreground font-medium">1 июня 2026</span></span>
          </div>

          {journalCur && journalCur.summary.total === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              Нет завершённых сделок с 1 июня 2026 — статистика появится по мере торговли
            </div>
          ) : journalCur && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <PerfCard
                  title="WIN RATE"
                  value={journalCur.summary.winRate != null ? `${journalCur.summary.winRate}%` : "—"}
                  sub={`${journalCur.summary.profit}✅ / ${journalCur.summary.stopLoss}❌ закрыто`}
                  icon={Trophy}
                  color={journalCur.summary.winRate != null && journalCur.summary.winRate >= 30 ? "text-green-400" : "text-yellow-400"}
                  bar={<WinRateBar winRate={journalCur.summary.winRate} profit={journalCur.summary.profit} stopLoss={journalCur.summary.stopLoss} />}
                />
                <PerfCard
                  title="AVG PROFIT"
                  value={fmtPnl(journalCur.summary.avgProfit)}
                  sub={`${journalCur.summary.profit} сделок`}
                  icon={TrendingUp}
                  color="text-green-400"
                />
                <PerfCard
                  title="AVG LOSS"
                  value={fmtPnl(journalCur.summary.avgLoss)}
                  sub={`${journalCur.summary.stopLoss} стопов`}
                  icon={TrendingDown}
                  color="text-red-400"
                />
                <PerfCard
                  title="ЛУЧШАЯ СДЕЛКА"
                  value={fmtPnl(journalCur.summary.bestTrade?.pnl)}
                  sub={journalCur.summary.bestTrade ? `${journalCur.summary.bestTrade.symbol} · ${patLabel(journalCur.summary.bestTrade.sentimentKey)}` : "—"}
                  icon={Trophy}
                  color="text-emerald-400"
                />
                <PerfCard
                  title="АКТИВНЫХ"
                  value={String(journalCur.summary.active)}
                  sub={`${journalCur.summary.cancelled} отменено`}
                  icon={AlertTriangle}
                  color="text-orange-400"
                />
              </div>

              {journalCur.byPattern.length > 0 && (
                <Card className="border-border bg-card">
                  <CardHeader className="border-b border-border py-3">
                    <CardTitle className="text-sm font-medium tracking-wider text-muted-foreground">РЕЗУЛЬТАТЫ ПО ПАТТЕРНАМ — ИЮНЬ 2026</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-border text-muted-foreground text-left">
                            <th className="px-4 py-2 font-medium">ПАТТЕРН</th>
                            <th className="px-3 py-2 font-medium text-center">ВСЕГО</th>
                            <th className="px-3 py-2 font-medium text-center text-green-500">PROFIT</th>
                            <th className="px-3 py-2 font-medium text-center text-red-500">STOP</th>
                            <th className="px-3 py-2 font-medium text-center text-zinc-400">CANCEL</th>
                            <th className="px-3 py-2 font-medium text-right">WIN%</th>
                            <th className="px-3 py-2 font-medium text-right">AVG PnL</th>
                            <th className="px-3 py-2 font-medium text-right">AVG PEAK</th>
                          </tr>
                        </thead>
                        <tbody>
                          {journalCur.byPattern.map((row: JournalPatternRow) => {
                            const wr = row.winRate ?? 0;
                            const wrColor = wr >= 40 ? "text-green-400" : wr >= 20 ? "text-yellow-400" : "text-red-400";
                            return (
                              <tr key={row.sentimentKey} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                                <td className="px-4 py-2 font-medium text-foreground">{patLabel(row.sentimentKey)}</td>
                                <td className="px-3 py-2 text-center text-muted-foreground">{row.total}</td>
                                <td className="px-3 py-2 text-center text-green-400 font-mono">{row.profit}</td>
                                <td className="px-3 py-2 text-center text-red-400 font-mono">{row.stopLoss}</td>
                                <td className="px-3 py-2 text-center text-zinc-500 font-mono">{row.cancelled}</td>
                                <td className={`px-3 py-2 text-right font-bold font-mono ${wrColor}`}>
                                  {row.winRate != null ? `${row.winRate}%` : "—"}
                                </td>
                                <td className={`px-3 py-2 text-right font-mono ${row.avgPnl != null && row.avgPnl >= 0 ? "text-green-400" : "text-red-400"}`}>
                                  {fmtPnl(row.avgPnl)}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-blue-300">
                                  {fmtPnl(row.avgPeak)}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {(journalCur.byToken ?? []).length > 0 && (
                <Card className="border-border bg-card">
                  <CardHeader className="border-b border-border py-3">
                    <CardTitle className="text-sm font-medium tracking-wider text-muted-foreground">РЕЗУЛЬТАТЫ ПО ТОКЕНАМ</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-border text-muted-foreground text-left">
                            <th className="px-4 py-2 font-medium">ТОКЕН</th>
                            <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
                            <th className="px-3 py-2 font-medium text-center">ВСЕГО</th>
                            <th className="px-3 py-2 font-medium text-center text-green-500">PROFIT</th>
                            <th className="px-3 py-2 font-medium text-center text-red-500">STOP</th>
                            <th className="px-3 py-2 font-medium text-center text-zinc-400">CANCEL</th>
                            <th className="px-3 py-2 font-medium text-right">WIN%</th>
                            <th className="px-3 py-2 font-medium text-right">AVG PnL</th>
                            <th className="px-3 py-2 font-medium text-right">BEST</th>
                            <th className="px-3 py-2 font-medium text-right">AVG PEAK</th>
                          </tr>
                        </thead>
                        <tbody>
                          {journalCur.byToken.map((row: JournalTokenRow) => {
                            const wr = row.winRate ?? 0;
                            const wrColor = wr >= 40 ? "text-green-400" : wr >= 20 ? "text-yellow-400" : "text-red-400";
                            return (
                              <tr key={row.symbol} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                                <td className="px-4 py-2 font-bold font-mono text-foreground">{row.symbol.replace("-USDT", "")}</td>
                                <td className="px-3 py-2 text-muted-foreground">{patLabel(row.mainPattern)}</td>
                                <td className="px-3 py-2 text-center text-muted-foreground">{row.total}</td>
                                <td className="px-3 py-2 text-center text-green-400 font-mono">{row.profit}</td>
                                <td className="px-3 py-2 text-center text-red-400 font-mono">{row.stopLoss}</td>
                                <td className="px-3 py-2 text-center text-zinc-500 font-mono">{row.cancelled}</td>
                                <td className={`px-3 py-2 text-right font-bold font-mono ${wrColor}`}>
                                  {row.winRate != null ? `${row.winRate}%` : "—"}
                                </td>
                                <td className={`px-3 py-2 text-right font-mono ${row.avgPnl != null && row.avgPnl >= 0 ? "text-green-400" : "text-red-400"}`}>
                                  {fmtPnl(row.avgPnl)}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-emerald-400 font-semibold">
                                  {fmtPnl(row.bestPnl)}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-blue-300">
                                  {fmtPnl(row.avgPeak)}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      )}

      {/* ── Tab: Архив статистики ── */}
      {tab === "archive" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Archive className="w-3.5 h-3.5" />
            <span>Исторические данные по месяцам — включая тестовый период (Май 2025 и ранее)</span>
          </div>

          {!monthlyStats ? (
            <div className="text-center py-12 text-muted-foreground text-sm">Загрузка...</div>
          ) : monthlyStats.months.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground text-sm">Нет архивных данных</div>
          ) : (
            <Card className="border-border bg-card">
              <CardHeader className="border-b border-border py-3">
                <CardTitle className="text-sm font-medium tracking-wider text-muted-foreground">СТАТИСТИКА ПО МЕСЯЦАМ</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground text-left">
                        <th className="px-4 py-2 font-medium">МЕСЯЦ</th>
                        <th className="px-3 py-2 font-medium text-center">ВСЕГО</th>
                        <th className="px-3 py-2 font-medium text-center text-green-500">PROFIT</th>
                        <th className="px-3 py-2 font-medium text-center text-red-500">STOP</th>
                        <th className="px-3 py-2 font-medium text-center text-zinc-400">CANCEL</th>
                        <th className="px-3 py-2 font-medium text-right">WIN%</th>
                        <th className="px-3 py-2 font-medium text-right">AVG PROFIT</th>
                        <th className="px-3 py-2 font-medium text-right">AVG LOSS</th>
                        <th className="px-3 py-2 font-medium text-right">ЛУЧШАЯ</th>
                        <th className="px-3 py-2 font-medium text-right">ХУДШАЯ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {monthlyStats.months.map((row: MonthlyStatRow) => {
                        const wr = row.winRate ?? 0;
                        const wrColor = wr >= 40 ? "text-green-400" : wr >= 20 ? "text-yellow-400" : "text-red-400";
                        const isCurrent = row.month >= CURRENT_PERIOD_FROM.slice(0, 7);
                        return (
                          <tr key={row.month} className={`border-b border-border/40 hover:bg-muted/30 transition-colors ${isCurrent ? "bg-blue-950/20" : ""}`}>
                            <td className="px-4 py-2 font-medium text-foreground whitespace-nowrap">
                              {isCurrent && <span className="text-blue-400 text-[10px] mr-1.5">▶</span>}
                              {row.label}
                            </td>
                            <td className="px-3 py-2 text-center text-muted-foreground">{row.total}</td>
                            <td className="px-3 py-2 text-center text-green-400 font-mono">{row.profit}</td>
                            <td className="px-3 py-2 text-center text-red-400 font-mono">{row.stopLoss}</td>
                            <td className="px-3 py-2 text-center text-zinc-500 font-mono">{row.cancelled}</td>
                            <td className={`px-3 py-2 text-right font-bold font-mono ${wrColor}`}>
                              {row.winRate != null ? `${row.winRate}%` : "—"}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-green-400">
                              {fmtPnl(row.avgProfit)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-red-400">
                              {fmtPnl(row.avgLoss)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-emerald-400">
                              {fmtPnl(row.bestPnl)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-red-300">
                              {fmtPnl(row.worstPnl)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* ── Tab: Дневник трейдера ── */}
      {tab === "journal" && (
        <div className="space-y-6">
          {journalAll && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <PerfCard
                title="WIN RATE (ALL)"
                value={journalAll.summary.winRate != null ? `${journalAll.summary.winRate}%` : "—"}
                sub={`${journalAll.summary.profit}✅ / ${journalAll.summary.stopLoss}❌ за всё время`}
                icon={Trophy}
                color={journalAll.summary.winRate != null && journalAll.summary.winRate >= 30 ? "text-green-400" : "text-yellow-400"}
                bar={<WinRateBar winRate={journalAll.summary.winRate} profit={journalAll.summary.profit} stopLoss={journalAll.summary.stopLoss} />}
              />
              <PerfCard
                title="AVG PROFIT"
                value={fmtPnl(journalAll.summary.avgProfit)}
                sub={`${journalAll.summary.profit} сделок`}
                icon={TrendingUp}
                color="text-green-400"
              />
              <PerfCard
                title="AVG LOSS"
                value={fmtPnl(journalAll.summary.avgLoss)}
                sub={`${journalAll.summary.stopLoss} стопов`}
                icon={TrendingDown}
                color="text-red-400"
              />
              <PerfCard
                title="ЛУЧШАЯ СДЕЛКА"
                value={fmtPnl(journalAll.summary.bestTrade?.pnl)}
                sub={journalAll.summary.bestTrade ? `${journalAll.summary.bestTrade.symbol} · ${patLabel(journalAll.summary.bestTrade.sentimentKey)}` : "—"}
                icon={Trophy}
                color="text-emerald-400"
              />
              <PerfCard
                title="АКТИВНЫХ"
                value={String(journalAll.summary.active)}
                sub={`${journalAll.summary.cancelled} отменено`}
                icon={AlertTriangle}
                color="text-orange-400"
              />
            </div>
          )}

          <Card className="border-border bg-card">
            <CardHeader className="border-b border-border py-3">
              <CardTitle className="text-sm font-medium tracking-wider flex items-center justify-between">
                <span className="text-muted-foreground">ЖУРНАЛ СДЕЛОК</span>
                <span className="text-xs text-muted-foreground font-normal">последние 50 закрытых</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground text-left">
                      <th className="px-3 py-2 font-medium">ДАТА</th>
                      <th className="px-3 py-2 font-medium">СИМВОЛ</th>
                      <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
                      <th className="px-3 py-2 font-medium text-right">ВХОД</th>
                      <th className="px-3 py-2 font-medium text-right">PnL</th>
                      <th className="px-3 py-2 font-medium text-right">ПИКОВЫЙ</th>
                      <th className="px-3 py-2 font-medium text-right">ДЕРЖАЛИ</th>
                      <th className="px-3 py-2 font-medium text-right">OI%</th>
                      <th className="px-3 py-2 font-medium text-right">VM</th>
                      <th className="px-3 py-2 font-medium text-right">24h</th>
                      <th className="px-3 py-2 font-medium text-center">ИТОГ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {!journalAll ? (
                      <tr><td colSpan={11} className="px-4 py-8 text-center text-muted-foreground">Загрузка...</td></tr>
                    ) : journalAll.trades.length === 0 ? (
                      <tr><td colSpan={11} className="px-4 py-8 text-center text-muted-foreground">Нет закрытых сделок.</td></tr>
                    ) : journalAll.trades.map((t: JournalTrade) => {
                      const isProfit    = t.status === "profit";
                      const isStop      = t.status === "stop_loss";
                      const isCancelled = t.status === "cancelled";
                      const rowCls = isProfit ? "bg-green-950/10" : isStop ? "bg-red-950/10" : isCancelled ? "opacity-60" : "";
                      const pnlCls = t.pnlPercent == null ? "text-muted-foreground" : t.pnlPercent >= 0 ? "text-green-400" : "text-red-400";
                      const px24Cls = t.px24h == null ? "text-muted-foreground" : t.px24h >= 0 ? "text-green-300" : "text-red-300";
                      return (
                        <tr key={t.id} className={`border-b border-border/40 hover:bg-muted/30 transition-colors ${rowCls}`}>
                          <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{fmtDate(t.detectedAt)}</td>
                          <td className="px-3 py-2 font-bold text-foreground">{t.symbol.replace("-USDT", "")}</td>
                          <td className="px-3 py-2 text-muted-foreground">{patLabel(t.sentimentKey)}</td>
                          <td className="px-3 py-2 text-right font-mono text-foreground/80">{fmtPx(t.entryPrice)}</td>
                          <td className={`px-3 py-2 text-right font-mono font-bold ${pnlCls}`}>{fmtPnl(t.pnlPercent)}</td>
                          <td className="px-3 py-2 text-right font-mono text-blue-300">{fmtPnl(t.peakPct)}</td>
                          <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                            {t.hoursHeld != null ? `${t.hoursHeld}h` : "—"}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                            {t.oiChangePct != null ? `${t.oiChangePct.toFixed(1)}%` : t.cumulativeOi != null ? `${t.cumulativeOi.toFixed(1)}%` : "—"}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                            {t.volMult != null ? `${t.volMult}x` : "—"}
                          </td>
                          <td className={`px-3 py-2 text-right font-mono ${px24Cls}`}>
                            {t.px24h != null ? fmtPnl(t.px24h, 1) : "—"}
                          </td>
                          <td className="px-3 py-2 text-center"><StatusBadge status={t.status} /></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

// ─── sub-components ───────────────────────────────────────────────────────────

function StatCard({ title, value, icon: Icon, subtitle, color = "text-primary" }: {
  title: string; value: number; icon: React.ElementType; subtitle?: string; color?: string;
}) {
  return (
    <Card className="border-border bg-card">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground tracking-wider">{title}</p>
            <p className="text-3xl font-bold tracking-tight">{value}</p>
          </div>
          <div className={`p-2 bg-muted rounded-none ${color}`}><Icon className="w-5 h-5" /></div>
        </div>
        {subtitle && <div className="mt-4 text-xs text-green-500 font-medium">{subtitle}</div>}
      </CardContent>
    </Card>
  );
}

function PerfCard({ title, value, sub, icon: Icon, color, bar }: {
  title: string; value: string; sub?: string; icon: React.ElementType; color: string; bar?: React.ReactNode;
}) {
  return (
    <Card className="border-border bg-card">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <p className="text-[10px] font-medium text-muted-foreground tracking-wider leading-tight">{title}</p>
          <div className={`${color} opacity-70`}><Icon className="w-3.5 h-3.5" /></div>
        </div>
        <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
        {bar}
        {sub && <p className="text-[10px] text-muted-foreground mt-1 truncate">{sub}</p>}
      </CardContent>
    </Card>
  );
}
