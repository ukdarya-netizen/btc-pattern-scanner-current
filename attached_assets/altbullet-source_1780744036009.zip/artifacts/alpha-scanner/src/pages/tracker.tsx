import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { SignalBadge } from "@/components/signal-badge";
import { SentimentBadge } from "@/components/sentiment-badge";
import { useToast } from "@/hooks/use-toast";
import { Trophy, BarChart2, RefreshCw, ExternalLink, ChevronLeft, ChevronRight, TrendingUp, TrendingDown } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const PAGE_SIZE = 50;

async function fetchTracked() {
  const res = await fetch(`${API_BASE}/api/tracker?limit=100`, { cache: "no-store" });
  return res.json();
}

async function fetchSignals(status: string, page: number) {
  const offset = (page - 1) * PAGE_SIZE;
  const params = new URLSearchParams({ limit: String(PAGE_SIZE), offset: String(offset) });
  if (status !== "all") params.set("status", status);
  const res = await fetch(`${API_BASE}/api/signals?${params}`, { cache: "no-store" });
  return res.json();
}

async function fetchStats() {
  const res = await fetch(`${API_BASE}/api/tracker/stats`, { cache: "no-store" });
  return res.json();
}

async function triggerCycle() {
  const res = await fetch(`${API_BASE}/api/tracker/run-cycle`, { method: "POST" });
  return res.json();
}

function fmtPrice(p: number | null | undefined): string {
  if (p == null) return "—";
  if (p >= 100)  return `$${p.toFixed(2)}`;
  if (p >= 1)    return `$${p.toFixed(4)}`;
  if (p >= 0.01) return `$${p.toFixed(5)}`;
  return `$${p.toFixed(6)}`;
}

function ageStr(date: string | Date): string {
  const ms = Date.now() - new Date(date).getTime();
  const h = ms / 3_600_000;
  if (h < 1) return `${Math.round(h * 60)}m`;
  if (h < 48) return `${h.toFixed(0)}h`;
  return `${(h / 24).toFixed(1)}d`;
}

const STATUS_CFG: Record<string, { label: string; icon: string; textCls: string; rowCls: string; borderCls: string }> = {
  active:       { label: "ACTIVE",   icon: "🟡", textCls: "text-zinc-300",   rowCls: "",                             borderCls: "border-zinc-700/50" },
  in_run:       { label: "IN RUN",   icon: "🚀", textCls: "text-orange-300", rowCls: "bg-orange-950/20",             borderCls: "border-l-2 border-l-orange-500" },
  accumulation: { label: "ACCUM",    icon: "🔵", textCls: "text-blue-300",   rowCls: "bg-blue-950/10",               borderCls: "border-zinc-700/50" },
  re_entry:     { label: "RE-ENTRY", icon: "🔄", textCls: "text-purple-300", rowCls: "bg-purple-950/10",             borderCls: "border-zinc-700/50" },
  profit:       { label: "PROFIT",   icon: "✅", textCls: "text-green-400",  rowCls: "bg-green-950/10",              borderCls: "border-zinc-700/50" },
  stop_loss:    { label: "STOP",     icon: "❌", textCls: "text-red-400",    rowCls: "bg-red-950/10",                borderCls: "border-zinc-700/50" },
  breakeven:    { label: "B/E",      icon: "⚖️", textCls: "text-yellow-500", rowCls: "",                             borderCls: "border-zinc-700/50" },
  bu_stop:      { label: "BU STOP",  icon: "🎯", textCls: "text-emerald-300",rowCls: "bg-emerald-950/10",            borderCls: "border-zinc-700/50" },
  cancelled:    { label: "CANCEL",   icon: "🚫", textCls: "text-zinc-500",   rowCls: "bg-zinc-900/30 opacity-60",    borderCls: "border-zinc-700/50" },
};

function StatusBadge({ status }: { status: string | null }) {
  const cfg = status ? (STATUS_CFG[status] ?? STATUS_CFG.active) : STATUS_CFG.active;
  return (
    <Badge variant="outline" className={`font-mono rounded-none text-[10px] font-bold border-zinc-700/50 ${cfg.textCls}`}>
      {cfg.icon} {cfg.label}
    </Badge>
  );
}

function PnlCell({ value, bold }: { value: number | null | undefined; bold?: boolean }) {
  if (value == null) return <span className="text-muted-foreground">—</span>;
  const cls = value >= 0 ? "text-green-400" : "text-red-400";
  return (
    <span className={`font-mono ${bold ? "font-bold text-sm" : "text-xs"} ${cls}`}>
      {value > 0 ? "+" : ""}{value.toFixed(2)}%
    </span>
  );
}

// ── Блок открытых позиций (= trackedSignalsTable) ─────────────────────────────
function OpenPositions({ data, isLoading, isError, onRetry }: {
  data: any; isLoading: boolean; isError: boolean; onRetry: () => void;
}) {
  const open = (data?.signals ?? []).filter((s: any) =>
    ["active", "in_run", "accumulation", "re_entry"].includes(s.status)
  );

  if (isLoading) return (
    <div className="flex items-center justify-center h-16 text-muted-foreground text-sm">Загрузка...</div>
  );

  if (isError) return (
    <div className="flex items-center gap-4 px-4 py-4 text-sm">
      <span className="text-red-400">⚠️ Ошибка загрузки позиций (нет связи с БД)</span>
      <Button variant="outline" size="sm" className="h-7 border-border text-muted-foreground" onClick={onRetry}>
        <RefreshCw className="w-3 h-3 mr-1" /> Retry
      </Button>
    </div>
  );

  if (open.length === 0) return (
    <div className="flex items-center gap-3 px-4 py-3 text-muted-foreground text-sm border-b border-border/50">
      <span>Нет открытых позиций.</span>
      <span className="text-xs text-muted-foreground/60">Сканер следит за рынком и откроет позицию при сигнале.</span>
    </div>
  );

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-muted-foreground text-left text-[11px] border-b border-border">
            <th className="px-3 py-2 font-medium">СИМВОЛ</th>
            <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
            <th className="px-3 py-2 font-medium text-right">ВХОД</th>
            <th className="px-3 py-2 font-medium text-right">ЦЕНА</th>
            <th className="px-3 py-2 font-medium text-right">P&L</th>
            <th className="px-3 py-2 font-medium text-right">ПИК</th>
            <th className="px-3 py-2 font-medium text-right">TRAILING STOP</th>
            <th className="px-3 py-2 font-medium text-center">СТАТУС</th>
            <th className="px-3 py-2 font-medium text-right">ВОЗРАСТ</th>
            <th className="px-3 py-2 font-medium"></th>
          </tr>
        </thead>
        <tbody>
          {open.map((s: any) => {
            const cfg = STATUS_CFG[s.status] ?? STATUS_CFG.active;
            const entryPrice  = s.entryPrice  as number | null;
            const peakPrice   = s.peakPrice   as number | null;
            const trailStop   = s.trailingStopLevel as number | null;
            const pnlPercent  = s.pnlPercent  as number | null;
            const currentPrice = s.currentPrice as number | null;
            const peakPct     = (peakPrice && entryPrice && entryPrice > 0)
              ? ((peakPrice - entryPrice) / entryPrice) * 100
              : null;
            const tvBase = s.symbol.replace("-USDT", "");
            const tvUrl  = `https://www.tradingview.com/chart/?symbol=BINGX:${tvBase}USDT.P`;

            return (
              <tr key={s.id} className={`border-b border-border/50 hover:bg-muted/20 transition-colors ${cfg.rowCls} ${cfg.borderCls}`}>
                <td className="px-3 py-3">
                  <div className="font-bold font-mono text-foreground">
                    {s.symbol.replace("-USDT", "")}
                    {s.isShort && <span className="ml-1 text-[10px] text-red-400">SHORT</span>}
                  </div>
                  <div className="text-[10px] text-muted-foreground/60">{s.signalType}</div>
                </td>
                <td className="px-3 py-3">
                  <span className={`text-xs font-mono ${cfg.textCls}`}>
                    {s.sentimentKey ?? "—"}
                  </span>
                </td>
                <td className="px-3 py-3 text-right font-mono text-xs text-foreground font-semibold">
                  {fmtPrice(entryPrice)}
                </td>
                <td className="px-3 py-3 text-right font-mono text-xs text-muted-foreground">
                  {currentPrice != null ? fmtPrice(currentPrice) : "—"}
                </td>
                <td className="px-3 py-3 text-right">
                  <PnlCell value={pnlPercent} bold />
                </td>
                <td className="px-3 py-3 text-right">
                  {peakPct != null && peakPct > 0 ? (
                    <span className="font-mono text-xs text-green-400/80">+{peakPct.toFixed(1)}%</span>
                  ) : <span className="text-muted-foreground text-xs">—</span>}
                </td>
                <td className="px-3 py-3 text-right">
                  {trailStop ? (
                    <span className="font-mono text-xs text-orange-300 font-bold">🛡 {fmtPrice(trailStop)}</span>
                  ) : <span className="text-muted-foreground text-xs">—</span>}
                </td>
                <td className="px-3 py-3 text-center">
                  <StatusBadge status={s.status} />
                </td>
                <td className="px-3 py-3 text-right font-mono text-xs text-muted-foreground">
                  {ageStr(s.detectedAt)}
                </td>
                <td className="px-3 py-3 text-center">
                  <a href={tvUrl} target="_blank" rel="noreferrer" className="text-zinc-600 hover:text-primary">
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Лог всех сигналов (= signalsTable) ────────────────────────────────────────
function SignalLog({ statusFilter, page, setPage, setStatusFilter }: {
  statusFilter: string; page: number;
  setPage: (n: number) => void;
  setStatusFilter: (s: string) => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["signals-log", statusFilter, page],
    queryFn: () => fetchSignals(statusFilter, page),
    refetchInterval: 20_000,
  });

  const signals    = data?.signals ?? [];
  const total      = data?.total   ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <Card className="border-border bg-card">
      <CardHeader className="py-3 px-4 border-b border-border">
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="text-sm font-mono tracking-wider text-muted-foreground">
            ИСТОРИЯ СИГНАЛОВ ТГ
          </CardTitle>
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
            <SelectTrigger className="w-[220px] h-8 bg-card border-border text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ВСЕ СИГНАЛЫ</SelectItem>
              <SelectItem value="active">🟡 Активные (отслеживаемые)</SelectItem>
              <SelectItem value="in_run">🚀 В полёте</SelectItem>
              <SelectItem value="profit">✅ Профит</SelectItem>
              <SelectItem value="bu_stop">🎯 БУ Стоп</SelectItem>
              <SelectItem value="breakeven">⚖️ Безубыток</SelectItem>
              <SelectItem value="stop_loss">❌ Стоп-лосс</SelectItem>
              <SelectItem value="cancelled">🚫 Отменены</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">Загрузка...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-card border-b border-border z-10">
                <tr className="text-muted-foreground text-left text-[11px]">
                  <th className="px-3 py-2 font-medium">ВРЕМЯ</th>
                  <th className="px-3 py-2 font-medium">СИМВОЛ</th>
                  <th className="px-3 py-2 font-medium">GRADE</th>
                  <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
                  <th className="px-3 py-2 font-medium text-right">OI%</th>
                  <th className="px-3 py-2 font-medium text-right">VOL</th>
                  <th className="px-3 py-2 font-medium text-center">SCORE</th>
                  <th className="px-3 py-2 font-medium text-right">ЦЕНА ВХОДА</th>
                  <th className="px-3 py-2 font-medium text-right">P&L</th>
                  <th className="px-3 py-2 font-medium text-center">СТАТУС</th>
                </tr>
              </thead>
              <tbody>
                {signals.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="px-4 py-10 text-center text-muted-foreground">Нет сигналов</td>
                  </tr>
                ) : signals.map((s: any) => {
                  const status = s.trackedStatus as string | null;
                  const pnl    = s.trackedPnl   as number | null;
                  const entry  = s.trackedEntryPrice as number | null;
                  const cfg    = status ? (STATUS_CFG[status] ?? STATUS_CFG.active) : null;
                  const oiPct  = s.oiChangePercent as number | null;
                  const score  = s.alphaScore as number | null;
                  const oiValid = oiPct !== null && oiPct !== 0;

                  return (
                    <tr key={s.id} className={`border-b border-border/40 hover:bg-muted/20 transition-colors ${cfg?.rowCls ?? ""}`}>
                      <td className="px-3 py-2 text-muted-foreground font-mono text-[11px] whitespace-nowrap">
                        {new Date(s.detectedAt).toLocaleString("ru-RU", {
                          month: "2-digit", day: "2-digit",
                          hour: "2-digit", minute: "2-digit",
                        })}
                        <div className="text-[10px] text-muted-foreground/50">{ageStr(s.detectedAt)}</div>
                      </td>
                      <td className="px-3 py-2 font-bold font-mono text-foreground whitespace-nowrap">
                        {s.symbol.replace("-USDT", "")}
                        {Boolean(s.isWhaleSeed) && <span className="ml-1 text-[10px] text-cyan-400">🐋</span>}
                      </td>
                      <td className="px-3 py-2"><SignalBadge type={s.type} /></td>
                      <td className="px-3 py-2">
                        <SentimentBadge sentimentKey={s.sentimentKey ?? "anomaly"} label={s.sentiment ?? "—"} />
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-xs">
                        {oiValid ? (
                          <span className={oiPct! >= 0 ? "text-green-400" : "text-red-400"}>
                            {oiPct! >= 0 ? "+" : ""}{oiPct!.toFixed(1)}%
                          </span>
                        ) : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-xs text-muted-foreground">
                        {s.value != null ? `${s.value.toFixed(1)}x` : "—"}
                      </td>
                      <td className="px-3 py-2 text-center font-mono text-xs">
                        {score != null && score > 0 ? (
                          <span className={score >= 8 ? "text-yellow-300" : score >= 6 ? "text-blue-300" : "text-green-400"}>
                            {score}/10
                          </span>
                        ) : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-xs text-foreground/80">
                        {entry != null ? fmtPrice(entry) : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-3 py-2 text-right">
                        <PnlCell value={pnl} />
                      </td>
                      <td className="px-3 py-2 text-center">
                        {status ? (
                          <StatusBadge status={status} />
                        ) : (
                          <span className="text-muted-foreground text-[10px]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-2 border-t border-border text-xs text-muted-foreground">
          <span className="font-mono">
            {signals.length > 0 ? `${(page-1)*PAGE_SIZE+1}–${(page-1)*PAGE_SIZE+signals.length}` : "0"} из {total}
          </span>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="h-7 border-border text-muted-foreground"
              onClick={() => setPage(Math.max(1, page-1))} disabled={page <= 1}>
              <ChevronLeft className="w-3 h-3" />
            </Button>
            <span className="font-mono text-[11px]">{page}/{totalPages}</span>
            <Button variant="outline" size="sm" className="h-7 border-border text-muted-foreground"
              onClick={() => setPage(Math.min(totalPages, page+1))} disabled={page >= totalPages}>
              <ChevronRight className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Главная страница ───────────────────────────────────────────────────────────
export default function Tracker() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage]                 = useState(1);
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: trackedData, isLoading: trackedLoading, isError: trackedError, refetch: refetchTracked } = useQuery({
    queryKey: ["tracked-open"],
    queryFn: fetchTracked,
    refetchInterval: 15_000,
    retry: 3,
  });

  const { data: statsData } = useQuery({
    queryKey: ["tracker-stats"],
    queryFn: fetchStats,
    refetchInterval: 30_000,
  });

  const cycleMut = useMutation({
    mutationFn: triggerCycle,
    onSuccess: (d) => {
      toast({ title: "Watcher цикл завершён", description: `Проверено: ${d.checked}, обновлено: ${d.updated}` });
      qc.invalidateQueries({ queryKey: ["tracked-open"] });
      qc.invalidateQueries({ queryKey: ["tracker-stats"] });
    },
    onError: () => toast({ title: "Ошибка", description: "Цикл watcher не запустился", variant: "destructive" }),
  });

  const sendReport = async (type: "daily" | "weekly" | "positions") => {
    const url = type === "daily"     ? "/api/tracker/daily-digest"
              : type === "weekly"    ? "/api/tracker/weekly-digest"
              : "/api/tracker/positions-update";
    try {
      await fetch(`${API_BASE}${url}`, { method: "POST" });
      toast({ title: "Отправлено", description: "Сообщение отправлено в Telegram" });
    } catch {
      toast({ title: "Ошибка", description: "Не удалось отправить", variant: "destructive" });
    }
  };

  const stats      = statsData ?? {};
  const allTracked = (trackedData?.signals ?? []) as any[];
  const openPos    = allTracked.filter((s: any) => ["active","in_run","accumulation","re_entry"].includes(s.status));
  const closedPos  = allTracked.filter((s: any) => ["profit","bu_stop","stop_loss","breakeven","cancelled"].includes(s.status));

  const inRunCount   = openPos.filter((s: any) => s.status === "in_run").length;
  const watchingCount = openPos.filter((s: any) => ["active","accumulation","re_entry"].includes(s.status)).length;

  const monthStats    = stats.monthStats ?? {};
  const profitCount   = monthStats["profit"]?.count   ?? 0;
  const stopCount     = monthStats["stop_loss"]?.count ?? 0;
  const winRate       = stats.monthWinRate   ?? null;
  const avgProfit     = stats.monthAvgProfit != null ? Number(stats.monthAvgProfit) : null;
  const cancelledCount = (monthStats["cancelled"]?.count ?? 0) + (monthStats["bu_stop"]?.count ?? 0);

  return (
    <div className="space-y-4">
      {/* Заголовок + кнопки */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wider">ALTBULLET WATCHER</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => sendReport("positions")}>
            📊 ПОЗИЦИИ
          </Button>
          <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => sendReport("daily")}>
            <BarChart2 className="w-3 h-3 mr-1" /> DAILY
          </Button>
          <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => sendReport("weekly")}>
            <Trophy className="w-3 h-3 mr-1" /> WEEKLY
          </Button>
          <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => cycleMut.mutate()} disabled={cycleMut.isPending}>
            <RefreshCw className={`w-3 h-3 mr-1 ${cycleMut.isPending ? "animate-spin" : ""}`} />
            CHECK
          </Button>
        </div>
      </div>

      {/* Стат-бар */}
      <div className="grid grid-cols-7 gap-3">
        {[
          { label: "В НАБЛЮДЕНИИ", value: watchingCount,  cls: "text-blue-400",   card: "" },
          { label: "🚀 В ПОЛЁТЕ",  value: inRunCount,     cls: "text-orange-300", card: "border-orange-500/30 bg-orange-950/10" },
          { label: "ПРОФИТ",       value: profitCount,     cls: "text-green-400",  card: "", sub: "тек. мес." },
          { label: "СТОП-ЛОСС",   value: stopCount,       cls: "text-red-400",    card: "", sub: "тек. мес." },
          { label: "WIN RATE",     value: winRate !== null ? `${winRate}%` : "—", cls: "text-yellow-300", card: "", sub: "тек. мес." },
          { label: "AVG PROFIT",   value: avgProfit !== null ? `+${avgProfit.toFixed(1)}%` : "—", cls: avgProfit && avgProfit > 0 ? "text-green-400" : "text-muted-foreground", card: "", sub: "тек. мес." },
          { label: "ОТМЕНЕНО",     value: cancelledCount,  cls: "text-zinc-400",   card: "border-zinc-500/20", sub: "тек. мес." },
        ].map(({ label, value, cls, card, sub }) => (
          <Card key={label} className={`border-border bg-card ${card}`}>
            <CardContent className="p-4">
              <div className="text-[10px] text-muted-foreground mb-1 tracking-wider">{label}</div>
              <div className={`text-2xl font-bold font-mono ${cls}`}>{value}</div>
              {sub && <div className="text-[10px] text-muted-foreground/50 mt-1">{sub}</div>}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Правила */}
      <div className="flex gap-x-5 gap-y-1 text-[11px] font-mono border border-border bg-card/50 px-4 py-2 flex-wrap items-center">
        <span className="text-orange-300">🚀 IN RUN ≥+10%: Trailing <span className="text-orange-200">+10%→−7% / +25%→−10% / +50%→−12%</span></span>
        <span className="text-red-400">❌ STOP −10%</span>
        <span className="text-emerald-400">🎯 BU: trailing ≤ entry → B/E</span>
        <span className="text-blue-400">🔵 ACCUM: 24h–7d</span>
        <span className="text-muted-foreground">⚖️ B/E: 7д без результата</span>
        <span className="text-zinc-500">🚫 STALE-CANCEL: 3ч если пик &lt;+2%</span>
      </div>

      {/* ── Раздел 1: Открытые позиции ────────────────────────────────────── */}
      <Card className="border-border bg-card">
        <CardHeader className="py-3 px-4 border-b border-border">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-mono tracking-wider">
              📍 ОТКРЫТЫЕ ПОЗИЦИИ
              <span className="ml-2 text-muted-foreground font-normal">({openPos.length})</span>
            </CardTitle>
            <span className="text-[10px] text-muted-foreground/60 font-mono">
              = источник TG-отчёта об открытых позициях
            </span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <OpenPositions data={trackedData} isLoading={trackedLoading} isError={trackedError} onRetry={refetchTracked} />
        </CardContent>
      </Card>

      {/* Недавно закрытые (последние 5) */}
      {closedPos.slice(0, 5).length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader className="py-3 px-4 border-b border-border">
            <CardTitle className="text-sm font-mono tracking-wider text-muted-foreground">
              🏁 ПОСЛЕДНИЕ ЗАКРЫТЫЕ
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-muted-foreground text-[11px] border-b border-border/50 text-left">
                  <th className="px-3 py-2">СИМВОЛ</th>
                  <th className="px-3 py-2">ПАТТЕРН</th>
                  <th className="px-3 py-2 text-right">ВХОД</th>
                  <th className="px-3 py-2 text-right">ВЫХОД</th>
                  <th className="px-3 py-2 text-right">P&L</th>
                  <th className="px-3 py-2 text-center">РЕЗУЛЬТАТ</th>
                  <th className="px-3 py-2 text-right">ВОЗРАСТ</th>
                </tr>
              </thead>
              <tbody>
                {closedPos.slice(0, 5).map((s: any) => {
                  const cfg = STATUS_CFG[s.status] ?? STATUS_CFG.active;
                  return (
                    <tr key={s.id} className={`border-b border-border/40 hover:bg-muted/20 ${cfg.rowCls}`}>
                      <td className="px-3 py-2 font-bold font-mono">{s.symbol.replace("-USDT", "")}</td>
                      <td className="px-3 py-2 text-xs text-muted-foreground">{s.sentimentKey ?? "—"}</td>
                      <td className="px-3 py-2 text-right font-mono text-xs">{fmtPrice(s.entryPrice)}</td>
                      <td className="px-3 py-2 text-right font-mono text-xs">{fmtPrice(s.exitPrice)}</td>
                      <td className="px-3 py-2 text-right"><PnlCell value={s.pnlPercent} bold /></td>
                      <td className="px-3 py-2 text-center"><StatusBadge status={s.status} /></td>
                      <td className="px-3 py-2 text-right font-mono text-xs text-muted-foreground">{ageStr(s.detectedAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {/* ── Раздел 2: Лог сигналов ────────────────────────────────────────── */}
      <SignalLog
        statusFilter={statusFilter}
        page={page}
        setPage={setPage}
        setStatusFilter={setStatusFilter}
      />
    </div>
  );
}
