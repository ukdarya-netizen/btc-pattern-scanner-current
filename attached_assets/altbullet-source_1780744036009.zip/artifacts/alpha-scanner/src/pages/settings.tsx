import { useGetSettings, useUpdateSettings } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useEffect, useRef, useState } from "react";
import { Save, Send } from "lucide-react";

const formSchema = z.object({
  volumeMultiplier: z.coerce.number().min(1).max(20),
  oiChangePercent: z.coerce.number().min(1).max(100),
  fundingRateThreshold: z.coerce.number().min(0.0001).max(1),
  scanIntervalMs: z.coerce.number().min(60000).max(86400000),
  telegramEnabled: z.boolean(),
  maxSymbols: z.coerce.number().min(1).max(500),
  channelId: z.string().nullable().optional(),
  watchlist: z.string().nullable().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function Settings() {
  const { toast } = useToast();
  const { data: settings, isLoading } = useGetSettings();
  const updateSettings = useUpdateSettings();
  const [testingChannel, setTestingChannel] = useState(false);

  const testChannel = async () => {
    setTestingChannel(true);
    try {
      const res = await fetch("/api/telegram/test-channel", { method: "POST" });
      const json = await res.json() as { success: boolean; message: string };
      toast({
        title: json.success ? "CHANNEL TEST OK" : "CHANNEL TEST FAILED",
        description: json.message,
        variant: json.success ? "default" : "destructive",
      });
    } catch {
      toast({ title: "ERROR", description: "Could not reach server", variant: "destructive" });
    } finally {
      setTestingChannel(false);
    }
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      volumeMultiplier: 3,
      oiChangePercent: 5,
      fundingRateThreshold: 0.05,
      scanIntervalMs: 1800000,
      telegramEnabled: false,
      maxSymbols: 50,
      channelId: null,
      watchlist: null,
    }
  });

  const initialized = useRef(false);

  useEffect(() => {
    if (settings && !initialized.current) {
      form.reset(settings);
      initialized.current = true;
    }
  }, [settings, form]);

  const onSubmit = (data: FormValues) => {
    updateSettings.mutate({ data }, {
      onSuccess: () => {
        toast({
          title: "SETTINGS SAVED",
          description: "Scanner configuration has been updated.",
        });
      },
      onError: (err) => {
        toast({
          title: "ERROR",
          description: "Failed to save settings.",
          variant: "destructive"
        });
      }
    });
  };

  if (isLoading) return <div className="p-8">LOADING CONFIGURATION...</div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wider">SCANNER CONFIGURATION</h2>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="border-border bg-card">
            <CardHeader className="border-b border-border">
              <CardTitle className="text-lg">SIGNAL THRESHOLDS</CardTitle>
              <CardDescription>Adjust the sensitivity of alpha detection algorithms.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="volumeMultiplier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs tracking-widest text-muted-foreground">VOLUME MULTIPLIER (x)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" className="font-mono bg-background border-border" {...field} />
                      </FormControl>
                      <FormDescription className="text-xs">
                        Triggers when 24h volume is X times the average.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="oiChangePercent"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs tracking-widest text-muted-foreground">OI INCREASE THRESHOLD (%)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" className="font-mono bg-background border-border" {...field} />
                      </FormControl>
                      <FormDescription className="text-xs">
                        Minimum Open Interest percentage change to trigger an alert.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fundingRateThreshold"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs tracking-widest text-muted-foreground">FUNDING RATE THRESHOLD (ABSOLUTE)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.0001" className="font-mono bg-background border-border" {...field} />
                      </FormControl>
                      <FormDescription className="text-xs">
                        Triggers when absolute funding rate exceeds this value.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="border-b border-border">
              <CardTitle className="text-lg">SYSTEM SETTINGS</CardTitle>
              <CardDescription>Core engine and notification preferences.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="scanIntervalMs"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs tracking-widest text-muted-foreground">SCAN INTERVAL (ms)</FormLabel>
                      <FormControl>
                        <Input type="number" step="60000" className="font-mono bg-background border-border" {...field} />
                      </FormControl>
                      <FormDescription className="text-xs">
                        Min 60000 ms (1 min). Default: 1800000 (30 min).
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="maxSymbols"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs tracking-widest text-muted-foreground">MAX MARKETS TO SCAN</FormLabel>
                      <FormControl>
                        <Input type="number" className="font-mono bg-background border-border" {...field} />
                      </FormControl>
                      <FormDescription className="text-xs">
                        Limit number of pairs to prevent rate limits.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="telegramEnabled"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between border border-border p-4 bg-background">
                      <div className="space-y-0.5">
                        <FormLabel className="text-sm font-bold">TELEGRAM ALERTS</FormLabel>
                        <FormDescription className="text-xs">
                          Send signals to subscribers and channel.
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="data-[state=checked]:bg-primary"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="border-b border-border">
              <CardTitle className="text-lg">TELEGRAM CHANNEL</CardTitle>
              <CardDescription>
                Add your bot as an admin to the channel, then enter the channel ID here.
                All signals will be posted there automatically.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <FormField
                control={form.control}
                name="channelId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs tracking-widest text-muted-foreground">CHANNEL ID</FormLabel>
                    <FormControl>
                      <Input
                        type="text"
                        placeholder="@yourchannel  or  -1001234567890"
                        className="font-mono bg-background border-border"
                        value={field.value ?? ""}
                        onChange={e => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormDescription className="text-xs space-y-1">
                      <span className="block">• Public channel: use <code className="text-primary">@channelname</code></span>
                      <span className="block">• Private channel: use numeric ID like <code className="text-primary">-1001234567890</code></span>
                      <span className="block">• Leave empty to send only to personal subscribers</span>
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="pt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={testChannel}
                  disabled={testingChannel}
                  className="font-mono text-xs border-border"
                >
                  <Send className="w-3 h-3 mr-2" />
                  {testingChannel ? "SENDING..." : "SEND TEST MESSAGE"}
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  Sends a test message to verify the bot has access to this channel.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="border-b border-border">
              <CardTitle className="text-lg">WATCHLIST</CardTitle>
              <CardDescription>
                Tokens always scanned regardless of market activity. Add any symbol you want to monitor continuously — even if it has low current activity.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <FormField
                control={form.control}
                name="watchlist"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs tracking-widest text-muted-foreground">ALWAYS-WATCH SYMBOLS</FormLabel>
                    <FormControl>
                      <Input
                        type="text"
                        placeholder="IOST, BIO, TRUST, WHITEWHALE"
                        className="font-mono bg-background border-border"
                        value={field.value ?? ""}
                        onChange={e => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormDescription className="text-xs space-y-1">
                      <span className="block">Comma-separated list of tokens to always scan. You can use the base name or full symbol.</span>
                      <span className="block">Examples: <code className="text-primary">IOST, BIO, TRUST</code> or <code className="text-primary">IOST-USDT, BIO-USDT</code></span>
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" disabled={updateSettings.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold px-8">
              {updateSettings.isPending ? "SAVING..." : <><Save className="w-4 h-4 mr-2" /> SAVE CONFIGURATION</>}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
