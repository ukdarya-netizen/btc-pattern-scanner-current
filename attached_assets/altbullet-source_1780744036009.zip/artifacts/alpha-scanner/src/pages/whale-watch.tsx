import {
  useGetWhaleWatch,
  useGetWhaleSeeds,
  useGetWhaleWatchSpotStats,
  getGetWhaleWatchQueryKey,
  getGetWhaleSeedsQueryKey,
  getGetWhaleWatchSpotStatsQueryKey,
  type WhaleSeedItem,
  type WhaleWatchSpotEntry,
  type WhaleWatchSpotSignal,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Waves, RefreshCw } from "lucide-react";

const PATTERN_LABELS: Record<string, string> = {
  hidden_accumulation:  "Hidden Accum",
  bullish_accumulation: "Bull Accum",
  aggressive_breakout:  "Aggr Break",
  short_squeeze:        "Short Squeeze",
  bear_trap:            "Bear Trap",
  bearish_pressure:     "Bear Pressure",
  anomaly:              "Anomaly",
  impulse_breakout:     "Impulse Break",
  sharp_impulse:        "Sharp Impulse",
  whale_futures:        "Whale Futures",
  volume_breakout:      "Vol Breakout",
  distribution:         "Distribution",
  whale_watch:          "Whale Watch",
};

function patLabel(key: string | null | undefined) {
  return PATTERN_LABELS[key ?? ""] ?? key ?? "—";
}

function hoursAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return `${diff}с`;
  if (diff < 3600) return `${Math.floor(diff / 60)}м`;
  const h = Math.floor(diff / 3600);
  const m = Math.floor((diff % 3600) / 60);
  return m > 0 ? `${h}ч ${m}м` : `${h}ч`;
}

function hoursUntil(iso: string): string {
  const diff = Math.max(0, Math.floor((new Date(iso).getTime() - Date.now()) / 1000));
  if (diff <= 0) return "истёк";
  if (diff < 3600) return `${Math.floor(diff / 60)}м`;
  const h = Math.floor(diff / 3600);
  const m = Math.floor((diff % 3600) / 60);
  return m > 0 ? `${h}ч ${m}м` : `${h}ч`;
}

function fmtPrice(p: number): string {
  if (p >= 1000) return p.toFixed(2);
  if (p >= 1)    return p.toFixed(4);
  if (p >= 0.01) return p.toFixed(5);
  return p.toFixed(6);
}

function SeedStatusBadge({ oiGrowthPct, days }: { oiGrowthPct: number | null; days: number }) {
  if (oiGrowthPct == null) {
    return <Badge className="text-[10px] bg-zinc-800 text-zinc-400 border-zinc-700">🌱 НОВЫЙ</Badge>;
  }
  if (oiGrowthPct >= 15) {
    return <Badge className="text-[10px] bg-green-900/40 text-green-400 border-green-700/50">🐋 +{oiGrowthPct.toFixed(0)}% OI</Badge>;
  }
  if (oiGrowthPct >= 5) {
    return <Badge className="text-[10px] bg-blue-900/40 text-blue-400 border-blue-700/50">📈 +{oiGrowthPct.toFixed(0)}% OI</Badge>;
  }
  if (oiGrowthPct < 0) {
    return <Badge className="text-[10px] bg-red-900/20 text-red-400 border-red-700/30">📉 {oiGrowthPct.toFixed(0)}% OI</Badge>;
  }
  return <Badge className="text-[10px] bg-zinc-800 text-zinc-400 border-zinc-700">⏳ {days.toFixed(0)}д</Badge>;
}

function pctColor(v: number | null | undefined): string {
  if (v == null) return "text-muted-foreground";
  if (v >= 10) return "text-green-400";
  if (v >= 5)  return "text-emerald-400";
  if (v >= 0)  return "text-foreground/80";
  return "text-red-400";
}

function pctCell(v: number | null | undefined) {
  if (v == null) return <span className="text-muted-foreground">—</span>;
  return (
    <span className={pctColor(v)}>
      {v >= 0 ? "+" : ""}{v.toFixed(1)}%
    </span>
  );
}

function SpotStatsTable({ signals, winRate24h, winRate48h, winRate7d, avg24hPct, avg48hPct, avg7dMaxPct, total, withStats }: {
  signals: WhaleWatchSpotSignal[];
  winRate24h: number | null | undefined;
  winRate48h: number | null | undefined;
  winRate7d:  number | null | undefined;
  avg24hPct:  number | null | undefined;
  avg48hPct:  number | null | undefined;
  avg7dMaxPct: number | null | undefined;
  total: number;
  withStats: number;
}) {
  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Win Rate 24ч", wr: winRate24h, avg: avg24hPct },
          { label: "Win Rate 48ч", wr: winRate48h, avg: avg48hPct },
          { label: "Макс за 7д",   wr: winRate7d,  avg: avg7dMaxPct },
        ].map(({ label, wr, avg }) => (
          <div key={label} className="bg-muted/20 rounded-md p-3 text-center">
            <div className="text-[10px] text-muted-foreground mb-1">{label}</div>
            <div className={`text-lg font-bold font-mono ${wr != null && wr >= 60 ? "text-green-400" : wr != null && wr >= 40 ? "text-yellow-400" : "text-muted-foreground"}`}>
              {wr != null ? `${wr}%` : "—"}
            </div>
            <div className={`text-[10px] font-mono mt-0.5 ${pctColor(avg)}`}>
              {avg != null ? `ср. ${avg >= 0 ? "+" : ""}${avg.toFixed(1)}%` : "нет данных"}
            </div>
          </div>
        ))}
      </div>
      <div className="text-[11px] text-muted-foreground text-center">
        Всего сигналов: {total} · со статистикой: {withStats} · Win = рост ≥5%
      </div>

      {/* Per-signal table */}
      {signals.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border text-muted-foreground">
                <th className="text-left py-2 pr-4 font-medium">Символ</th>
                <th className="text-right py-2 pr-2 font-medium">Выстрел</th>
                <th className="text-right py-2 pr-2 font-medium">+24ч</th>
                <th className="text-right py-2 pr-2 font-medium">+48ч</th>
                <th className="text-right py-2 font-medium">Макс 7д</th>
              </tr>
            </thead>
            <tbody>
              {signals.map((s) => (
                <tr key={s.id} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                  <td className="py-2 pr-4">
                    <a
                      href={`https://www.tradingview.com/chart/?symbol=BYBIT:${s.symbol.replace("-", "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-mono font-bold text-cyan-400 hover:underline"
                    >
                      {s.symbol.replace("-USDT", "")}
                    </a>
                  </td>
                  <td className="py-2 pr-2 text-right font-mono text-muted-foreground">
                    {s.firedAt ? hoursAgo(s.firedAt) + " назад" : "—"}
                  </td>
                  <td className="py-2 pr-2 text-right font-mono">{pctCell(s.price24hPct)}</td>
                  <td className="py-2 pr-2 text-right font-mono">{pctCell(s.price48hPct)}</td>
                  <td className="py-2 text-right font-mono">{pctCell(s.price7dMaxPct)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function SpotWatchingTable({ rows }: { rows: WhaleWatchSpotEntry[] }) {
  if (rows.length === 0) {
    return (
      <p className="text-xs text-muted-foreground text-center py-6">
        Пока пусто — детектор ищет OI ≥2% + спот CVD+ + цена -1%..+3%
      </p>
    );
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-border text-muted-foreground">
            <th className="text-left py-2 pr-4 font-medium">Символ</th>
            <th className="text-right py-2 pr-4 font-medium">В наблюдении</th>
            <th className="text-right py-2 pr-4 font-medium">OI при входе</th>
            <th className="text-right py-2 pr-4 font-medium">Цена входа</th>
            <th className="text-right py-2 pr-4 font-medium">Проверок</th>
            <th className="text-right py-2 font-medium">Истекает через</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const oi = row.oi30mAtDetection ?? row.oi1hAtDetection;
            const expiresMs = new Date(row.expiresAt).getTime();
            const urgency = expiresMs - Date.now() < 4 * 3600 * 1000;
            return (
              <tr key={row.id} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                <td className="py-2.5 pr-4">
                  <a
                    href={`https://www.tradingview.com/chart/?symbol=BYBIT:${row.symbol.replace("-", "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-mono font-bold text-cyan-400 hover:underline"
                  >
                    {row.symbol.replace("-USDT", "")}
                  </a>
                </td>
                <td className="py-2.5 pr-4 text-right font-mono text-muted-foreground">
                  {hoursAgo(row.detectedAt)}
                </td>
                <td className="py-2.5 pr-4 text-right font-mono">
                  {oi != null ? (
                    <span className="text-blue-400">+{oi.toFixed(1)}%</span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </td>
                <td className="py-2.5 pr-4 text-right font-mono text-foreground/80">
                  ${fmtPrice(row.priceAtDetection)}
                </td>
                <td className="py-2.5 pr-4 text-right font-mono text-muted-foreground">
                  {row.checkCount}
                </td>
                <td className="py-2.5 text-right font-mono">
                  <span className={urgency ? "text-red-400" : "text-muted-foreground"}>
                    {hoursUntil(row.expiresAt)}
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function SpotFiredTable({ rows }: { rows: WhaleWatchSpotEntry[] }) {
  if (rows.length === 0) {
    return (
      <p className="text-xs text-muted-foreground text-center py-6">
        Подтверждённых сигналов пока нет
      </p>
    );
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-border text-muted-foreground">
            <th className="text-left py-2 pr-4 font-medium">Символ</th>
            <th className="text-right py-2 pr-4 font-medium">Выстрел</th>
            <th className="text-right py-2 pr-4 font-medium">OI при входе</th>
            <th className="text-right py-2 pr-4 font-medium">Цена входа</th>
            <th className="text-right py-2 font-medium">Проверок до огня</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const oi = row.oi30mAtDetection ?? row.oi1hAtDetection;
            return (
              <tr key={row.id} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                <td className="py-2.5 pr-4">
                  <a
                    href={`https://www.tradingview.com/chart/?symbol=BYBIT:${row.symbol.replace("-", "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-mono font-bold text-green-400 hover:underline"
                  >
                    {row.symbol.replace("-USDT", "")}
                  </a>
                </td>
                <td className="py-2.5 pr-4 text-right font-mono text-muted-foreground">
                  {row.firedAt ? hoursAgo(row.firedAt) + " назад" : "—"}
                </td>
                <td className="py-2.5 pr-4 text-right font-mono">
                  {oi != null ? (
                    <span className="text-blue-400">+{oi.toFixed(1)}%</span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </td>
                <td className="py-2.5 pr-4 text-right font-mono text-foreground/80">
                  ${fmtPrice(row.priceAtDetection)}
                </td>
                <td className="py-2.5 text-right font-mono text-muted-foreground">
                  {row.checkCount}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default function WhaleWatch() {
  const { data, isLoading, refetch, dataUpdatedAt } = useGetWhaleWatch({
    query: { queryKey: getGetWhaleWatchQueryKey(), refetchInterval: 15_000 },
  });
  const { data: seedsData } = useGetWhaleSeeds({
    query: { queryKey: getGetWhaleSeedsQueryKey(), refetchInterval: 60_000 },
  });
  const { data: spotStats } = useGetWhaleWatchSpotStats({
    query: { queryKey: getGetWhaleWatchSpotStatsQueryKey(), refetchInterval: 120_000 },
  });

  const spotWatching = data?.spotWatching ?? [];
  const spotFired    = data?.spotFired    ?? [];

  const lastUpdated = dataUpdatedAt
    ? new Date(dataUpdatedAt).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : "—";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Waves className="w-5 h-5 text-blue-400" />
            Whale Watch
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Спот-накопление: OI ≥2% + CVD+ + цена боковая. Подтверждение через 2 мин.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">обновлено {lastUpdated}</span>
          <button
            onClick={() => refetch()}
            className="p-1.5 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* ── В наблюдении ─────────────────────────────────────────────── */}
      <Card className={spotWatching.length > 0 ? "border-cyan-500/40 bg-cyan-500/5" : ""}>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <span className="text-cyan-400">🐋</span>
            В наблюдении
            <Badge
              variant="outline"
              className={`ml-auto text-xs ${spotWatching.length > 0 ? "border-cyan-500/50 text-cyan-400" : ""}`}
            >
              {isLoading ? "…" : spotWatching.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-xs text-muted-foreground text-center py-4">Загрузка…</p>
          ) : (
            <SpotWatchingTable rows={spotWatching} />
          )}
        </CardContent>
      </Card>

      {/* ── Подтверждённые сигналы ───────────────────────────────────── */}
      <Card className={spotFired.length > 0 ? "border-green-500/30 bg-green-500/5" : ""}>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <span className="text-green-400">✅</span>
            Подтверждённые сигналы
            <Badge
              variant="outline"
              className={`ml-auto text-xs ${spotFired.length > 0 ? "border-green-500/50 text-green-400" : ""}`}
            >
              {isLoading ? "…" : spotFired.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-xs text-muted-foreground text-center py-4">Загрузка…</p>
          ) : (
            <SpotFiredTable rows={spotFired} />
          )}
        </CardContent>
      </Card>

      {/* ── Статистика спот-сигналов ─────────────────────────────────── */}
      <Card className="border-border bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <span>📊</span>
            Статистика Китового Накопления (Спот)
            <Badge variant="outline" className="ml-auto text-xs">
              {spotStats?.total ?? 0} сигналов
            </Badge>
          </CardTitle>
          <p className="text-[11px] text-muted-foreground">
            Результат спот-сигналов по окнам 24ч / 48ч / макс за 7 дней. Win = рост ≥5%.
          </p>
        </CardHeader>
        <CardContent>
          {!spotStats ? (
            <p className="text-xs text-muted-foreground text-center py-4">
              Данные появятся после первых подтверждённых сигналов
            </p>
          ) : (
            <SpotStatsTable
              signals={spotStats.signals ?? []}
              winRate24h={spotStats.winRate24h}
              winRate48h={spotStats.winRate48h}
              winRate7d={spotStats.winRate7d}
              avg24hPct={spotStats.avg24hPct}
              avg48hPct={spotStats.avg48hPct}
              avg7dMaxPct={spotStats.avg7dMaxPct}
              total={spotStats.total}
              withStats={spotStats.withStats}
            />
          )}
        </CardContent>
      </Card>

      {/* ── Сид-лист ─────────────────────────────────────────────────── */}
      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <span className="text-green-400">🌱</span>
            Сид-лист — отменённые сигналы под наблюдением
            <Badge variant="outline" className="ml-auto text-xs">
              {seedsData?.total ?? 0}
            </Badge>
          </CardTitle>
          <p className="text-[11px] text-muted-foreground">
            Сигналы, у которых OI ≥3% при обнаружении, но цена не подтвердила. Следим за OI 90 дней.
          </p>
        </CardHeader>
        <CardContent className="p-0">
          {!seedsData || seedsData.seeds.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">
              Пока пусто — первые сиды появятся после следующих отменённых сигналов с OI ≥3%
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border text-muted-foreground text-left">
                    <th className="px-4 py-2 font-medium">СИМВОЛ</th>
                    <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
                    <th className="px-3 py-2 font-medium text-right">OI при сиде</th>
                    <th className="px-3 py-2 font-medium text-right">ЦЕНА ВХОДА</th>
                    <th className="px-3 py-2 font-medium text-right">ДНЕЙ</th>
                    <th className="px-3 py-2 font-medium text-center">СТАТУС OI</th>
                  </tr>
                </thead>
                <tbody>
                  {seedsData.seeds.map((seed: WhaleSeedItem) => (
                    <tr key={seed.id} className="border-b border-border/40 hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-2.5 font-bold text-foreground">
                        <a
                          href={`https://www.tradingview.com/chart/?symbol=BYBIT:${seed.symbol.replace("-USDT", "USDT")}`}
                          target="_blank"
                          rel="noreferrer"
                          className="hover:text-primary transition-colors"
                        >
                          {seed.symbol.replace("-USDT", "")}
                        </a>
                      </td>
                      <td className="px-3 py-2.5 text-muted-foreground">{patLabel(seed.sentimentKey)}</td>
                      <td className="px-3 py-2.5 text-right font-mono text-blue-300">
                        {seed.oiAtSeed != null ? `+${seed.oiAtSeed.toFixed(1)}%` : "—"}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-foreground/80">
                        {seed.priceAtSeed != null
                          ? `$${seed.priceAtSeed < 1 ? seed.priceAtSeed.toFixed(5) : seed.priceAtSeed.toFixed(4)}`
                          : "—"}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-muted-foreground">
                        {seed.daysSinceSeeded.toFixed(1)}д
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <SeedStatusBadge oiGrowthPct={seed.oiGrowthPct} days={seed.daysSinceSeeded} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
