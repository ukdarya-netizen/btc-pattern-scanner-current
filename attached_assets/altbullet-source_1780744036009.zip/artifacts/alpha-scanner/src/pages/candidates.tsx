import React, { useEffect, useState } from "react";
import { useGetScannerCandidates, getGetScannerCandidatesQueryKey } from "@workspace/api-client-react";
import type { FilteredCandidate } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Flame, Eye, XCircle, Zap } from "lucide-react";

const PATTERN_NAMES: Record<string, string> = {
  hidden_accumulation: "Скрытое накопление",
  aggressive_breakout: "Агрессивный пробой",
  short_squeeze:       "Short Squeeze",
  bullish_accumulation:"Бычье накопление",
  bear_trap:           "Медвежья ловушка",
  anomaly:             "Аномалия",
  sharp_impulse:       "Резкий импульс",
  impulse_breakout:    "Импульсный пробой",
  volume_flash:        "Объёмная вспышка",
  early_ignition:      "Ранний запал",
  mega_oi:             "Мега-OI",
};

const STANDARD_TFS = ["5m", "30m", "1h", "4h", "24h"] as const;

const TF_COLORS: Record<string, string> = {
  "5m":  "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  "30m": "bg-orange-500/20 text-orange-400 border-orange-500/30",
  "1h":  "bg-red-500/20 text-red-400 border-red-500/30",
  "4h":  "bg-purple-500/20 text-purple-400 border-purple-500/30",
  "24h": "bg-blue-500/20 text-blue-400 border-blue-500/30",
};

const SPECIAL_TF_LABELS: Record<string, { label: string; color: string }> = {
  bingx_volume:  { label: "BX Vol",   color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
  cg_building:   { label: "OI build", color: "bg-teal-500/20 text-teal-400 border-teal-500/30" },
  cg_timeout:    { label: "OI~",      color: "bg-slate-500/20 text-slate-400 border-slate-500/30" },
  dark_flow:     { label: "Dark",     color: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30" },
  fast_track:    { label: "Fast",     color: "bg-green-500/20 text-green-400 border-green-500/30" },
  steady:        { label: "Steady",   color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  "4h_momentum": { label: "4h Mmt",  color: "bg-pink-500/20 text-pink-400 border-pink-500/30" },
};

function TfGrid({ triggerTf }: { triggerTf: string }) {
  if (SPECIAL_TF_LABELS[triggerTf]) {
    const { label, color } = SPECIAL_TF_LABELS[triggerTf]!;
    return (
      <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border ${color}`}>
        {label}
      </span>
    );
  }
  const passing = new Set(triggerTf.split("+").map(s => s.trim()).filter(s => s !== "all"));
  return (
    <div className="flex items-center gap-0.5">
      {STANDARD_TFS.map(tf => {
        const active = passing.has(tf);
        return (
          <span
            key={tf}
            className={`inline-flex items-center px-1 py-0.5 rounded text-[9px] font-mono border ${
              active ? TF_COLORS[tf] : "bg-transparent text-border border-border/30"
            }`}
          >
            {tf}
          </span>
        );
      })}
    </div>
  );
}

function timeAgo(isoOrMs: string | number): string {
  const ms = typeof isoOrMs === "number" ? isoOrMs : new Date(isoOrMs).getTime();
  const diff = Math.floor((Date.now() - ms) / 1000);
  if (diff < 60) return `${diff}с`;
  if (diff < 3600) return `${Math.floor(diff / 60)}м`;
  return `${Math.floor(diff / 3600)}ч`;
}

function expiresIn(isoStr: string): string {
  const diff = Math.floor((new Date(isoStr).getTime() - Date.now()) / 1000);
  if (diff <= 0) return "истёк";
  if (diff < 60) return `${diff}с`;
  if (diff < 3600) return `${Math.floor(diff / 60)}м`;
  return `${Math.floor(diff / 3600)}ч`;
}

// ─── tab nav ──────────────────────────────────────────────────────────────────

type Tab = "oi_watch" | "prescan" | "filtered";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "oi_watch",  label: "OI Watch",    icon: Eye      },
  { id: "prescan",   label: "Prescan",     icon: Flame    },
  { id: "filtered",  label: "Отсеянные",   icon: XCircle  },
];

function TabNav({
  active,
  onChange,
  counts,
}: {
  active: Tab;
  onChange: (t: Tab) => void;
  counts: Record<Tab, number>;
}) {
  return (
    <div className="flex border-b border-border gap-0">
      {TABS.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium tracking-wider transition-colors
            ${active === id
              ? "border-b-2 border-primary text-primary -mb-px"
              : "text-muted-foreground hover:text-foreground"
            }`}
        >
          <Icon className="w-3.5 h-3.5" />
          {label.toUpperCase()}
          <span className={`ml-1 text-[10px] px-1.5 py-0.5 rounded-full font-mono ${
            active === id ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
          }`}>
            {counts[id]}
          </span>
        </button>
      ))}
    </div>
  );
}

// ─── main component ───────────────────────────────────────────────────────────

export default function Candidates() {
  const [tab, setTab] = useState<Tab>("oi_watch");
  const [tick, setTick] = useState(0);

  const { data, isLoading, refetch, dataUpdatedAt } = useGetScannerCandidates({
    query: { queryKey: getGetScannerCandidatesQueryKey(), refetchInterval: 15_000 },
  });

  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 10_000);
    return () => clearInterval(id);
  }, []);

  void tick;

  const prescan  = data?.prescan  ?? [];
  const oiWatch  = data?.oiWatch  ?? [];
  const filtered = data?.filtered ?? [];

  const counts: Record<Tab, number> = {
    oi_watch: oiWatch.length,
    prescan:  prescan.length,
    filtered: filtered.length,
  };

  const lastUpdated = dataUpdatedAt
    ? new Date(dataUpdatedAt).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : "—";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Воронка сканера</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Кандидаты до финального сигнала — обновляется каждые 15с
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">обновлено {lastUpdated}</span>
          <button
            onClick={() => refetch()}
            className="p-1.5 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Pipeline overview */}
      <div className="rounded-lg border border-border bg-muted/10 p-4 text-xs">
        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">Воронка сканера — путь от рынка до сигнала</p>
        <div className="grid grid-cols-4 gap-2">
          <div className="rounded border border-orange-500/25 bg-orange-500/5 p-2.5">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Flame className="w-3 h-3 text-orange-400" />
              <span className="font-semibold text-orange-400 tracking-wide">PRESCAN</span>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              500+ USDT-перп пар ранжируются каждый цикл (≈2–4 мин) по{" "}
              <em>activity score</em>: OI + объём + taker flow. Топ-10–20 попадают в мониторинг.
            </p>
          </div>
          <div className="rounded border border-yellow-500/25 bg-yellow-500/5 p-2.5">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Eye className="w-3 h-3 text-yellow-400" />
              <span className="font-semibold text-yellow-400 tracking-wide">OI WATCH</span>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              90-мин окно наблюдения для горячих кандидатов из prescan.{" "}
              <span className="text-blue-400">Наблюдение</span> — ждём OI ≥ порога.{" "}
              <span className="text-yellow-400">Подтверждение</span> — OI пройден, идёт 7-мин проверка объёма (vol должен быть повышенным).
            </p>
          </div>
          <div className="rounded border border-red-500/25 bg-red-500/5 p-2.5">
            <div className="flex items-center gap-1.5 mb-1.5">
              <XCircle className="w-3 h-3 text-red-400/70" />
              <span className="font-semibold text-red-400/70 tracking-wide">ОТСЕЯННЫЕ</span>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Топ prescan, не прошедшие финальные гейты: CVD заблокировал (покупки не подтверждены), OI ниже порога, памп уже отыгран, spot CVD против.
            </p>
          </div>
          <div className="rounded border border-green-500/25 bg-green-500/5 p-2.5">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Zap className="w-3 h-3 text-green-400" />
              <span className="font-semibold text-green-400 tracking-wide">СИГНАЛ</span>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Все гейты пройдены (OI + объём + CVD + цена + funding) → запись в трекер + уведомление в Telegram.
            </p>
          </div>
        </div>
        <p className="text-[10px] text-muted-foreground mt-2.5 px-0.5">
          <span className="text-orange-400 font-medium">Prescan</span> и{" "}
          <span className="text-yellow-400 font-medium">OI Watch</span> — независимые фазы, работают параллельно.{" "}
          Vol 1.0x = норма (не подтверждает), vol ≥ 1.5–2x = повышенный (подтверждает).
        </p>
      </div>

      {/* Tab nav + content card */}
      <Card>
        <CardHeader className="pb-0 pt-4 px-4">
          <TabNav active={tab} onChange={setTab} counts={counts} />
        </CardHeader>

        <CardContent className="pt-4">

          {/* ── OI Watch ── */}
          {tab === "oi_watch" && (
            <>
              <div className="flex items-center gap-2 mb-4">
                <Eye className="w-4 h-4 text-orange-400" />
                <span className="text-sm font-medium">Ждут подтверждения объёма</span>
                <Badge variant="outline" className="text-xs ml-auto">{oiWatch.length}</Badge>
              </div>
              {oiWatch.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-8">
                  {isLoading ? "Загрузка…" : "Очередь пуста — сигналов нет"}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        <th className="text-left py-2 pr-4 font-medium">Символ</th>
                        <th className="text-left py-2 pr-4 font-medium">Статус</th>
                        <th className="text-left py-2 pr-4 font-medium">ТФ</th>
                        <th className="text-right py-2 pr-4 font-medium">5m</th>
                        <th className="text-right py-2 pr-4 font-medium">30m</th>
                        <th className="text-right py-2 pr-4 font-medium">1h</th>
                        <th className="text-right py-2 pr-4 font-medium">Объём</th>
                        <th className="text-left py-2 pr-4 font-medium">Паттерн</th>
                        <th className="text-right py-2 font-medium">Истекает</th>
                      </tr>
                    </thead>
                    <tbody>
                      {oiWatch.map((row) => (
                        <tr key={row.id} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                          <td className="py-2 pr-4">
                            <a
                              href={`https://www.tradingview.com/chart/?symbol=BINGX:${row.symbol.replace("-", "")}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-mono font-semibold text-primary hover:underline"
                            >
                              {row.symbol.replace("-USDT", "")}
                            </a>
                          </td>
                          <td className="py-2 pr-4">
                            {row.status === "confirming" ? (
                              <Badge className="text-[10px] bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                                подтверждение
                              </Badge>
                            ) : (
                              <Badge className="text-[10px] bg-blue-500/20 text-blue-400 border-blue-500/30">
                                наблюдение
                              </Badge>
                            )}
                          </td>
                          <td className="py-2 pr-4">
                            <TfGrid triggerTf={row.triggerTf} />
                          </td>
                          {(["oi5m", "oi30m", "oi1h"] as const).map(key => {
                            const val = row[key];
                            return (
                              <td key={key} className="py-2 pr-4 text-right font-mono text-[11px]">
                                {val != null ? (
                                  <span className={val >= 5 ? "text-green-400 font-semibold" : val > 0 ? "text-green-400/70" : "text-red-400/70"}>
                                    {val >= 0 ? "+" : ""}{val.toFixed(1)}%
                                  </span>
                                ) : (
                                  <span className="text-border">—</span>
                                )}
                              </td>
                            );
                          })}
                          <td className="py-2 pr-4 text-right font-mono">
                            {row.volumeMultiplier.toFixed(1)}x
                          </td>
                          <td className="py-2 pr-4 text-muted-foreground">
                            {row.sentimentKey ? (PATTERN_NAMES[row.sentimentKey] ?? row.sentimentKey) : "—"}
                          </td>
                          <td className="py-2 text-right">
                            <span className="text-muted-foreground font-mono">
                              {expiresIn(row.expiresAt)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground mt-3 px-1">
                OI-порог пройден, ждём подтверждения объёма (один шаг до сигнала).{" "}
                <span className="text-yellow-400">Подтверждение</span> = 7-мин окно проверки устойчивости. ТФ-сетка: <span className="text-yellow-400">5m</span> /{" "}
                <span className="text-orange-400">30m</span> / <span className="text-red-400">1h</span> /{" "}
                <span className="text-purple-400">4h</span> / <span className="text-blue-400">24h</span>.
              </p>
            </>
          )}

          {/* ── Prescan ── */}
          {tab === "prescan" && (
            <>
              <div className="flex items-center gap-2 mb-4">
                <Flame className="w-4 h-4 text-red-400" />
                <span className="text-sm font-medium">Горячие кандидаты текущего цикла</span>
                <Badge variant="outline" className="text-xs ml-auto">{prescan.length}</Badge>
              </div>
              {prescan.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-8">
                  {isLoading ? "Загрузка…" : "Нет кандидатов — сканер ещё не завершил цикл или сервер только запустился"}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        <th className="text-left py-2 pr-3 font-medium">Ранг</th>
                        <th className="text-left py-2 pr-3 font-medium">Символ</th>
                        <th className="text-right py-2 pr-3 font-medium">Скор</th>
                        <th className="text-right py-2 pr-3 font-medium">24h%</th>
                        <th className="text-right py-2 pr-3 font-medium">1h%</th>
                        <th className="text-right py-2 pr-3 font-medium">Движ.</th>
                        <th className="text-right py-2 pr-3 font-medium">OI 5m</th>
                        <th className="text-right py-2 pr-3 font-medium">OI 30m</th>
                        <th className="text-right py-2 pr-3 font-medium">OI 1h</th>
                        <th className="text-right py-2 pr-3 font-medium">OI 4h</th>
                        <th className="text-right py-2 pr-3 font-medium">OI 24h</th>
                        <th className="text-right py-2 pr-3 font-medium">Taker</th>
                        <th className="text-center py-2 pr-3 font-medium">CVD</th>
                        <th className="text-right py-2 font-medium">Циклов</th>
                      </tr>
                    </thead>
                    <tbody>
                      {prescan.map((row) => (
                        <tr key={row.symbol} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                          <td className="py-2 pr-3">
                            <span className={`font-mono font-bold ${
                              row.bestRank <= 3  ? "text-yellow-400" :
                              row.bestRank <= 10 ? "text-orange-400" : "text-muted-foreground"
                            }`}>
                              #{row.bestRank}
                            </span>
                          </td>
                          <td className="py-2 pr-3">
                            <a
                              href={`https://www.tradingview.com/chart/?symbol=BINGX:${row.symbol.replace("-", "")}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-mono font-semibold text-primary hover:underline"
                            >
                              {row.symbol.replace("-USDT", "")}
                            </a>
                          </td>
                          <td className="py-2 pr-3 text-right">
                            <span className="font-mono text-cyan-400 font-semibold">
                              {row.lastScore.toFixed(0)}
                            </span>
                          </td>
                          <td className="py-2 pr-3 text-right">
                            <span className={row.lastPrice24h >= 10 ? "text-green-400 font-semibold" : "text-green-400"}>
                              +{row.lastPrice24h.toFixed(1)}%
                            </span>
                          </td>
                          <td className="py-2 pr-3 text-right font-mono text-[11px]">
                            {row.lastPrice1h != null ? (
                              <span className={
                                row.lastPrice1h >= 3  ? "text-green-400 font-semibold" :
                                row.lastPrice1h >= 0  ? "text-green-400/70" :
                                row.lastPrice1h >= -2 ? "text-red-400/60" :
                                "text-red-400 font-semibold"
                              }>
                                {row.lastPrice1h >= 0 ? "+" : ""}{row.lastPrice1h.toFixed(2)}%
                              </span>
                            ) : <span className="text-border">—</span>}
                          </td>
                          <td className="py-2 pr-3 text-right font-mono text-[11px]">
                            {row.priceMovePct != null ? (
                              <span className={
                                row.priceMovePct >= 2  ? "text-green-400 font-semibold" :
                                row.priceMovePct >= 0  ? "text-green-400/60" :
                                "text-red-400/70"
                              }>
                                {row.priceMovePct >= 0 ? "+" : ""}{row.priceMovePct.toFixed(2)}%
                              </span>
                            ) : <span className="text-border">—</span>}
                          </td>
                          {([
                            [row.lastOi5m,  "5m"],
                            [row.lastOi30m, "30m"],
                            [row.lastOi1h,  "1h"],
                            [row.lastOi4h,  "4h"],
                            [row.lastOi24h, "24h"],
                          ] as [number | null | undefined, string][]).map(([val, tf]) => (
                            <td key={tf} className="py-2 pr-3 text-right font-mono text-[11px]">
                              {val != null ? (
                                <span className={
                                  val >= 5  ? "text-orange-400 font-semibold" :
                                  val >= 1  ? "text-yellow-400" :
                                  val >= 0  ? "text-muted-foreground" :
                                  "text-red-400/60"
                                }>
                                  {val >= 0 ? "+" : ""}{val.toFixed(1)}%
                                </span>
                              ) : <span className="text-border/40">—</span>}
                            </td>
                          ))}
                          <td className="py-2 pr-3 text-right font-mono">
                            {row.lastNetBuyPct != null ? (
                              <span className={
                                row.lastNetBuyPct >= 10 ? "text-green-400 font-semibold" :
                                row.lastNetBuyPct >= 0  ? "text-green-400/60" :
                                "text-red-400"
                              }>
                                {row.lastNetBuyPct >= 0 ? "+" : ""}{row.lastNetBuyPct.toFixed(1)}%
                              </span>
                            ) : <span className="text-border">—</span>}
                          </td>
                          <td className="py-2 pr-3 text-center">
                            {row.lastCvdOk != null ? (
                              row.lastCvdOk
                                ? <span className="text-green-400 font-bold">✓</span>
                                : <span className="text-red-400/60">✗</span>
                            ) : <span className="text-border text-[10px]">—</span>}
                          </td>
                          <td className="py-2 text-right">
                            <span className={`font-mono ${row.cycleCount >= 3 ? "text-orange-400 font-semibold" : "text-muted-foreground"}`}>
                              {row.cycleCount}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground mt-3 px-1">
                Топ по activity score из 500+ пар. Ранги: <span className="text-yellow-400">топ-3</span> / <span className="text-orange-400">топ-10</span>.{" "}
                <span className="text-green-400 font-medium">Taker</span> — netBuyPct из CoinGlass (&gt;0% = нетто-покупки).{" "}
                <span className="text-green-400 font-medium">CVD ✓</span> = 2 цикла нетто-покупок подтверждены.
              </p>
            </>
          )}

          {/* ── Filtered / Отсеянные ── */}
          {tab === "filtered" && (
            <>
              <div className="flex items-center gap-2 mb-4">
                <XCircle className="w-4 h-4 text-red-400/70" />
                <span className="text-sm font-medium">Топ-10 prescan — причины пропуска</span>
                <Badge variant="outline" className="text-xs ml-auto">{filtered.length}</Badge>
              </div>
              {filtered.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-8">
                  {isLoading ? "Загрузка…" : "Нет данных — появится после первого цикла сканера"}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground">
                        <th className="text-left py-2 pr-3 font-medium">Символ</th>
                        <th className="text-left py-2 pr-3 font-medium">Причина отсева</th>
                        <th className="text-right py-2 pr-2 font-medium">OI 5m</th>
                        <th className="text-right py-2 pr-2 font-medium">OI 30m</th>
                        <th className="text-right py-2 pr-2 font-medium">OI 1h</th>
                        <th className="text-right py-2 pr-2 font-medium">OI 4h</th>
                        <th className="text-right py-2 pr-2 font-medium">OI 24h</th>
                        <th className="text-right py-2 pr-2 font-medium">Объём</th>
                        <th className="text-right py-2 pr-2 font-medium">Цена</th>
                        <th className="text-right py-2 font-medium">Когда</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((row: FilteredCandidate) => {
                        const reasonColor =
                          row.reason === "oi_filter"        ? "bg-orange-500/15 text-orange-400 border-orange-500/30" :
                          row.reason === "cvd_blocked"      ? "bg-blue-500/15 text-blue-400 border-blue-500/30" :
                          row.reason === "oi_24h_drop"      ? "bg-purple-500/15 text-purple-400 border-purple-500/30" :
                          row.reason.startsWith("oi_contra") ? "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" :
                          "bg-muted/30 text-muted-foreground border-border";

                        const fmtOI = (v: number | null) =>
                          v != null ? (
                            <span className={
                              v >= 5  ? "text-orange-400 font-semibold" :
                              v >= 1  ? "text-yellow-400" :
                              v >= 0  ? "text-muted-foreground" :
                              "text-red-400"
                            }>
                              {v >= 0 ? "+" : ""}{v.toFixed(1)}%
                            </span>
                          ) : <span className="text-border/40">—</span>;

                        return (
                          <tr key={row.symbol + row.filteredAt} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                            <td className="py-2 pr-3">
                              <a
                                href={`https://www.tradingview.com/chart/?symbol=BINGX:${row.symbol.replace("-", "")}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="font-mono font-semibold text-primary hover:underline"
                              >
                                {row.symbol.replace("-USDT", "")}
                              </a>
                            </td>
                            <td className="py-2 pr-3">
                              <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border ${reasonColor}`}>
                                {row.reasonLabel}
                              </span>
                            </td>
                            <td className="py-2 pr-2 text-right font-mono text-[11px]">{fmtOI(row.oi5m)}</td>
                            <td className="py-2 pr-2 text-right font-mono text-[11px]">{fmtOI(row.oi30m)}</td>
                            <td className="py-2 pr-2 text-right font-mono text-[11px]">{fmtOI(row.oi1h)}</td>
                            <td className="py-2 pr-2 text-right font-mono text-[11px]">{fmtOI(row.oi4h)}</td>
                            <td className="py-2 pr-2 text-right font-mono text-[11px]">{fmtOI(row.oi24h)}</td>
                            <td className="py-2 pr-2 text-right font-mono">
                              {row.vol != null ? (
                                <span className={row.vol >= 3 ? "text-cyan-400 font-semibold" : "text-muted-foreground"}>
                                  {row.vol.toFixed(1)}x
                                </span>
                              ) : <span className="text-border/40">—</span>}
                            </td>
                            <td className="py-2 pr-2 text-right font-mono text-[11px]">
                              {row.price != null ? (
                                <span className={row.price >= 0 ? "text-green-400/80" : "text-red-400/80"}>
                                  {row.price >= 0 ? "+" : ""}{row.price.toFixed(1)}%
                                </span>
                              ) : <span className="text-border/40">—</span>}
                            </td>
                            <td className="py-2 text-right text-muted-foreground font-mono">
                              {timeAgo(row.filteredAt)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground mt-3 px-1">
                Только монеты из <span className="text-foreground/60 font-medium">топ-10 pre-screen</span> текущего цикла.{" "}
                Цвет бейджа: <span className="text-orange-400 font-medium">OI ниже порога</span> ·{" "}
                <span className="text-blue-400 font-medium">CVD заблокировал</span> ·{" "}
                <span className="text-purple-400 font-medium">памп отыгран</span> ·{" "}
                <span className="text-yellow-400 font-medium">OI-противоречие</span>
              </p>
            </>
          )}

        </CardContent>
      </Card>
    </div>
  );
}
