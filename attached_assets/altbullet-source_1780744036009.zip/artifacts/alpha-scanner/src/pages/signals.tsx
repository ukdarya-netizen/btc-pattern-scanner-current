import { useGetSignals, getGetSignalsQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { SignalBadge } from "@/components/signal-badge";
import { SentimentBadge } from "@/components/sentiment-badge";
import { ExternalLink, ChevronLeft, ChevronRight } from "lucide-react";

type SignalFilterType = "all" | "alpha" | "super_alpha" | "short_sniper";

type StatusConfig = {
  label: string;
  className: string;
  rowClass: string;
};

function getStatusConfig(ts: string | null | undefined, isWhaleSeed: boolean): StatusConfig | null {
  if (!ts || ts === "active") return null;

  if (ts === "cancelled" && isWhaleSeed) return {
    label: "🐋 WHALE",
    className: "text-cyan-300 border-cyan-500/40 bg-cyan-950/40",
    rowClass: "bg-cyan-950/10",
  };
  if (ts === "cancelled") return {
    label: "🚫 CANCEL",
    className: "text-zinc-400 border-zinc-500/40 bg-zinc-800/40",
    rowClass: "opacity-50 bg-zinc-900/30",
  };
  if (ts === "profit") return {
    label: "✅ PROFIT",
    className: "text-green-400 border-green-500/40 bg-green-950/40",
    rowClass: "bg-green-950/10",
  };
  if (ts === "bu_stop") return {
    label: "🎯 BU STOP",
    className: "text-emerald-300 border-emerald-500/40 bg-emerald-950/40",
    rowClass: "bg-emerald-950/10",
  };
  if (ts === "stop_loss") return {
    label: "❌ STOP",
    className: "text-red-400 border-red-500/40 bg-red-950/40",
    rowClass: "bg-red-950/10",
  };
  if (ts === "breakeven") return {
    label: "⚖️ B/E",
    className: "text-yellow-500 border-yellow-600/40 bg-yellow-950/30",
    rowClass: "",
  };
  if (ts === "in_run") return {
    label: "🚀 IN RUN",
    className: "text-orange-300 border-orange-500/40 bg-orange-950/30",
    rowClass: "bg-orange-950/15",
  };
  if (ts === "accumulation") return {
    label: "🔵 ACCUM",
    className: "text-blue-300 border-blue-500/40 bg-blue-950/40",
    rowClass: "bg-blue-950/10",
  };
  if (ts === "re_entry") return {
    label: "🔄 RE-ENTRY",
    className: "text-purple-300 border-purple-500/40 bg-purple-950/40",
    rowClass: "bg-purple-950/10",
  };
  return {
    label: ts.toUpperCase().replace("_", " "),
    className: "text-blue-400 border-blue-500/40 bg-blue-950/30",
    rowClass: "",
  };
}

function hasPnl(ts: string | null | undefined): boolean {
  return ts === "profit" || ts === "bu_stop" || ts === "stop_loss" || ts === "breakeven";
}

export default function Signals() {
  const [type, setType] = useState<SignalFilterType>("all");

  const signalParams = { limit: 50, type: type === "all" ? undefined : type };
  const { data, isLoading } = useGetSignals(
    signalParams,
    { query: { queryKey: getGetSignalsQueryKey(signalParams), refetchInterval: 10000 } }
  );

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wider">SIGNAL HISTORY</h2>

        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">FILTER:</span>
          <Select value={type} onValueChange={(val) => setType(val as SignalFilterType)}>
            <SelectTrigger className="w-[200px] bg-card border-border">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ALL SIGNALS</SelectItem>
              <SelectItem value="super_alpha">⚡⚡ SUPER BULLET</SelectItem>
              <SelectItem value="alpha">⚡ BULLET</SelectItem>
              <SelectItem value="short_sniper">📉 SHORT SNIPER</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="border-border bg-card flex-1 flex flex-col overflow-hidden">
        <CardContent className="p-0 flex-1 overflow-auto">
          {isLoading ? (
            <div className="flex items-center justify-center h-64 text-muted-foreground">
              SCANNING DATABASE...
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-card border-b border-border z-10">
                <tr className="text-muted-foreground text-left">
                  <th className="px-4 py-3 font-medium">TIME (UTC)</th>
                  <th className="px-4 py-3 font-medium">SYMBOL</th>
                  <th className="px-4 py-3 font-medium">GRADE</th>
                  <th className="px-4 py-3 font-medium">PATTERN</th>
                  <th className="px-4 py-3 font-medium text-center">SCORE</th>
                  <th className="px-4 py-3 font-medium text-right">PRICE</th>
                  <th className="px-4 py-3 font-medium text-right">VOL</th>
                  <th className="px-4 py-3 font-medium text-right">OI%</th>
                  <th className="px-4 py-3 font-medium text-center">STATUS</th>
                </tr>
              </thead>
              <tbody>
                {data?.signals.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">
                      NO SIGNALS FOUND MATCHING CRITERIA.
                    </td>
                  </tr>
                ) : (
                  data?.signals.map((signal) => {
                    const sig = signal as any;
                    const score: number = sig.alphaScore ?? 0;
                    const scoreColor =
                      score >= 8 ? "text-yellow-300" :
                      score >= 6 ? "text-blue-300" :
                      score >= 4 ? "text-green-400" : "text-muted-foreground";

                    const ts = signal.trackedStatus as string | null | undefined;
                    const pnl = signal.trackedPnl as number | null | undefined;
                    const isWhaleSeed = Boolean(signal.isWhaleSeed);
                    const cfg = getStatusConfig(ts, isWhaleSeed);

                    const rowCls = cfg?.rowClass
                      ?? (signal.type === "short_sniper" ? "bg-red-950/10 hover:bg-red-950/20" : "");

                    return (
                      <tr key={signal.id} className={`border-b border-border/50 hover:bg-muted/50 transition-colors ${rowCls}`}>
                        <td className="px-4 py-3 text-muted-foreground font-mono text-xs">
                          {new Date(signal.detectedAt).toLocaleString("ru-RU", {
                            month: "2-digit", day: "2-digit",
                            hour: "2-digit", minute: "2-digit",
                          })}
                        </td>
                        <td className="px-4 py-3 font-bold text-foreground font-mono">
                          {signal.symbol}
                        </td>
                        <td className="px-4 py-3">
                          <SignalBadge type={signal.type} />
                        </td>
                        <td className="px-4 py-3">
                          <SentimentBadge sentimentKey={sig.sentimentKey ?? "anomaly"} label={sig.sentiment ?? "—"} />
                        </td>
                        <td className="px-4 py-3 text-center">
                          {score > 0 ? (
                            <span className={`font-mono font-bold text-sm ${scoreColor}`}>
                              {score}<span className="text-muted-foreground text-xs">/10</span>
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs">
                          <div>${signal.price < 1 ? signal.price.toFixed(6) : signal.price.toFixed(4)}</div>
                          <div className={`text-xs ${signal.priceChangePercent >= 0 ? "text-green-500" : "text-red-500"}`}>
                            {signal.priceChangePercent > 0 ? "+" : ""}{signal.priceChangePercent.toFixed(2)}%
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-muted-foreground text-xs">
                          {signal.value.toFixed(1)}x
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs">
                          {signal.oiChangePercent != null ? (
                            <span className={signal.oiChangePercent >= 0 ? "text-green-400" : "text-red-400"}>
                              {signal.oiChangePercent >= 0 ? "+" : ""}{signal.oiChangePercent.toFixed(1)}%
                            </span>
                          ) : "—"}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <div className="flex flex-col items-center gap-1">
                            {cfg ? (
                              <span className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-none border ${cfg.className}`}>
                                {cfg.label}
                              </span>
                            ) : (
                              <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-none border text-zinc-500 border-zinc-700/40 bg-zinc-900/20">
                                🟡 ACTIVE
                              </span>
                            )}
                            {pnl != null && hasPnl(ts) && (
                              <span className={`font-mono text-[10px] ${pnl >= 0 ? "text-green-400" : "text-red-400"}`}>
                                {pnl > 0 ? "+" : ""}{pnl.toFixed(1)}%
                              </span>
                            )}
                            <a
                              href={signal.tradingViewUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-zinc-600 hover:text-primary transition-colors"
                              title="TradingView"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          )}
        </CardContent>
        <div className="p-4 border-t border-border flex items-center justify-between bg-card text-sm text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>SHOWING {data?.signals.length ?? 0} OF {data?.total ?? 0} SIGNALS</span>
            <div className="flex flex-wrap gap-2 text-[10px]">
              <span className="text-zinc-500 border border-zinc-700/40 px-1">🟡 ACTIVE</span>
              <span className="text-blue-300 border border-blue-500/30 px-1">🔵 ACCUM</span>
              <span className="text-purple-300 border border-purple-500/30 px-1">🔄 RE-ENTRY</span>
              <span className="text-orange-300 border border-orange-500/30 px-1">🚀 IN RUN</span>
              <span className="text-green-400 border border-green-500/30 px-1">✅ PROFIT</span>
              <span className="text-emerald-300 border border-emerald-500/30 px-1">🎯 BU STOP</span>
              <span className="text-yellow-500 border border-yellow-600/30 px-1">⚖️ B/E</span>
              <span className="text-red-400 border border-red-500/30 px-1">❌ STOP</span>
              <span className="text-zinc-400 border border-zinc-500/30 px-1">🚫 CANCEL</span>
              <span className="text-cyan-300 border border-cyan-500/30 px-1">🐋 WHALE</span>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" disabled className="h-8 border-border">
              <ChevronLeft className="w-4 h-4 mr-1" /> PREV
            </Button>
            <Button variant="outline" size="sm" disabled className="h-8 border-border">
              NEXT <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
