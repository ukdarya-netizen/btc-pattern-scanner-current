import { logger } from "./logger.js";
import { getFutureTickers, getKlines, getOpenInterest, getFundingRate, testConnection as testBingX, fetchCVD, getOrderBookAnalysis, type BingXTicker, type OrderBookAnalysis } from "./bingx.js";
import { broadcastBatchAlert, testConnection as testTelegram } from "./telegram.js";
import { trackSignal } from "./watcher.js";
import { getTrendingRank } from "./trending.js";
import { getLiquidations } from "./liquidations.js";
import { batchGetCoinglassOI, clearCoinglassOICache, type CoinglassOIResult } from "./coinglass_oi.js";
import { getCoinalyzeOI } from "./coinalyze.js";
import { db, signalsTable, settingsTable, oiBaselinesTable, oiWatchTable, trackedSignalsTable, type InsertSignal } from "@workspace/db";
import { gte, sql, eq, and, inArray, isNull, or } from "drizzle-orm";

export interface ScannerState {
  running: boolean;
  lastScanAt: Date | null;
  nextScanAt: Date | null;
  marketsScanned: number;
  scanIntervalMs: number;
  bingxConnected: boolean;
  telegramConnected: boolean;
}

const state: ScannerState = {
  running: false,
  lastScanAt: null,
  nextScanAt: null,
  marketsScanned: 0,
  scanIntervalMs: 600_000,
  bingxConnected: false,
  telegramConnected: false,
};

/**
 * Персистентный кеш глобальных объёмов из CoinGlass (volUsd).
 * Накапливается между сканами — не сбрасывается.
 * Ключ: baseSymbol без USDT (например "DYDX"), значение: volUsd в USD.
 * После 1-го скана используется вместо BingX-объёма для пре-скрина Layer 2.
 */
const cgVolumeCache = new Map<string, number>();

// ── In-memory state ─────────────────────────────────────────────────────────

/**
 * OI baseline — time-based.
 * Activity-score approach: the same "hot" tokens are scanned every 10 min,
 * so we can build baselines quickly and measure OI delta over ~20-60 min.
 */
interface OIBaseline {
  oi: number;
  takenAt: number;
}
const oiBaseline = new Map<string, OIBaseline>();
// Hot tokens are rescanned every 10 min — measure OI over a ~20-60 min window
const MIN_BASELINE_AGE_MS = 20 * 60 * 1000;   // update baseline no more than once per 20 min
const MAX_BASELINE_AGE_MS = 60 * 60 * 1000;   // baseline older than 60 min is too stale

/** Load OI baselines from DB on startup so restarts don't cause blind spots */
async function loadBaselinesFromDb(): Promise<void> {
  try {
    const rows = await db.select().from(oiBaselinesTable);
    const cutoff = Date.now() - MAX_BASELINE_AGE_MS;
    let loaded = 0;
    for (const row of rows) {
      const takenAt = row.takenAt.getTime();
      if (takenAt >= cutoff) {
        oiBaseline.set(row.symbol, { oi: row.oi, takenAt });
        loaded++;
      }
    }
    logger.info({ loaded, total: rows.length }, "OI baselines loaded from DB");
  } catch (err) {
    logger.warn({ err }, "Failed to load OI baselines from DB — starting fresh");
  }
}

let _lastBaselinePersist = 0;
const BASELINE_PERSIST_INTERVAL_MS = 5 * 60 * 1000; // persist to DB every 5 min

/** Persist changed baselines to DB (called after each scan) */
async function persistBaselinesToDb(): Promise<void> {
  const now = Date.now();
  if (now - _lastBaselinePersist < BASELINE_PERSIST_INTERVAL_MS) return;
  _lastBaselinePersist = now;
  try {
    const values = [...oiBaseline.entries()].map(([symbol, b]) => ({
      symbol,
      oi: b.oi,
      takenAt: new Date(b.takenAt),
    }));
    if (values.length === 0) return;
    await db.insert(oiBaselinesTable)
      .values(values)
      .onConflictDoUpdate({ target: oiBaselinesTable.symbol, set: { oi: sql`excluded.oi`, takenAt: sql`excluded.taken_at` } });
    logger.debug({ count: values.length }, "OI baselines persisted to DB");
  } catch (err) {
    logger.warn({ err }, "Failed to persist OI baselines to DB");
  }
}

interface SymbolSignalState {
  firstSignalAt: Date;
  signalCount: number;
  cumulativeOiChange: number;
}
const signalHistory = new Map<string, SymbolSignalState>();

let scanTimer: ReturnType<typeof setTimeout> | null = null;

// ── Settings ────────────────────────────────────────────────────────────────
async function getSettings() {
  const rows = await db.select().from(settingsTable).limit(1);
  if (rows.length === 0) {
    const inserted = await db.insert(settingsTable).values({
      volumeMultiplier: 3,
      oiChangePercent: 5,
      fundingRateThreshold: 0.0005,
      scanIntervalMs: 300_000,
      telegramEnabled: true,
      maxSymbols: 100,
    }).returning();
    return inserted[0];
  }
  return rows[0];
}

// ── Sentiment patterns ───────────────────────────────────────────────────────
export type SentimentKey =
  | "hidden_accumulation"
  | "aggressive_breakout"
  | "short_squeeze"
  | "bullish_accumulation"
  | "bearish_pressure"
  | "bear_trap"
  | "anomaly"
  | "sharp_impulse"
  | "impulse_breakout"
  | "volume_flash";

export interface SentimentResult {
  key: SentimentKey;
  label: string;
  traderAction: string;
  /** Does this pattern require OI to be FALLING instead of rising? */
  oiFalling: boolean;
}

/**
 * Determine sentiment pattern based on price, OI change direction/magnitude and volume.
 *
 * Pattern priority (first match wins):
 * 1. Short Squeeze      — OI falling, price sharply up, liq ≥ 2x
 * 2. Дистрибуция        — OI falling, price stagnant/slowing
 * 3. Скрытое накопление — OI high, price almost flat (pre-pump)
 * 4. Bear Trap          — OI rising sharply + price drops (shorts crowding in = squeeze setup)
 * 5. Агрессивный пробой — OI very high, vol very high, price big move
 * 6. Бычье накопление   — OI rising, price positive
 * 7. Медвежье давление  — OI rising, price negative
 * 8. Аномальная         — fallback
 */
/**
 * OI кепы зависят от таймфрейма который сработал.
 * 30m OI = 14% это поздно (памп уже идёт). 4h OI = 14% это тихое накопление за часы.
 *
 * triggerTf примеры: "30m", "5m+30m", "1h", "4h", "24h", "steady", "fast_track", "bingx_volume"
 */
function getOiCaps(triggerTf: string): { hiddenMax: number; bullishMax: number } {
  // Используем \b (word boundary) чтобы "4h_momentum" не совпало с "4h".
  // "4h_momentum" — паттерн цены, не 4h OI → применяем короткий кеп как для 30m.
  if (/\b24h\b/.test(triggerTf)) return { hiddenMax: 30, bullishMax: 50 };
  if (/\b4h\b/.test(triggerTf))  return { hiddenMax: 25, bullishMax: 35 };
  if (/\b1h\b/.test(triggerTf))  return { hiddenMax: 15, bullishMax: 20 };
  // 30m, 5m, steady, fast_track, bingx_volume, 4h_momentum, confirm — жёсткий кеп
  return { hiddenMax: 10, bullishMax: 15 };
}

function detectSentiment(
  priceChange: number,
  oiChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  triggerTf: string = "30m",
): SentimentResult {
  const { hiddenMax, bullishMax } = getOiCaps(triggerTf);
  // 1. Short Squeeze: OI falling sharply (shorts force-closed) + price rising + vol spike.
  // Raised OI threshold -2 → -5% to cut noise: weak OI dip can be normal profit-taking,
  // not a real squeeze.
  if (oiChange < -5 && priceChange > 2 && volumeMultiplier >= 4) {
    return {
      key: "short_squeeze",
      label: "Short Squeeze",
      traderAction: "SCALP LONG / Фиксация лонга",
      oiFalling: true,
    };
  }

  // 3. Hidden Accumulation — требуем ПОДТВЕРЖДЕНИЕ покупок.
  // OI range 6–15%: свежее накопление умных денег (не старое, не навязшее).
  //
  // ВХОД РАЗРЕШЁН только в двух случаях:
  // A) Цена уже начала движение вверх (+2% до +8%) — покупки РЕАЛЬНЫЕ, подтверждены
  // B) Дип-выкуп: цена слегка упала (–0.5% до –3%) при росте OI — умные деньги откупают
  //
  // ЗАПРЕЩЕНО: мёртвая зона (price –0.5% до +2%) = flat + OI → только в OI Watch, не в сигнал.
  // Исторические данные: WAVES(flat+34.8%), BB(flat+18%), UB(flat+16%) — все failed.
  // LUMIA(+13%, OI 8.8%), NAORIS(–0.87%, OI 6.9%) — win.

  // 3A. Подтверждённый разгон: OI + цена уже движется
  // Кеп зависит от ТФ: 30m ≤10% (данные: OI>10% на 30m = ловушка), 4h ≤25%, 24h ≤30%.
  // Логика: 4h OI 14% = тихое накопление за часы. 30m OI 14% = уже опоздали.
  if (oiChange >= 6 && oiChange <= hiddenMax && priceChange >= 2.0 && priceChange <= 8.0 && volumeMultiplier >= 1.3) {
    return {
      key: "hidden_accumulation",
      label: "Скрытое накопление",
      traderAction: "LONG (вход в начале движения)",
      oiFalling: false,
    };
  }

  // 3B. Дип-выкуп: OI растёт пока цена снижается — умные деньги откупают дип
  if (oiChange >= 6 && oiChange <= hiddenMax && priceChange >= -3.0 && priceChange < -0.5 && volumeMultiplier >= 2.0) {
    return {
      key: "hidden_accumulation",
      label: "Скрытое накопление",
      traderAction: "LONG (выкуп дипа, ждать разворота)",
      oiFalling: false,
    };
  }

  // 4. Bear Trap: price drops sharply BUT OI rises strongly = shorts crowding in.
  // Smart money is on the other side absorbing the selling — classic squeeze setup.
  if (oiChange >= 5 && priceChange < -3) {
    return {
      key: "bear_trap",
      label: "Медвежья ловушка",
      traderAction: "LONG при развороте (ждать подтверждение)",
      oiFalling: false,
    };
  }

  // 5. Aggressive Breakout: price > 3% + volume ≥ 5x + OI rising (new longs opening).
  // If OI is falling with a price spike → that's Short Squeeze (shorts closing), NOT breakout
  // (fresh longs entering). Require oiChange > 0 to distinguish the two.
  if (volumeMultiplier >= 5 && priceChange > 3 && oiChange > 0) {
    return {
      key: "aggressive_breakout",
      label: "Агрессивный пробой",
      traderAction: "LONG по тренду (импульс запущен)",
      oiFalling: false,
    };
  }

  // 6. Bullish Accumulation — кеп зависит от ТФ (bullishMax)
  if (priceChange > 1.5 && oiChange > 5 && oiChange <= bullishMax) {
    return {
      key: "bullish_accumulation",
      label: "Бычье накопление",
      traderAction: "LONG",
      oiFalling: false,
    };
  }

  // 7. Bearish Pressure: tightened from (price < 0, OI > 3%) to (price < -2%, OI > 5%).
  // Captures only genuinely aggressive market shorts, not minor OI tick-ups.
  if (priceChange < -2 && oiChange > 5) {
    return {
      key: "bearish_pressure",
      label: "Медвежье давление",
      traderAction: "SHORT / Осторожность",
      oiFalling: false,
    };
  }

  return {
    key: "anomaly",
    label: "Аномальная активность",
    traderAction: "Наблюдение",
    oiFalling: false,
  };
}

// ── Alpha Score 1–10 ─────────────────────────────────────────────────────────
/**
 * Score breakdown (max 10):
 *   OI strength     0 – 3.5
 *   Volume          0 – 3.0
 *   Price action    0 – 0.5
 *   CMC trending    0 – 2.0  (flat +2 if any trending entry found)
 *   Liquidations    0 – 2.0  (capped at 10 total)
 *
 * Reference from spec (v3.0):
 *   OI + Vol only       ≈ 4–6
 *   OI + Vol + CMC      ≈ 6–8
 *   OI + Vol + CMC + Liq → 8–10 (SUPER ALPHA)
 */
function calcAlphaScore(params: {
  oiChange: number;
  volumeMultiplier: number;
  priceChange: number;
  sentimentKey: SentimentKey;
  cmcAvailable: boolean;
  cmcRank: number | null;
  coinglassAvailable: boolean;
  liquidationsMultiple: number | null;
  fundingRate?: number | null;
}): number {
  const absOI = Math.abs(params.oiChange);
  const absPrice = Math.abs(params.priceChange);

  // OI component (0 – 3.5)
  const oiScore =
    absOI >= 20 ? 3.5 :
    absOI >= 15 ? 3.0 :
    absOI >= 10 ? 2.5 :
    absOI >= 7  ? 2.0 :
    absOI >= 5  ? 1.5 :
    absOI >= 3  ? 1.0 : 0.5;

  // Volume component (0 – 3.0)
  const volScore =
    params.volumeMultiplier >= 10 ? 3.0 :
    params.volumeMultiplier >= 7  ? 2.5 :
    params.volumeMultiplier >= 5  ? 2.0 :
    params.volumeMultiplier >= 4  ? 1.5 :
    params.volumeMultiplier >= 3  ? 1.0 : 0.5;

  // Price action (0 – 0.5)
  let priceScore = 0;
  if (params.sentimentKey === "hidden_accumulation") {
    // low price movement is GOOD for this pattern
    priceScore = absPrice < 1.5 ? 0.5 : 0.25;
  } else {
    priceScore =
      absPrice >= 6 ? 0.5 :
      absPrice >= 4 ? 0.4 :
      absPrice >= 2 ? 0.3 : 0.1;
  }

  // CMC trending: flat +2 if found in any trending position (v3.0 spec)
  const cmcScore = (params.cmcAvailable && params.cmcRank !== null) ? 2.0 : 0;

  // Liquidations (0 – 3.0 для Squeeze/Bear Trap, 0 – 2.0 иначе)
  const isSqueezePattern = params.sentimentKey === "short_squeeze"
                        || params.sentimentKey === "bear_trap";
  let liqScore = 0;
  if (params.coinglassAvailable && params.liquidationsMultiple !== null) {
    const liqCap = isSqueezePattern ? 3.0 : 2.0;
    liqScore = Math.min(liqCap,
      params.liquidationsMultiple >= 5 ? liqCap :
      params.liquidationsMultiple >= 3 ? liqCap * 0.75 :
      params.liquidationsMultiple >= 2 ? liqCap * 0.5 : 0
    );
  }

  // Funding rate bonus/penalty (0 – +1.5 / 0 – -0.5)
  // Отрицательный фандинг → шорты платят → сквиз-потенциал → буст
  // Сильно положительный → лонги перегреты → пенальти
  let fundingScore = 0;
  if (params.fundingRate != null) {
    const fr = params.fundingRate;
    const isSqueezeOrTrap = params.sentimentKey === "short_squeeze"
                         || params.sentimentKey === "bear_trap"
                         || params.sentimentKey === "hidden_accumulation";
    if (fr <= -0.0003) {
      fundingScore = isSqueezeOrTrap ? 1.5 : 1.0;
    } else if (fr <= -0.0001) {
      fundingScore = isSqueezeOrTrap ? 0.75 : 0.5;
    } else if (fr >= 0.0005) {
      fundingScore = -0.5;
    } else if (fr >= 0.0003) {
      fundingScore = -0.25;
    }
  }

  const raw = oiScore + volScore + priceScore + cmcScore + liqScore + fundingScore;
  return Math.min(10, Math.max(1, Math.round(raw)));
}

// ── Result type ──────────────────────────────────────────────────────────────
export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha" | "bingx_volume";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  /** Кросс-биржевое OI изменение от Coinalyze (30m) */
  coinalyzeOiChange: number | null;
  /** Coinalyze подтвердил OI-рост кросс-биржево */
  coinalyzeConfirmed: boolean;
  /** Новый листинг (< 24ч на фьючерсах BingX) */
  isNewListing: boolean;
  /** SHORT_SQUEEZE с Coinalyze OI < -20% — выдавливание шортов уже завершено */
  isExhaustedSqueeze: boolean;
  /** % рост цены от первого открытия фьючерса */
  pumpFromOpen: number | null;
  /** Количество 30м свечей (< 48 = новый) */
  candleCount: number;
  sentiment: string;
  sentimentKey: SentimentKey;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "5m", "30m", "1h" или комбинация */
  oiTriggerTf: string;
  /** Значение 5m OI изменения (для отображения в сигнале) */
  oiChange5m: number | null;
  /** Значение 1h OI изменения (для отображения в сигнале) */
  oiChange1h: number | null;
  /** Значение 4h OI изменения (для отображения в сигнале) */
  oiChange4h: number | null;
  /** Значение 24h OI изменения (для отображения в сигнале) */
  oiChange24h: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже был в отслеживаемых сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт BingX (decimal, напр. -0.0004 = -0.04% за 8ч) */
  fundingRate?: number | null;
  /** Mark price BingX перп */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Анализ стакана BingX: имбаланс бидов/асков, bid-стены */
  obImbalance?: OrderBookAnalysis | null;
}

// ── Whether a symbol passes any detection path ───────────────────────────────
interface DetectionResult {
  passes: boolean;
  oiChangePercent: number;
  openInterest: number;
  sentiment: SentimentResult;
}

function evaluatePattern(
  oiChange: number,
  priceChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  settings: { volumeMultiplier: number; oiChangePercent: number },
  triggerTf: string = "30m",
): DetectionResult | null {
  // NOTE: At this point CoinGlass global OI ≥ 5% and Volume ≥ 2x are already
  // confirmed upstream (Steps 1 & 3 of v3.0 pipeline). Pattern evaluation
  // here only assigns the pattern type and applies pattern-specific thresholds.
  const { bullishMax } = getOiCaps(triggerTf);
  const sent = detectSentiment(priceChange, oiChange, volumeMultiplier, liquidationsMultiple, triggerTf);

  // Path A: Rising OI patterns (LONG сигналы)
  if (!sent.oiFalling) {
    if (sent.key === "hidden_accumulation") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

    if (sent.key === "aggressive_breakout") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

    // Bullish Standard: OI ≥ threshold + Vol ≥ threshold + price move + ТФ-зависимый кеп.
    // 30m OI>15% = ловушка. 4h OI=20% = устойчивое накопление за часы.
    if (oiChange >= settings.oiChangePercent && oiChange <= bullishMax && volumeMultiplier >= settings.volumeMultiplier && Math.abs(priceChange) >= 1) {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }
  }

  // Path B: Falling OI patterns
  if (sent.oiFalling) {
    if (sent.key === "short_squeeze") {
      // OI падает (шорты выдавлены) + цена РАСТЁТ → LONG скальп
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

  }

  // Path C: Bear Trap — OI растёт + цена падает = шорты набираются → потенциальный сквиз
  if (sent.key === "bear_trap") {
    return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
  }

  return null;
}

// ── Main scan ────────────────────────────────────────────────────────────────
export async function performScan(): Promise<{ signalsFound: number; marketsScanned: number; durationMs: number }> {
  const startTime = Date.now();
  const settings = await getSettings();

  // Очищаем устаревшие записи signalHistory (TTL: 48 часов).
  // Без TTL история растёт вечно — символы которые давно не скануются остаются в памяти.
  const TTL_MS = 48 * 60 * 60 * 1000;
  for (const [sym, st] of signalHistory.entries()) {
    if (Date.now() - st.firstSignalAt.getTime() > TTL_MS) {
      signalHistory.delete(sym);
    }
  }

  // Очищаем кэш CoinGlass перед каждым сканом — данные всегда свежие
  clearCoinglassOICache();
  logger.info("Starting Alpha Scanner (5m scan, 30m TF, 5-pattern)...");

  let tickers;
  try {
    tickers = await getFutureTickers();
  } catch (err) {
    logger.error({ err }, "Failed to fetch BingX tickers");
    state.bingxConnected = false;
    return { signalsFound: 0, marketsScanned: 0, durationMs: Date.now() - startTime };
  }
  state.bingxConnected = true;

  // ── Activity-score pre-screening (ALL tokens, 1 API call) ───────────────────
  // Score every USDT token using already-fetched ticker data (free, no extra calls).
  // Hot tokens (big price move + big volume) get deep-scanned every 10 min,
  // so OI baselines build up within 20 min — not 100 min like with rotation.
  //
  // score = abs(priceChange24h%) × log10(quoteVolumeUSD + 1)
  // This ranks: tokens with big price moves in liquid markets first.
  // Exclude index/stock trackers (NCS*, NCC*, symbols with "2USD" — e.g. NCSKSPY2USD-USDT)
  const isCryptoFuture = (symbol: string) => {
    const base = symbol.replace("-USDT", "");
    return !base.includes("2USD") && !base.startsWith("NCS") && !base.startsWith("NCC");
  };

  const scored = tickers
    .filter(t => t.symbol.endsWith("-USDT") && isCryptoFuture(t.symbol))
    .map(t => {
      const pctChange = Math.abs(parseFloat(t.priceChangePercent) || 0);
      const vol = parseFloat(t.quoteVolume) || 0;
      const score = pctChange * Math.log10(vol + 1);
      return { ticker: t, score };
    })
    .sort((a, b) => b.score - a.score);

  // ── Layer 0: user watchlist — always scanned regardless of rank ──────────────
  const watchlistSymbols: string[] = (String(settings.watchlist ?? ""))
    .split(",")
    .map((s: string) => s.trim().toUpperCase())
    .filter((s: string) => s.length > 0)
    .map((s: string) => s.includes("-") ? s : `${s}-USDT`); // auto-append -USDT if missing
  const watchlistSet = new Set(watchlistSymbols);
  const watchlistTickers = tickers.filter(t => watchlistSet.has(t.symbol));
  const watchlistSymbolsFound = new Set(watchlistTickers.map(t => t.symbol));

  // ── Layer 1: top-N by activity score (current hot movers)
  const activityLimit = settings.maxSymbols; // default 50
  const topByActivity = scored.slice(0, activityLimit).map(s => s.ticker);
  const activeSymbols = new Set(topByActivity.map(t => t.symbol));

  // ── Layer 2: top-200 by volume — BingX только как fallback для первого скана.
  //    После 1-го скана используем cgVolumeCache (global volUsd от CoinGlass):
  //    DYDX с $246M OI и высоким global volume попадёт в пул даже при низком BingX-объёме.
  const useCgVolume = cgVolumeCache.size > 0;
  const topByVolume = [...scored]
    .sort((a, b) => {
      const symA = a.ticker.symbol.replace("USDT", "").replace("-", "");
      const symB = b.ticker.symbol.replace("USDT", "").replace("-", "");
      const volA = useCgVolume
        ? (cgVolumeCache.get(symA) ?? cgVolumeCache.get(a.ticker.symbol) ?? (parseFloat(a.ticker.quoteVolume) || 0))
        : (parseFloat(a.ticker.quoteVolume) || 0);
      const volB = useCgVolume
        ? (cgVolumeCache.get(symB) ?? cgVolumeCache.get(b.ticker.symbol) ?? (parseFloat(b.ticker.quoteVolume) || 0))
        : (parseFloat(b.ticker.quoteVolume) || 0);
      return volB - volA;
    })
    .slice(0, 200)
    .map(s => s.ticker)
    .filter(t => !activeSymbols.has(t.symbol) && !watchlistSymbolsFound.has(t.symbol));

  const usdtTickers = [...watchlistTickers, ...topByActivity, ...topByVolume];
  const scanLimit = activityLimit;

  const topScore = scored[0]?.score?.toFixed(1) ?? "0";
  logger.info(
    {
      count: usdtTickers.length,
      watchlist: watchlistTickers.length,
      byActivity: topByActivity.length,
      byVolume: topByVolume.length,
      volSource: useCgVolume ? `CoinGlass(cache=${cgVolumeCache.size})` : "BingX(firstRun)",
      totalTokens: scored.length,
      topScore,
      top5: scored.slice(0, 5).map(s => `${s.ticker.symbol}(${s.score.toFixed(1)})`),
      watchlistSymbols: watchlistTickers.map(t => t.symbol),
    },
    "Pre-screened tokens for deep scan"
  );

  // ── Phase 1: CoinGlass OI batch — PRIMARY filter ─────────────────────────────
  // CoinGlass даёт агрегированный глобальный OI по всем биржам (m30OIChangePercent).
  // Это основной фильтр — BingX OI больше не используется для альфа-сигналов.
  // Rate limit: 2s stagger между некэшированными запросами = 30 req/min.
  const allSymbols = usdtTickers.map(t => t.symbol);
  logger.info({ count: allSymbols.length }, "Fetching CoinGlass global OI (primary filter)...");
  const coinglassOIMap = await batchGetCoinglassOI(allSymbols);

  const oiMoversCount = [...coinglassOIMap.values()].filter(r => {
    if (!r.available) return false;
    const t5   = Math.abs(r.oiChange5m  ?? 0) >= 3.5;
    const t30  = Math.abs(r.oiChange30m ?? 0) >= 4.5;
    const t1h  = Math.abs(r.oiChange1h  ?? 0) >= 6.0;
    const t4h  = Math.abs(r.oiChange4h  ?? 0) >= 8.0;
    const t24h = Math.abs(r.oiChange24h ?? 0) >= 20.0;
    return t5 || t30 || t1h || t4h || t24h;
  }).length;
  // Наполняем персистентный кеш глобальных объёмов для следующего пре-скрина
  let cgVolCacheUpdated = 0;
  for (const [sym, oi] of coinglassOIMap.entries()) {
    if (oi.cgVolUsd && oi.cgVolUsd > 0) {
      // Ключ без -USDT суффикса, например "DYDX"
      const base = sym.replace(/-?USDT$/i, "").replace(/-/g, "");
      cgVolumeCache.set(base, oi.cgVolUsd);
      cgVolCacheUpdated++;
    }
  }
  logger.info(
    { total: allSymbols.length, movers: oiMoversCount, threshold: settings.oiChangePercent + "%", cgCacheSize: cgVolumeCache.size, cgUpdated: cgVolCacheUpdated },
    "CoinGlass OI batch complete"
  );

  // Phase 2: gather alpha candidates (klines + volume + pattern)
  const candidates: {
    symbol: string;
    price: number;
    priceChange30m: number;
    price4hChange: number;      // Изменение цены за 4ч (8×30m) — для пост-памп фильтра
    currentVolume: number;
    avgVolume: number;
    volumeMultiplier: number;
    oiChangePercent: number;    // Best (max abs) из 5m/30m/1h OI — для скоринга
    oiChange5m: number | null;  // Сырое 5m значение — для отображения в сигнале
    oiChange1h: number | null;  // Сырое 1h значение — для отображения в сигнале
    oiChange4h: number | null;  // Сырое 4h значение — для отображения в сигнале
    oiChange24h: number | null; // Сырое 24h значение — для отображения в сигнале
    openInterest: number;       // CoinGlass global OI in USD (or 0)
    sentiment: SentimentResult;
    coinglassOI: CoinglassOIResult;
    oiTriggerTf: string;       // Какой ТФ сработал: "5m", "30m", "5m+30m"
    isRepeatSignal: boolean;   // символ уже был в сигналах за последние 24ч
  }[] = [];

  // Track top-performers for debug log (even if they don't pass)
  const debugTop: { symbol: string; vol: number; cgOI: number | null; price: number }[] = [];

  // Skip reason counters for INFO-level diagnostics
  const skipCount = {
    noKlines: 0,
    exhaustedPump: 0,
    deepNegative: 0,
    noOiNoVol: 0,
    contraSignal: 0,
    lowVolume: 0,
    repeatSignal: 0,
    other: 0,
  };

  const now = Date.now();

  // ── Pre-scan fresh prices для confirming inserts ─────────────────────────────
  // CoinGlass batch уже занял 8+ мин. Kline close = закрытие свечи (0-30 мин назад).
  // Чтобы priceAtEntry в confirming был реальной ценой в момент добавления —
  // берём свежий тикер прямо перед per-symbol loop.
  const confirmPriceMap = new Map<string, number>();
  try {
    const confirmTickers = await getFutureTickers();
    for (const t of confirmTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) confirmPriceMap.set((t as any).symbol, p);
    }
  } catch { /* non-critical — falls back to kline close */ }

  for (const ticker of usdtTickers) {
    const symbol = ticker.symbol;
    try {
      const klines = await getKlines(symbol, "30m", 49);

      // Требуем минимум 10 свечей для расчёта среднего объёма
      if (klines.length < 10) continue;

      const current = klines[klines.length - 1];
      // v3.0 Step 3: use last 20 candles for average volume (not all 48)
      const historical = klines.slice(-21, -1);

      const close = parseFloat(current.close) || 0;
      const open = parseFloat(current.open) || 0;
      if (!close || !open) continue;

      const currentVol = (parseFloat(current.volume) || 0) * close;
      const avgVol = historical.length > 0
        ? historical.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / historical.length
        : 0;

      if (!avgVol) continue;

      const priceChange = ((close - open) / open) * 100;
      const volMult = currentVol / avgVol;

      // 4h price context: compare current close to close ~8 candles (4h) ago.
      // Используется для пост-памп фильтра в Phase 3.
      const lookback4hIdx = Math.max(0, klines.length - 1 - 8);
      const base4hClose = parseFloat(klines[lookback4hIdx]?.close || "0");
      const price4hChange = base4hClose > 0 ? ((close - base4hClose) / base4hClose) * 100 : 0;

      // 4h cumulative volume: средний объём последних 8 свечей (4h) vs базовый avgVol (20 свечей).
      // Используется в 4h Momentum Pattern для обнаружения медленных грайндов.
      const recent8 = klines.slice(-9, -1); // 8×30m = 4h, без текущей свечи
      const vol4hAvg = recent8.length >= 4
        ? recent8.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / recent8.length
        : 0;
      const volMult4h = avgVol > 0 && vol4hAvg > 0 ? vol4hAvg / avgVol : 0;

      // Volume trend: объём за последние 2 закрытые свечи (не текущая).
      // Если хотя бы одна из них >= 1.3x нормы — объём нарастает трендом, не одиночный спайк.
      // Используется как фильтр качества для hidden_accumulation.
      const prev1k = klines[klines.length - 2];
      const prev2k = klines[klines.length - 3];
      const prevVol1 = prev1k ? (parseFloat(prev1k.volume) || 0) * (parseFloat(prev1k.close) || 0) : 0;
      const prevVol2 = prev2k ? (parseFloat(prev2k.volume) || 0) * (parseFloat(prev2k.close) || 0) : 0;
      const prevVol1Mult = avgVol > 0 ? prevVol1 / avgVol : 0;
      const prevVol2Mult = avgVol > 0 ? prevVol2 / avgVol : 0;
      // Тренд объёма: хотя бы одна из 2 предыдущих закрытых свечей тоже была >= 1.3x
      const isVolTrend = prevVol1Mult >= 1.3 || prevVol2Mult >= 1.3;

      // ── PRE-FILTER: Exhausted pump — price up >20% in 24h AND volume now cooling off ──
      // We DON'T block early breakouts (PIPPIN: 24h=0.84% at signal time).
      // Блок поздних входов по 24h цене из BingX — независимо от CoinGlass/Coinalyze.
      // BingX priceChangePercent = изменение за последние 24h, всегда актуально.
      const price24hChange = parseFloat(ticker.priceChangePercent) || 0;

      // ── Sharp Impulse Detection ────────────────────────────────────────────────
      // Паттерн: текущая свеча сама является импульсом (price >= 12% за свечу + vol >= 2x).
      // Примеры: HYPERLANE +20.28% за 15 мин, AXS +12%+. Цена уже улетела, но движение продолжается.
      // Такие сигналы блокируются exhausted pump filter + anti-stale filter — обходим их для этого паттерна.
      const isSharpImpulse = priceChange >= 12 && volMult >= 2.0;

      // ── Volume Flash Detection ─────────────────────────────────────────────────
      // Паттерн: объём взорвался (>= 10x baseline) + цена начала движение (>= 3%).
      // Ловит начало flash-памп без OI-подтверждения — следуй за деньгами.
      // Примеры: SKYAI +71% за день — объём был аномальным, OI не успел отреагировать.
      // Обходит stale-фильтр: высокий объём = движение ещё идёт (не устаревший сигнал).
      const isVolumeFlash = !isSharpImpulse && volMult >= 10.0 && priceChange >= 3.0 && priceChange <= 45.0;

      // 1. Памп уже отыгран: цена выросла 30%+ за 24h И объём остывает (< 2.5x).
      //    Порог 30% (был 20%) — ZEC на +20% за день это тренд, не исчерпанный памп.
      //    Дополнительно: если 4h объём >= 1.3x — монета ещё активна (многодневный тренд), пропускаем.
      //    Исключение: sharp_impulse — свеча сама является импульсом, объём ещё горячий.
      if (!isSharpImpulse && price24hChange > 40 && volMult < 2.5 && volMult4h < 1.3) {
        logger.debug({ symbol, price24hChange: price24hChange.toFixed(1) + "%", volMult: volMult.toFixed(2) }, "SKIP: exhausted pump (>40% 24h + vol < 2.5x)");
        skipCount.exhaustedPump++;
        continue;
      }

      // 2. Монета в нисходящем тренде 24h → хвост дампа после пампа, лонги ликвидируются.
      //    Памп был вчера — сегодня монета уже -8% или хуже. Входить = ловить падающий нож.
      if (price24hChange < -8) {
        logger.debug({ symbol, price24hChange: price24hChange.toFixed(1) + "%" }, "SKIP: 24h price deeply negative — post-pump dump");
        skipCount.deepNegative++;
        continue;
      }

      // ── FAST TRACK: BingX Price + Volume (без CoinGlass) ────────────────────────
      // Если свеча >= 10% И объём >= 7x среднего — сигнал достаточно сильный сам по себе.
      // Это ловит explosive starts (BIO 12:00 МСК: +9.82%, 5.1x vol) без ожидания OI.
      // Пример: при CoinGlass batch = 8 мин, к 12:08 МСК цена уже выросла на 25%.
      const FAST_TRACK_PRICE_PCT = 10.0;  // % свечи для прямого входа
      const FAST_TRACK_VOL_MULT  = 7.0;  // множитель объёма для прямого входа

      // ── PREV CANDLE FAST TRACK: ловим когда большая свеча закрылась между сканами ──
      // Проблема: скан запускается в 05:29, тратит 8 мин на CoinGlass batch.
      // К 05:37 свеча 05:00-05:30 (+28%) уже закрылась, текущая 05:30-06:00 flat (+0.5%).
      // Решение: если ПРЕДЫДУЩАЯ закрытая свеча была fast_track — и цена ещё держится
      // (не откатилась > 5% от закрытия той свечи) — это тоже valid сигнал.
      const prevPriceChange = prev1k
        ? ((parseFloat(prev1k.close) - parseFloat(prev1k.open)) / parseFloat(prev1k.open)) * 100
        : 0;
      const prevClose1 = parseFloat(prev1k?.close || "0");
      const priceFromPrevClose = prevClose1 > 0 ? ((close - prevClose1) / prevClose1) * 100 : 0;
      const isPrevFastTrack = Math.abs(prevPriceChange) >= FAST_TRACK_PRICE_PCT
                           && prevVol1Mult >= FAST_TRACK_VOL_MULT
                           && priceFromPrevClose > -5.0;  // цена ещё держится от закрытия

      const isFastTrack = (Math.abs(priceChange) >= FAST_TRACK_PRICE_PCT && volMult >= FAST_TRACK_VOL_MULT)
                       || isPrevFastTrack;

      // ── STEP 1: PRIMARY FILTER — CoinGlass глобальный OI (агрегат по всем биржам) ──
      // Проверяем 5 таймфреймов: 5m, 30m, 1h, 4h, 24h.
      // Fast Track символы проходят этот блок без проверки OI.
      const cgOI = coinglassOIMap.get(symbol);

      // ── CoinGlass Timeout Fallback: BingX OI прямой запрос ───────────────────
      // Когда CoinGlass таймаутит по символу (малые токены, rate-limit),
      // вычисляем % изменения OI напрямую из BingX: текущий OI vs сохранённый baseline.
      // Baseline обновляется каждые 20-60 мин → получаем аналог oi30m/oi1h.
      let bingxDirectOIChange: number | null = null;
      if (!cgOI?.available) {
        // Уровень 1: BingX прямой запрос vs baseline (без лимитов, мгновенно)
        const baseline = oiBaseline.get(symbol);
        if (baseline && (Date.now() - baseline.takenAt.getTime()) < MAX_BASELINE_AGE_MS) {
          const bxOI = await getOpenInterest(symbol);
          if (bxOI) {
            const currentOI = parseFloat(bxOI.openInterest);
            if (currentOI > 0 && baseline.oi > 0) {
              bingxDirectOIChange = ((currentOI - baseline.oi) / baseline.oi) * 100;
              logger.info(
                {
                  symbol,
                  currentOI: currentOI.toFixed(0),
                  baselineOI: baseline.oi.toFixed(0),
                  changePct: bingxDirectOIChange.toFixed(1) + "%",
                  baselineAgeMin: ((Date.now() - baseline.takenAt.getTime()) / 60000).toFixed(0),
                },
                "🔄 CG FALLBACK L1: BingX OI прямой запрос (CoinGlass таймаут)"
              );
            }
          }
        }

        // Уровень 2: Coinalyze — кросс-биржевой агрегат (100 req/day, 30-мин кэш)
        // Включается когда BingX baseline недоступен (новые монеты, GWEI и пр.)
        if (bingxDirectOIChange === null) {
          const czResult = await getCoinalyzeOI(symbol);
          if (czResult.available && czResult.oiChange30m !== null) {
            bingxDirectOIChange = czResult.oiChange30m;
            logger.info(
              { symbol, oiChange30m: czResult.oiChange30m.toFixed(1) + "%" },
              "🔄 CG FALLBACK L2: Coinalyze OI (BingX baseline недоступен)"
            );
          }
        }
      }

      const oi5m  = cgOI?.oiChange5m  ?? null;
      const oi30m = cgOI?.oiChange30m ?? (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
      const oi1h  = cgOI?.oiChange1h  ?? (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
      const oi4h  = cgOI?.oiChange4h  ?? null;
      const oi24h = cgOI?.oiChange24h ?? null;

      // Пороги — дифференцированные по ТФ:
      // 5m: 5.0% (ловим начало импульса), 30m: 6.0%, 1h: 6% (исключаем флэт-шум),
      // 4h: 8% (медленное накопление за несколько часов), 24h: 20% (крупная капитализация)
      const OI_THRESH_5M  = 5.0;
      const OI_THRESH_30M = 6.0;
      const OI_THRESH_1H  = 6.0;
      const OI_THRESH_4H  = 8.0;
      const OI_THRESH_24H = 20.0;
      // Требуем ПОЛОЖИТЕЛЬНЫЙ OI — отрицательный означает закрытие позиций/окончание движения.
      // Исключение short_squeeze обрабатывается отдельным детектором через hasShortTfOiDrop.
      const t5   = oi5m  !== null && oi5m  >= OI_THRESH_5M;
      const t30  = oi30m !== null && oi30m >= OI_THRESH_30M;
      const t1h  = oi1h  !== null && oi1h  >= OI_THRESH_1H;
      const t4h  = oi4h  !== null && oi4h  >= OI_THRESH_4H;
      const t24h = oi24h !== null && oi24h >= OI_THRESH_24H;

      // ── ФИЛЬТР: памп уже был — кросс-биржевой OI (CoinGlass, агрегат всех бирж) ──
      //
      // CoinGlass = агрегат Binance + Bybit + OKX + BingX + др. → это глобальный сигнал,
      // не привязан к одной бирже. Два случая:
      //
      // A) CoinGlass вернул 24h OI < -15% → шорты закрывались весь день → памп отыгран.
      if (oi24h !== null && oi24h < -15) {
        logger.debug(
          { symbol, oi24h: oi24h.toFixed(1) + "%" },
          "SKIP: памп уже был — CoinGlass 24h OI < -15% (глобальный агрегат)"
        );
        skipCount.other++;
        continue;
      }

      // B) CoinGlass покрывает монету, но 24h поле отсутствует (null) — типично для малых токенов.
      //    В этом случае смотрим краткосрочные TF: если ВСЕ доступные (5m, 30m, 1h) отрицательные
      //    → OI падает по всему фронту → выдавливание лонгов / пост-памп дамп.
      if (cgOI?.available && oi24h === null) {
        const shortTfValues = [oi5m, oi30m, oi1h].filter(v => v !== null) as number[];
        const allNegative = shortTfValues.length >= 2 && shortTfValues.every(v => v < -2);
        if (allNegative) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
            "SKIP: 24h OI недоступен, но все краткосрочные TF отрицательные — OI падает по всему фронту"
          );
          continue;
        }
      }

      // "Steady Accumulation": 5m И 30m — умеренный но одновременный рост OI + цена во флэте.
      // Ловит скрытое накопление где ни один ТФ не пробивает порог, но оба показывают рост.
      // Примеры: oi5m=3%, oi30m=4.5% при priceChange=0.3% → крупный игрок набирает позицию тихо.
      const tSteady = !t5 && !t30 && !t1h && !t4h && !t24h
                   && oi5m  !== null && oi5m  >= 3.0
                   && oi30m !== null && oi30m >= 4.0
                   && Math.abs(priceChange) <= 2.0;

      // Multi-TF confirmation:
      // — Короткие ТФ (5m, 30m) должны подтверждать друг друга — одиночный всплеск на 5m или 30m шум.
      // — Длинные ТФ (1h ≥6%, 4h ≥8%, 24h ≥20%) достаточно сильны и проходят поодиночке.
      const shortTfsConfirmed = t5 && t30;
      const longTfPass        = t1h || t4h || t24h;
      // anyOiPass: либо CoinGlass дал данные, либо BingX прямой фолбэк сработал
      const hasFallbackOI = bingxDirectOIChange !== null;
      const anyOiPass = (cgOI?.available || hasFallbackOI) && (shortTfsConfirmed || longTfPass || tSteady);

      // ── Фильтр: короткие ТФ + противоречие длинных ────────────────────────────
      // Если сработали только 5м+30м, но 4h или 24h OI глубоко в минусе —
      // весь день шли продажи/выход из позиций, краткосрочный всплеск ложный.
      // Исключение: short_squeeze — там отрицательный OI является частью тезиса.
      if (shortTfsConfirmed && !longTfPass && det?.sentiment.key !== "short_squeeze") {
        if (oi24h !== null && oi24h < -10) {
          logger.debug({ symbol, oi24h: oi24h.toFixed(1) + "%" }, "SKIP: 5м+30м ок, но 24ч OI < -10% — дневной слив");
          skipCount.other++;
          continue;
        }
        if (oi4h !== null && oi4h < -5) {
          logger.debug({ symbol, oi4h: oi4h.toFixed(1) + "%" }, "SKIP: 5м+30м ок, но 4ч OI < -5% — последние 4ч продажи");
          skipCount.other++;
          continue;
        }
      }

      // ── BingX Volume Pattern: объём + движение цены без подтверждения OI ────────
      // Без CoinGlass нет подтверждения умных денег — требуем БОЛЕЕ высокую планку.
      // Порог 5x+5%: случайные шорты/арбитраж генерировали сигналы при 2.5x+3%.
      // US(2.68x, 4.79%) / SIREN(5.42x, 7.31%) / ZBT(4.16x, 3.47%) — все failed.
      // Требуем также тренд объёма (isVolTrend) — не одиночный спайк.
      const isBingxVolume = !anyOiPass
                         && volMult >= 5.0
                         && priceChange >= 5.0
                         && isVolTrend;

      // ── 4h Momentum Pattern: медленный грайнд за несколько часов ─────────────────
      // Ловит монеты которые растут постепенно (+8-20% за 4h) с повышенным объёмом,
      // но без взрывной одиночной свечи. Пример: BLEND, LYN.
      // Средний объём последних 8 свечей (4h) должен быть 1.5x выше базовой нормы.
      // Порог снижен: 4% (был 8%) — ZEC за 4ч может расти на 3-5%, а не 8-20%.
      // volMult4h снижен: 1.2x (был 1.5x) — медленный тренд не даёт взрывного объёма.
      // Этот паттерн теперь покрывает и многодневные гринды (ZEC-тип), и внутридневные.
      const is4hMomentum = !anyOiPass
                        && !isBingxVolume
                        && price4hChange >= 4.0
                        && volMult4h >= 1.2
                        && priceChange > -2;   // текущая свеча не разворачивается

      // ── Байпас для cg_timeout/cg_building записей в очереди подтверждения ──────
      // Эти символы пропустили OI-фильтр (CG timeout или OI ниже порога), но уже
      // добавлены в confirming-очередь. Позволяем им дойти до confirming-блока (строка ~1426).
      const cgFallbackConfirmingRows = await db.select({ id: oiWatchTable.id })
        .from(oiWatchTable)
        .where(and(
          eq(oiWatchTable.symbol, symbol),
          eq(oiWatchTable.status, "confirming"),
          inArray(oiWatchTable.triggerTf, ["cg_timeout", "cg_building"])
        ))
        .limit(1);
      const isCgFallbackConfirming = cgFallbackConfirmingRows.length > 0;

      if (!isFastTrack && !anyOiPass && !isBingxVolume && !is4hMomentum && !isCgFallbackConfirming) {
        // ── FALLBACK: топ-50 активных токенов с недоступным или строящимся OI ─────
        // A) CG timeout (available=false): batch-запрос падает для TAG → добавляем в
        //    confirming-очередь. Те же 2ч ожидание что и у всех остальных сигналов.
        //    OI-фильтр не применяется (CG недоступен), но retrace/runaway/price+2% работают.
        // B) CG вернул данные но OI ниже порога на 2+ TF («строится»).
        //    Кейс: SKYAI/4USD — OI 3-4% на 5m+30m вместо 6% порога.
        if (activeSymbols.has(symbol)) {
          const cgTimeoutFallback = !cgOI?.available
                                 && volMult >= 2.0
                                 && priceChange > -5
                                 && priceChange < 25;
          const buildingTfCount = cgOI?.available
            ? [oi5m, oi30m, oi1h].filter(v => v !== null && v >= 2.0).length
            : 0;
          const cgBuildingFallback = cgOI?.available && buildingTfCount >= 2 && !anyOiPass;

          if (cgTimeoutFallback || cgBuildingFallback) {
            // Не дублируем если символ уже в очереди (watching или confirming)
            const alreadyQueued = await db.select({ id: oiWatchTable.id })
              .from(oiWatchTable)
              .where(and(
                eq(oiWatchTable.symbol, symbol),
                inArray(oiWatchTable.status, ["watching", "confirming"])
              ))
              .limit(1);

            if (alreadyQueued.length === 0) {
              const watchTf = cgTimeoutFallback ? "cg_timeout" : "cg_building";
              const watchOi = oi30m ?? oi5m ?? oi1h ?? 0;
              try {
                await db.insert(oiWatchTable).values({
                  symbol,
                  triggerTf: watchTf,
                  oiChange: watchOi,
                  priceAtEntry: confirmPriceMap.get(symbol) ?? close,
                  volumeMultiplier: volMult,
                  sentimentKey: null,
                  status: "confirming",           // тот же путь что у всех → 2ч окно
                  addedAt: new Date(),
                  expiresAt: new Date(Date.now() + 6 * 60 * 60 * 1000), // 6ч как CONFIRM_EXPIRE_MS
                  avgVolume: avgVol,
                  isVolConfirmed: false,
                });
                logger.info(
                  { symbol, reason: watchTf, vol: volMult.toFixed(1) + "x", price: priceChange.toFixed(1) + "%", buildingTfs: buildingTfCount },
                  "👁 ACTIVITY WATCH: топ-активный кандидат добавлен в 2ч confirming-очередь"
                );
              } catch { /* duplicate or db error — non-critical */ }
            }
          }
        }

        logger.debug(
          {
            symbol,
            vol:      volMult.toFixed(2) + "x",
            vol4h:    volMult4h.toFixed(2) + "x",
            price:    priceChange.toFixed(2) + "%",
            price4h:  price4hChange.toFixed(1) + "%",
            oi5m:  oi5m?.toFixed(2)  ?? "n/a",
            oi30m: oi30m?.toFixed(2) ?? "n/a",
            oi1h:  oi1h?.toFixed(2)  ?? "n/a",
          },
          "SKIP: недостаточно объёма или движения цены (vol < 1.0x или price < 2.5%)"
        );
        skipCount.noOiNoVol++;
        continue;
      }

      // Какой ТФ сработал (OI path) или fast_track (BingX path)
      let oiTriggerTf: string;
      let cgOIChange: number;

      if (isBingxVolume && !anyOiPass && !isFastTrack) {
        // BingX Volume Pattern — нет CoinGlass OI, но объём взрывной
        oiTriggerTf = "bingx_volume";
        cgOIChange = 0;
        logger.info(
          { symbol, price: priceChange.toFixed(1) + "%", vol: volMult.toFixed(1) + "x" },
          "📈 BINGX VOLUME: нет CoinGlass OI, но объём + цена сильные"
        );
      } else if (is4hMomentum && !anyOiPass && !isFastTrack) {
        // 4h Momentum Pattern — медленный грайнд за несколько часов
        oiTriggerTf = "4h_momentum";
        cgOIChange = 0;
        logger.info(
          { symbol, price4h: price4hChange.toFixed(1) + "%", vol4h: volMult4h.toFixed(2) + "x", price: priceChange.toFixed(1) + "%" },
          "📈 4H MOMENTUM: медленный грайнд — 4h рост + повышенный средний объём"
        );
      } else if (isFastTrack && !anyOiPass) {
        // Чистый Fast Track — OI не сработал, но свеча + объём сильные
        oiTriggerTf = isPrevFastTrack && !(Math.abs(priceChange) >= FAST_TRACK_PRICE_PCT && volMult >= FAST_TRACK_VOL_MULT)
          ? "fast_track_prev"   // сработала предыдущая свеча (HIVE-кейс)
          : "fast_track";
        cgOIChange = 0;
        logger.info(
          {
            symbol,
            price:      priceChange.toFixed(1) + "%",
            vol:        volMult.toFixed(1) + "x",
            prevPrice:  prevPriceChange.toFixed(1) + "%",
            prevVol:    prevVol1Mult.toFixed(1) + "x",
            isPrevCandle: isPrevFastTrack && oiTriggerTf === "fast_track_prev",
          },
          "⚡ FAST TRACK: BingX price+vol bypass CoinGlass gate"
        );
      } else if (tSteady) {
        // Steady Accumulation — 5m + 30m одновременно, цена flat
        oiTriggerTf = "steady";
        cgOIChange = oi30m!; // берём 30m как основное значение для скоринга
        logger.info(
          { symbol, oi5m: oi5m!.toFixed(1) + "%", oi30m: oi30m!.toFixed(1) + "%", price: priceChange.toFixed(1) + "%" },
          "🔍 STEADY ACCUM: Multi-TF OI convergence + flat price"
        );
      } else {
        // Стандартный CoinGlass OI путь (или fast_track + OI — берём OI для скоринга)
        const triggeredTfs = [
          t5   && "5m",
          t30  && "30m",
          t1h  && "1h",
          t4h  && "4h",
          t24h && "24h",
        ].filter(Boolean) as string[];
        const fallbackSuffix = hasFallbackOI && !cgOI?.available ? "+bingx_direct" : "";
        oiTriggerTf = isFastTrack ? "fast_track+" + triggeredTfs.join("+") + fallbackSuffix : triggeredTfs.join("+") + fallbackSuffix;

        const cand5m  = t5   ? Math.abs(oi5m!)  : 0;
        const cand30m = t30  ? Math.abs(oi30m!) : 0;
        const cand1h  = t1h  ? Math.abs(oi1h!)  : 0;
        const cand4h  = t4h  ? Math.abs(oi4h!)  : 0;
        const cand24h = t24h ? Math.abs(oi24h!) : 0;
        const bestAbs = Math.max(cand5m, cand30m, cand1h, cand4h, cand24h);
        cgOIChange = bestAbs === cand5m  && t5   ? oi5m!
                   : bestAbs === cand30m && t30  ? oi30m!
                   : bestAbs === cand1h  && t1h  ? oi1h!
                   : bestAbs === cand4h  && t4h  ? oi4h!
                   : oi24h!;
      }

      // ── STEP 2: LIQUIDITY FILTER — Global Vol24h / OI USD > 0.1 (не «мёртвые» монеты) ──
      // Пропускаем для fast_track и bingx_volume (у них высокий BingX-объём, монета явно активна).
      const oiUsd = cgOI?.oiUsd;
      const cgVolUsd = cgOI?.cgVolUsd;
      const vol24hUSD = parseFloat(ticker.quoteVolume) || 0;

      if (!isFastTrack && !isBingxVolume && oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
        const turnoverRatio = cgVolUsd / oiUsd;
        if (turnoverRatio < 0.1) {
          logger.debug({ symbol, turnoverRatio: turnoverRatio.toFixed(3), cgVol: cgVolUsd, oiUsd }, "SKIP: low global turnover ratio (cgVol/OI < 0.1)");
          continue;
        }
      }

      // ── Ликвидность: относительные фильтры покрывают без абсолютных порогов ───
      // Все фильтры ниже — относительные (volMult, OI%, turnoverRatio, спред).
      // Абсолютных долларовых порогов нет: $15M для BTC — песчинка,
      // $15M для микрокапа — всё что есть. Мёртвые монеты отсеиваются спредом
      // (≥0.5% → пропустить) и volMult (2.5x своей базы).

      // ── FILTER: Exit pump — объём в 4x+ раз больше OI = поздний сброс, не органика ──
      if (!isFastTrack && !isBingxVolume && oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
        const volToOi = cgVolUsd / oiUsd;
        if (volToOi > 4.0) {
          logger.debug({ symbol, volToOi: volToOi.toFixed(2) }, "SKIP: exit pump — объём >> OI (4x+)");
          continue;
        }
      }

      // Debug tracking (для лог-сводки по итогам цикла)
      debugTop.push({ symbol, vol: volMult, cgOI: cgOIChange || null, price: priceChange });

      // ── FILTER: Spread — узкий спред (< 0.5%) если BingX возвращает bid/ask ────
      const bid = parseFloat(ticker.bidPrice ?? "0") || 0;
      const ask = parseFloat(ticker.askPrice ?? "0") || 0;
      if (bid > 0 && ask > 0) {
        const spreadPct = (ask - bid) / ask * 100;
        if (spreadPct >= 0.5) {
          logger.debug({ symbol, spread: spreadPct.toFixed(3) }, "SKIP: spread >= 0.5%");
          continue;
        }
      }

      // ── STEP 3: VOLUME FILTER — подтверждение интереса ──────────────────────────
      // Логика порогов объёма:
      //
      // A) "High OI Quiet" — OI ≥ 20% (24h) или ≥ 12% (4h) И цена ≤ 1.5% flat.
      //    Крупный игрок набирает позицию тихо в течение часов/суток.
      //    Порог: 1.8x — минимальное подтверждение объёмом (было 1.0x — слишком много шума).
      //
      // B) "Steady Accum" — 5m+30m одновременно + flat price (мульти-ТФ паттерн).
      //    Порог: 1.8x
      //
      // C) Стандартный путь (импульс, пробой, шорт-сквиз): единый порог 1.0x
      const isHighOiQuiet = Math.abs(priceChange) <= 1.5
                         && ((t24h && Math.abs(oi24h!) >= 20) || (t4h && Math.abs(oi4h!) >= 12));

      // Порог объёма: 2.5x.
      // Победители с НИЗКИМ объёмом: M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%), BNLIFE(0.99x, +3.3%).
      // Ключевой фильтр — OI диапазон (10% кеп), а не объём. Не режем низкий объём.
      const volThreshold = 2.5;

      // 4h Momentum: 30m объём может быть умеренным (1.2-2x) — монета идёт несколько часов/дней.
      // Условие достаточности: 4h объём >= 1.2x (проверено в is4hMomentum).
      if (volMult < volThreshold && !is4hMomentum) {
        // ── OI WATCH: OI сработал, но объём ещё не подтянулся ────────────────────
        // Вместо того чтобы просто пропустить, ставим монету на наблюдение.
        // Критерии добавления в watch:
        //   1. OI уверенно сработал (хоть один ТФ)
        //   2. Объём пока ниже порога (иначе бы уже дали сигнал)
        //   3. Цена ещё не улетела (< 25% на текущей свече) — зарождение, не поздний вход
        //   4. Не новый листинг (у них своя логика Short Sniper)
        const oiTriggeredStrongly = cgOI?.available && (t5 || t30 || t1h);
        const priceNotYetExploded = Math.abs(priceChange) < 25;
        if (oiTriggeredStrongly && priceNotYetExploded && avgVol > 0) {
          try {
            // Изменение 2: если ВСЕ доступные TF OI положительные — используем
            // пониженный порог объёма в OI Watch (кодируем в triggerTf как "all+{tf}")
            const availableOis = [oi5m, oi30m, oi1h, oi4h, oi24h].filter(v => v !== null) as number[];
            const allAvailablePositive = availableOis.length >= 2 && availableOis.every(v => v > 0);
            const baseTf    = t5 ? "5m" : t30 ? "30m" : "1h";
            const triggerTf = allAvailablePositive ? `all+${baseTf}` : baseTf;
            const triggerOi = t5 ? oi5m! : t30 ? oi30m! : oi1h!;
            const expiresAt = new Date(Date.now() + 2 * 3600 * 1000); // +2h

            // Upsert: обновляем только активные watching записи, иначе вставляем новую
            const existing = await db.select({ id: oiWatchTable.id, status: oiWatchTable.status })
              .from(oiWatchTable)
              .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "watching")))
              .limit(1);

            if (existing.length > 0) {
              // Обновляем OI значение (накапливается)
              await db.update(oiWatchTable)
                .set({ oiChange: triggerOi, volumeMultiplier: volMult, expiresAt })
                .where(eq(oiWatchTable.id, existing[0].id));
            } else if (existing.length === 0) {
              await db.insert(oiWatchTable).values({
                symbol,
                triggerTf,
                oiChange: triggerOi,
                priceAtEntry: close,
                volumeMultiplier: volMult,
                sentimentKey: null,
                status: "watching",
                addedAt: new Date(),
                expiresAt,
                avgVolume: avgVol,
              });
              logger.info(
                { symbol, triggerTf, oiChange: triggerOi.toFixed(2) + "%", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
                "👁 OI WATCH: добавлен кандидат (OI есть, объём ещё не подтянулся)"
              );
            }
          } catch (err) {
            logger.warn({ err, symbol }, "OI Watch insert failed");
          }
        }
        logger.debug(
          { symbol, volMult: volMult.toFixed(2), threshold: volThreshold, isHighOiQuiet, isSteady: tSteady },
          "SKIP: volume below threshold"
        );
        skipCount.lowVolume++;
        continue;
      }

      if (isHighOiQuiet) {
        logger.info(
          { symbol, oi24h: oi24h?.toFixed(1) + "%", oi4h: oi4h?.toFixed(1) + "%", price: priceChange.toFixed(1) + "%", vol: volMult.toFixed(1) + "x" },
          "🏦 HIGH OI QUIET: Large OI + flat price — hidden accumulation/distribution"
        );
      }

      // ── STEP 4: ANTI-STALE FILTER ─────────────────────────────────────────────
      // Если CoinGlass batch занял 8+ минут и монета уже двинулась на >= 20%
      // за последние 2 свечи (60 мин) — это запоздалый сигнал, пропускаем.
      // Исключение: sharp_impulse — свеча сама и есть начало движения, фильтр неприменим.
      // Исключение: volume_flash — объём 10x+ = движение ещё активно, не устаревший сигнал.
      // (было 3 свечи / 15% — слишком агрессивно, пропускали вторые волны)
      const STALE_LOOKBACK  = 2; // свечи назад (2 × 30m = 60 мин)
      const STALE_THRESHOLD = 20; // % порог "уже поздно"
      const staleRefIdx = klines.length - 1 - STALE_LOOKBACK;
      if (!isSharpImpulse && !isVolumeFlash && staleRefIdx >= 0) {
        const staleRefClose = parseFloat(klines[staleRefIdx].close) || 0;
        if (staleRefClose > 0) {
          const staleMove = Math.abs((close - staleRefClose) / staleRefClose * 100);
          if (staleMove >= STALE_THRESHOLD) {
            logger.info(
              { symbol, staleMove: staleMove.toFixed(1) + "%", lookbackCandles: STALE_LOOKBACK },
              "SKIP: stale signal — price already moved too much in last 3 candles"
            );
            skipCount.other++;
            continue;
          }
        }
      }

      // ── PATTERN EVALUATION (CoinGlass OI + Volume + Price) ────────────────────
      let det = evaluatePattern(cgOIChange, priceChange, volMult, null, settings, oiTriggerTf);

      // ── ФИЛЬТР: hidden_accumulation — требуем объёмный тренд (не одиночный спайк) ──
      // Одна свеча с высоким объёмом может быть шумом (арбитраж, вынос стопов).
      // Если предыдущие 2 закрытые свечи тоже показывают объём >= 1.3x — это ТРЕНД покупок.
      // Данные: SYN (vol=8x но prevVol была нормальная) — убираем такие сигналы.
      if (det?.sentiment.key === "hidden_accumulation" && !isVolTrend) {
        logger.debug(
          { symbol, prevVol1: prevVol1Mult.toFixed(2) + "x", prevVol2: prevVol2Mult.toFixed(2) + "x" },
          "SKIP: hidden_accum — нет объёмного тренда (предыдущие свечи < 1.3x нормы)"
        );
        det = null;
      }

      // ── ФИЛЬТР: устаревший Short Squeeze ─────────────────────────────────────
      // Если OI упал только на 4h/24h, но на 5m/30m нейтральный → сквиз был вчера,
      // не сейчас. Заходить в хвост пампа — опасно. Убираем такие сигналы.
      if (det?.sentiment.key === "short_squeeze") {
        const hasShortTfOiDrop = (oi5m !== null && oi5m < -2) || (oi30m !== null && oi30m < -2);
        if (!hasShortTfOiDrop) {
          logger.info(
            { symbol, cgOIChange: cgOIChange.toFixed(1), oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a" },
            "SKIP: устаревший Short Squeeze — падение OI только на 4h/24h, на 5m/30m уже нейтрально"
          );
          det = null;
        }
      }

      // Override: Steady Accumulation — 5m+30m одновременный рост + цена flat.
      // С новой философией (только подтверждённые покупки) — НЕ стреляем напрямую при flat цене.
      // Вместо этого добавляем в OI Watch: когда цена тронется на 2%+ — PATH B выстрелит.
      // tSteady попадает сюда с volMult >= 2.5 (иначе ушёл бы в OI Watch раньше).
      if (!det && tSteady) {
        try {
          const existingWatch = await db.select({ id: oiWatchTable.id })
            .from(oiWatchTable)
            .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "watching")))
            .limit(1);
          if (existingWatch.length === 0) {
            await db.insert(oiWatchTable).values({
              symbol,
              triggerTf: "5m+30m",
              oiChange: oi30m!,
              priceAtEntry: close,
              volumeMultiplier: volMult,
              sentimentKey: null,
              status: "watching",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + 2 * 3600 * 1000),
              avgVolume: avgVol,
            });
            logger.info(
              { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), vol: volMult.toFixed(2) },
              "👁 STEADY ACCUM → OI Watch: flat цена, ждём подтверждения движения"
            );
          }
        } catch (err) {
          logger.warn({ err, symbol }, "tSteady OI Watch insert failed");
        }
        // Не устанавливаем det — продолжаем без прямого сигнала
      }

      // BingX Volume fallback: объём + движение цены без OI-подтверждения.
      // evaluatePattern может вернуть null при cgOIChange=0 — форсируем паттерн вручную.
      if (!det && isBingxVolume) {
        det = {
          passes: true,
          oiChangePercent: 0,
          openInterest: 0,
          sentiment: {
            key: "impulse_breakout",
            label: "Объёмный импульс",
            traderAction: "LONG (объём + цена, вход до роста OI)",
            oiFalling: false,
          },
        };
      }

      // Sharp Impulse override: свеча сама является взрывным импульсом (≥12% за свечу, объём ≥2x).
      // Перезаписываем любой паттерн — исключение из stale + exhausted фильтров уже выдано выше.
      // CVD-фильтр ниже остаётся — подтверждение покупательского давления обязательно.
      if (isSharpImpulse) {
        det = {
          passes: true,
          oiChangePercent: cgOIChange || 0,
          openInterest: 0,
          sentiment: {
            key: "sharp_impulse",
            label: "Резкий импульс",
            traderAction: "LONG (вход на продолжение импульса, стоп -7%)",
            oiFalling: false,
          },
        };
        logger.info(
          { symbol, priceChange: priceChange.toFixed(1) + "%", volMult: volMult.toFixed(1) + "x" },
          "⚡ SHARP IMPULSE: взрывная свеча — обход stale + exhausted фильтров"
        );
      }

      // Volume Flash override: аномальный объём (>= 10x) + цена движется (3–45%).
      // Перезаписывает любой другой паттерн — как sharp_impulse.
      // Обходит stale-фильтр (выше) — объём 10x говорит что движение ещё активно.
      // Обходит OI-требование — ловим flash-памп без накопления открытого интереса.
      if (isVolumeFlash) {
        det = {
          passes: true,
          oiChangePercent: cgOIChange || 0,
          openInterest: 0,
          sentiment: {
            key: "volume_flash",
            label: "Объёмная вспышка",
            traderAction: "SCALP LONG (следуй за объёмом, стоп -5%)",
            oiFalling: false,
          },
        };
        logger.info(
          { symbol, volMult: volMult.toFixed(1) + "x", priceChange: priceChange.toFixed(1) + "%" },
          "⚡⚡ VOLUME FLASH: аномальный объём без OI-паттерна — обход stale фильтра"
        );
      }

      if (!det) continue;

      // ── КУЛДАУН по символу: 24ч после cancelled/stop_loss ────────────────────
      // Если по этому символу уже был сигнал который отменили или выбило по стопу —
      // новый сигнал раньше чем через 24ч это шум (6ч было слишком мало: UB, BB).
      // Защита от NULL closed_at (баг в старых записях): используем detectedAt как запасное.
      {
        const cooldownMs = 24 * 60 * 60 * 1000;  // 24ч кулдаун после отмены
        const since = new Date(Date.now() - cooldownMs);
        const recent = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              inArray(trackedSignalsTable.status, ["cancelled", "stop_loss"]),
              or(
                // Нормальный случай: closed_at установлен и свежий
                gte(trackedSignalsTable.closedAt, since),
                // Защита от NULL closed_at (старый баг): смотрим на detectedAt
                and(isNull(trackedSignalsTable.closedAt), gte(trackedSignalsTable.detectedAt, since)),
              ),
            )
          )
          .limit(1);
        if (recent.length > 0) {
          logger.debug({ symbol }, "SKIP: кулдаун 24ч — недавний cancelled/stop_loss по этому символу");
          continue;
        }
      }

      // ── ХРОНИЧЕСКИЙ ТОКЕН: hidden_accumulation без результата 4 дня → 72ч блок ──
      // WAVES: 2 недели повторяющихся hidden_accumulation без движения цены.
      // Если за последние 4 дня было 2+ отмены hidden_accumulation — токен мёртв.
      // Не давать ему снова заходить в систему раньше чем через 72ч.
      {
        const since4d = new Date(Date.now() - 4 * 24 * 60 * 60 * 1000);
        const since72h = new Date(Date.now() - 72 * 60 * 60 * 1000);
        const chronicCancels = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .innerJoin(signalsTable, eq(signalsTable.id, trackedSignalsTable.signalId))
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "cancelled"),
              eq(signalsTable.sentimentKey, "hidden_accumulation"),
              gte(trackedSignalsTable.closedAt, since4d),
            )
          );
        if (chronicCancels.length >= 2) {
          // Проверяем, не было ли профита за последние 72ч (если был — не блокируем)
          const recentProfit = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                eq(trackedSignalsTable.status, "profit"),
                gte(trackedSignalsTable.closedAt, since72h),
              )
            )
            .limit(1);
          if (recentProfit.length === 0) {
            logger.info(
              { symbol, chronicCancels: chronicCancels.length },
              "SKIP: хронический токен — 2+ отмены hidden_accumulation за 4 дня без профита (блок 72ч)"
            );
            skipCount.other++;
            continue;
          }
        }
      }

      // ── ПОВТОРНЫЙ СИГНАЛ: был ли символ в сигналах за последние 24ч ──────────
      // После кулдауна сигнал всё равно может прийти повторно — помечаем его.
      // Бот добавит пометку: "Символ уже был в сигналах — тезис подтвердился снова".
      let isRepeatSignal = false;
      {
        const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
        const prev = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              gte(trackedSignalsTable.detectedAt, since24h),
            )
          )
          .limit(1);
        isRepeatSignal = prev.length > 0;
        if (isRepeatSignal) {
          logger.debug({ symbol }, "REPEAT: символ уже был в сигналах за 24ч — пометим в сообщении");
        }
      }

      // ── БЛОКИРОВКА: cooldown после стоп-лосса (3 дня) ───────────────────────
      // Если монета получила стоп-лосс в последние 3 дня — она, скорее всего, в
      // нисходящем тренде (пост-памп распродажа). Повторный сигнал будет ложным.
      // Пример: MAGMA стоп 24 апр → новый сигнал 26 апр = заход в нисходящий тренд.
      {
        const since3d = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000);
        const recentSL = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "stop_loss"),
              gte(trackedSignalsTable.closedAt, since3d),
            )
          )
          .limit(1);
        if (recentSL.length > 0) {
          logger.info({ symbol }, "SKIP: стоп-лосс cooldown (3 дня) — не входим в нисходящий тренд");
          skipCount.other++;
          continue;
        }
      }

      // OI теперь бонус, а не ворота — отрицательный OI на отдельных ТФ не блокирует сигнал.
      // Исключение 1: если CoinGlass покрывает монету И все краткосрочные ТФ глубоко отрицательные
      // — это явный пост-памп дамп, входить опасно.
      if (cgOI?.available && !isBingxVolume) {
        const shortTfValues = [oi5m, oi30m, oi1h].filter(v => v !== null) as number[];
        const allDeeplyNegative = shortTfValues.length >= 2 && shortTfValues.every(v => v < -3);
        if (allDeeplyNegative) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
            "SKIP: все краткосрочные OI глубоко отрицательные (< -3%) — пост-памп дамп"
          );
          continue;
        }
      }

      // Исключение 2 (contra-signal): объём + цена сигнализируют вход,
      // но умные деньги ВЫХОДЯТ по 5m/30m OI — нельзя входить против крупного игрока.
      // 5m OI < -3% = позиции закрываются прямо сейчас, 30m < -4% = устойчивый выход.
      if (isBingxVolume && cgOI?.available) {
        const oiContraSignal =
          (oi5m  !== null && oi5m  < -3.0) ||
          (oi30m !== null && oi30m < -4.0);
        if (oiContraSignal) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1) },
            "SKIP: BingX Volume contra-signal — умные деньги выходят (OI 5m/30m отрицательный)"
          );
          continue;
        }
      }

      // ── ОКНО ПОДТВЕРЖДЕНИЯ: 60 минут для всех паттернов ──────────────────────
      // Идея: засёк рост OI → подожди 1 час → проверь что OI всё ещё растёт → сигнал.
      // Это отсекает flash-пампы (OI резко растёт и тут же падает за 10-15 минут).
      // Настоящее накопление держит OI положительным часами.
      //
      // Проверки на 60-й минуте:
      //   • свежий OI (cgOIChange) < -3%   → OI иссяк, накопление закончилось → отмена
      //   • цена откатилась > 5% от точки   → ложный сигнал → отмена
      //   • цена улетела > 20% вверх         → вход слишком дорогой → отмена
      //   • всё остальное                    → СИГНАЛ
      //
      // Исключения: sharp_impulse / volume_flash работают на скорости — ждать 60 мин нельзя.
      if (!isSharpImpulse && !isVolumeFlash) {
        // Время ожидания зависит от ТФ: 4h/24h уже подтверждают многочасовое накопление,
        // долго ждать смысла нет. 30m/5m спайки требуют полного часа проверки.
        // Увеличено с 4ч до 6ч: теперь окно подтверждения 2ч + запас ещё 4ч наблюдения.
        const CONFIRM_EXPIRE_MS = 6 * 60 * 60 * 1000;
        const MAX_RETRACE_PCT   = -5.0;
        const OI_DRAIN_PCT      = -3.0;

        const confirmingEntry = await db.select()
          .from(oiWatchTable)
          .where(and(
            eq(oiWatchTable.symbol, symbol),
            eq(oiWatchTable.status, "confirming"),
          ))
          .limit(1);

        if (confirmingEntry.length > 0) {
          const entry = confirmingEntry[0];
          const ageMs = Date.now() - new Date(entry.addedAt).getTime();
          const priceFromDetection = ((close - entry.priceAtEntry) / entry.priceAtEntry) * 100;

          // Время ожидания определяется по ТФ сохранённому в записи очереди.
          // ВАЖНО: проверяем через \b (word boundary), чтобы "4h_momentum" не совпало с "4h".
          // "4h_momentum" — это паттерн цены за 4ч, не 4h OI → должен ждать 60 мин.
          // "4h", "fast_track+4h", "5m+4h" — реальные 4h OI → 15 мин достаточно.
          const entryTf = entry.triggerTf ?? "30m";
          const is4hOI  = /\b4h\b/.test(entryTf);   // "4h" как отдельное слово, не в "4h_momentum"
          const is24hOI = /\b24h\b/.test(entryTf);
          const is1hOI  = /\b1h\b/.test(entryTf);
          // Быстрые паттерны живут 1-4ч — 2ч окно убивает их (движение уже заканчивается).
          // Для них: 30 мин подтверждения + повышенный MAX_RUNAWAY_PCT (breakout ≠ поздний вход).
          const isFastPattern = [
            "aggressive_breakout", "sharp_impulse", "volume_flash",
            "short_squeeze", "bear_trap",
          ].includes(entry.sentimentKey ?? "");
          const isSlowPattern = [
            "hidden_accumulation",
            "bullish_accumulation",
          ].includes(entry.sentimentKey ?? "");
          // MAX_RUNAWAY_PCT: для накопления 10% — правильно. Для breakout — движение только начинается.
          const MAX_RUNAWAY_PCT = isFastPattern ? 25.0 : 10.0;
          // Удвоенные окна подтверждения: монета должна удержать накопление дольше.
          // Слабые кандидаты (OI иссякает или цена откатывается) отсеиваются ДО сигнала.
          const CONFIRM_WINDOW_MS =
            (is4hOI || is24hOI) ? 30 * 60 * 1000    // 30 мин: 4h/24h OI
            : is1hOI            ? 60 * 60 * 1000    // 60 мин: 1h OI
            : isFastPattern     ? 30 * 60 * 1000    // 30 мин: быстрые паттерны (breakout/squeeze/flash)
                                : 60 * 60 * 1000; // 60 мин: 30m/5m/4h_momentum/steady/bingx (было 2 часа)
          const waitMin = Math.round(CONFIRM_WINDOW_MS / 60000);

          if (isSlowPattern) {
            // Триггер для медленных паттернов: пробой локального хая ИЛИ всплеск объема
            const recentHighs = klines.slice(-9, -1).map(k => parseFloat(k.high) || 0);
            const recentHigh = Math.max(...recentHighs);
            const breakout = recentHigh > 0 && close > recentHigh * 1.005; // Пробой на 0.5% выше хая

            // Дополнительный триггер: всплеск объема на текущей свече (> 3x от avgVolume)
            const currentVolume = parseFloat(klines[klines.length - 1].volume);
            const avgVol = entry.avgVolume; // Используем avgVolume из oiWatchTable
            const volumeSpike = (avgVol ?? 0) > 0 && currentVolume > (avgVol ?? 0) * 3.0;

            if (!breakout && !volumeSpike) {
              logger.debug(
                { symbol, close, recentHigh, gap: ((close / recentHigh - 1) * 100).toFixed(2) + "%", currentVolume, avgVol },
                "⏳ SLOW PATTERN: ждём пробоя локального хая ИЛИ всплеска объема"
              );
              continue;
            }

            logger.info(
              { symbol, close, recentHigh, currentVolume, avgVol, trigger: breakout ? "breakout" : "volume_spike" },
              "✅ SLOW PATTERN: пробой локального хая ИЛИ всплеск объема — сигнал разрешён"
            );
            // Триггер сработал — проверяем OI и даём сигнал через стандартные проверки ниже
          }

          // ── 4h_momentum: условие вместо таймера ─────────────────────────────────
          // Тренд — это не ОИ-импульс. Нет смысла ждать 2 часа.
          // Условие для сигнала: цена не откатилась от точки детекции (держится выше -3%)
          // И прошёл хотя бы 1 скан (30 мин — чтобы не стрелять в ту же секунду).
          // Если цена ушла ниже -3% — тренд сломан, отменяем запись.
          if (entryTf === "4h_momentum") {
            if (priceFromDetection < -3.0) {
              await db.update(oiWatchTable)
                .set({ status: "expired", firedAt: new Date() })
                .where(eq(oiWatchTable.id, entry.id));
              logger.info(
                { symbol, drift: priceFromDetection.toFixed(1) + "%" },
                "❌ 4H MOMENTUM: цена откатила от точки входа — тренд сломан"
              );
              continue;
            }
            if (ageMs < 30 * 60 * 1000) {
              logger.debug(
                { symbol, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%" },
                "⏳ 4H MOMENTUM: ждём минимум 1 скан (30 мин)"
              );
              continue;
            }
            // Цена держится + прошёл 1 скан → сигнал
            logger.info(
              { symbol, drift: priceFromDetection.toFixed(1) + "%", ageMin: (ageMs / 60000).toFixed(1) },
              "✅ 4H MOMENTUM: цена держится — сигнал разрешён"
            );
            // Проваливаемся к финальным проверкам (runaway/stale cancel и выдача)
          }

          if (!isSlowPattern && entryTf !== "4h_momentum" && ageMs < CONFIRM_WINDOW_MS) {
            // Ещё в окне наблюдения. Ранняя отмена если OI уже иссяк или цена рухнула.
            const earlyOIDrain = cgOI?.available && cgOIChange < OI_DRAIN_PCT;
            const earlyRetrace = priceFromDetection < MAX_RETRACE_PCT;
            if (earlyOIDrain || earlyRetrace) {
              await db.update(oiWatchTable)
                .set({ status: "expired", firedAt: new Date() })
                .where(eq(oiWatchTable.id, entry.id));
              logger.info(
                { symbol, tf: entryTf, ageMin: (ageMs / 60000).toFixed(1), oi: cgOIChange.toFixed(1) + "%", drift: priceFromDetection.toFixed(1) + "%" },
                earlyOIDrain
                  ? "❌ CONFIRM EARLY CANCEL: OI иссяк до окончания ожидания"
                  : "❌ CONFIRM EARLY CANCEL: цена откатилась > 5% — ложный сигнал"
              );
              continue;
            }
            logger.debug(
              { symbol, tf: entryTf, waitMin, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%", freshOI: cgOIChange.toFixed(1) + "%" },
              `⏳ CONFIRMING: ждём ${waitMin} мин. OI держится.`
            );
            continue;
          }

          // Окно закрылось — финальные проверки

          if (cgOI?.available && cgOIChange < OI_DRAIN_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, freshOI: cgOIChange.toFixed(1) + "%" },
              `❌ CONFIRM FAILED: ${waitMin} мин прошло, но OI упал — накопление закончилось`
            );
            continue;
          }

          if (priceFromDetection < MAX_RETRACE_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%" },
              `❌ CONFIRM FAILED: цена откатилась > 5% за ${waitMin} мин — ложный сигнал`
            );
            continue;
          }

          if (priceFromDetection > MAX_RUNAWAY_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%" },
              `❌ CONFIRM SKIP: цена ушла > ${MAX_RUNAWAY_PCT}% вверх — вход слишком поздний`
            );
            continue;
          }

          // Ждём реального начала роста — не входим если цена ещё в минусе или флэте.
          // ZBT-кейс: цена -2.5% → в допуске [-5%..+10%] → сигнал стрелял → вход на дне.
          // ZETA/ATOM/CRV-кейс: цена +0.5% → signal fire → сразу разворот → peak=0% → stale cancel.
          // Теперь: ждём минимум +2% реального движения от точки детектирования.
          const MIN_POSITIVE_DRIFT = 2.0;
          if (priceFromDetection < MIN_POSITIVE_DRIFT) {
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%", ageMin: (ageMs / 60000).toFixed(0) },
              "⏳ CONFIRM WAIT: цена ещё не в росте — ждём старта движения"
            );
            continue; // не отменяем, просто ждём — expire случится через 6ч если роста не будет
          }

          // ✅ OI держится, цена пошла вверх — сигнал подтверждён
          await db.update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(eq(oiWatchTable.id, entry.id));
          logger.info(
            { symbol, tf: entryTf, waitMin, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%", freshOI: cgOIChange.toFixed(1) + "%" },
            `✅ CONFIRMED: OI держится ${waitMin} мин, цена стабильна — сигнал разрешён`
          );
        } else {
          // Первый раз видим — сохраняем реальный ТФ, чтобы знать сколько ждать
          try {
            await db.insert(oiWatchTable).values({
              symbol,
              triggerTf: oiTriggerTf,   // реальный ТФ вместо "confirm"
              oiChange: cgOIChange,
              priceAtEntry: confirmPriceMap.get(symbol) ?? close,
              volumeMultiplier: volMult,
              sentimentKey: det.sentiment.key,
              status: "confirming",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + CONFIRM_EXPIRE_MS),
              avgVolume: avgVol,
            });
            const waitMin =
              (oiTriggerTf.includes("24h") || oiTriggerTf.includes("4h")) ? 15
              : oiTriggerTf.includes("1h") ? 30 : 60;
            logger.info(
              { symbol, tf: oiTriggerTf, waitMin, price: priceChange.toFixed(1) + "%", oi: cgOIChange.toFixed(1) + "%", pattern: det.sentiment.key },
              `🕐 QUEUED: первое обнаружение — ждём ${waitMin} мин подтверждения OI`
            );
          } catch (err) {
            logger.warn({ err, symbol }, "confirming OI Watch insert failed");
          }
          continue;
        }
      }

      logger.info(
        {
          symbol,
          globalOI: cgOIChange.toFixed(1) + "%",
          bingxOI: cgOI?.bingxOiChange30m != null ? cgOI.bingxOiChange30m.toFixed(1) + "%" : "n/a",
          vol: volMult.toFixed(1) + "x",
          price: priceChange.toFixed(1) + "%",
          pattern: det.sentiment.key,
        },
        "CoinGlass OI + Volume PASSED → candidate"
      );

      // When cgOI is undefined (bingx_volume path), use a minimal fallback
      const safeOI: CoinglassOIResult = cgOI ?? {
        available: false, source: "coinglass", oiUsd: 0,
        oiChange5m: null, oiChange30m: 0,
        oiChange1h: null, oiChange4h: null, oiChange24h: null,
        bingxOiChange30m: null, cgVolUsd: null,
      };

      candidates.push({
        symbol,
        price: close,
        priceChange30m: priceChange,
        price4hChange,
        currentVolume: currentVol,
        avgVolume: avgVol,
        volumeMultiplier: volMult,
        oiChangePercent: cgOIChange,
        oiChange5m: oi5m,
        oiChange1h: oi1h,
        oiChange4h: oi4h,
        oiChange24h: oi24h,
        openInterest: safeOI.oiUsd ?? 0,
        sentiment: det.sentiment,
        coinglassOI: safeOI,
        oiTriggerTf,
        isRepeatSignal,
      });
    } catch (err) {
      logger.warn({ symbol, err }, "Error scanning symbol");
    }
    await new Promise(r => setTimeout(r, 100));
  }

  // Log top-5 by volume among those that passed CoinGlass OI filter
  const top5 = [...debugTop]
    .sort((a, b) => b.vol - a.vol)
    .slice(0, 5);
  if (top5.length > 0) {
    logger.info(
      {
        top5: top5.map(d => ({
          symbol: d.symbol,
          vol: d.vol.toFixed(1) + "x",
          globalOI: d.cgOI != null ? d.cgOI.toFixed(1) + "%" : "n/a",
          price: d.price.toFixed(2) + "%",
        }))
      },
      "Top-5 (CoinGlass OI passed) by volume this cycle"
    );
  }

  if (candidates.length === 0) {
    state.lastScanAt = new Date();
    state.marketsScanned = usdtTickers.length;
    logger.info(
      {
        marketsScanned: usdtTickers.length,
        oiMovers: oiMoversCount,
        topActive: scanLimit,
        skipped: {
          exhaustedPump: skipCount.exhaustedPump,
          noOiNoVol: skipCount.noOiNoVol,
          lowVolume: skipCount.lowVolume,
          deepNeg: skipCount.deepNegative,
          other: skipCount.other,
        },
      },
      "No candidates this cycle (CoinGlass OI + Volume filters)"
    );
    await persistBaselinesToDb();
    return { signalsFound: 0, marketsScanned: usdtTickers.length, durationMs: Date.now() - startTime };
  }

  // ── FRESH PRICE FETCH ───────────────────────────────────────────────────────
  // CoinGlass batch занял 8+ мин. Klines были взяты в начале скана, поэтому
  // base.price = закрытие свечи из прошлого. Перечитываем текущую цену для
  // каждого кандидата, чтобы трекер и Telegram показывали реальную точку входа.
  const freshPriceMap = new Map<string, number>();
  try {
    const freshTickers = await getFutureTickers();
    for (const t of freshTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) freshPriceMap.set((t as any).symbol, p);
    }
    logger.info({ fetched: freshPriceMap.size }, "Fresh ticker prices fetched for candidate entry pricing");
  } catch (err) {
    logger.warn({ err }, "Failed to fetch fresh ticker prices — using kline close as fallback");
  }

  logger.info({ count: candidates.length }, "Phase 3: grade + score for CoinGlass OI candidates...");

  // Phase 3: grade + score (CoinGlass OI already confirmed in Phase 1)
  const alphaResults: AlphaResult[] = [];
  const signalsToInsert: InsertSignal[] = [];

  for (const base of candidates) {
    const { symbol } = base;

    // CoinGlass OI data already fetched in batch — use directly
    const coinglassOI = base.coinglassOI;
    const coinalyzeOiChange = coinglassOI.oiChange30m; // global aggregate
    const coinalyzeConfirmed = true; // all candidates already passed CoinGlass OI filter

    const [trending, liquidations, fundingData] = await Promise.all([
      getTrendingRank(symbol),
      getLiquidations(symbol),
      getFundingRate(symbol),
    ]);

    const fundingRate = fundingData?.lastFundingRate != null ? parseFloat(fundingData.lastFundingRate) : null;
    const markPrice  = fundingData?.markPrice  != null ? parseFloat(fundingData.markPrice)  : null;
    const indexPrice = fundingData?.indexPrice != null ? parseFloat(fundingData.indexPrice) : null;

    if (fundingRate != null) {
      logger.info(
        { symbol, fundingRate: (fundingRate * 100).toFixed(4) + "%" },
        fundingRate <= -0.0003 ? "💰 Глубоко отрицательный фандинг — шорты в ловушке"
          : fundingRate <= -0.0001 ? "💰 Фандинг отрицательный — шорты платят"
          : fundingRate >= 0.0003  ? "⚠️ Фандинг сильно положительный — лонги перегреты"
          : "⚖️ Фандинг нейтральный"
      );
    }

    // Re-detect sentiment now that we have liquidation data
    const finalSentiment = detectSentiment(
      base.priceChange30m,
      base.oiChangePercent,
      base.volumeMultiplier,
      liquidations.multiple ?? null,
      base.oiTriggerTf,
    );

    // ── STEP 5: Alpha Score (1–10) ──────────────────────────────────────────────
    const alphaScore = calcAlphaScore({
      oiChange: base.oiChangePercent,
      volumeMultiplier: base.volumeMultiplier,
      priceChange: base.priceChange30m,
      sentimentKey: finalSentiment.key,
      cmcAvailable: trending.available,
      cmcRank: trending.rank,
      coinglassAvailable: liquidations.available,
      liquidationsMultiple: liquidations.multiple,
      fundingRate,
    });

    // ── STEP 5: Grading ──────────────────────────────────────────────────────────
    // bingx_volume — только объём + цена, без OI подтверждения → ставим в OI Watch на 15 мин
    // super_alpha  — Score ≥ 8 И OI подтвердили 2+ таймфрейма, OR глобальный OI ≥ 15%
    // alpha        — стандартный сигнал (OI сработал на 1+ ТФ)

    // Считаем количество OI таймфреймов которые сработали для этого кандидата
    const oiTfCount = base.oiTriggerTf === "bingx_volume" ? 0
      : base.oiTriggerTf === "steady"                     ? 2
      : base.oiTriggerTf.startsWith("fast_track")
        ? base.oiTriggerTf.split("+").slice(1).length
        : base.oiTriggerTf.split("+").length;

    // Grade будет обновлён после OB анализа (finalAlphaScore) — здесь предварительное значение
    let grade: "alpha" | "super_alpha" | "bingx_volume" =
      base.oiTriggerTf === "bingx_volume"                                        ? "bingx_volume"
      : (alphaScore >= 8 && oiTfCount >= 2) || Math.abs(base.oiChangePercent) >= 15 ? "super_alpha"
      : "alpha";

    // ── FILTER: Аномалия в пост-памп контексте (4h) ─────────────────────────────
    // Если паттерн — anomaly (fallback, нет чёткого накопления) И цена уже выросла
    // >10% за последние 4ч — это остаточный объём после пампа, не накопление.
    // Breakout-паттерны (sharp_impulse, aggressive_breakout) не блокируются.
    // Исключение: 4h_momentum — весь смысл паттерна в том что price4hChange > 8%.
    if (finalSentiment.key === "anomaly" && base.price4hChange > 10 && base.oiTriggerTf !== "4h_momentum") {
      logger.info(
        { symbol, price4hChange: base.price4hChange.toFixed(1) + "%" },
        "SKIP: аномалия в пост-памп контексте — цена +>10% за 4ч"
      );
      skipCount.other++;
      continue;
    }

    // ── CVD Filter: третье подтверждение — покупатели должны доминировать ────────
    const cvd = await fetchCVD(symbol);
    if (cvd) {
      if (!cvd.positive) {
        logger.info(
          { symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", trades: cvd.trades },
          "🔴 CVD негативный — продажи доминируют, пропускаем сигнал"
        );
        skipCount.other++;
        continue;
      }
      logger.info(
        { symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", trades: cvd.trades },
        "🟢 CVD позитивный — покупатели доминируют"
      );
    } else {
      logger.warn({ symbol }, "CVD: не удалось получить данные — пропускаем проверку");
    }

    // ── STEP 6: Order Book Imbalance (стакан BingX) ──────────────────────────────
    // Запрашиваем только для финальных кандидатов (прошли CVD и все фильтры).
    // Буллиш стакан → бонус до +2 к alpha score.
    const obImbalance = await getOrderBookAnalysis(symbol, 20);
    let finalAlphaScore = alphaScore;

    if (obImbalance) {
      finalAlphaScore = Math.min(10, alphaScore + obImbalance.scoreBonus);

      const biasLabel = obImbalance.bias === "strong_bull" ? "🟢🟢 STRONG BULL" :
                        obImbalance.bias === "bull"         ? "🟢 BULL" :
                        obImbalance.bias === "bear"         ? "🔴 BEAR" : "⚪ NEUTRAL";

      logger.info({
        symbol,
        bidAskRatio:  obImbalance.bidAskRatio.toFixed(2),
        bidVolumeUsd: obImbalance.bidVolumeUsd.toFixed(0),
        askVolumeUsd: obImbalance.askVolumeUsd.toFixed(0),
        bidWalls:     obImbalance.bidWallCount,
        largestWall:  `$${obImbalance.largestBidWallUsd.toFixed(0)} @ ${obImbalance.largestBidWallPrice}`,
        bias:         biasLabel,
        scoreBonus:   obImbalance.scoreBonus > 0 ? `+${obImbalance.scoreBonus}` : "0",
      }, "📚 Order book analysis");
    } else {
      logger.warn({ symbol }, "📚 Order book: данные недоступны");
    }

    // Пересчёт grade с учётом OB бонуса
    if (grade !== "bingx_volume" && obImbalance && obImbalance.scoreBonus > 0) {
      if ((finalAlphaScore >= 8 && oiTfCount >= 2) || Math.abs(base.oiChangePercent) >= 15) {
        grade = "super_alpha";
      }
    }

    // State tracking
    const prevState = signalHistory.get(symbol);
    const isContinuing = !!prevState;
    const cumulativeOiChange = prevState
      ? prevState.cumulativeOiChange + base.oiChangePercent
      : base.oiChangePercent;

    signalHistory.set(symbol, {
      firstSignalAt: prevState?.firstSignalAt ?? new Date(),
      signalCount: (prevState?.signalCount ?? 0) + 1,
      cumulativeOiChange,
    });

    const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${symbol.replace("-", "")}`;
    const bingxUrl = `https://bingx.com/en/trade/${symbol.replace("-", "")}/`;

    // Используем свежую цену (текущий рынок), а не закрытие kline 8 мин назад.
    // Это предотвращает ситуацию когда трекер видит "вход" по старой цене
    // и сразу стреляет milestone 25%/50% потому что рынок уже ушёл.
    const freshPrice = freshPriceMap.get(symbol) ?? base.price;
    const klineSlippage = base.price > 0 ? ((freshPrice - base.price) / base.price) * 100 : 0;
    if (Math.abs(klineSlippage) >= 3) {
      logger.info(
        { symbol, klineClose: base.price, freshPrice, slippage: klineSlippage.toFixed(1) + "%" },
        "⚠️ Entry price slippage since kline fetch — using fresh price"
      );
    }

    alphaResults.push({
      symbol,
      grade,
      price: freshPrice,
      priceChange30m: base.priceChange30m,
      currentVolume: base.currentVolume,
      avgVolume: base.avgVolume,
      volumeMultiplier: base.volumeMultiplier,
      oiChangePercent: base.oiChangePercent,
      openInterest: base.openInterest,
      cmcRank: trending.rank,
      cmcSource: trending.source,
      cmcAvailable: trending.available,
      liquidationsUsd: liquidations.liquidationsUsd,
      liquidationsMultiple: liquidations.multiple,
      coinglassAvailable: liquidations.available,
      coinalyzeOiChange,
      coinalyzeConfirmed,
      isNewListing: false,
      isExhaustedSqueeze: false,
      pumpFromOpen: null,
      candleCount: 48,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      traderAction: finalSentiment.traderAction,
      isContinuing,
      cumulativeOiChange,
      tradingViewUrl,
      bingxUrl,
      oiTriggerTf: base.oiTriggerTf,
      oiChange5m: base.oiChange5m,
      oiChange1h: base.oiChange1h,
      oiChange4h: base.oiChange4h,
      oiChange24h: base.oiChange24h,
      klineSlippage,
      isRepeatSignal: base.isRepeatSignal,
      fundingRate,
      markPrice,
      indexPrice,
      obImbalance,
      alphaScore: finalAlphaScore,
    });

    signalsToInsert.push({
      symbol,
      type: grade,
      value: base.volumeMultiplier,
      threshold: settings.volumeMultiplier,
      price: freshPrice,
      priceChangePercent: base.priceChange30m,
      volume24h: base.currentVolume,
      avgVolume: base.avgVolume,
      openInterest: base.openInterest,
      oiChangePercent: base.oiChangePercent,
      fundingRate: fundingRate ?? null,
      tradingViewUrl,
      cmcRank: trending.rank ?? null,
      cmcSource: trending.source ?? null,
      liquidationsUsd: liquidations.liquidationsUsd ?? null,
      liquidationsMultiple: liquidations.multiple ?? null,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      alphaScore,
      isContinuing,
      cumulativeOiChange,
      detectedAt: new Date(),
    });

    logger.info(
      { symbol, grade, alphaScore, pattern: finalSentiment.key },
      `✅ ${grade.toUpperCase()} score=${alphaScore}`
    );
  }

  // ── Route signals through OI Watch (two-stage confirmation) ─────────────────
  // alpha/super_alpha: isVolConfirmed=true, 30-min window — fire as soon as conditions hold
  // bingx_volume:      isVolConfirmed=false, 15-min window — wait for CoinGlass OI to appear
  //                    If OI confirms within 15 min → upgrade to alpha and fire
  //                    If no OI within 15 min → expire silently (avoid noise)

  for (let i = 0; i < alphaResults.length; i++) {
    const res = alphaResults[i];
    const sig = signalsToInsert[i];
    try {
      const payload = { alphaResult: res, signalRow: sig };
      const isBvGrade = res.grade === "bingx_volume";

      const expiresAt = new Date(Date.now() + (isBvGrade ? 15 : 90) * 60 * 1000);
      const triggerTf = isBvGrade ? "bingx_volume_watch" : res.oiTriggerTf;
      const isVolConfirmed = !isBvGrade;

      const existing = await db.select({ id: oiWatchTable.id, status: oiWatchTable.status })
        .from(oiWatchTable)
        .where(and(eq(oiWatchTable.symbol, res.symbol), eq(oiWatchTable.status, "watching")))
        .limit(1);

      if (existing.length > 0) {
        await db.update(oiWatchTable)
          .set({
            oiChange: res.oiChangePercent,
            volumeMultiplier: res.volumeMultiplier,
            priceAtEntry: res.price,
            expiresAt,
            isVolConfirmed,
            signalPayload: payload as any,
          })
          .where(eq(oiWatchTable.id, existing[0].id));
        logger.info(
          { symbol: res.symbol, grade: res.grade, vol: res.volumeMultiplier.toFixed(1) + "x" },
          isBvGrade ? "👁 BingX Volume Watch: ждём OI подтверждения (15 мин)" : "👁 OI Watch: обновлён свежими данными"
        );
      } else {
        await db.insert(oiWatchTable).values({
          symbol: res.symbol,
          triggerTf,
          oiChange: res.oiChangePercent,
          priceAtEntry: res.price,
          volumeMultiplier: res.volumeMultiplier,
          sentimentKey: res.sentimentKey,
          status: "watching",
          addedAt: new Date(),
          expiresAt,
          avgVolume: res.avgVolume,
          isVolConfirmed,
          signalPayload: payload as any,
        });
        logger.info(
          { symbol: res.symbol, grade: res.grade, alphaScore: res.alphaScore, vol: res.volumeMultiplier.toFixed(1) + "x" },
          isBvGrade
            ? "👁 BingX Volume Watch: добавлен — сработает если OI подтвердит за 15 мин"
            : "👁 OI Watch: сигнал в очереди — сработает через 2 мин если условия сохранятся"
        );
      }
    } catch (err) {
      logger.warn({ err, symbol: res.symbol }, "Ошибка при постановке сигнала в OI Watch");
    }
  }

  const totalSignals = alphaResults.length;
  state.lastScanAt = new Date();
  state.marketsScanned = usdtTickers.length;

  const durationMs = Date.now() - startTime;
  logger.info(
    {
      signalsFound: totalSignals,
      alphaCount: alphaResults.filter(r => r.grade === "alpha").length,
      superAlphaCount: alphaResults.filter(r => r.grade === "super_alpha").length,
      bingxVolumeCount: alphaResults.filter(r => r.grade === "bingx_volume").length,
      marketsScanned: usdtTickers.length,
      durationMs,
    },
    "Scan complete"
  );

  // Persist OI baselines to DB every 5 min so restarts don't lose context
  await persistBaselinesToDb();

  return { signalsFound: totalSignals, marketsScanned: usdtTickers.length, durationMs };
}

/**
 * Вычисляет задержку до следующего выровненного интервала скана.
 * Например, при интервале 30 мин и текущем времени HH:17:xx →
 * следующий скан будет ровно в HH:30:00 (+ 2с), а не HH:17+30=HH:47.
 * Это устраняет drift: каждый скан попадает в начало 30-минутной свечи.
 */
function msUntilNextBoundary(intervalMs: number): number {
  const now = Date.now();
  const msSinceEpoch = now % intervalMs;
  const msToNext = intervalMs - msSinceEpoch;
  // Добавляем 2 секунды, чтобы гарантированно попасть в новую свечу
  return msToNext + 2000;
}

async function scheduledScan() {
  if (!state.running) return;
  try {
    await performScan();
  } catch (err) {
    logger.error({ err }, "Scheduled scan error");
  }
  if (state.running) {
    const settings = await getSettings();
    state.scanIntervalMs = settings.scanIntervalMs;
    const delay = msUntilNextBoundary(settings.scanIntervalMs);
    state.nextScanAt = new Date(Date.now() + delay);
    scanTimer = setTimeout(scheduledScan, delay);
    logger.info({ nextScanIn: `${Math.round(delay / 1000)}s`, nextScanAt: state.nextScanAt }, "Next scan scheduled");
  }
}

export async function startScanner(): Promise<void> {
  if (state.running) return;
  state.running = true;
  logger.info("Alpha Scanner started (5-Pattern, 5m scan, 30m TF)");

  state.bingxConnected = await testBingX();
  state.telegramConnected = await testTelegram();

  // Restore OI baselines from DB so restarts don't cause a blind period
  await loadBaselinesFromDb();

  const settings = await getSettings();
  state.scanIntervalMs = settings.scanIntervalMs;

  await performScan();

  const delay = msUntilNextBoundary(settings.scanIntervalMs);
  state.nextScanAt = new Date(Date.now() + delay);
  scanTimer = setTimeout(scheduledScan, delay);
  logger.info({ nextScanIn: `${Math.round(delay / 1000)}s`, nextScanAt: state.nextScanAt }, "Next scan scheduled");
}

export async function stopScanner(): Promise<void> {
  state.running = false;
  state.nextScanAt = null;
  if (scanTimer) {
    clearTimeout(scanTimer);
    scanTimer = null;
  }
  logger.info("Scanner stopped");
}

export async function getScannerState(): Promise<ScannerState & { totalSignals: number; signalsToday: number }> {
  const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(signalsTable);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [todayResult] = await db
    .select({ count: sql<number>`count(*)` })
    .from(signalsTable)
    .where(gte(signalsTable.detectedAt, today));

  return {
    ...state,
    totalSignals: Number(totalResult.count),
    signalsToday: Number(todayResult.count),
  };
}
