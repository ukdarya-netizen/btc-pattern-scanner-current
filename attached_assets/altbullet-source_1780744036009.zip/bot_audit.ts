
// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/app.ts
// ═══════════════════════════════════════════════════════

import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Disable ETag — prevents 304 Not Modified caching of API responses in the dashboard
app.set("etag", false);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Force no-cache on all API responses so the dashboard always gets fresh data
app.use("/api", (_, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

app.use("/api", router);

export default app;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/index.ts
// ═══════════════════════════════════════════════════════

import app from "./app";
import { logger } from "./lib/logger";
import { setWebhook } from "./lib/telegram.js";
import { startScanner, stopScanner } from "./lib/scanner.js";
import { startWatcher, broadcast } from "./lib/watcher.js";
import { startOrderBookScanner } from "./lib/orderbookScanner.js";

// ── Глобальная защита от падения процесса ─────────────────────────────────────
// Без этого Node.js завершает процесс при любом необработанном промисе/исключении.
process.on("unhandledRejection", (reason, promise) => {
  logger.error({ reason, promise: String(promise) }, "⚠️ Unhandled promise rejection — caught, server stays alive");
});

process.on("uncaughtException", (err) => {
  logger.error({ err }, "⚠️ Uncaught exception — caught, server stays alive");
});

// ── Graceful shutdown при деплое (SIGTERM от Replit) ──────────────────────────
// Останавливаем планировщик сканера, даём текущим операциям завершиться (10 сек),
// затем выходим чисто — без обрыва на середине скана или отправки Telegram.
let isShuttingDown = false;
async function gracefulShutdown(signal: string) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  logger.info({ signal }, "Graceful shutdown: получен сигнал, останавливаем сканер...");
  try {
    await stopScanner();
  } catch { /* non-critical */ }
  // Ждём 5 секунд чтобы текущие DB/Telegram операции завершились
  await new Promise(resolve => setTimeout(resolve, 5_000));
  logger.info("Graceful shutdown: завершено, выходим");
  process.exit(0);
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT",  () => gracefulShutdown("SIGINT"));

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  const domains = process.env.REPLIT_DOMAINS;
  if (domains) {
    const domain = domains.split(",")[0].trim();
    const webhookUrl = `https://${domain}/api/telegram/webhook`;
    const ok = await setWebhook(webhookUrl);
    if (ok) {
      logger.info({ webhookUrl }, "Telegram webhook registered");
    } else {
      logger.warn("Failed to register Telegram webhook — bot subscriptions may not work");
    }
  } else {
    logger.info("REPLIT_DOMAINS not set, skipping webhook registration");
  }

  // Auto-start scanner on server boot
  startScanner().catch(err => logger.error({ err }, "Failed to auto-start scanner"));

  // Auto-start alpha watcher
  startWatcher();

  // Auto-start order book scanner (watchlist stacks)
  startOrderBookScanner().catch(err => logger.error({ err }, "Failed to auto-start order book scanner"));

  // Startup notification — только в продакшне, чтобы dev-рестарты не спамили в Telegram
  if (process.env.NODE_ENV !== "development") {
    broadcast("🚀 <b>Бот запущен.</b> Версия v5.0. Сканирование активно.").catch(err =>
      logger.error({ err }, "Failed to send startup message")
    );
  }
});

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/bingx.ts
// ═══════════════════════════════════════════════════════

import crypto from "crypto";

const BINGX_BASE_URL = "https://open-api.bingx.com";

function sign(params: Record<string, string | number>, secret: string): string {
  const queryString = Object.entries(params)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("&");
  return crypto.createHmac("sha256", secret).update(queryString).digest("hex");
}

function buildSignedParams(params: Record<string, string | number>, secret: string): string {
  const timestamp = Date.now();
  const allParams = { ...params, timestamp };
  const signature = sign(allParams, secret);
  const queryString = Object.entries(allParams)
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
    .join("&");
  return `${queryString}&signature=${signature}`;
}

async function bingxGet(path: string, params: Record<string, string | number> = {}, signed = false): Promise<unknown> {
  const apiKey = process.env.BINGX_API_KEY;
  const apiSecret = process.env.BINGX_API_SECRET;

  let qs: string;
  const headers: Record<string, string> = {
    "X-SOURCE-KEY": "AlphaScanner",
  };

  if (signed) {
    if (!apiKey || !apiSecret) throw new Error("BINGX_API_KEY and BINGX_API_SECRET are required");
    headers["X-BX-APIKEY"] = apiKey;
    qs = buildSignedParams(params, apiSecret);
  } else {
    qs = Object.entries(params)
      .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
      .join("&");
  }

  const url = `${BINGX_BASE_URL}${path}${qs ? "?" + qs : ""}`;
  const res = await fetch(url, { headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`BingX API error ${res.status}: ${text}`);
  }
  return res.json();
}

export interface BingXTicker {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  volume: string;
  quoteVolume: string;
  // Available on some BingX endpoints
  bidPrice?: string;
  askPrice?: string;
  openInterestSize?: string; // OI in base asset (if returned by ticker)
}

export interface BingXKline {
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  openTime: number;
  closeTime: number;
}

export interface BingXOpenInterest {
  symbol: string;
  openInterest: string;
  time: number;
}

export interface BingXFundingRate {
  symbol: string;
  lastFundingRate: string;
  nextFundingTime: number;
  markPrice: string;
  indexPrice?: string;
}

export async function getFutureTickers(): Promise<BingXTicker[]> {
  const data = await bingxGet("/openApi/swap/v2/quote/ticker") as { data: BingXTicker[] };
  return data.data ?? [];
}

export async function getFutureTicker(symbol: string): Promise<BingXTicker | null> {
  try {
    const data = await bingxGet("/openApi/swap/v2/quote/ticker", { symbol }) as { data: BingXTicker | BingXTicker[] };
    const result = data.data;
    if (!result) return null;
    return Array.isArray(result) ? (result[0] ?? null) : result;
  } catch {
    return null;
  }
}

export async function getKlines(symbol: string, interval = "5m", limit = 288): Promise<BingXKline[]> {
  const data = await bingxGet("/openApi/swap/v3/quote/klines", { symbol, interval, limit }) as { data: BingXKline[] };
  return data.data ?? [];
}

export async function getOpenInterest(symbol: string): Promise<BingXOpenInterest | null> {
  try {
    const data = await bingxGet("/openApi/swap/v2/quote/openInterest", { symbol }) as { data: BingXOpenInterest };
    return data.data ?? null;
  } catch {
    return null;
  }
}

export async function getFundingRate(symbol: string): Promise<BingXFundingRate | null> {
  try {
    const data = await bingxGet("/openApi/swap/v2/quote/premiumIndex", { symbol }) as { data: BingXFundingRate };
    return data.data ?? null;
  } catch {
    return null;
  }
}

export async function testConnection(): Promise<boolean> {
  try {
    await bingxGet("/openApi/swap/v2/quote/ticker");
    return true;
  } catch {
    return false;
  }
}

// ── Order Book Analysis ───────────────────────────────────────────────────────

export interface OrderBookLevel {
  price: number;
  qty:   number;
  usd:   number; // price × qty
}

export interface OrderBookAnalysis {
  /** Суммарный объём бидов (USD) в топ-N уровнях */
  bidVolumeUsd: number;
  /** Суммарный объём асков (USD) в топ-N уровнях */
  askVolumeUsd: number;
  /** bidVolumeUsd / askVolumeUsd */
  bidAskRatio: number;
  /** Самая крупная стена на биде (USD) */
  largestBidWallUsd: number;
  /** Цена самой крупной bid-стены */
  largestBidWallPrice: number;
  /** Самая крупная bid-стена как % от суммарных бидов */
  largestBidWallPct: number;
  /** Количество уровней с bid > 3× среднего — "кластер стен" */
  bidWallCount: number;
  /** Степень давления: "strong_bull" > 3:1 | "bull" > 1.8:1 | "neutral" | "bear" < 0.6:1 */
  bias: "strong_bull" | "bull" | "neutral" | "bear";
  /** +0..+2 бонус к alpha score */
  scoreBonus: number;
}

/**
 * Fetches order book depth from BingX and computes imbalance metrics.
 * limit=20: достаточно для детекции стен и имбаланса, минимальная нагрузка на API.
 */
export async function getOrderBookAnalysis(symbol: string, limit = 20): Promise<OrderBookAnalysis | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const url = `${BINGX_BASE_URL}/openApi/swap/v2/quote/depth?symbol=${encodeURIComponent(symbol)}&limit=${limit}`;
    const res = await fetch(url, {
      headers: { "X-SOURCE-KEY": "AlphaScanner" },
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;

    const data = await res.json() as {
      data?: {
        bids?: [string, string][];
        asks?: [string, string][];
      };
    };

    const rawBids = data.data?.bids ?? [];
    const rawAsks = data.data?.asks ?? [];
    if (rawBids.length === 0 && rawAsks.length === 0) return null;

    // Parse levels
    const bids: OrderBookLevel[] = rawBids.map(([p, q]) => {
      const price = parseFloat(p); const qty = parseFloat(q);
      return { price, qty, usd: price * qty };
    });
    const asks: OrderBookLevel[] = rawAsks.map(([p, q]) => {
      const price = parseFloat(p); const qty = parseFloat(q);
      return { price, qty, usd: price * qty };
    });

    const bidVolumeUsd = bids.reduce((s, l) => s + l.usd, 0);
    const askVolumeUsd = asks.reduce((s, l) => s + l.usd, 0);
    const bidAskRatio  = askVolumeUsd > 0 ? bidVolumeUsd / askVolumeUsd : 0;

    // Bid wall detection: уровни где объём > 3× среднего
    const avgBidUsd = bids.length > 0 ? bidVolumeUsd / bids.length : 0;
    const wallThreshold = avgBidUsd * 3;
    const bidWalls = bids.filter(l => l.usd >= wallThreshold);

    const largestWall    = bids.reduce((best, l) => l.usd > best.usd ? l : best, { price: 0, qty: 0, usd: 0 });
    const largestBidWallUsd   = largestWall.usd;
    const largestBidWallPrice = largestWall.price;
    const largestBidWallPct   = bidVolumeUsd > 0 ? (largestBidWallUsd / bidVolumeUsd) * 100 : 0;
    const bidWallCount        = bidWalls.length;

    // Bias classification
    const bias: OrderBookAnalysis["bias"] =
      bidAskRatio >= 3.0 ? "strong_bull" :
      bidAskRatio >= 1.8 ? "bull" :
      bidAskRatio <= 0.6 ? "bear" : "neutral";

    // Score bonus: только для bullish bias с реальной глубиной стакана (>$5k)
    const scoreBonus =
      (bias === "strong_bull" && bidWallCount >= 1 && bidVolumeUsd >= 5000) ? 2 :
      (bias === "bull"         && bidVolumeUsd >= 3000)                       ? 1 : 0;

    return {
      bidVolumeUsd, askVolumeUsd, bidAskRatio,
      largestBidWallUsd, largestBidWallPrice, largestBidWallPct,
      bidWallCount, bias, scoreBonus,
    };
  } catch {
    return null;
  }
}

export interface CVDResult {
  buyPct: number;
  sellPct: number;
  cvd: number;
  positive: boolean;
  trades: number;
}

export async function fetchCVD(symbol: string, limit = 2000): Promise<CVDResult | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const url = `${BINGX_BASE_URL}/openApi/swap/v2/quote/trades?symbol=${encodeURIComponent(symbol)}&limit=${limit}`;
    const res = await fetch(url, {
      headers: { "X-SOURCE-KEY": "AlphaScanner" },
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    const data = await res.json() as { data?: Array<{ qty: string; isBuyerMaker: boolean }> };
    const trades = data.data;
    if (!trades || trades.length === 0) return null;

    let buyVol = 0, sellVol = 0;
    for (const t of trades) {
      const qty = parseFloat(t.qty);
      if (isNaN(qty)) continue;
      if (t.isBuyerMaker) {
        sellVol += qty;
      } else {
        buyVol += qty;
      }
    }

    const total = buyVol + sellVol;
    if (total === 0) return null;

    const buyPct = (buyVol / total) * 100;
    return {
      buyPct,
      sellPct: 100 - buyPct,
      cvd: buyVol - sellVol,
      positive: buyPct >= 50,
      trades: trades.length,
    };
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/coinalyze.ts
// ═══════════════════════════════════════════════════════

/**
 * Coinalyze — кросс-биржевой агрегатор OI.
 * Используется для верификации: если OI растёт не только на BingX, но и по всему рынку —
 * сигнал значительно сильнее (не манипуляция одной биржей).
 *
 * Требует COINALYZE_API_KEY (бесплатный план: 100 req/day).
 * Ключ: https://coinalyze.net/account/
 *
 * Формат символа: BTCUSDT_PERP.6 (Binance), BTCUSDT_PERP.A (Bybit) и т.д.
 * Мы проверяем агрегат по всем биржам — BTCUSDT_PERP без суффикса.
 */

import { logger } from "./logger.js";

export interface CoinalyzeOIResult {
  /** Кросс-биржевое изменение OI за 30 минут в % */
  oiChange30m: number | null;
  /** Абсолютное значение OI в USD */
  oiUsd: number | null;
  available: boolean;
  source: "coinalyze";
}

// Кэш для снижения числа запросов (30 мин)
const cache = new Map<string, { result: CoinalyzeOIResult; ts: number }>();
const CACHE_TTL = 30 * 60 * 1000; // 30 мин — снижает суточный расход вдвое

// ── Дневной счётчик запросов ─────────────────────────────────────────────────
// Бесплатный план: 100 req/day. Резервируем 90 для single-symbol, 10 — запас.
const DAILY_LIMIT = 90;
let dailyCallCount = 0;
let dailyResetAt = startOfNextDayUtc();

function startOfNextDayUtc(): number {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
  return next.getTime();
}

function checkDailyLimit(): boolean {
  const now = Date.now();
  if (now >= dailyResetAt) {
    logger.info({ prevCount: dailyCallCount }, "Coinalyze daily counter reset");
    dailyCallCount = 0;
    dailyResetAt = startOfNextDayUtc();
  }
  if (dailyCallCount >= DAILY_LIMIT) {
    logger.warn({ dailyCallCount, limit: DAILY_LIMIT }, "Coinalyze daily limit reached — skipping call");
    return false;
  }
  dailyCallCount++;
  return true;
}

/** Возвращает текущее число запросов сегодня и лимит */
export function getCoinalyzeDailyStats(): { used: number; limit: number; remaining: number } {
  return { used: dailyCallCount, limit: DAILY_LIMIT, remaining: Math.max(0, DAILY_LIMIT - dailyCallCount) };
}

/**
 * Нормализует символ BingX в формат Coinalyze.
 * BTC-USDT → BTCUSDT_PERP
 * Примечание: без суффикса биржи = агрегат по всем биржам
 */
function toBingxCoinalyzeSymbol(bingxSymbol: string): string {
  const base = bingxSymbol.replace("-USDT", "");
  return `${base}USDT_PERP`;
}

export async function getCoinalyzeOI(symbol: string): Promise<CoinalyzeOIResult> {
  const apiKey = process.env.COINALYZE_API_KEY;

  const noData: CoinalyzeOIResult = {
    oiChange30m: null,
    oiUsd: null,
    available: false,
    source: "coinalyze",
  };

  if (!apiKey) return noData;

  const cglSymbol = toBingxCoinalyzeSymbol(symbol);

  const cached = cache.get(cglSymbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  // Проверяем дневной лимит перед запросом
  if (!checkDailyLimit()) return noData;

  try {
    // Coinalyze API: open interest history for the last 30 minutes
    // Interval "30" = 30 min candles, we take last 2 to compute change
    const url = new URL("https://coinalyze.net/api/v1/open-interest");
    url.searchParams.set("symbols", cglSymbol);
    url.searchParams.set("interval", "30min");
    url.searchParams.set("limit", "2");
    url.searchParams.set("api_key", apiKey);

    const res = await fetch(url.toString(), {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });

    if (!res.ok) {
      logger.warn({ symbol, status: res.status }, "Coinalyze OI request failed");
      return noData;
    }

    const data = await res.json() as {
      error?: string;
      data?: {
        [sym: string]: {
          t: number[];
          o: number[];   // OI values
          c?: number[];  // close OI
        };
      };
    };

    if (data.error || !data.data) {
      logger.warn({ symbol, err: data.error }, "Coinalyze OI error");
      return noData;
    }

    const symData = data.data[cglSymbol];
    if (!symData || !symData.o || symData.o.length < 2) return noData;

    const values = symData.o;
    const prev = values[values.length - 2];
    const curr = values[values.length - 1];

    const oiChange30m = prev > 0 ? ((curr - prev) / prev) * 100 : null;

    const result: CoinalyzeOIResult = {
      oiChange30m,
      oiUsd: curr,
      available: true,
      source: "coinalyze",
    };

    cache.set(cglSymbol, { result, ts: Date.now() });
    return result;
  } catch (err) {
    logger.warn({ symbol, err }, "Coinalyze OI fetch error");
    return noData;
  }
}

// ── Pool Ranking Cache ────────────────────────────────────────────────────────
interface OIRankEntry { symbol: string; oiUsd: number; }
let poolRankingCache: OIRankEntry[] = [];
let poolRankingCachedAt = 0;
const POOL_CACHE_TTL = 2 * 60 * 60 * 1000; // 2 часа

/**
 * Получить ранжирование символов по абсолютному глобальному OI (USD).
 * Используется для формирования пула 500 монет вместо сортировки по объёму BingX.
 * Кэшируется на 2 часа, чтобы не превышать лимиты API.
 */
export async function getGlobalOIRanking(
  bingxSymbols: string[],
): Promise<OIRankEntry[]> {
  const apiKey = process.env.COINALYZE_API_KEY;
  if (!apiKey || bingxSymbols.length === 0) return [];

  // Return cached ranking if fresh
  if (poolRankingCache.length > 0 && Date.now() - poolRankingCachedAt < POOL_CACHE_TTL) {
    return poolRankingCache;
  }

  const coinalyzeSymbols = bingxSymbols.map(toBingxCoinalyzeSymbol);
  const batches: string[][] = [];
  for (let i = 0; i < coinalyzeSymbols.length; i += 20) {
    batches.push(coinalyzeSymbols.slice(i, i + 20));
  }

  const results: OIRankEntry[] = [];
  let requestCount = 0;

  for (const batch of batches) {
    try {
      const url = new URL("https://coinalyze.net/api/v1/open-interest");
      url.searchParams.set("symbols", batch.join(","));
      url.searchParams.set("interval", "30min");
      url.searchParams.set("limit", "1");
      url.searchParams.set("api_key", apiKey);

      const res = await fetch(url.toString(), {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(8000),
      });

      requestCount++;
      if (!res.ok) {
        logger.warn({ status: res.status, batch: batch.length }, "Coinalyze pool ranking batch failed");
        continue;
      }

      const data = await res.json() as {
        error?: string;
        data?: { [sym: string]: { t: number[]; o: number[] } };
      };

      if (data.error || !data.data) continue;

      for (const [cglSym, symData] of Object.entries(data.data)) {
        if (!symData.o || symData.o.length === 0) continue;
        const oiUsd = symData.o[symData.o.length - 1] ?? 0;
        const bingxSym = cglSym.replace("USDT_PERP", "-USDT");
        results.push({ symbol: bingxSym, oiUsd });
      }

      await new Promise(r => setTimeout(r, 150));
    } catch (err) {
      logger.warn({ err }, "Coinalyze pool ranking error");
    }
  }

  results.sort((a, b) => b.oiUsd - a.oiUsd);

  if (results.length > 0) {
    poolRankingCache = results;
    poolRankingCachedAt = Date.now();
    logger.info({ count: results.length, requests: requestCount }, "Coinalyze global OI pool ranking updated");
  } else {
    logger.warn({ requestCount }, "Coinalyze pool ranking returned no data — keeping fallback");
  }

  return results;
}

/**
 * Получить список топ-N монет по изменению OI с Coinalyze.
 * Используется как первичный фильтр перед проверкой на BingX.
 * Возвращает символы в формате BingX (BTC-USDT) с их OI изменением.
 */
export async function getTopOIMovers(
  bingxSymbols: string[],
  minOiChange = 5,
  limit = 20,
): Promise<{ symbol: string; oiChange: number }[]> {
  const apiKey = process.env.COINALYZE_API_KEY;
  if (!apiKey || bingxSymbols.length === 0) return [];

  // Batch fetch: up to 20 symbols per request
  const coinalyzeSymbols = bingxSymbols.map(toBingxCoinalyzeSymbol);
  const batches: string[][] = [];
  for (let i = 0; i < coinalyzeSymbols.length; i += 20) {
    batches.push(coinalyzeSymbols.slice(i, i + 20));
  }

  const results: { symbol: string; oiChange: number }[] = [];

  for (const batch of batches) {
    try {
      const url = new URL("https://coinalyze.net/api/v1/open-interest");
      url.searchParams.set("symbols", batch.join(","));
      url.searchParams.set("interval", "30min");
      url.searchParams.set("limit", "2");
      url.searchParams.set("api_key", apiKey);

      const res = await fetch(url.toString(), {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(8000),
      });

      if (!res.ok) continue;

      const data = await res.json() as {
        data?: { [sym: string]: { t: number[]; o: number[] } };
      };

      if (!data.data) continue;

      for (const [cglSym, symData] of Object.entries(data.data)) {
        if (!symData.o || symData.o.length < 2) continue;
        const prev = symData.o[symData.o.length - 2];
        const curr = symData.o[symData.o.length - 1];
        if (!prev || prev === 0) continue;

        const oiChange = ((curr - prev) / prev) * 100;
        if (Math.abs(oiChange) >= minOiChange) {
          // Map back to BingX format: BTCUSDT_PERP → BTC-USDT
          const bingxSym = cglSym.replace("USDT_PERP", "-USDT");
          results.push({ symbol: bingxSym, oiChange });
        }
      }

      await new Promise(r => setTimeout(r, 200));
    } catch (err) {
      logger.warn({ err }, "Coinalyze batch OI error");
    }
  }

  return results
    .sort((a, b) => Math.abs(b.oiChange) - Math.abs(a.oiChange))
    .slice(0, limit);
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/coinglass_oi.ts
// ═══════════════════════════════════════════════════════

/**
 * CoinGlass — агрегированный OI по всем биржам.
 * Используется для верификации сигналов: если OI растёт глобально,
 * а не только на BingX — сигнал значительно сильнее.
 *
 * Endpoint: GET /public/v2/open_interest?symbol=BTC
 * Header: coinglassSecret: <API_KEY>
 * Строка "All" в ответе = агрегат по всем биржам.
 *
 * Лимит HOBBYIST: 30 req/min.
 * Кэш: 5 мин на символ.
 */

import { logger } from "./logger.js";

export interface CoinglassOIResult {
  /** Агрегированное изменение OI за 5 минут в % (строка "All") */
  oiChange5m: number | null;
  /** Агрегированное изменение OI за 30 минут в % (строка "All") */
  oiChange30m: number | null;
  /** Агрегированное изменение OI за 1 час в % (строка "All") */
  oiChange1h: number | null;
  /** Агрегированное изменение OI за 4 часа в % (строка "All") */
  oiChange4h: number | null;
  /** Агрегированное изменение OI за 24 часа в % (строка "All") */
  oiChange24h: number | null;
  /** Абсолютный OI в USD (строка "All") */
  oiUsd: number | null;
  /** Глобальный торговый объём в USD (строка "All") — для пре-скрина по CoinGlass */
  cgVolUsd: number | null;
  /** OI изменение специфично для BingX (%) */
  bingxOiChange30m: number | null;
  available: boolean;
  source: "coinglass";
}

const cache = new Map<string, { result: CoinglassOIResult; ts: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 минут — каждый скан получает свежие данные

/** Преобразует BingX-символ в базовый тикер для CoinGlass */
function toBaseSymbol(bingxSymbol: string): string {
  return bingxSymbol.replace("-USDT", "");
}

export async function getCoinglassOI(symbol: string): Promise<CoinglassOIResult> {
  const apiKey = process.env.COINGLASS_API_KEY;

  const noData: CoinglassOIResult = {
    oiChange5m: null,
    oiChange30m: null,
    oiChange1h: null,
    oiChange4h: null,
    oiChange24h: null,
    oiUsd: null,
    cgVolUsd: null,
    bingxOiChange30m: null,
    available: false,
    source: "coinglass",
  };

  if (!apiKey) return noData;

  const base = toBaseSymbol(symbol);
  const cached = cache.get(base);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  try {
    const res = await fetch(
      `https://open-api.coinglass.com/public/v2/open_interest?symbol=${base}`,
      {
        headers: {
          coinglassSecret: apiKey,
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(6000),
      }
    );

    if (!res.ok) {
      logger.warn({ symbol, status: res.status }, "CoinGlass OI request failed");
      return noData;
    }

    const data = await res.json() as {
      success?: boolean;
      code?: string;
      data?: {
        exchangeName: string;
        openInterestAmount: number;
        m5OIChangePercent: number;
        m30OIChangePercent: number;
        h1OIChangePercent: number;
        h4OIChangePercent?: number;
        h24OIChangePercent?: number;
        volUsd?: number;
      }[];
    };

    const rows = data.data;
    if (!rows || rows.length === 0) {
      logger.debug({ symbol }, "CoinGlass OI: no data rows");
      return noData;
    }

    // Строка "All" = агрегат по всем биржам
    const allRow = rows.find(r => r.exchangeName === "All");
    // Строка BingX
    const bingxRow = rows.find(r => r.exchangeName === "BingX");

    if (!allRow) {
      logger.debug({ symbol, exchanges: rows.map(r => r.exchangeName) }, "CoinGlass OI: no 'All' row");
      return noData;
    }

    const result: CoinglassOIResult = {
      oiChange5m: allRow.m5OIChangePercent ?? null,
      oiChange30m: allRow.m30OIChangePercent ?? null,
      oiChange1h: allRow.h1OIChangePercent ?? null,
      oiChange4h: allRow.h4OIChangePercent ?? null,
      oiChange24h: allRow.h24OIChangePercent ?? null,
      oiUsd: allRow.openInterestAmount ?? null,
      cgVolUsd: allRow.volUsd ?? null,
      bingxOiChange30m: bingxRow?.m30OIChangePercent ?? null,
      available: true,
      source: "coinglass",
    };

    cache.set(base, { result, ts: Date.now() });
    logger.debug(
      {
        symbol,
        oi5m: result.oiChange5m?.toFixed(2) + "%",
        oi30m: result.oiChange30m?.toFixed(2) + "%",
        oi1h: result.oiChange1h?.toFixed(2) + "%",
        oi4h: result.oiChange4h != null ? result.oiChange4h.toFixed(2) + "%" : "n/a",
        oi24h: result.oiChange24h != null ? result.oiChange24h.toFixed(2) + "%" : "n/a",
        bingxOI: result.bingxOiChange30m?.toFixed(2) + "%",
      },
      "CoinGlass OI fetched"
    );
    return result;
  } catch (err) {
    logger.warn({ symbol, err }, "CoinGlass OI fetch error");
    return noData;
  }
}

/**
 * Батч-получение CoinGlass OI для списка BingX-символов.
 * Возвращает Map<symbol, CoinglassOIResult> для всех запрошенных символов.
 *
 * Rate limit HOBBYIST: 30 req/min → используем 2 сек между запросами.
 * Символы с актуальным кэшем (< 5 мин) возвращаются мгновенно без API-вызова.
 */
export async function batchGetCoinglassOI(
  bingxSymbols: string[],
): Promise<Map<string, CoinglassOIResult>> {
  const results = new Map<string, CoinglassOIResult>();
  const STAGGER_MS = 2000; // 30 req/min max

  for (let i = 0; i < bingxSymbols.length; i++) {
    const symbol = bingxSymbols[i];
    const base = toBaseSymbol(symbol);

    // Check cache first — if fresh, no stagger needed
    const cached = cache.get(base);
    const isCached = cached && Date.now() - cached.ts < CACHE_TTL;

    if (!isCached && i > 0) {
      // Stagger only if we actually need to make an API call
      await new Promise(r => setTimeout(r, STAGGER_MS));
    }

    const result = await getCoinglassOI(symbol);
    results.set(symbol, result);
  }

  return results;
}

/** Сброс кэша для тестов */
export function clearCoinglassOICache(): void {
  cache.clear();
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/liquidations.ts
// ═══════════════════════════════════════════════════════

import { logger } from "./logger.js";

export interface LiquidationResult {
  liquidationsUsd: number | null;
  avgLiquidationsUsd: number | null;
  multiple: number | null;
  available: boolean;
}

// In-memory store of recent liquidation values per symbol for computing average
const liqHistory = new Map<string, number[]>();
const MAX_HISTORY = 8; // keep last 8 readings (4h at 30m intervals)

// Normalize symbol for Coinglass: BTC-USDT → BTCUSDT
function toCglSymbol(symbol: string): string {
  return symbol.replace("-", "");
}

export async function getLiquidations(symbol: string): Promise<LiquidationResult> {
  const apiKey = process.env.COINGLASS_API_KEY;
  if (!apiKey) {
    return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
  }

  const cglSymbol = toCglSymbol(symbol);

  try {
    // Coinglass liquidation chart for last 30m
    const res = await fetch(
      `https://open-api.coinglass.com/public/v2/liquidation_history?ex=Binance&pair=${cglSymbol}&interval=0.5h&limit=2`,
      {
        headers: {
          "coinglassSecret": apiKey,
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(5000),
      }
    );

    if (!res.ok) {
      return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
    }

    const data = await res.json() as {
      code: string;
      data: {
        shortLiquidationUsd: number;
        longLiquidationUsd: number;
        t: number;
      }[];
    };

    if (data.code !== "0" || !data.data?.length) {
      return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
    }

    // Get the most recent interval's short liquidations
    const latest = data.data[data.data.length - 1];
    const currentLiqUsd = (latest.shortLiquidationUsd ?? 0) + (latest.longLiquidationUsd ?? 0);

    // Track history to compute rolling average
    const history = liqHistory.get(symbol) ?? [];
    if (history.length >= MAX_HISTORY) history.shift();
    history.push(currentLiqUsd);
    liqHistory.set(symbol, history);

    const avgLiq = history.length > 1
      ? history.slice(0, -1).reduce((a, b) => a + b, 0) / (history.length - 1)
      : currentLiqUsd;

    const multiple = avgLiq > 0 ? currentLiqUsd / avgLiq : null;

    return {
      liquidationsUsd: currentLiqUsd,
      avgLiquidationsUsd: avgLiq,
      multiple,
      available: true,
    };
  } catch (err) {
    logger.warn({ symbol, err }, "Coinglass liquidations fetch failed");
    return { liquidationsUsd: null, avgLiquidationsUsd: null, multiple: null, available: false };
  }
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/logger.ts
// ═══════════════════════════════════════════════════════

import pino from "pino";

const isProduction = process.env.NODE_ENV === "production";

export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: [
    "req.headers.authorization",
    "req.headers.cookie",
    "res.headers['set-cookie']",
  ],
  ...(isProduction
    ? {}
    : {
        transport: {
          target: "pino-pretty",
          options: { colorize: true },
        },
      }),
});

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/orderbookScanner.ts
// ═══════════════════════════════════════════════════════

import { db, settingsTable, subscribersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { logger } from "./logger.js";
import { getOrderBookAnalysis } from "./bingx.js";
import { sendMessage } from "./telegram.js";

async function getOrderBookTargets(): Promise<(number | string)[]> {
  const targets: (number | string)[] = [];
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);
    if (settings?.channelId) targets.push(settings.channelId);
    const subs = await db.select({ chatId: subscribersTable.chatId })
      .from(subscribersTable)
      .where(eq(subscribersTable.active, true));
    for (const s of subs) targets.push(s.chatId);
  } catch { /* ignore */ }
  return targets;
}

async function scanWatchlistOrderbooks(): Promise<void> {
  logger.info("OrderBook scanner cycle start");
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);
    const watchlist = settings?.watchlist ?? "";
    if (!watchlist.trim()) {
      logger.info("OrderBook scanner: watchlist empty, skipping");
      return;
    }

    const symbols = watchlist.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);
    const targets = await getOrderBookTargets();

    for (const symbol of symbols) {
      try {
        const ob = await getOrderBookAnalysis(symbol, 50);
        if (!ob) continue;

        if (ob.bias === "strong_bull" && ob.largestBidWallUsd > 50_000) {
          const msg = [
            `🐋 <b>Крупная стена в стакане!</b>`,
            `Символ: <b>${symbol}</b>`,
            `Стена: <b>$${Math.round(ob.largestBidWallUsd).toLocaleString("ru")}</b> @ ${ob.largestBidWallPrice}`,
            `Перекос: ${ob.bidAskRatio.toFixed(2)} (Bid/Ask)`,
            `#${symbol.replace("-USDT", "").toLowerCase()} #orderbook_wall`,
          ].join("\n");
          for (const t of targets) {
            await sendMessage(t, msg).catch(() => {});
          }
          logger.info({ symbol, wallUsd: ob.largestBidWallUsd }, "OrderBook: large bid wall detected");
        }
      } catch (err) {
        logger.error({ symbol, err }, "OrderBook scanner: error for symbol");
      }
      await new Promise(r => setTimeout(r, 1000));
    }
  } catch (err) {
    logger.error({ err }, "OrderBook scanner cycle error");
  }
}

export async function startOrderBookScanner(): Promise<void> {
  logger.info("Starting Order Book Scanner (watchlist, 5m)");
  setInterval(() => {
    scanWatchlistOrderbooks().catch(err =>
      logger.error({ err }, "OrderBook scanner interval error")
    );
  }, 5 * 60_000);
  await scanWatchlistOrderbooks();
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/positionsReport.ts
// ═══════════════════════════════════════════════════════

import { db, trackedSignalsTable } from "@workspace/db";
import type { TrackedSignal } from "@workspace/db";
import { inArray } from "drizzle-orm";
import { getFutureTickers } from "./bingx.js";

function fmtP(p: number): string {
  if (p >= 1) return `$${p.toFixed(3)}`;
  if (p >= 0.01) return `$${p.toFixed(4)}`;
  if (p >= 0.001) return `$${p.toFixed(5)}`;
  return `$${p.toFixed(6)}`;
}

function fmtPct(n: number): string {
  return `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`;
}

function computePnl(s: TrackedSignal, price: number): number {
  if (!s.entryPrice || s.entryPrice === 0) return 0;
  const diff = price - s.entryPrice;
  return (s.isShort ? -diff : diff) / s.entryPrice * 100;
}

function ageLabel(detectedAt: Date): string {
  const h = (Date.now() - detectedAt.getTime()) / 3_600_000;
  if (h < 24) return `${h.toFixed(0)}ч`;
  return `${(h / 24).toFixed(1)}д`;
}

export async function buildPositionsStatusText(): Promise<string> {
  const open = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation"]));

  if (open.length === 0) {
    return [
      `📊 <b>Открытых позиций нет</b>`,
      ``,
      `Сканер ищет сигналы в режиме реального времени.`,
      `Сигнал придёт когда условия выполнятся.`,
    ].join("\n");
  }

  const priceMap = new Map<string, number>();
  try {
    const tickers = await getFutureTickers() as { symbol: string; lastPrice: string }[];
    for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
  } catch { /* use cached data */ }

  const now = new Date();
  const moscowTime = now.toLocaleString("ru-RU", {
    timeZone: "Europe/Moscow",
    day: "2-digit", month: "long", hour: "2-digit", minute: "2-digit"
  });

  const lines: string[] = [
    `📊 <b>Открытые позиции</b> — <i>${moscowTime} МСК</i>`,
    ``,
  ];

  const inRun      = open.filter(s => s.status === "in_run");
  const active     = open.filter(s => s.status === "active");
  const accum      = open.filter(s => s.status === "accumulation");

  // ── Moonshot / in_run ─────────────────────────────────────────────────────
  if (inRun.length > 0) {
    lines.push(`🚀 <b>В полёте (Moonshot) — ${inRun.length}</b>`);
    for (const s of inRun) {
      const coin       = s.symbol.replace("-USDT", "");
      const tag        = `#${coin.replace(/[^A-Za-z0-9]/g, "")}`;
      const curPrice   = priceMap.get(s.symbol);
      const pnl        = curPrice ? computePnl(s, curPrice) : null;
      const peakPnl    = s.peakPrice && s.entryPrice ? ((s.peakPrice - s.entryPrice) / s.entryPrice * 100) : null;
      const stopPnl    = s.trailingStopLevel && s.entryPrice
        ? ((s.trailingStopLevel - s.entryPrice) / s.entryPrice * 100) : null;

      const pnlStr     = pnl != null ? ` | Сейчас <b>${fmtPct(pnl)}</b>` : "";
      const peakStr    = peakPnl != null ? ` | Пик <b>${fmtPct(peakPnl)}</b>` : "";
      const stopStr    = s.trailingStopLevel && stopPnl != null
        ? ` | 🛡 Стоп ${fmtP(s.trailingStopLevel)} (<b>${fmtPct(stopPnl)}</b>)`
        : "";
      const ageStr     = ageLabel(s.detectedAt);

      lines.push(`  • <b>${coin}</b> ${tag}${pnlStr}${peakStr}${stopStr} | ${ageStr}`);
    }
    lines.push(``);
  }

  // ── Active ────────────────────────────────────────────────────────────────
  if (active.length > 0) {
    lines.push(`⚡ <b>Активные — ${active.length}</b>`);
    for (const s of active) {
      const coin     = s.symbol.replace("-USDT", "");
      const tag      = `#${coin.replace(/[^A-Za-z0-9]/g, "")}`;
      const curPrice = priceMap.get(s.symbol);
      const pnl      = curPrice ? computePnl(s, curPrice) : null;
      const pnlStr   = pnl != null ? ` | <b>${fmtPct(pnl)}</b>` : "";
      const priceStr = curPrice ? ` | ${fmtP(s.entryPrice ?? 0)} → ${fmtP(curPrice)}` : "";
      const ageStr   = ageLabel(s.detectedAt);
      lines.push(`  • <b>${coin}</b> ${tag}${priceStr}${pnlStr} | ${ageStr}`);
    }
    lines.push(``);
  }

  // ── Accumulation ──────────────────────────────────────────────────────────
  if (accum.length > 0) {
    lines.push(`👁 <b>В накоплении — ${accum.length}</b>`);
    for (const s of accum) {
      const coin     = s.symbol.replace("-USDT", "");
      const tag      = `#${coin.replace(/[^A-Za-z0-9]/g, "")}`;
      const curPrice = priceMap.get(s.symbol);
      const pnl      = curPrice ? computePnl(s, curPrice) : null;
      const peakPnl  = s.peakPrice && s.entryPrice
        ? ((s.peakPrice - s.entryPrice) / s.entryPrice * 100) : null;
      const pnlStr   = pnl != null ? ` ${fmtPct(pnl)}` : "";
      const peakStr  = peakPnl != null && peakPnl > 0.5 ? ` (пик ${fmtPct(peakPnl)})` : "";
      const ageStr   = ageLabel(s.detectedAt);
      lines.push(`  • <b>${coin}</b> ${tag} |${pnlStr}${peakStr} | ${ageStr}`);
    }
    lines.push(``);
  }

  lines.push(`📋 Всего открытых: <b>${open.length}</b> | Авто-апдейт каждые 4ч`);

  return lines.join("\n");
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/scanner.ts
// ═══════════════════════════════════════════════════════

import { logger } from "./logger.js";
import { getFutureTickers, getFutureTicker, getKlines, getOpenInterest, getFundingRate, testConnection as testBingX, fetchCVD, getOrderBookAnalysis, type BingXTicker, type OrderBookAnalysis } from "./bingx.js";
import { broadcastBatchAlert, broadcastRawAlert, testConnection as testTelegram } from "./telegram.js";
import { trackSignal, broadcast } from "./watcher.js";
import { getTrendingRank } from "./trending.js";
import { getLiquidations } from "./liquidations.js";
import { batchGetCoinglassOI, clearCoinglassOICache, type CoinglassOIResult } from "./coinglass_oi.js";
import { getCoinalyzeOI, getCoinalyzeDailyStats } from "./coinalyze.js";
import { db, signalsTable, settingsTable, oiBaselinesTable, oiWatchTable, trackedSignalsTable, type InsertSignal } from "@workspace/db";
import { gte, sql, eq, and, inArray, isNull, or } from "drizzle-orm";

export interface ScannerState {
  running: boolean;
  lastScanAt: Date | null;
  nextScanAt: Date | null;
  marketsScanned: number;
  scanIntervalMs: number;
  bingxConnected: boolean;
  telegramConnected: boolean;
}

const state: ScannerState = {
  running: false,
  lastScanAt: null,
  nextScanAt: null,
  marketsScanned: 0,
  scanIntervalMs: 600_000,
  bingxConnected: false,
  telegramConnected: false,
};

/**
 * Персистентный кеш глобальных объёмов из CoinGlass (volUsd).
 * Накапливается между сканами — не сбрасывается.
 * Ключ: baseSymbol без USDT (например "DYDX"), значение: volUsd в USD.
 * После 1-го скана используется вместо BingX-объёма для пре-скрина Layer 2.
 */
const cgVolumeCache = new Map<string, number>();

// ── Persistent Pre-screen Tracker ───────────────────────────────────────────
// Ловит GOBLIN-тип: токены которые грайндят вверх без OI/объёма, но стабильно
// держатся в топ-N pre-screen 3+ цикла подряд (~30+ мин).
interface PrescanEntry {
  firstPrice24h: number;   // price24h% при первом появлении в топ-N
  lastPrice24h:  number;   // актуальное price24h% (обновляется каждый цикл)
  firstSeenAt:   number;   // timestamp первого появления
  cycleCount:    number;   // сколько циклов подряд в топ-N
  lastPrice:     number;   // текущая цена (для алерта)
  lastFiredAt:   number;   // timestamp последнего алерта (кулдаун)
}
const prescanTracker = new Map<string, PrescanEntry>();
const PERSIST_MIN_CYCLES    = 3;
const PERSIST_MIN_PRICE24H  = 20.0;   // % 24h изменение
const PERSIST_MIN_GROWTH    = 3.0;    // % рост price24h с момента первого появления
const PERSIST_COOLDOWN_MS   = 6 * 60 * 60 * 1000; // 6ч между алертами одного токена

// ── In-memory state ─────────────────────────────────────────────────────────

/**
 * OI baseline — time-based.
 * Activity-score approach: the same "hot" tokens are scanned every 10 min,
 * so we can build baselines quickly and measure OI delta over ~20-60 min.
 */
interface OIBaseline {
  oi: number;
  takenAt: number;
}
const oiBaseline = new Map<string, OIBaseline>();
// Hot tokens are rescanned every 10 min — measure OI over a ~20-60 min window
const MIN_BASELINE_AGE_MS = 20 * 60 * 1000;   // update baseline no more than once per 20 min
const MAX_BASELINE_AGE_MS = 60 * 60 * 1000;   // baseline older than 60 min is too stale

/** Fetch fresh market price for a symbol at the moment of oiWatchTable insert.
 *  Prevents stale priceAtEntry caused by long scan loops (10-15 min lag). */
async function getFreshPrice(symbol: string, fallback: number): Promise<number> {
  try {
    const ticker = await getFutureTicker(symbol);
    if (ticker) {
      const p = parseFloat((ticker as any).lastPrice);
      if (p > 0) return p;
    }
  } catch { /* non-critical */ }
  return fallback;
}

/** Load OI baselines from DB on startup so restarts don't cause blind spots */
async function loadBaselinesFromDb(): Promise<void> {
  try {
    const rows = await db.select().from(oiBaselinesTable);
    const cutoff = Date.now() - MAX_BASELINE_AGE_MS;
    let loaded = 0;
    for (const row of rows) {
      const takenAt = row.takenAt.getTime();
      if (takenAt >= cutoff) {
        oiBaseline.set(row.symbol, { oi: row.oi, takenAt });
        loaded++;
      }
    }
    logger.info({ loaded, total: rows.length }, "OI baselines loaded from DB");
  } catch (err) {
    logger.warn({ err }, "Failed to load OI baselines from DB — starting fresh");
  }
}

let _lastBaselinePersist = 0;
const BASELINE_PERSIST_INTERVAL_MS = 5 * 60 * 1000; // persist to DB every 5 min

/** Persist changed baselines to DB (called after each scan) */
async function persistBaselinesToDb(): Promise<void> {
  const now = Date.now();
  if (now - _lastBaselinePersist < BASELINE_PERSIST_INTERVAL_MS) return;
  _lastBaselinePersist = now;
  try {
    const values = [...oiBaseline.entries()].map(([symbol, b]) => ({
      symbol,
      oi: b.oi,
      takenAt: new Date(b.takenAt),
    }));
    if (values.length === 0) return;
    await db.insert(oiBaselinesTable)
      .values(values)
      .onConflictDoUpdate({ target: oiBaselinesTable.symbol, set: { oi: sql`excluded.oi`, takenAt: sql`excluded.taken_at` } });
    logger.debug({ count: values.length }, "OI baselines persisted to DB");
  } catch (err) {
    logger.warn({ err }, "Failed to persist OI baselines to DB");
  }
}

interface SymbolSignalState {
  firstSignalAt: Date;
  signalCount: number;
  cumulativeOiChange: number;
}
const signalHistory = new Map<string, SymbolSignalState>();

let scanTimer: ReturnType<typeof setTimeout> | null = null;

// ── Settings ────────────────────────────────────────────────────────────────
async function getSettings() {
  const rows = await db.select().from(settingsTable).limit(1);
  if (rows.length === 0) {
    const inserted = await db.insert(settingsTable).values({
      volumeMultiplier: 3,
      oiChangePercent: 5,
      fundingRateThreshold: 0.0005,
      scanIntervalMs: 300_000,
      telegramEnabled: true,
      maxSymbols: 100,
    }).returning();
    return inserted[0];
  }
  return rows[0];
}

// ── Sentiment patterns ───────────────────────────────────────────────────────
export type SentimentKey =
  | "hidden_accumulation"
  | "aggressive_breakout"
  | "short_squeeze"
  | "bullish_accumulation"
  | "bearish_pressure"
  | "bear_trap"
  | "anomaly"
  | "sharp_impulse"
  | "impulse_breakout"
  | "volume_flash";

export interface SentimentResult {
  key: SentimentKey;
  label: string;
  traderAction: string;
  /** Does this pattern require OI to be FALLING instead of rising? */
  oiFalling: boolean;
}

/**
 * Determine sentiment pattern based on price, OI change direction/magnitude and volume.
 *
 * Pattern priority (first match wins):
 * 1. Short Squeeze      — OI falling, price sharply up, liq ≥ 2x
 * 2. Дистрибуция        — OI falling, price stagnant/slowing
 * 3. Скрытое накопление — OI high, price almost flat (pre-pump)
 * 4. Bear Trap          — OI rising sharply + price drops (shorts crowding in = squeeze setup)
 * 5. Агрессивный пробой — OI very high, vol very high, price big move
 * 6. Бычье накопление   — OI rising, price positive
 * 7. Медвежье давление  — OI rising, price negative
 * 8. Аномальная         — fallback
 */
/**
 * OI кепы зависят от таймфрейма который сработал.
 * 30m OI = 14% это поздно (памп уже идёт). 4h OI = 14% это тихое накопление за часы.
 *
 * triggerTf примеры: "30m", "5m+30m", "1h", "4h", "24h", "steady", "fast_track", "bingx_volume"
 */
function getOiCaps(triggerTf: string): { hiddenMax: number; bullishMax: number } {
  // Используем \b (word boundary) чтобы "4h_momentum" не совпало с "4h".
  // "4h_momentum" — паттерн цены, не 4h OI → применяем короткий кеп как для 30m.
  if (/\b24h\b/.test(triggerTf)) return { hiddenMax: 30, bullishMax: 50 };
  if (/\b4h\b/.test(triggerTf))  return { hiddenMax: 25, bullishMax: 35 };
  if (/\b1h\b/.test(triggerTf))  return { hiddenMax: 15, bullishMax: 20 };
  // 30m, 5m, steady, fast_track, bingx_volume, 4h_momentum, confirm — жёсткий кеп
  return { hiddenMax: 10, bullishMax: 15 };
}

function detectSentiment(
  priceChange: number,
  oiChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  triggerTf: string = "30m",
): SentimentResult {
  const { hiddenMax, bullishMax } = getOiCaps(triggerTf);
  // 1. Short Squeeze: OI falling sharply (shorts force-closed) + price rising + vol spike.
  // Raised OI threshold -2 → -5% to cut noise: weak OI dip can be normal profit-taking,
  // not a real squeeze.
  if (oiChange < -3 && priceChange > 2 && volumeMultiplier >= 3) {
    return {
      key: "short_squeeze",
      label: "Short Squeeze",
      traderAction: "SCALP LONG / Фиксация лонга",
      oiFalling: true,
    };
  }

  // 3. Hidden Accumulation — требуем ПОДТВЕРЖДЕНИЕ покупок.
  // OI range 6–15%: свежее накопление умных денег (не старое, не навязшее).
  //
  // ВХОД РАЗРЕШЁН только в двух случаях:
  // A) Цена уже начала движение вверх (+2% до +8%) — покупки РЕАЛЬНЫЕ, подтверждены
  // B) Дип-выкуп: цена слегка упала (–0.5% до –3%) при росте OI — умные деньги откупают
  //
  // ЗАПРЕЩЕНО: мёртвая зона (price –0.5% до +2%) = flat + OI → только в OI Watch, не в сигнал.
  // Исторические данные: WAVES(flat+34.8%), BB(flat+18%), UB(flat+16%) — все failed.
  // LUMIA(+13%, OI 8.8%), NAORIS(–0.87%, OI 6.9%) — win.

  // 3A. Подтверждённый разгон: OI + цена уже движется
  // Кеп зависит от ТФ: 30m ≤10% (данные: OI>10% на 30m = ловушка), 4h ≤25%, 24h ≤30%.
  // Логика: 4h OI 14% = тихое накопление за часы. 30m OI 14% = уже опоздали.
  if (oiChange >= 6 && oiChange <= hiddenMax && priceChange >= 2.0 && priceChange <= 8.0 && volumeMultiplier >= 1.3) {
    return {
      key: "hidden_accumulation",
      label: "Скрытое накопление",
      traderAction: "LONG (вход в начале движения)",
      oiFalling: false,
    };
  }

  // 3B. Дип-выкуп: OI растёт пока цена снижается — умные деньги откупают дип
  if (oiChange >= 6 && oiChange <= hiddenMax && priceChange >= -3.0 && priceChange < -0.5 && volumeMultiplier >= 2.0) {
    return {
      key: "hidden_accumulation",
      label: "Скрытое накопление",
      traderAction: "LONG (выкуп дипа, ждать разворота)",
      oiFalling: false,
    };
  }

  // 4. Bear Trap: price drops sharply BUT OI rises strongly = shorts crowding in.
  // Smart money is on the other side absorbing the selling — classic squeeze setup.
  if (oiChange >= 8 && priceChange < -2.5) {
    return {
      key: "bear_trap",
      label: "Медвежья ловушка",
      traderAction: "LONG при развороте (ждать подтверждение)",
      oiFalling: false,
    };
  }

  // 5. Aggressive Breakout: price > 3% + volume ≥ 2.5x + OI rising (new longs opening).
  // If OI is falling with a price spike → that's Short Squeeze (shorts closing), NOT breakout
  // (fresh longs entering). Require oiChange > 0 to distinguish the two.
  // Порог снижен с (vol≥3.5x, price>4%) до (vol≥2.5x, price>3%) чтобы ловить мем-монеты
  // (GOBLIN, COLLECT, MAXXING) на стадии разгона до того как 24h-дельта уходит в exhausted pump.
  if (volumeMultiplier >= 2.5 && priceChange > 3 && oiChange > 0) {
    return {
      key: "aggressive_breakout",
      label: "Агрессивный пробой",
      traderAction: "LONG по тренду (импульс запущен)",
      oiFalling: false,
    };
  }

  // 6. Bullish Accumulation — кеп зависит от ТФ (bullishMax)
  if (priceChange > 1 && oiChange > 3 && oiChange <= bullishMax) {
    return {
      key: "bullish_accumulation",
      label: "Бычье накопление",
      traderAction: "LONG",
      oiFalling: false,
    };
  }

  // 7. Bearish Pressure: tightened from (price < 0, OI > 3%) to (price < -2%, OI > 5%).
  // Captures only genuinely aggressive market shorts, not minor OI tick-ups.
  if (priceChange < -2 && oiChange > 5) {
    return {
      key: "bearish_pressure",
      label: "Медвежье давление",
      traderAction: "SHORT / Осторожность",
      oiFalling: false,
    };
  }

  return {
    key: "anomaly",
    label: "Аномальная активность",
    traderAction: "Наблюдение",
    oiFalling: false,
  };
}

// ── Alpha Score 1–10 ─────────────────────────────────────────────────────────
/**
 * Score breakdown (max 10):
 *   OI strength     0 – 3.5
 *   Volume          0 – 3.0
 *   Price action    0 – 0.5
 *   CMC trending    0 – 2.0  (flat +2 if any trending entry found)
 *   Liquidations    0 – 2.0  (capped at 10 total)
 *
 * Reference from spec (v3.0):
 *   OI + Vol only       ≈ 4–6
 *   OI + Vol + CMC      ≈ 6–8
 *   OI + Vol + CMC + Liq → 8–10 (SUPER ALPHA)
 */
function calcAlphaScore(params: {
  oiChange: number;
  volumeMultiplier: number;
  priceChange: number;
  sentimentKey: SentimentKey;
  cmcAvailable: boolean;
  cmcRank: number | null;
  coinglassAvailable: boolean;
  liquidationsMultiple: number | null;
  fundingRate?: number | null;
}): number {
  const absOI = Math.abs(params.oiChange);
  const absPrice = Math.abs(params.priceChange);

  // OI component (0 – 3.5)
  const oiScore =
    absOI >= 20 ? 3.5 :
    absOI >= 15 ? 3.0 :
    absOI >= 10 ? 2.5 :
    absOI >= 7  ? 2.0 :
    absOI >= 5  ? 1.5 :
    absOI >= 3  ? 1.0 : 0.5;

  // Volume component (0 – 3.0)
  const volScore =
    params.volumeMultiplier >= 10 ? 3.0 :
    params.volumeMultiplier >= 7  ? 2.5 :
    params.volumeMultiplier >= 5  ? 2.0 :
    params.volumeMultiplier >= 4  ? 1.5 :
    params.volumeMultiplier >= 3  ? 1.0 : 0.5;

  // Price action (0 – 0.5)
  let priceScore = 0;
  if (params.sentimentKey === "hidden_accumulation") {
    // low price movement is GOOD for this pattern
    priceScore = absPrice < 1.5 ? 0.5 : 0.25;
  } else {
    priceScore =
      absPrice >= 6 ? 0.5 :
      absPrice >= 4 ? 0.4 :
      absPrice >= 2 ? 0.3 : 0.1;
  }

  // CMC trending: flat +2 if found in any trending position (v3.0 spec)
  const cmcScore = (params.cmcAvailable && params.cmcRank !== null) ? 2.0 : 0;

  // Liquidations (0 – 3.0 для Squeeze/Bear Trap, 0 – 2.0 иначе)
  const isSqueezePattern = params.sentimentKey === "short_squeeze"
                        || params.sentimentKey === "bear_trap";
  let liqScore = 0;
  if (params.coinglassAvailable && params.liquidationsMultiple !== null) {
    const liqCap = isSqueezePattern ? 3.0 : 2.0;
    liqScore = Math.min(liqCap,
      params.liquidationsMultiple >= 5 ? liqCap :
      params.liquidationsMultiple >= 3 ? liqCap * 0.75 :
      params.liquidationsMultiple >= 2 ? liqCap * 0.5 : 0
    );
  }

  // Funding rate bonus/penalty (0 – +1.5 / 0 – -0.5)
  // Отрицательный фандинг → шорты платят → сквиз-потенциал → буст
  // Сильно положительный → лонги перегреты → пенальти
  let fundingScore = 0;
  if (params.fundingRate != null) {
    const fr = params.fundingRate;
    const isSqueezeOrTrap = params.sentimentKey === "short_squeeze"
                         || params.sentimentKey === "bear_trap"
                         || params.sentimentKey === "hidden_accumulation";
    if (fr <= -0.0003) {
      fundingScore = isSqueezeOrTrap ? 1.5 : 1.0;
    } else if (fr <= -0.0001) {
      fundingScore = isSqueezeOrTrap ? 0.75 : 0.5;
    } else if (fr >= 0.0005) {
      fundingScore = -0.5;
    } else if (fr >= 0.0003) {
      fundingScore = -0.25;
    }
  }

  const raw = oiScore + volScore + priceScore + cmcScore + liqScore + fundingScore;
  return Math.min(10, Math.max(1, Math.round(raw)));
}

// ── Result type ──────────────────────────────────────────────────────────────
export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha" | "bingx_volume";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  /** Кросс-биржевое OI изменение от Coinalyze (30m) */
  coinalyzeOiChange: number | null;
  /** Coinalyze подтвердил OI-рост кросс-биржево */
  coinalyzeConfirmed: boolean;
  /** Новый листинг (< 24ч на фьючерсах BingX) */
  isNewListing: boolean;
  /** SHORT_SQUEEZE с Coinalyze OI < -20% — выдавливание шортов уже завершено */
  isExhaustedSqueeze: boolean;
  /** % рост цены от первого открытия фьючерса */
  pumpFromOpen: number | null;
  /** Количество 30м свечей (< 48 = новый) */
  candleCount: number;
  sentiment: string;
  sentimentKey: SentimentKey;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "5m", "30m", "1h" или комбинация */
  oiTriggerTf: string;
  /** Значение 5m OI изменения (для отображения в сигнале) */
  oiChange5m: number | null;
  /** Значение 1h OI изменения (для отображения в сигнале) */
  oiChange1h: number | null;
  /** Значение 4h OI изменения (для отображения в сигнале) */
  oiChange4h: number | null;
  /** Значение 24h OI изменения (для отображения в сигнале) */
  oiChange24h: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже был в отслеживаемых сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт BingX (decimal, напр. -0.0004 = -0.04% за 8ч) */
  fundingRate?: number | null;
  /** Mark price BingX перп */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Анализ стакана BingX: имбаланс бидов/асков, bid-стены */
  obImbalance?: OrderBookAnalysis | null;
}

// ── Whether a symbol passes any detection path ───────────────────────────────
interface DetectionResult {
  passes: boolean;
  oiChangePercent: number;
  openInterest: number;
  sentiment: SentimentResult;
}

function evaluatePattern(
  oiChange: number,
  priceChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  settings: { volumeMultiplier: number; oiChangePercent: number },
  triggerTf: string = "30m",
): DetectionResult | null {
  // NOTE: At this point CoinGlass global OI ≥ 5% and Volume ≥ 2x are already
  // confirmed upstream (Steps 1 & 3 of v3.0 pipeline). Pattern evaluation
  // here only assigns the pattern type and applies pattern-specific thresholds.
  const { bullishMax } = getOiCaps(triggerTf);
  const sent = detectSentiment(priceChange, oiChange, volumeMultiplier, liquidationsMultiple, triggerTf);

  // Path A: Rising OI patterns (LONG сигналы)
  if (!sent.oiFalling) {
    if (sent.key === "hidden_accumulation") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

    if (sent.key === "aggressive_breakout") {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

    // Bullish Standard: OI ≥ threshold + Vol ≥ threshold + price move + ТФ-зависимый кеп.
    // 30m OI>15% = ловушка. 4h OI=20% = устойчивое накопление за часы.
    if (oiChange >= settings.oiChangePercent && oiChange <= bullishMax && volumeMultiplier >= settings.volumeMultiplier && Math.abs(priceChange) >= 1) {
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }
  }

  // Path B: Falling OI patterns
  if (sent.oiFalling) {
    if (sent.key === "short_squeeze") {
      // OI падает (шорты выдавлены) + цена РАСТЁТ → LONG скальп
      return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
    }

  }

  // Path C: Bear Trap — OI растёт + цена падает = шорты набираются → потенциальный сквиз
  if (sent.key === "bear_trap") {
    return { passes: true, oiChangePercent: oiChange, openInterest: 0, sentiment: sent };
  }

  return null;
}

// ── Main scan ────────────────────────────────────────────────────────────────
export async function performScan(): Promise<{ signalsFound: number; marketsScanned: number; durationMs: number }> {
  const startTime = Date.now();
  const settings = await getSettings();

  // Очищаем устаревшие записи signalHistory (TTL: 48 часов).
  // Без TTL история растёт вечно — символы которые давно не скануются остаются в памяти.
  const TTL_MS = 48 * 60 * 60 * 1000;
  for (const [sym, st] of signalHistory.entries()) {
    if (Date.now() - st.firstSignalAt.getTime() > TTL_MS) {
      signalHistory.delete(sym);
    }
  }

  // Очищаем кэш CoinGlass перед каждым сканом — данные всегда свежие
  clearCoinglassOICache();
  logger.info("Starting Alpha Scanner (5m scan, 30m TF, 5-pattern)...");

  let tickers;
  try {
    tickers = await getFutureTickers();
  } catch (err) {
    logger.error({ err }, "Failed to fetch BingX tickers");
    state.bingxConnected = false;
    return { signalsFound: 0, marketsScanned: 0, durationMs: Date.now() - startTime };
  }
  state.bingxConnected = true;

  // ── Activity-score pre-screening (ALL tokens, 1 API call) ───────────────────
  // Score every USDT token using already-fetched ticker data (free, no extra calls).
  // Hot tokens (big price move + big volume) get deep-scanned every 10 min,
  // so OI baselines build up within 20 min — not 100 min like with rotation.
  //
  // score = abs(priceChange24h%) × log10(quoteVolumeUSD + 1)
  // This ranks: tokens with big price moves in liquid markets first.
  // Exclude index/stock trackers (NCS*, NCC*, symbols with "2USD" — e.g. NCSKSPY2USD-USDT)
  const isCryptoFuture = (symbol: string) => {
    const base = symbol.replace("-USDT", "");
    return !base.includes("2USD") && !base.startsWith("NCS") && !base.startsWith("NCC");
  };

  const scored = tickers
    .filter(t => t.symbol.endsWith("-USDT") && isCryptoFuture(t.symbol))
    .map(t => {
      const pctChange = Math.abs(parseFloat(t.priceChangePercent) || 0);
      const vol = parseFloat(t.quoteVolume) || 0;
      const score = pctChange * Math.log10(vol + 1);
      return { ticker: t, score };
    })
    .sort((a, b) => b.score - a.score);

  // ── Layer 0: user watchlist — always scanned regardless of rank ──────────────
  const watchlistSymbols: string[] = (String(settings.watchlist ?? ""))
    .split(",")
    .map((s: string) => s.trim().toUpperCase())
    .filter((s: string) => s.length > 0)
    .map((s: string) => s.includes("-") ? s : `${s}-USDT`); // auto-append -USDT if missing
  const watchlistSet = new Set(watchlistSymbols);
  const watchlistTickers = tickers.filter(t => watchlistSet.has(t.symbol));
  const watchlistSymbolsFound = new Set(watchlistTickers.map(t => t.symbol));

  // ── Layer 1: top-N by activity score (current hot movers)
  const activityLimit = settings.maxSymbols; // default 50
  const topByActivity = scored.slice(0, activityLimit).map(s => s.ticker);
  const activeSymbols = new Set(topByActivity.map(t => t.symbol));

  // ── Layer 2: top-100 by volume — BingX только как fallback для первого скана.
  //    После 1-го скана используем cgVolumeCache (global volUsd от CoinGlass):
  //    DYDX с $246M OI и высоким global volume попадёт в пул даже при низком BingX-объёме.
  //    Урезано с 200 до 100 чтобы сохранить Coinalyze API-лимит (90 req/day).
  const useCgVolume = cgVolumeCache.size > 0;
  const topByVolume = [...scored]
    .sort((a, b) => {
      const symA = a.ticker.symbol.replace("USDT", "").replace("-", "");
      const symB = b.ticker.symbol.replace("USDT", "").replace("-", "");
      const volA = useCgVolume
        ? (cgVolumeCache.get(symA) ?? cgVolumeCache.get(a.ticker.symbol) ?? (parseFloat(a.ticker.quoteVolume) || 0))
        : (parseFloat(a.ticker.quoteVolume) || 0);
      const volB = useCgVolume
        ? (cgVolumeCache.get(symB) ?? cgVolumeCache.get(b.ticker.symbol) ?? (parseFloat(b.ticker.quoteVolume) || 0))
        : (parseFloat(b.ticker.quoteVolume) || 0);
      return volB - volA;
    })
    .slice(0, 100)
    .map(s => s.ticker)
    .filter(t => !activeSymbols.has(t.symbol) && !watchlistSymbolsFound.has(t.symbol));

  const usdtTickers = [...watchlistTickers, ...topByActivity, ...topByVolume];
  const scanLimit = activityLimit;

  const topScore = scored[0]?.score?.toFixed(1) ?? "0";
  logger.info(
    {
      count: usdtTickers.length,
      watchlist: watchlistTickers.length,
      byActivity: topByActivity.length,
      byVolume: topByVolume.length,
      volSource: useCgVolume ? `CoinGlass(cache=${cgVolumeCache.size})` : "BingX(firstRun)",
      totalTokens: scored.length,
      topScore,
      top5: scored.slice(0, 5).map(s => `${s.ticker.symbol}(${s.score.toFixed(1)})`),
      watchlistSymbols: watchlistTickers.map(t => t.symbol),
    },
    "Pre-screened tokens for deep scan"
  );

  // ── Persistent Pre-screen Tracker: обновляем счётчики ───────────────────────
  {
    const nowTs = Date.now();
    const currentTopSymbols = new Set(topByActivity.map(s => s.symbol));

    // Удаляем токены, которые вышли из топ-N в этом цикле
    for (const sym of prescanTracker.keys()) {
      if (!currentTopSymbols.has(sym)) prescanTracker.delete(sym);
    }

    // Обновляем или добавляем токены в топ-N
    for (const s of scored.slice(0, activityLimit)) {
      const sym = s.ticker.symbol;
      const price24h = Math.abs(parseFloat(s.ticker.priceChangePercent) || 0);
      const lastPrice = parseFloat(s.ticker.lastPrice) || 0;
      const existing = prescanTracker.get(sym);
      if (existing) {
        existing.cycleCount++;
        existing.lastPrice24h = price24h;
        existing.lastPrice    = lastPrice;
      } else {
        prescanTracker.set(sym, {
          firstPrice24h: price24h,
          lastPrice24h:  price24h,
          firstSeenAt:   nowTs,
          cycleCount:    1,
          lastPrice:     lastPrice,
          lastFiredAt:   0,
        });
      }
    }
  }

  // ── Phase 1: CoinGlass OI batch — PRIMARY filter ─────────────────────────────
  // CoinGlass даёт агрегированный глобальный OI по всем биржам (m30OIChangePercent).
  // Это основной фильтр — BingX OI больше не используется для альфа-сигналов.
  // Rate limit: 2s stagger между некэшированными запросами = 30 req/min.
  const allSymbols = usdtTickers.map(t => t.symbol);
  logger.info({ count: allSymbols.length }, "Fetching CoinGlass global OI (primary filter)...");
  const coinglassOIMap = await batchGetCoinglassOI(allSymbols);

  const oiMoversCount = [...coinglassOIMap.values()].filter(r => {
    if (!r.available) return false;
    const t5   = Math.abs(r.oiChange5m  ?? 0) >= 3.5;
    const t30  = Math.abs(r.oiChange30m ?? 0) >= 4.5;
    const t1h  = Math.abs(r.oiChange1h  ?? 0) >= 6.0;
    const t4h  = Math.abs(r.oiChange4h  ?? 0) >= 8.0;
    const t24h = Math.abs(r.oiChange24h ?? 0) >= 20.0;
    return t5 || t30 || t1h || t4h || t24h;
  }).length;
  // Наполняем персистентный кеш глобальных объёмов для следующего пре-скрина
  let cgVolCacheUpdated = 0;
  for (const [sym, oi] of coinglassOIMap.entries()) {
    if (oi.cgVolUsd && oi.cgVolUsd > 0) {
      // Ключ без -USDT суффикса, например "DYDX"
      const base = sym.replace(/-?USDT$/i, "").replace(/-/g, "");
      cgVolumeCache.set(base, oi.cgVolUsd);
      cgVolCacheUpdated++;
    }
  }
  logger.info(
    { total: allSymbols.length, movers: oiMoversCount, threshold: settings.oiChangePercent + "%", cgCacheSize: cgVolumeCache.size, cgUpdated: cgVolCacheUpdated },
    "CoinGlass OI batch complete"
  );

  // Phase 2: gather alpha candidates (klines + volume + pattern)
  const candidates: {
    symbol: string;
    price: number;
    priceChange30m: number;
    price4hChange: number;      // Изменение цены за 4ч (8×30m) — для пост-памп фильтра
    currentVolume: number;
    avgVolume: number;
    volumeMultiplier: number;
    oiChangePercent: number;    // Best (max abs) из 5m/30m/1h OI — для скоринга
    oiChange5m: number | null;  // Сырое 5m значение — для отображения в сигнале
    oiChange1h: number | null;  // Сырое 1h значение — для отображения в сигнале
    oiChange4h: number | null;  // Сырое 4h значение — для отображения в сигнале
    oiChange24h: number | null; // Сырое 24h значение — для отображения в сигнале
    openInterest: number;       // CoinGlass global OI in USD (or 0)
    sentiment: SentimentResult;
    coinglassOI: CoinglassOIResult;
    oiTriggerTf: string;       // Какой ТФ сработал: "5m", "30m", "5m+30m"
    isRepeatSignal: boolean;   // символ уже был в сигналах за последние 24ч
  }[] = [];

  // Track top-performers for debug log (even if they don't pass)
  const debugTop: { symbol: string; vol: number; cgOI: number | null; price: number }[] = [];

  // Skip reason counters for INFO-level diagnostics
  const skipCount = {
    noKlines: 0,
    exhaustedPump: 0,
    deepNegative: 0,
    noOiNoVol: 0,
    contraSignal: 0,
    lowVolume: 0,
    repeatSignal: 0,
    other: 0,
  };

  const now = Date.now();

  // ── Pre-scan fresh prices для confirming inserts ─────────────────────────────
  // CoinGlass batch уже занял 8+ мин. Kline close = закрытие свечи (0-30 мин назад).
  // Чтобы priceAtEntry в confirming был реальной ценой в момент добавления —
  // берём свежий тикер прямо перед per-symbol loop.
  const confirmPriceMap = new Map<string, number>();
  try {
    const confirmTickers = await getFutureTickers();
    for (const t of confirmTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) confirmPriceMap.set((t as any).symbol, p);
    }
  } catch { /* non-critical — falls back to kline close */ }

  for (const ticker of usdtTickers) {
    const symbol = ticker.symbol;
    try {
      const klines = await getKlines(symbol, "30m", 49);

      // Требуем минимум 10 свечей для расчёта среднего объёма
      if (klines.length < 10) continue;

      const current = klines[klines.length - 1];
      // v3.0 Step 3: use last 20 candles for average volume (not all 48)
      const historical = klines.slice(-21, -1);

      const close = parseFloat(current.close) || 0;
      const open = parseFloat(current.open) || 0;
      if (!close || !open) continue;

      const currentVol = (parseFloat(current.volume) || 0) * close;
      const avgVol = historical.length > 0
        ? historical.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / historical.length
        : 0;

      if (!avgVol) continue;

      const priceChange = ((close - open) / open) * 100;
      const volMult = currentVol / avgVol;

      // 4h price context: compare current close to close ~8 candles (4h) ago.
      // Используется для пост-памп фильтра в Phase 3.
      const lookback4hIdx = Math.max(0, klines.length - 1 - 8);
      const base4hClose = parseFloat(klines[lookback4hIdx]?.close || "0");
      const price4hChange = base4hClose > 0 ? ((close - base4hClose) / base4hClose) * 100 : 0;

      // 4h cumulative volume: средний объём последних 8 свечей (4h) vs базовый avgVol (20 свечей).
      // Используется в 4h Momentum Pattern для обнаружения медленных грайндов.
      const recent8 = klines.slice(-9, -1); // 8×30m = 4h, без текущей свечи
      const vol4hAvg = recent8.length >= 4
        ? recent8.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / recent8.length
        : 0;
      const volMult4h = avgVol > 0 && vol4hAvg > 0 ? vol4hAvg / avgVol : 0;

      // Volume trend: объём за последние 2 закрытые свечи (не текущая).
      // Если хотя бы одна из них >= 1.3x нормы — объём нарастает трендом, не одиночный спайк.
      // Используется как фильтр качества для hidden_accumulation.
      const prev1k = klines[klines.length - 2];
      const prev2k = klines[klines.length - 3];
      const prevVol1 = prev1k ? (parseFloat(prev1k.volume) || 0) * (parseFloat(prev1k.close) || 0) : 0;
      const prevVol2 = prev2k ? (parseFloat(prev2k.volume) || 0) * (parseFloat(prev2k.close) || 0) : 0;
      const prevVol1Mult = avgVol > 0 ? prevVol1 / avgVol : 0;
      const prevVol2Mult = avgVol > 0 ? prevVol2 / avgVol : 0;
      // Тренд объёма: хотя бы одна из 2 предыдущих закрытых свечей тоже была >= 1.3x
      const isVolTrend = prevVol1Mult >= 1.3 || prevVol2Mult >= 1.3;

      // ── PRE-FILTER: Exhausted pump — price up >20% in 24h AND volume now cooling off ──
      // We DON'T block early breakouts (PIPPIN: 24h=0.84% at signal time).
      // Блок поздних входов по 24h цене из BingX — независимо от CoinGlass/Coinalyze.
      // BingX priceChangePercent = изменение за последние 24h, всегда актуально.
      const price24hChange = parseFloat(ticker.priceChangePercent) || 0;

      // ── Sharp Impulse Detection ────────────────────────────────────────────────
      // Паттерн: текущая свеча сама является импульсом (price >= 12% за свечу + vol >= 2x).
      // Примеры: HYPERLANE +20.28% за 15 мин, AXS +12%+. Цена уже улетела, но движение продолжается.
      // Такие сигналы блокируются exhausted pump filter + anti-stale filter — обходим их для этого паттерна.
      const isSharpImpulse = priceChange >= 12 && volMult >= 2.0;

      // ── Volume Flash Detection ─────────────────────────────────────────────────
      // Паттерн: объём взорвался (>= 10x baseline) + цена начала движение (>= 3%).
      // Ловит начало flash-памп без OI-подтверждения — следуй за деньгами.
      // Примеры: SKYAI +71% за день — объём был аномальным, OI не успел отреагировать.
      // Обходит stale-фильтр: высокий объём = движение ещё идёт (не устаревший сигнал).
      const isVolumeFlash = !isSharpImpulse && volMult >= 10.0 && priceChange >= 3.0 && priceChange <= 45.0;

      // 1. Памп уже отыгран: цена выросла 30%+ за 24h И объём остывает (< 2.5x).
      //    Порог 30% (был 20%) — ZEC на +20% за день это тренд, не исчерпанный памп.
      //    Дополнительно: если 4h объём >= 1.3x — монета ещё активна (многодневный тренд), пропускаем.
      //    Исключение: sharp_impulse — свеча сама является импульсом, объём ещё горячий.
      if (!isSharpImpulse && price24hChange > 40 && volMult < 2.5 && volMult4h < 1.3) {
        logger.info({ symbol, price24hChange: price24hChange.toFixed(1) + "%", volMult: volMult.toFixed(2) }, "SKIP: exhausted pump (>40% 24h + vol < 2.5x) — слишком поздно для входа");
        skipCount.exhaustedPump++;
        continue;
      }

      // 2. Монета в нисходящем тренде 24h → хвост дампа после пампа, лонги ликвидируются.
      //    Памп был вчера — сегодня монета уже -8% или хуже. Входить = ловить падающий нож.
      if (price24hChange < -8) {
        logger.debug({ symbol, price24hChange: price24hChange.toFixed(1) + "%" }, "SKIP: 24h price deeply negative — post-pump dump");
        skipCount.deepNegative++;
        continue;
      }

      // ── FAST TRACK: BingX Price + Volume (без CoinGlass) ────────────────────────
      // Если свеча >= 10% И объём >= 7x среднего — сигнал достаточно сильный сам по себе.
      // Это ловит explosive starts (BIO 12:00 МСК: +9.82%, 5.1x vol) без ожидания OI.
      // Пример: при CoinGlass batch = 8 мин, к 12:08 МСК цена уже выросла на 25%.
      const FAST_TRACK_PRICE_PCT = 10.0;  // % свечи для прямого входа
      const FAST_TRACK_VOL_MULT  = 7.0;  // множитель объёма для прямого входа

      // ── PREV CANDLE FAST TRACK: ловим когда большая свеча закрылась между сканами ──
      // Проблема: скан запускается в 05:29, тратит 8 мин на CoinGlass batch.
      // К 05:37 свеча 05:00-05:30 (+28%) уже закрылась, текущая 05:30-06:00 flat (+0.5%).
      // Решение: если ПРЕДЫДУЩАЯ закрытая свеча была fast_track — и цена ещё держится
      // (не откатилась > 5% от закрытия той свечи) — это тоже valid сигнал.
      const prevPriceChange = prev1k
        ? ((parseFloat(prev1k.close) - parseFloat(prev1k.open)) / parseFloat(prev1k.open)) * 100
        : 0;
      const prevClose1 = parseFloat(prev1k?.close || "0");
      const priceFromPrevClose = prevClose1 > 0 ? ((close - prevClose1) / prevClose1) * 100 : 0;
      const isPrevFastTrack = Math.abs(prevPriceChange) >= FAST_TRACK_PRICE_PCT
                           && prevVol1Mult >= FAST_TRACK_VOL_MULT
                           && priceFromPrevClose > -5.0;  // цена ещё держится от закрытия

      const isFastTrack = (Math.abs(priceChange) >= FAST_TRACK_PRICE_PCT && volMult >= FAST_TRACK_VOL_MULT)
                       || isPrevFastTrack;

      // ── STEP 1: PRIMARY FILTER — CoinGlass глобальный OI (агрегат по всем биржам) ──
      // Проверяем 5 таймфреймов: 5m, 30m, 1h, 4h, 24h.
      // Fast Track символы проходят этот блок без проверки OI.
      const cgOI = coinglassOIMap.get(symbol);

      // ── CoinGlass Timeout Fallback: BingX OI прямой запрос ───────────────────
      // Когда CoinGlass таймаутит по символу (малые токены, rate-limit),
      // вычисляем % изменения OI напрямую из BingX: текущий OI vs сохранённый baseline.
      // Baseline обновляется каждые 20-60 мин → получаем аналог oi30m/oi1h.
      let bingxDirectOIChange: number | null = null;
      if (!cgOI?.available) {
        // Уровень 1: BingX прямой запрос vs baseline (без лимитов, мгновенно)
        const baseline = oiBaseline.get(symbol);
        if (baseline && (Date.now() - baseline.takenAt.getTime()) < MAX_BASELINE_AGE_MS) {
          const bxOI = await getOpenInterest(symbol);
          if (bxOI) {
            const currentOI = parseFloat(bxOI.openInterest);
            if (currentOI > 0 && baseline.oi > 0) {
              bingxDirectOIChange = ((currentOI - baseline.oi) / baseline.oi) * 100;
              logger.info(
                {
                  symbol,
                  currentOI: currentOI.toFixed(0),
                  baselineOI: baseline.oi.toFixed(0),
                  changePct: bingxDirectOIChange.toFixed(1) + "%",
                  baselineAgeMin: ((Date.now() - baseline.takenAt.getTime()) / 60000).toFixed(0),
                },
                "🔄 CG FALLBACK L1: BingX OI прямой запрос (CoinGlass таймаут)"
              );
            }
          }
        }

        // Уровень 2: Coinalyze — кросс-биржевой агрегат (100 req/day, 30-мин кэш)
        // Включается когда BingX baseline недоступен (новые монеты, GWEI и пр.)
        // Сохраняем ≥30 вызовов в день — они нужны для stale-cancel и ручных проверок.
        if (bingxDirectOIChange === null) {
          const czStats = getCoinalyzeDailyStats();
          if (czStats.remaining >= 30) {
            const czResult = await getCoinalyzeOI(symbol);
            if (czResult.available && czResult.oiChange30m !== null) {
              bingxDirectOIChange = czResult.oiChange30m;
              logger.info(
                { symbol, oiChange30m: czResult.oiChange30m.toFixed(1) + "%", czRemaining: czStats.remaining },
                "🔄 CG FALLBACK L2: Coinalyze OI (BingX baseline недоступен)"
              );
            }
          } else {
            logger.debug(
              { symbol, czRemaining: czStats.remaining },
              "⚠️ CG FALLBACK L2: Coinalyze пропущен — лимит заканчивается (< 30 вызовов)"
            );
          }
        }
      }

      const oi5m  = cgOI?.oiChange5m  ?? null;
      const oi30m = cgOI?.oiChange30m ?? (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
      const oi1h  = cgOI?.oiChange1h  ?? (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
      const oi4h  = cgOI?.oiChange4h  ?? null;
      const oi24h = cgOI?.oiChange24h ?? null;

      // Пороги — дифференцированные по ТФ:
      // 5m: 5.0% (ловим начало импульса), 30m: 6.0%, 1h: 6% (исключаем флэт-шум),
      // 4h: 8% (медленное накопление за несколько часов), 24h: 20% (крупная капитализация)
      const OI_THRESH_5M  = 5.0;
      const OI_THRESH_30M = 6.0;
      const OI_THRESH_1H  = 6.0;
      const OI_THRESH_4H  = 8.0;
      const OI_THRESH_24H = 20.0;
      // Требуем ПОЛОЖИТЕЛЬНЫЙ OI — отрицательный означает закрытие позиций/окончание движения.
      // Исключение short_squeeze обрабатывается отдельным детектором через hasShortTfOiDrop.
      const t5   = oi5m  !== null && oi5m  >= OI_THRESH_5M;
      const t30  = oi30m !== null && oi30m >= OI_THRESH_30M;
      const t1h  = oi1h  !== null && oi1h  >= OI_THRESH_1H;
      const t4h  = oi4h  !== null && oi4h  >= OI_THRESH_4H;
      const t24h = oi24h !== null && oi24h >= OI_THRESH_24H;

      // ── ФИЛЬТР: памп уже был — кросс-биржевой OI (CoinGlass, агрегат всех бирж) ──
      //
      // CoinGlass = агрегат Binance + Bybit + OKX + BingX + др. → это глобальный сигнал,
      // не привязан к одной бирже. Два случая:
      //
      // A) CoinGlass вернул 24h OI < -15% → шорты закрывались весь день → памп отыгран.
      if (oi24h !== null && oi24h < -15) {
        logger.debug(
          { symbol, oi24h: oi24h.toFixed(1) + "%" },
          "SKIP: памп уже был — CoinGlass 24h OI < -15% (глобальный агрегат)"
        );
        skipCount.other++;
        continue;
      }

      // B) CoinGlass покрывает монету, но 24h поле отсутствует (null) — типично для малых токенов.
      //    В этом случае смотрим краткосрочные TF: если ВСЕ доступные (5m, 30m, 1h) отрицательные
      //    → OI падает по всему фронту → выдавливание лонгов / пост-памп дамп.
      if (cgOI?.available && oi24h === null) {
        const shortTfValues = [oi5m, oi30m, oi1h].filter(v => v !== null) as number[];
        const allNegative = shortTfValues.length >= 2 && shortTfValues.every(v => v < -2);
        if (allNegative) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
            "SKIP: 24h OI недоступен, но все краткосрочные TF отрицательные — OI падает по всему фронту"
          );
          continue;
        }
      }

      // "Steady Accumulation": 5m И 30m — умеренный но одновременный рост OI + цена во флэте.
      // Ловит скрытое накопление где ни один ТФ не пробивает порог, но оба показывают рост.
      // Примеры: oi5m=3%, oi30m=4.5% при priceChange=0.3% → крупный игрок набирает позицию тихо.
      const tSteady = !t5 && !t30 && !t1h && !t4h && !t24h
                   && oi5m  !== null && oi5m  >= 3.0
                   && oi30m !== null && oi30m >= 4.0
                   && Math.abs(priceChange) <= 2.0;

      // Multi-TF confirmation:
      // — Короткие ТФ (5m, 30m) должны подтверждать друг друга — одиночный всплеск на 5m или 30m шум.
      // — Длинные ТФ (1h ≥6%, 4h ≥8%, 24h ≥20%) достаточно сильны и проходят поодиночке.
      const shortTfsConfirmed = t5 && t30;
      const longTfPass        = t1h || t4h || t24h;
      // anyOiPass: либо CoinGlass дал данные, либо BingX прямой фолбэк сработал
      const hasFallbackOI = bingxDirectOIChange !== null;
      const anyOiPass = (cgOI?.available || hasFallbackOI) && (shortTfsConfirmed || longTfPass || tSteady);

      // ── Фильтр: короткие ТФ + противоречие длинных ────────────────────────────
      // Если сработали только 5м+30м, но 4h или 24h OI глубоко в минусе —
      // весь день шли продажи/выход из позиций, краткосрочный всплеск ложный.
      // short_squeeze здесь невозможен: требует отрицательного OI (hasShortTfOiDrop),
      // тогда как shortTfsConfirmed требует положительного OI ≥5%/6% — взаимоисключение.
      if (shortTfsConfirmed && !longTfPass) {
        if (oi24h !== null && oi24h < -10) {
          logger.debug({ symbol, oi24h: oi24h.toFixed(1) + "%" }, "SKIP: 5м+30м ок, но 24ч OI < -10% — дневной слив");
          skipCount.other++;
          continue;
        }
        if (oi4h !== null && oi4h < -5) {
          logger.debug({ symbol, oi4h: oi4h.toFixed(1) + "%" }, "SKIP: 5м+30м ок, но 4ч OI < -5% — последние 4ч продажи");
          skipCount.other++;
          continue;
        }
      }

      // ── BingX Volume Pattern: объём + движение цены без подтверждения OI ────────
      // Без CoinGlass нет подтверждения умных денег — требуем тренд объёма (isVolTrend),
      // чтобы отсечь одиночные шортовые свечи и арбитраж.
      // Порог 3x+3%: снижен с 5x+5% чтобы ловить умеренные мувы (GOBLIN-тип, UB-тип).
      // Примечание: токены без объёмной подписи вообще (vol <1.5x весь памп) — не поймать.
      const isBingxVolume = !anyOiPass
                         && volMult >= 3.0
                         && priceChange >= 3.0
                         && isVolTrend;

      // ── 4h Momentum Pattern: медленный грайнд за несколько часов ─────────────────
      // Ловит монеты которые растут постепенно (+8-20% за 4h) с повышенным объёмом,
      // но без взрывной одиночной свечи. Пример: BLEND, LYN.
      // Средний объём последних 8 свечей (4h) должен быть 1.5x выше базовой нормы.
      // Порог снижен: 4% (был 8%) — ZEC за 4ч может расти на 3-5%, а не 8-20%.
      // volMult4h снижен: 1.2x (был 1.5x) — медленный тренд не даёт взрывного объёма.
      // Этот паттерн теперь покрывает и многодневные гринды (ZEC-тип), и внутридневные.
      const is4hMomentum = !anyOiPass
                        && !isBingxVolume
                        && price4hChange >= 4.0
                        && volMult4h >= 1.2
                        && priceChange > -2;   // текущая свеча не разворачивается

      // ── Байпас для cg_timeout/cg_building записей в очереди подтверждения ──────
      // Эти символы пропустили OI-фильтр (CG timeout или OI ниже порога), но уже
      // добавлены в confirming-очередь. Позволяем им дойти до confirming-блока (строка ~1426).
      const cgFallbackConfirmingRows = await db.select({ id: oiWatchTable.id })
        .from(oiWatchTable)
        .where(and(
          eq(oiWatchTable.symbol, symbol),
          eq(oiWatchTable.status, "confirming"),
          inArray(oiWatchTable.triggerTf, ["cg_timeout", "cg_building"])
        ))
        .limit(1);
      const isCgFallbackConfirming = cgFallbackConfirmingRows.length > 0;

      if (!isFastTrack && !anyOiPass && !isBingxVolume && !is4hMomentum && !isCgFallbackConfirming) {
        // ── FALLBACK: топ-50 активных токенов с недоступным или строящимся OI ─────
        // A) CG timeout (available=false): batch-запрос падает для TAG → добавляем в
        //    confirming-очередь. Те же 2ч ожидание что и у всех остальных сигналов.
        //    OI-фильтр не применяется (CG недоступен), но retrace/runaway/price+2% работают.
        // B) CG вернул данные но OI ниже порога на 2+ TF («строится»).
        //    Кейс: SKYAI/4USD — OI 3-4% на 5m+30m вместо 6% порога.
        if (activeSymbols.has(symbol)) {
          const cgTimeoutFallback = !cgOI?.available
                                 && volMult >= 2.0
                                 && priceChange > -5
                                 && priceChange < 25;
          const buildingTfCount = cgOI?.available
            ? [oi5m, oi30m, oi1h].filter(v => v !== null && v >= 2.0).length
            : 0;
          const cgBuildingFallback = cgOI?.available && buildingTfCount >= 2 && !anyOiPass;

          if (cgTimeoutFallback || cgBuildingFallback) {
            // Не дублируем если символ уже в очереди (watching или confirming)
            const alreadyQueued = await db.select({ id: oiWatchTable.id })
              .from(oiWatchTable)
              .where(and(
                eq(oiWatchTable.symbol, symbol),
                inArray(oiWatchTable.status, ["watching", "confirming"])
              ))
              .limit(1);

            if (alreadyQueued.length === 0) {
              const watchTf = cgTimeoutFallback ? "cg_timeout" : "cg_building";
              const watchOi = oi30m ?? oi5m ?? oi1h ?? 0;
              try {
                await db.insert(oiWatchTable).values({
                  symbol,
                  triggerTf: watchTf,
                  oiChange: watchOi,
                  priceAtEntry: await getFreshPrice(symbol, close),
                  volumeMultiplier: volMult,
                  sentimentKey: null,
                  status: "confirming",           // тот же путь что у всех → 2ч окно
                  addedAt: new Date(),
                  expiresAt: new Date(Date.now() + 6 * 60 * 60 * 1000), // 6ч как CONFIRM_EXPIRE_MS
                  avgVolume: avgVol,
                  isVolConfirmed: false,
                });
                logger.info(
                  { symbol, reason: watchTf, vol: volMult.toFixed(1) + "x", price: priceChange.toFixed(1) + "%", buildingTfs: buildingTfCount },
                  "👁 ACTIVITY WATCH: топ-активный кандидат добавлен в 2ч confirming-очередь"
                );
              } catch { /* duplicate or db error — non-critical */ }
            }
          }
        }

        logger.debug(
          {
            symbol,
            vol:      volMult.toFixed(2) + "x",
            vol4h:    volMult4h.toFixed(2) + "x",
            price:    priceChange.toFixed(2) + "%",
            price4h:  price4hChange.toFixed(1) + "%",
            oi5m:  oi5m?.toFixed(2)  ?? "n/a",
            oi30m: oi30m?.toFixed(2) ?? "n/a",
            oi1h:  oi1h?.toFixed(2)  ?? "n/a",
          },
          "SKIP: недостаточно объёма или движения цены (vol < 1.0x или price < 2.5%)"
        );
        skipCount.noOiNoVol++;
        continue;
      }

      // Какой ТФ сработал (OI path) или fast_track (BingX path)
      let oiTriggerTf: string;
      let cgOIChange: number;

      if (isBingxVolume && !anyOiPass && !isFastTrack) {
        // BingX Volume Pattern — нет CoinGlass OI, но объём взрывной
        oiTriggerTf = "bingx_volume";
        cgOIChange = 0;
        logger.info(
          { symbol, price: priceChange.toFixed(1) + "%", vol: volMult.toFixed(1) + "x" },
          "📈 BINGX VOLUME: нет CoinGlass OI, но объём + цена сильные"
        );
      } else if (is4hMomentum && !anyOiPass && !isFastTrack) {
        // 4h Momentum Pattern — медленный грайнд за несколько часов
        oiTriggerTf = "4h_momentum";
        cgOIChange = 0;
        logger.info(
          { symbol, price4h: price4hChange.toFixed(1) + "%", vol4h: volMult4h.toFixed(2) + "x", price: priceChange.toFixed(1) + "%" },
          "📈 4H MOMENTUM: медленный грайнд — 4h рост + повышенный средний объём"
        );
      } else if (isFastTrack && !anyOiPass) {
        // Чистый Fast Track — OI не сработал, но свеча + объём сильные
        oiTriggerTf = isPrevFastTrack && !(Math.abs(priceChange) >= FAST_TRACK_PRICE_PCT && volMult >= FAST_TRACK_VOL_MULT)
          ? "fast_track_prev"   // сработала предыдущая свеча (HIVE-кейс)
          : "fast_track";
        cgOIChange = 0;
        logger.info(
          {
            symbol,
            price:      priceChange.toFixed(1) + "%",
            vol:        volMult.toFixed(1) + "x",
            prevPrice:  prevPriceChange.toFixed(1) + "%",
            prevVol:    prevVol1Mult.toFixed(1) + "x",
            isPrevCandle: isPrevFastTrack && oiTriggerTf === "fast_track_prev",
          },
          "⚡ FAST TRACK: BingX price+vol bypass CoinGlass gate"
        );
      } else if (tSteady) {
        // Steady Accumulation — 5m + 30m одновременно, цена flat
        oiTriggerTf = "steady";
        cgOIChange = oi30m!; // берём 30m как основное значение для скоринга
        logger.info(
          { symbol, oi5m: oi5m!.toFixed(1) + "%", oi30m: oi30m!.toFixed(1) + "%", price: priceChange.toFixed(1) + "%" },
          "🔍 STEADY ACCUM: Multi-TF OI convergence + flat price"
        );
      } else {
        // Стандартный CoinGlass OI путь (или fast_track + OI — берём OI для скоринга)
        const triggeredTfs = [
          t5   && "5m",
          t30  && "30m",
          t1h  && "1h",
          t4h  && "4h",
          t24h && "24h",
        ].filter(Boolean) as string[];
        const fallbackSuffix = hasFallbackOI && !cgOI?.available ? "+bingx_direct" : "";
        oiTriggerTf = isFastTrack ? "fast_track+" + triggeredTfs.join("+") + fallbackSuffix : triggeredTfs.join("+") + fallbackSuffix;

        const cand5m  = t5   ? Math.abs(oi5m!)  : 0;
        const cand30m = t30  ? Math.abs(oi30m!) : 0;
        const cand1h  = t1h  ? Math.abs(oi1h!)  : 0;
        const cand4h  = t4h  ? Math.abs(oi4h!)  : 0;
        const cand24h = t24h ? Math.abs(oi24h!) : 0;
        const bestAbs = Math.max(cand5m, cand30m, cand1h, cand4h, cand24h);
        cgOIChange = bestAbs === cand5m  && t5   ? oi5m!
                   : bestAbs === cand30m && t30  ? oi30m!
                   : bestAbs === cand1h  && t1h  ? oi1h!
                   : bestAbs === cand4h  && t4h  ? oi4h!
                   : oi24h!;
      }

      // ── STEP 2: LIQUIDITY FILTER — Global Vol24h / OI USD > 0.1 (не «мёртвые» монеты) ──
      // Пропускаем для fast_track и bingx_volume (у них высокий BingX-объём, монета явно активна).
      const oiUsd = cgOI?.oiUsd;
      const cgVolUsd = cgOI?.cgVolUsd;
      const vol24hUSD = parseFloat(ticker.quoteVolume) || 0;

      if (!isFastTrack && !isBingxVolume && oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
        const turnoverRatio = cgVolUsd / oiUsd;
        if (turnoverRatio < 0.1) {
          logger.debug({ symbol, turnoverRatio: turnoverRatio.toFixed(3), cgVol: cgVolUsd, oiUsd }, "SKIP: low global turnover ratio (cgVol/OI < 0.1)");
          continue;
        }
      }

      // ── Ликвидность: относительные фильтры покрывают без абсолютных порогов ───
      // Все фильтры ниже — относительные (volMult, OI%, turnoverRatio, спред).
      // Абсолютных долларовых порогов нет: $15M для BTC — песчинка,
      // $15M для микрокапа — всё что есть. Мёртвые монеты отсеиваются спредом
      // (≥0.5% → пропустить) и volMult (2.5x своей базы).

      // ── FILTER: Exit pump — объём в 4x+ раз больше OI = поздний сброс, не органика ──
      if (!isFastTrack && !isBingxVolume && oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
        const volToOi = cgVolUsd / oiUsd;
        if (volToOi > 4.0) {
          logger.debug({ symbol, volToOi: volToOi.toFixed(2) }, "SKIP: exit pump — объём >> OI (4x+)");
          continue;
        }
      }

      // Debug tracking (для лог-сводки по итогам цикла)
      debugTop.push({ symbol, vol: volMult, cgOI: cgOIChange || null, price: priceChange });

      // ── FILTER: Spread — узкий спред (< 0.5%) если BingX возвращает bid/ask ────
      const bid = parseFloat(ticker.bidPrice ?? "0") || 0;
      const ask = parseFloat(ticker.askPrice ?? "0") || 0;
      if (bid > 0 && ask > 0) {
        const spreadPct = (ask - bid) / ask * 100;
        if (spreadPct >= 0.5) {
          logger.debug({ symbol, spread: spreadPct.toFixed(3) }, "SKIP: spread >= 0.5%");
          continue;
        }
      }

      // ── STEP 3: VOLUME FILTER — подтверждение интереса ──────────────────────────
      // Логика порогов объёма:
      //
      // A) "High OI Quiet" — OI ≥ 20% (24h) или ≥ 12% (4h) И цена ≤ 1.5% flat.
      //    Крупный игрок набирает позицию тихо в течение часов/суток.
      //    Порог: 1.8x — минимальное подтверждение объёмом (было 1.0x — слишком много шума).
      //
      // B) "Steady Accum" — 5m+30m одновременно + flat price (мульти-ТФ паттерн).
      //    Порог: 1.8x
      //
      // C) Стандартный путь (импульс, пробой, шорт-сквиз): единый порог 1.0x
      const isHighOiQuiet = Math.abs(priceChange) <= 1.5
                         && ((t24h && Math.abs(oi24h!) >= 20) || (t4h && Math.abs(oi4h!) >= 12));

      // Порог объёма: 2.5x.
      // Победители с НИЗКИМ объёмом: M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%), BNLIFE(0.99x, +3.3%).
      // Ключевой фильтр — OI диапазон (10% кеп), а не объём. Не режем низкий объём.
      const volThreshold = 2.5;

      // 4h Momentum: 30m объём может быть умеренным (1.2-2x) — монета идёт несколько часов/дней.
      // Условие достаточности: 4h объём >= 1.2x (проверено в is4hMomentum).
      if (volMult < volThreshold && !is4hMomentum) {
        // ── OI WATCH: OI сработал, но объём ещё не подтянулся ────────────────────
        // Вместо того чтобы просто пропустить, ставим монету на наблюдение.
        // Критерии добавления в watch:
        //   1. OI уверенно сработал (хоть один ТФ)
        //   2. Объём пока ниже порога (иначе бы уже дали сигнал)
        //   3. Цена ещё не улетела (< 25% на текущей свече) — зарождение, не поздний вход
        //   4. Не новый листинг (у них своя логика Short Sniper)
        const oiTriggeredStrongly = cgOI?.available && (t5 || t30 || t1h);
        const priceNotYetExploded = Math.abs(priceChange) < 25;
        if (oiTriggeredStrongly && priceNotYetExploded && avgVol > 0) {
          try {
            // Изменение 2: если ВСЕ доступные TF OI положительные — используем
            // пониженный порог объёма в OI Watch (кодируем в triggerTf как "all+{tf}")
            const availableOis = [oi5m, oi30m, oi1h, oi4h, oi24h].filter(v => v !== null) as number[];
            const allAvailablePositive = availableOis.length >= 2 && availableOis.every(v => v > 0);
            const baseTf    = t5 ? "5m" : t30 ? "30m" : "1h";
            const triggerTf = allAvailablePositive ? `all+${baseTf}` : baseTf;
            const triggerOi = t5 ? oi5m! : t30 ? oi30m! : oi1h!;
            const expiresAt = new Date(Date.now() + 2 * 3600 * 1000); // +2h

            // Upsert: обновляем только активные watching записи, иначе вставляем новую
            const existing = await db.select({ id: oiWatchTable.id, status: oiWatchTable.status })
              .from(oiWatchTable)
              .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "watching")))
              .limit(1);

            if (existing.length > 0) {
              // Обновляем OI значение (накапливается)
              await db.update(oiWatchTable)
                .set({ oiChange: triggerOi, volumeMultiplier: volMult, expiresAt })
                .where(eq(oiWatchTable.id, existing[0].id));
            } else if (existing.length === 0) {
              await db.insert(oiWatchTable).values({
                symbol,
                triggerTf,
                oiChange: triggerOi,
                priceAtEntry: await getFreshPrice(symbol, close),
                volumeMultiplier: volMult,
                sentimentKey: null,
                status: "watching",
                addedAt: new Date(),
                expiresAt,
                avgVolume: avgVol,
              });
              logger.info(
                { symbol, triggerTf, oiChange: triggerOi.toFixed(2) + "%", vol: volMult.toFixed(2) + "x", price: priceChange.toFixed(2) + "%" },
                "👁 OI WATCH: добавлен кандидат (OI есть, объём ещё не подтянулся)"
              );
            }
          } catch (err) {
            logger.warn({ err, symbol }, "OI Watch insert failed");
          }
        }
        logger.debug(
          { symbol, volMult: volMult.toFixed(2), threshold: volThreshold, isHighOiQuiet, isSteady: tSteady },
          "SKIP: volume below threshold"
        );
        skipCount.lowVolume++;
        continue;
      }

      if (isHighOiQuiet) {
        logger.info(
          { symbol, oi24h: oi24h?.toFixed(1) + "%", oi4h: oi4h?.toFixed(1) + "%", price: priceChange.toFixed(1) + "%", vol: volMult.toFixed(1) + "x" },
          "🏦 HIGH OI QUIET: Large OI + flat price — hidden accumulation/distribution"
        );
      }

      // ── STEP 4: ANTI-STALE FILTER ─────────────────────────────────────────────
      // Если CoinGlass batch занял 8+ минут и монета уже двинулась на >= 20%
      // за последние 2 свечи (60 мин) — это запоздалый сигнал, пропускаем.
      // Исключение: sharp_impulse — свеча сама и есть начало движения, фильтр неприменим.
      // Исключение: volume_flash — объём 10x+ = движение ещё активно, не устаревший сигнал.
      // (было 3 свечи / 15% — слишком агрессивно, пропускали вторые волны)
      const STALE_LOOKBACK  = 2; // свечи назад (2 × 30m = 60 мин)
      const STALE_THRESHOLD = 45; // % порог "уже поздно" (увеличено для ракет типа SUP/OWL)
      const staleRefIdx = klines.length - 1 - STALE_LOOKBACK;
      if (!isSharpImpulse && !isVolumeFlash && staleRefIdx >= 0) {
        const staleRefClose = parseFloat(klines[staleRefIdx].close) || 0;
        if (staleRefClose > 0) {
          const staleMove = Math.abs((close - staleRefClose) / staleRefClose * 100);
          if (staleMove >= STALE_THRESHOLD) {
            logger.info(
              { symbol, staleMove: staleMove.toFixed(1) + "%", lookbackCandles: STALE_LOOKBACK },
              "SKIP: stale signal — price already moved too much in last 3 candles"
            );
            skipCount.other++;
            continue;
          }
        }
      }

      // ── PATTERN EVALUATION (CoinGlass OI + Volume + Price) ────────────────────
      let det = evaluatePattern(cgOIChange, priceChange, volMult, null, settings, oiTriggerTf);

      // ── ФИЛЬТР: hidden_accumulation — требуем объёмный тренд (не одиночный спайк) ──
      // Одна свеча с высоким объёмом может быть шумом (арбитраж, вынос стопов).
      // Если предыдущие 2 закрытые свечи тоже показывают объём >= 1.3x — это ТРЕНД покупок.
      // Данные: SYN (vol=8x но prevVol была нормальная) — убираем такие сигналы.
      if (det?.sentiment.key === "hidden_accumulation" && !isVolTrend) {
        logger.debug(
          { symbol, prevVol1: prevVol1Mult.toFixed(2) + "x", prevVol2: prevVol2Mult.toFixed(2) + "x" },
          "SKIP: hidden_accum — нет объёмного тренда (предыдущие свечи < 1.3x нормы)"
        );
        det = null;
      }

      // ── ФИЛЬТР: устаревший Short Squeeze ─────────────────────────────────────
      // Если OI упал только на 4h/24h, но на 5m/30m нейтральный → сквиз был вчера,
      // не сейчас. Заходить в хвост пампа — опасно. Убираем такие сигналы.
      if (det?.sentiment.key === "short_squeeze") {
        const hasShortTfOiDrop = (oi5m !== null && oi5m < -2) || (oi30m !== null && oi30m < -2);
        if (!hasShortTfOiDrop) {
          logger.info(
            { symbol, cgOIChange: cgOIChange.toFixed(1), oi5m: oi5m?.toFixed(1) ?? "n/a", oi30m: oi30m?.toFixed(1) ?? "n/a" },
            "SKIP: устаревший Short Squeeze — падение OI только на 4h/24h, на 5m/30m уже нейтрально"
          );
          det = null;
        }
      }

      // Override: Steady Accumulation — 5m+30m одновременный рост + цена flat.
      // С новой философией (только подтверждённые покупки) — НЕ стреляем напрямую при flat цене.
      // Вместо этого добавляем в OI Watch: когда цена тронется на 2%+ — PATH B выстрелит.
      // tSteady попадает сюда с volMult >= 2.5 (иначе ушёл бы в OI Watch раньше).
      if (!det && tSteady) {
        try {
          const existingWatch = await db.select({ id: oiWatchTable.id })
            .from(oiWatchTable)
            .where(and(eq(oiWatchTable.symbol, symbol), eq(oiWatchTable.status, "watching")))
            .limit(1);
          if (existingWatch.length === 0) {
            await db.insert(oiWatchTable).values({
              symbol,
              triggerTf: "5m+30m",
              oiChange: oi30m!,
              priceAtEntry: await getFreshPrice(symbol, close),
              volumeMultiplier: volMult,
              sentimentKey: null,
              status: "watching",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + 2 * 3600 * 1000),
              avgVolume: avgVol,
            });
            logger.info(
              { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), vol: volMult.toFixed(2) },
              "👁 STEADY ACCUM → OI Watch: flat цена, ждём подтверждения движения"
            );
          }
        } catch (err) {
          logger.warn({ err, symbol }, "tSteady OI Watch insert failed");
        }
        // Не устанавливаем det — продолжаем без прямого сигнала
      }

      // BingX Volume fallback: объём + движение цены без OI-подтверждения.
      // evaluatePattern может вернуть null при cgOIChange=0 — форсируем паттерн вручную.
      if (!det && isBingxVolume) {
        det = {
          passes: true,
          oiChangePercent: 0,
          openInterest: 0,
          sentiment: {
            key: "impulse_breakout",
            label: "Объёмный импульс",
            traderAction: "LONG (объём + цена, вход до роста OI)",
            oiFalling: false,
          },
        };
      }

      // Sharp Impulse override: свеча сама является взрывным импульсом (≥12% за свечу, объём ≥2x).
      // Перезаписываем любой паттерн — исключение из stale + exhausted фильтров уже выдано выше.
      // CVD-фильтр ниже остаётся — подтверждение покупательского давления обязательно.
      if (isSharpImpulse) {
        det = {
          passes: true,
          oiChangePercent: cgOIChange || 0,
          openInterest: 0,
          sentiment: {
            key: "sharp_impulse",
            label: "Резкий импульс",
            traderAction: "LONG (вход на продолжение импульса, стоп -7%)",
            oiFalling: false,
          },
        };
        logger.info(
          { symbol, priceChange: priceChange.toFixed(1) + "%", volMult: volMult.toFixed(1) + "x" },
          "⚡ SHARP IMPULSE: взрывная свеча — обход stale + exhausted фильтров"
        );
      }

      // Volume Flash override: аномальный объём (>= 10x) + цена движется (3–45%).
      // Перезаписывает любой другой паттерн — как sharp_impulse.
      // Обходит stale-фильтр (выше) — объём 10x говорит что движение ещё активно.
      // Обходит OI-требование — ловим flash-памп без накопления открытого интереса.
      if (isVolumeFlash) {
        det = {
          passes: true,
          oiChangePercent: cgOIChange || 0,
          openInterest: 0,
          sentiment: {
            key: "volume_flash",
            label: "Объёмная вспышка",
            traderAction: "SCALP LONG (следуй за объёмом, стоп -5%)",
            oiFalling: false,
          },
        };
        logger.info(
          { symbol, volMult: volMult.toFixed(1) + "x", priceChange: priceChange.toFixed(1) + "%" },
          "⚡⚡ VOLUME FLASH: аномальный объём без OI-паттерна — обход stale фильтра"
        );
      }

      if (!det) continue;

      // ── КУЛДАУН по символу: 24ч после cancelled/stop_loss ────────────────────
      // Если по этому символу уже был сигнал который отменили или выбило по стопу —
      // новый сигнал раньше чем через 24ч это шум (6ч было слишком мало: UB, BB).
      // Защита от NULL closed_at (баг в старых записях): используем detectedAt как запасное.
      {
        const cooldownMs = 24 * 60 * 60 * 1000;  // 24ч кулдаун после отмены
        const since = new Date(Date.now() - cooldownMs);
        const recent = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              inArray(trackedSignalsTable.status, ["cancelled", "stop_loss"]),
              or(
                // Нормальный случай: closed_at установлен и свежий
                gte(trackedSignalsTable.closedAt, since),
                // Защита от NULL closed_at (старый баг): смотрим на detectedAt
                and(isNull(trackedSignalsTable.closedAt), gte(trackedSignalsTable.detectedAt, since)),
              ),
            )
          )
          .limit(1);
        if (recent.length > 0) {
          logger.debug({ symbol }, "SKIP: кулдаун 24ч — недавний cancelled/stop_loss по этому символу");
          continue;
        }
      }

      // ── ХРОНИЧЕСКИЙ ТОКЕН: hidden_accumulation без результата 4 дня → 72ч блок ──
      // WAVES: 2 недели повторяющихся hidden_accumulation без движения цены.
      // Если за последние 4 дня было 2+ отмены hidden_accumulation — токен мёртв.
      // Не давать ему снова заходить в систему раньше чем через 72ч.
      {
        const since4d = new Date(Date.now() - 4 * 24 * 60 * 60 * 1000);
        const since72h = new Date(Date.now() - 72 * 60 * 60 * 1000);
        const chronicCancels = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .innerJoin(signalsTable, eq(signalsTable.id, trackedSignalsTable.signalId))
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "cancelled"),
              eq(signalsTable.sentimentKey, "hidden_accumulation"),
              gte(trackedSignalsTable.closedAt, since4d),
            )
          );
        if (chronicCancels.length >= 2) {
          // Проверяем, не было ли профита за последние 72ч (если был — не блокируем)
          const recentProfit = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                eq(trackedSignalsTable.status, "profit"),
                gte(trackedSignalsTable.closedAt, since72h),
              )
            )
            .limit(1);
          if (recentProfit.length === 0) {
            logger.info(
              { symbol, chronicCancels: chronicCancels.length },
              "SKIP: хронический токен — 2+ отмены hidden_accumulation за 4 дня без профита (блок 72ч)"
            );
            skipCount.other++;
            continue;
          }
        }
      }

      // ── ПОВТОРНЫЙ СИГНАЛ: был ли символ в сигналах за последние 24ч ──────────
      // После кулдауна сигнал всё равно может прийти повторно — помечаем его.
      // Бот добавит пометку: "Символ уже был в сигналах — тезис подтвердился снова".
      let isRepeatSignal = false;
      {
        const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
        const prev = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              gte(trackedSignalsTable.detectedAt, since24h),
            )
          )
          .limit(1);
        isRepeatSignal = prev.length > 0;
        if (isRepeatSignal) {
          logger.debug({ symbol }, "REPEAT: символ уже был в сигналах за 24ч — пометим в сообщении");
        }
      }

      // ── БЛОКИРОВКА: cooldown после стоп-лосса (3 дня) ───────────────────────
      // Если монета получила стоп-лосс в последние 3 дня — она, скорее всего, в
      // нисходящем тренде (пост-памп распродажа). Повторный сигнал будет ложным.
      // Пример: MAGMA стоп 24 апр → новый сигнал 26 апр = заход в нисходящий тренд.
      {
        const since3d = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000);
        const recentSL = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, symbol),
              eq(trackedSignalsTable.status, "stop_loss"),
              gte(trackedSignalsTable.closedAt, since3d),
            )
          )
          .limit(1);
        if (recentSL.length > 0) {
          logger.info({ symbol }, "SKIP: стоп-лосс cooldown (3 дня) — не входим в нисходящий тренд");
          skipCount.other++;
          continue;
        }
      }

      // OI теперь бонус, а не ворота — отрицательный OI на отдельных ТФ не блокирует сигнал.
      // Исключение 1: если CoinGlass покрывает монету И все краткосрочные ТФ глубоко отрицательные
      // — это явный пост-памп дамп, входить опасно.
      if (cgOI?.available && !isBingxVolume) {
        const shortTfValues = [oi5m, oi30m, oi1h].filter(v => v !== null) as number[];
        const allDeeplyNegative = shortTfValues.length >= 2 && shortTfValues.every(v => v < -3);
        if (allDeeplyNegative) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
            "SKIP: все краткосрочные OI глубоко отрицательные (< -3%) — пост-памп дамп"
          );
          continue;
        }
      }

      // Исключение 2 (contra-signal): объём + цена сигнализируют вход,
      // но умные деньги ВЫХОДЯТ по 5m/30m OI — нельзя входить против крупного игрока.
      // 5m OI < -3% = позиции закрываются прямо сейчас, 30m < -4% = устойчивый выход.
      if (isBingxVolume && cgOI?.available) {
        const oiContraSignal =
          (oi5m  !== null && oi5m  < -3.0) ||
          (oi30m !== null && oi30m < -4.0);
        if (oiContraSignal) {
          logger.debug(
            { symbol, oi5m: oi5m?.toFixed(1), oi30m: oi30m?.toFixed(1) },
            "SKIP: BingX Volume contra-signal — умные деньги выходят (OI 5m/30m отрицательный)"
          );
          continue;
        }
      }

      // ── ОКНО ПОДТВЕРЖДЕНИЯ: 60 минут для всех паттернов ──────────────────────
      // Идея: засёк рост OI → подожди 1 час → проверь что OI всё ещё растёт → сигнал.
      // Это отсекает flash-пампы (OI резко растёт и тут же падает за 10-15 минут).
      // Настоящее накопление держит OI положительным часами.
      //
      // Проверки на 60-й минуте:
      //   • свежий OI (cgOIChange) < -3%   → OI иссяк, накопление закончилось → отмена
      //   • цена откатилась > 5% от точки   → ложный сигнал → отмена
      //   • цена улетела > 20% вверх         → вход слишком дорогой → отмена
      //   • всё остальное                    → СИГНАЛ
      //
      // Исключения: sharp_impulse / volume_flash работают на скорости — ждать 60 мин нельзя.
      if (!isSharpImpulse && !isVolumeFlash) {
        // Время ожидания зависит от ТФ: 4h/24h уже подтверждают многочасовое накопление,
        // долго ждать смысла нет. 30m/5m спайки требуют полного часа проверки.
        // Увеличено с 4ч до 6ч: теперь окно подтверждения 2ч + запас ещё 4ч наблюдения.
        const CONFIRM_EXPIRE_MS = 6 * 60 * 60 * 1000;
        const MAX_RETRACE_PCT   = -5.0;
        const OI_DRAIN_PCT      = -3.0;

        const confirmingEntry = await db.select()
          .from(oiWatchTable)
          .where(and(
            eq(oiWatchTable.symbol, symbol),
            eq(oiWatchTable.status, "confirming"),
          ))
          .limit(1);

        if (confirmingEntry.length > 0) {
          const entry = confirmingEntry[0];
          const ageMs = Date.now() - new Date(entry.addedAt).getTime();
          const priceFromDetection = ((close - entry.priceAtEntry) / entry.priceAtEntry) * 100;

          // Время ожидания определяется по ТФ сохранённому в записи очереди.
          // ВАЖНО: проверяем через \b (word boundary), чтобы "4h_momentum" не совпало с "4h".
          // "4h_momentum" — это паттерн цены за 4ч, не 4h OI → должен ждать 60 мин.
          // "4h", "fast_track+4h", "5m+4h" — реальные 4h OI → 15 мин достаточно.
          const entryTf = entry.triggerTf ?? "30m";
          const is4hOI  = /\b4h\b/.test(entryTf);   // "4h" как отдельное слово, не в "4h_momentum"
          const is24hOI = /\b24h\b/.test(entryTf);
          const is1hOI  = /\b1h\b/.test(entryTf);
          // Быстрые паттерны живут 1-4ч — 2ч окно убивает их (движение уже заканчивается).
          // Для них: 30 мин подтверждения + повышенный MAX_RUNAWAY_PCT (breakout ≠ поздний вход).
          const isFastPattern = [
            "aggressive_breakout", "sharp_impulse", "volume_flash",
            "short_squeeze", "bear_trap",
          ].includes(entry.sentimentKey ?? "");
          const isSlowPattern = [
            "hidden_accumulation",
            "bullish_accumulation",
          ].includes(entry.sentimentKey ?? "");
          // MAX_RUNAWAY_PCT: для накопления 10% — правильно. Для breakout — движение только начинается.
          const MAX_RUNAWAY_PCT = isFastPattern ? 25.0 : 10.0;
          // Удвоенные окна подтверждения: монета должна удержать накопление дольше.
          // Слабые кандидаты (OI иссякает или цена откатывается) отсеиваются ДО сигнала.
          const CONFIRM_WINDOW_MS =
            (is4hOI || is24hOI) ? 30 * 60 * 1000    // 30 мин: 4h/24h OI
            : is1hOI            ? 60 * 60 * 1000    // 60 мин: 1h OI
            : isFastPattern     ? 30 * 60 * 1000    // 30 мин: быстрые паттерны (breakout/squeeze/flash)
                                : 60 * 60 * 1000; // 60 мин: 30m/5m/4h_momentum/steady/bingx (было 2 часа)
          const waitMin = Math.round(CONFIRM_WINDOW_MS / 60000);

          if (isSlowPattern) {
            // Триггер для медленных паттернов: пробой локального хая ИЛИ всплеск объема
            const recentHighs = klines.slice(-9, -1).map(k => parseFloat(k.high) || 0);
            const recentHigh = Math.max(...recentHighs);
            const breakout = recentHigh > 0 && close > recentHigh * 1.005; // Пробой на 0.5% выше хая

            // Дополнительный триггер: всплеск объема на текущей свече (> 3x от avgVolume)
            const currentVolume = parseFloat(klines[klines.length - 1].volume);
            const avgVol = entry.avgVolume; // Используем avgVolume из oiWatchTable
            const volumeSpike = (avgVol ?? 0) > 0 && currentVolume > (avgVol ?? 0) * 3.0;

            if (!breakout && !volumeSpike) {
              logger.debug(
                { symbol, close, recentHigh, gap: ((close / recentHigh - 1) * 100).toFixed(2) + "%", currentVolume, avgVol },
                "⏳ SLOW PATTERN: ждём пробоя локального хая ИЛИ всплеска объема"
              );
              continue;
            }

            logger.info(
              { symbol, close, recentHigh, currentVolume, avgVol, trigger: breakout ? "breakout" : "volume_spike" },
              "✅ SLOW PATTERN: пробой локального хая ИЛИ всплеск объема — сигнал разрешён"
            );
            // Триггер сработал — проверяем OI и даём сигнал через стандартные проверки ниже
          }

          // ── 4h_momentum: условие вместо таймера ─────────────────────────────────
          // Тренд — это не ОИ-импульс. Нет смысла ждать 2 часа.
          // Условие для сигнала: цена не откатилась от точки детекции (держится выше -3%)
          // И прошёл хотя бы 1 скан (30 мин — чтобы не стрелять в ту же секунду).
          // Если цена ушла ниже -3% — тренд сломан, отменяем запись.
          if (entryTf === "4h_momentum") {
            if (priceFromDetection < -3.0) {
              await db.update(oiWatchTable)
                .set({ status: "expired", firedAt: new Date() })
                .where(eq(oiWatchTable.id, entry.id));
              logger.info(
                { symbol, drift: priceFromDetection.toFixed(1) + "%" },
                "❌ 4H MOMENTUM: цена откатила от точки входа — тренд сломан"
              );
              continue;
            }
            if (ageMs < 30 * 60 * 1000) {
              logger.debug(
                { symbol, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%" },
                "⏳ 4H MOMENTUM: ждём минимум 1 скан (30 мин)"
              );
              continue;
            }
            // Цена держится + прошёл 1 скан → сигнал
            logger.info(
              { symbol, drift: priceFromDetection.toFixed(1) + "%", ageMin: (ageMs / 60000).toFixed(1) },
              "✅ 4H MOMENTUM: цена держится — сигнал разрешён"
            );
            // Проваливаемся к финальным проверкам (runaway/stale cancel и выдача)
          }

          if (!isSlowPattern && entryTf !== "4h_momentum" && ageMs < CONFIRM_WINDOW_MS) {
            // Ещё в окне наблюдения. Ранняя отмена если OI уже иссяк или цена рухнула.
            const earlyOIDrain = cgOI?.available && cgOIChange < OI_DRAIN_PCT;
            const earlyRetrace = priceFromDetection < MAX_RETRACE_PCT;
            if (earlyOIDrain || earlyRetrace) {
              await db.update(oiWatchTable)
                .set({ status: "expired", firedAt: new Date() })
                .where(eq(oiWatchTable.id, entry.id));
              logger.info(
                { symbol, tf: entryTf, ageMin: (ageMs / 60000).toFixed(1), oi: cgOIChange.toFixed(1) + "%", drift: priceFromDetection.toFixed(1) + "%" },
                earlyOIDrain
                  ? "❌ CONFIRM EARLY CANCEL: OI иссяк до окончания ожидания"
                  : "❌ CONFIRM EARLY CANCEL: цена откатилась > 5% — ложный сигнал"
              );
              continue;
            }
            logger.debug(
              { symbol, tf: entryTf, waitMin, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%", freshOI: cgOIChange.toFixed(1) + "%" },
              `⏳ CONFIRMING: ждём ${waitMin} мин. OI держится.`
            );
            continue;
          }

          // Окно закрылось — финальные проверки

          if (cgOI?.available && cgOIChange < OI_DRAIN_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, freshOI: cgOIChange.toFixed(1) + "%" },
              `❌ CONFIRM FAILED: ${waitMin} мин прошло, но OI упал — накопление закончилось`
            );
            continue;
          }

          if (priceFromDetection < MAX_RETRACE_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%" },
              `❌ CONFIRM FAILED: цена откатилась > 5% за ${waitMin} мин — ложный сигнал`
            );
            continue;
          }

          if (priceFromDetection > MAX_RUNAWAY_PCT) {
            await db.update(oiWatchTable)
              .set({ status: "expired", firedAt: new Date() })
              .where(eq(oiWatchTable.id, entry.id));
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%" },
              `❌ CONFIRM SKIP: цена ушла > ${MAX_RUNAWAY_PCT}% вверх — вход слишком поздний`
            );
            continue;
          }

          // Ждём реального начала роста — не входим если цена ещё в минусе или флэте.
          // ZBT-кейс: цена -2.5% → в допуске [-5%..+10%] → сигнал стрелял → вход на дне.
          // ZETA/ATOM/CRV-кейс: цена +0.5% → signal fire → сразу разворот → peak=0% → stale cancel.
          // Теперь: ждём минимум +2% реального движения от точки детектирования.
          const MIN_POSITIVE_DRIFT = 2.0;
          if (priceFromDetection < MIN_POSITIVE_DRIFT) {
            logger.info(
              { symbol, tf: entryTf, drift: priceFromDetection.toFixed(1) + "%", ageMin: (ageMs / 60000).toFixed(0) },
              "⏳ CONFIRM WAIT: цена ещё не в росте — ждём старта движения"
            );
            continue; // не отменяем, просто ждём — expire случится через 6ч если роста не будет
          }

          // ✅ OI держится, цена пошла вверх — сигнал подтверждён
          await db.update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(eq(oiWatchTable.id, entry.id));
          logger.info(
            { symbol, tf: entryTf, waitMin, ageMin: (ageMs / 60000).toFixed(1), drift: priceFromDetection.toFixed(1) + "%", freshOI: cgOIChange.toFixed(1) + "%" },
            `✅ CONFIRMED: OI держится ${waitMin} мин, цена стабильна — сигнал разрешён`
          );
        } else {
          // Первый раз видим — сохраняем реальный ТФ, чтобы знать сколько ждать
          try {
            await db.insert(oiWatchTable).values({
              symbol,
              triggerTf: oiTriggerTf,   // реальный ТФ вместо "confirm"
              oiChange: cgOIChange,
              priceAtEntry: await getFreshPrice(symbol, close),
              volumeMultiplier: volMult,
              sentimentKey: det.sentiment.key,
              status: "confirming",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + CONFIRM_EXPIRE_MS),
              avgVolume: avgVol,
            });
            const waitMin =
              (oiTriggerTf.includes("24h") || oiTriggerTf.includes("4h")) ? 15
              : oiTriggerTf.includes("1h") ? 30 : 60;
            logger.info(
              { symbol, tf: oiTriggerTf, waitMin, price: priceChange.toFixed(1) + "%", oi: cgOIChange.toFixed(1) + "%", pattern: det.sentiment.key },
              `🕐 QUEUED: первое обнаружение — ждём ${waitMin} мин подтверждения OI`
            );
          } catch (err) {
            logger.warn({ err, symbol }, "confirming OI Watch insert failed");
          }
          continue;
        }
      }

      logger.info(
        {
          symbol,
          globalOI: cgOIChange.toFixed(1) + "%",
          bingxOI: cgOI?.bingxOiChange30m != null ? cgOI.bingxOiChange30m.toFixed(1) + "%" : "n/a",
          vol: volMult.toFixed(1) + "x",
          price: priceChange.toFixed(1) + "%",
          pattern: det.sentiment.key,
        },
        "CoinGlass OI + Volume PASSED → candidate"
      );

      // When cgOI is undefined (bingx_volume path), use a minimal fallback
      const safeOI: CoinglassOIResult = cgOI ?? {
        available: false, source: "coinglass", oiUsd: 0,
        oiChange5m: null, oiChange30m: 0,
        oiChange1h: null, oiChange4h: null, oiChange24h: null,
        bingxOiChange30m: null, cgVolUsd: null,
      };

      candidates.push({
        symbol,
        price: close,
        priceChange30m: priceChange,
        price4hChange,
        currentVolume: currentVol,
        avgVolume: avgVol,
        volumeMultiplier: volMult,
        oiChangePercent: cgOIChange,
        oiChange5m: oi5m,
        oiChange1h: oi1h,
        oiChange4h: oi4h,
        oiChange24h: oi24h,
        openInterest: safeOI.oiUsd ?? 0,
        sentiment: det.sentiment,
        coinglassOI: safeOI,
        oiTriggerTf,
        isRepeatSignal,
      });
    } catch (err) {
      logger.warn({ symbol, err }, "Error scanning symbol");
    }
    await new Promise(r => setTimeout(r, 100));
  }

  // Log top-5 by volume among those that passed CoinGlass OI filter
  const top5 = [...debugTop]
    .sort((a, b) => b.vol - a.vol)
    .slice(0, 5);
  if (top5.length > 0) {
    logger.info(
      {
        top5: top5.map(d => ({
          symbol: d.symbol,
          vol: d.vol.toFixed(1) + "x",
          globalOI: d.cgOI != null ? d.cgOI.toFixed(1) + "%" : "n/a",
          price: d.price.toFixed(2) + "%",
        }))
      },
      "Top-5 (CoinGlass OI passed) by volume this cycle"
    );
  }

  if (candidates.length === 0) {
    state.lastScanAt = new Date();
    state.marketsScanned = usdtTickers.length;
    logger.info(
      {
        marketsScanned: usdtTickers.length,
        oiMovers: oiMoversCount,
        topActive: scanLimit,
        skipped: {
          exhaustedPump: skipCount.exhaustedPump,
          noOiNoVol: skipCount.noOiNoVol,
          lowVolume: skipCount.lowVolume,
          deepNeg: skipCount.deepNegative,
          other: skipCount.other,
        },
      },
      "No candidates this cycle (CoinGlass OI + Volume filters)"
    );
    await persistBaselinesToDb();
    return { signalsFound: 0, marketsScanned: usdtTickers.length, durationMs: Date.now() - startTime };
  }

  // ── FRESH PRICE FETCH ───────────────────────────────────────────────────────
  // CoinGlass batch занял 8+ мин. Klines были взяты в начале скана, поэтому
  // base.price = закрытие свечи из прошлого. Перечитываем текущую цену для
  // каждого кандидата, чтобы трекер и Telegram показывали реальную точку входа.
  const freshPriceMap = new Map<string, number>();
  try {
    const freshTickers = await getFutureTickers();
    for (const t of freshTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) freshPriceMap.set((t as any).symbol, p);
    }
    logger.info({ fetched: freshPriceMap.size }, "Fresh ticker prices fetched for candidate entry pricing");
  } catch (err) {
    logger.warn({ err }, "Failed to fetch fresh ticker prices — using kline close as fallback");
  }

  logger.info({ count: candidates.length }, "Phase 3: grade + score for CoinGlass OI candidates...");

  // Phase 3: grade + score (CoinGlass OI already confirmed in Phase 1)
  const alphaResults: AlphaResult[] = [];
  const signalsToInsert: InsertSignal[] = [];

  for (const base of candidates) {
    const { symbol } = base;

    // CoinGlass OI data already fetched in batch — use directly
    const coinglassOI = base.coinglassOI;
    const coinalyzeOiChange = coinglassOI.oiChange30m; // global aggregate
    const coinalyzeConfirmed = true; // all candidates already passed CoinGlass OI filter

    const [trending, liquidations, fundingData] = await Promise.all([
      getTrendingRank(symbol),
      getLiquidations(symbol),
      getFundingRate(symbol),
    ]);

    const fundingRate = fundingData?.lastFundingRate != null ? parseFloat(fundingData.lastFundingRate) : null;
    const markPrice  = fundingData?.markPrice  != null ? parseFloat(fundingData.markPrice)  : null;
    const indexPrice = fundingData?.indexPrice != null ? parseFloat(fundingData.indexPrice) : null;

    if (fundingRate != null) {
      logger.info(
        { symbol, fundingRate: (fundingRate * 100).toFixed(4) + "%" },
        fundingRate <= -0.0003 ? "💰 Глубоко отрицательный фандинг — шорты в ловушке"
          : fundingRate <= -0.0001 ? "💰 Фандинг отрицательный — шорты платят"
          : fundingRate >= 0.0003  ? "⚠️ Фандинг сильно положительный — лонги перегреты"
          : "⚖️ Фандинг нейтральный"
      );
    }

    // Re-detect sentiment now that we have liquidation data
    const finalSentiment = detectSentiment(
      base.priceChange30m,
      base.oiChangePercent,
      base.volumeMultiplier,
      liquidations.multiple ?? null,
      base.oiTriggerTf,
    );

    // ── STEP 5: Alpha Score (1–10) ──────────────────────────────────────────────
    const alphaScore = calcAlphaScore({
      oiChange: base.oiChangePercent,
      volumeMultiplier: base.volumeMultiplier,
      priceChange: base.priceChange30m,
      sentimentKey: finalSentiment.key,
      cmcAvailable: trending.available,
      cmcRank: trending.rank,
      coinglassAvailable: liquidations.available,
      liquidationsMultiple: liquidations.multiple,
      fundingRate,
    });

    // ── STEP 5: Grading ──────────────────────────────────────────────────────────
    // bingx_volume — только объём + цена, без OI подтверждения → ставим в OI Watch на 15 мин
    // super_alpha  — Score ≥ 8 И OI подтвердили 2+ таймфрейма, OR глобальный OI ≥ 15%
    // alpha        — стандартный сигнал (OI сработал на 1+ ТФ)

    // Считаем количество OI таймфреймов которые сработали для этого кандидата
    const oiTfCount = base.oiTriggerTf === "bingx_volume" ? 0
      : base.oiTriggerTf === "steady"                     ? 2
      : base.oiTriggerTf.startsWith("fast_track")
        ? base.oiTriggerTf.split("+").slice(1).length
        : base.oiTriggerTf.split("+").length;

    // Grade будет обновлён после OB анализа (finalAlphaScore) — здесь предварительное значение
    let grade: "alpha" | "super_alpha" | "bingx_volume" =
      base.oiTriggerTf === "bingx_volume"                                        ? "bingx_volume"
      : (alphaScore >= 8 && oiTfCount >= 2) || Math.abs(base.oiChangePercent) >= 15 ? "super_alpha"
      : "alpha";

    // ── FILTER: Аномалия в пост-памп контексте (4h) ─────────────────────────────
    // Если паттерн — anomaly (fallback, нет чёткого накопления) И цена уже выросла
    // >10% за последние 4ч — это остаточный объём после пампа, не накопление.
    // Breakout-паттерны (sharp_impulse, aggressive_breakout) не блокируются.
    // Исключение: 4h_momentum — весь смысл паттерна в том что price4hChange > 8%.
    if (finalSentiment.key === "anomaly" && base.price4hChange > 10 && base.oiTriggerTf !== "4h_momentum") {
      logger.info(
        { symbol, price4hChange: base.price4hChange.toFixed(1) + "%" },
        "SKIP: аномалия в пост-памп контексте — цена +>10% за 4ч"
      );
      skipCount.other++;
      continue;
    }

    // ── CVD Filter: третье подтверждение — покупатели должны доминировать ────────
    const cvd = await fetchCVD(symbol);
    if (cvd) {
      if (!cvd.positive) {
        logger.info(
          { symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", trades: cvd.trades },
          "🔴 CVD негативный — продажи доминируют, пропускаем сигнал"
        );
        skipCount.other++;
        continue;
      }
      logger.info(
        { symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", trades: cvd.trades },
        "🟢 CVD позитивный — покупатели доминируют"
      );
    } else {
      logger.warn({ symbol }, "CVD: не удалось получить данные — пропускаем проверку");
    }

    // ── STEP 6: Order Book Imbalance (стакан BingX) ──────────────────────────────
    // Запрашиваем только для финальных кандидатов (прошли CVD и все фильтры).
    // Буллиш стакан → бонус до +2 к alpha score.
    const obImbalance = await getOrderBookAnalysis(symbol, 20);
    let finalAlphaScore = alphaScore;

    if (obImbalance) {
      finalAlphaScore = Math.min(10, alphaScore + obImbalance.scoreBonus);

      const biasLabel = obImbalance.bias === "strong_bull" ? "🟢🟢 STRONG BULL" :
                        obImbalance.bias === "bull"         ? "🟢 BULL" :
                        obImbalance.bias === "bear"         ? "🔴 BEAR" : "⚪ NEUTRAL";

      logger.info({
        symbol,
        bidAskRatio:  obImbalance.bidAskRatio.toFixed(2),
        bidVolumeUsd: obImbalance.bidVolumeUsd.toFixed(0),
        askVolumeUsd: obImbalance.askVolumeUsd.toFixed(0),
        bidWalls:     obImbalance.bidWallCount,
        largestWall:  `$${obImbalance.largestBidWallUsd.toFixed(0)} @ ${obImbalance.largestBidWallPrice}`,
        bias:         biasLabel,
        scoreBonus:   obImbalance.scoreBonus > 0 ? `+${obImbalance.scoreBonus}` : "0",
      }, "📚 Order book analysis");
    } else {
      logger.warn({ symbol }, "📚 Order book: данные недоступны");
    }

    // Пересчёт grade с учётом OB бонуса
    if (grade !== "bingx_volume" && obImbalance && obImbalance.scoreBonus > 0) {
      if ((finalAlphaScore >= 8 && oiTfCount >= 2) || Math.abs(base.oiChangePercent) >= 15) {
        grade = "super_alpha";
      }
    }

    // State tracking
    const prevState = signalHistory.get(symbol);
    const isContinuing = !!prevState;
    const cumulativeOiChange = prevState
      ? prevState.cumulativeOiChange + base.oiChangePercent
      : base.oiChangePercent;

    signalHistory.set(symbol, {
      firstSignalAt: prevState?.firstSignalAt ?? new Date(),
      signalCount: (prevState?.signalCount ?? 0) + 1,
      cumulativeOiChange,
    });

    const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${symbol.replace("-", "")}`;
    const bingxUrl = `https://bingx.com/en/trade/${symbol.replace("-", "")}/`;

    // Используем свежую цену (текущий рынок), а не закрытие kline 8 мин назад.
    // Это предотвращает ситуацию когда трекер видит "вход" по старой цене
    // и сразу стреляет milestone 25%/50% потому что рынок уже ушёл.
    const freshPrice = freshPriceMap.get(symbol) ?? base.price;
    const klineSlippage = base.price > 0 ? ((freshPrice - base.price) / base.price) * 100 : 0;
    if (Math.abs(klineSlippage) >= 3) {
      logger.info(
        { symbol, klineClose: base.price, freshPrice, slippage: klineSlippage.toFixed(1) + "%" },
        "⚠️ Entry price slippage since kline fetch — using fresh price"
      );
    }

    alphaResults.push({
      symbol,
      grade,
      price: freshPrice,
      priceChange30m: base.priceChange30m,
      currentVolume: base.currentVolume,
      avgVolume: base.avgVolume,
      volumeMultiplier: base.volumeMultiplier,
      oiChangePercent: base.oiChangePercent,
      openInterest: base.openInterest,
      cmcRank: trending.rank,
      cmcSource: trending.source,
      cmcAvailable: trending.available,
      liquidationsUsd: liquidations.liquidationsUsd,
      liquidationsMultiple: liquidations.multiple,
      coinglassAvailable: liquidations.available,
      coinalyzeOiChange,
      coinalyzeConfirmed,
      isNewListing: false,
      isExhaustedSqueeze: false,
      pumpFromOpen: null,
      candleCount: 48,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      traderAction: finalSentiment.traderAction,
      isContinuing,
      cumulativeOiChange,
      tradingViewUrl,
      bingxUrl,
      oiTriggerTf: base.oiTriggerTf,
      oiChange5m: base.oiChange5m,
      oiChange1h: base.oiChange1h,
      oiChange4h: base.oiChange4h,
      oiChange24h: base.oiChange24h,
      klineSlippage,
      isRepeatSignal: base.isRepeatSignal,
      fundingRate,
      markPrice,
      indexPrice,
      obImbalance,
      alphaScore: finalAlphaScore,
    });

    signalsToInsert.push({
      symbol,
      type: grade,
      value: base.volumeMultiplier,
      threshold: settings.volumeMultiplier,
      price: freshPrice,
      priceChangePercent: base.priceChange30m,
      volume24h: base.currentVolume,
      avgVolume: base.avgVolume,
      openInterest: base.openInterest,
      oiChangePercent: base.oiChangePercent,
      fundingRate: fundingRate ?? null,
      tradingViewUrl,
      cmcRank: trending.rank ?? null,
      cmcSource: trending.source ?? null,
      liquidationsUsd: liquidations.liquidationsUsd ?? null,
      liquidationsMultiple: liquidations.multiple ?? null,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      alphaScore,
      isContinuing,
      cumulativeOiChange,
      detectedAt: new Date(),
    });

    logger.info(
      { symbol, grade, alphaScore, pattern: finalSentiment.key },
      `✅ ${grade.toUpperCase()} score=${alphaScore}`
    );
  }

  // ── Route signals through OI Watch (two-stage confirmation) ─────────────────
  // alpha/super_alpha: isVolConfirmed=true, 30-min window — fire as soon as conditions hold
  // bingx_volume:      isVolConfirmed=false, 15-min window — wait for CoinGlass OI to appear
  //                    If OI confirms within 15 min → upgrade to alpha and fire
  //                    If no OI within 15 min → expire silently (avoid noise)

  for (let i = 0; i < alphaResults.length; i++) {
    const res = alphaResults[i];
    const sig = signalsToInsert[i];
    try {
      const payload = { alphaResult: res, signalRow: sig };
      const isBvGrade = res.grade === "bingx_volume";

      const expiresAt = new Date(Date.now() + (isBvGrade ? 15 : 90) * 60 * 1000);
      const triggerTf = isBvGrade ? "bingx_volume_watch" : res.oiTriggerTf;
      const isVolConfirmed = !isBvGrade;

      const existing = await db.select({ id: oiWatchTable.id, status: oiWatchTable.status })
        .from(oiWatchTable)
        .where(and(eq(oiWatchTable.symbol, res.symbol), eq(oiWatchTable.status, "watching")))
        .limit(1);

      if (existing.length > 0) {
        await db.update(oiWatchTable)
          .set({
            oiChange: res.oiChangePercent,
            volumeMultiplier: res.volumeMultiplier,
            priceAtEntry: res.price,
            expiresAt,
            isVolConfirmed,
            signalPayload: payload as any,
          })
          .where(eq(oiWatchTable.id, existing[0].id));
        logger.info(
          { symbol: res.symbol, grade: res.grade, vol: res.volumeMultiplier.toFixed(1) + "x" },
          isBvGrade ? "👁 BingX Volume Watch: ждём OI подтверждения (15 мин)" : "👁 OI Watch: обновлён свежими данными"
        );
      } else {
        await db.insert(oiWatchTable).values({
          symbol: res.symbol,
          triggerTf,
          oiChange: res.oiChangePercent,
          priceAtEntry: await getFreshPrice(res.symbol, res.price),
          volumeMultiplier: res.volumeMultiplier,
          sentimentKey: res.sentimentKey,
          status: "watching",
          addedAt: new Date(),
          expiresAt,
          avgVolume: res.avgVolume,
          isVolConfirmed,
          signalPayload: payload as any,
        });
        logger.info(
          { symbol: res.symbol, grade: res.grade, alphaScore: res.alphaScore, vol: res.volumeMultiplier.toFixed(1) + "x" },
          isBvGrade
            ? "👁 BingX Volume Watch: добавлен — сработает если OI подтвердит за 15 мин"
            : "👁 OI Watch: сигнал в очереди — сработает через 2 мин если условия сохранятся"
        );
      }
    } catch (err) {
      logger.warn({ err, symbol: res.symbol }, "Ошибка при постановке сигнала в OI Watch");
    }
  }

  const totalSignals = alphaResults.length;
  state.lastScanAt = new Date();
  state.marketsScanned = usdtTickers.length;

  const durationMs = Date.now() - startTime;
  logger.info(
    {
      signalsFound: totalSignals,
      alphaCount: alphaResults.filter(r => r.grade === "alpha").length,
      superAlphaCount: alphaResults.filter(r => r.grade === "super_alpha").length,
      bingxVolumeCount: alphaResults.filter(r => r.grade === "bingx_volume").length,
      marketsScanned: usdtTickers.length,
      durationMs,
    },
    "Scan complete"
  );

  // ── Persistent Momentum: алерт для GOBLIN-типа (тихий грайнд 3+ цикла) ─────
  for (const [sym, entry] of prescanTracker) {
    if (entry.cycleCount < PERSIST_MIN_CYCLES) continue;
    if (entry.lastPrice24h < PERSIST_MIN_PRICE24H) continue;
    if (entry.lastPrice24h - entry.firstPrice24h < PERSIST_MIN_GROWTH) continue;
    if (Date.now() - entry.lastFiredAt < PERSIST_COOLDOWN_MS) continue;

    // Не дублируем если по этому токену уже есть активный сигнал
    const hasActive = await db.select({ id: trackedSignalsTable.id })
      .from(trackedSignalsTable)
      .where(and(
        eq(trackedSignalsTable.symbol, sym),
        inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation"]),
      ))
      .limit(1);
    if (hasActive.length > 0) continue;

    entry.lastFiredAt = Date.now();
    const growthSinceFirst = (entry.lastPrice24h - entry.firstPrice24h).toFixed(1);
    const minutesInTop    = Math.round(entry.cycleCount * 10);
    const base = sym.replace("-USDT", "");

    const msg = [
      `👁 <b>GHOST PUMP: ${sym}</b>`,
      `🏷 <b>Паттерн:</b> Ghost Pump — токен 30+ мин в топ-50 без OI и объёма`,
      ``,
      `📈 <b>Цена 24h:</b> +${entry.lastPrice24h.toFixed(1)}% (растёт, +${growthSinceFirst}% за ${minutesInTop} мин)`,
      `💰 <b>Текущая цена:</b> $${entry.lastPrice}`,
      `📊 <b>В топ-50 скора:</b> ${entry.cycleCount} циклов подряд (~${minutesInTop} мин)`,
      ``,
      `⚠️ <i>Без OI и объёмного подтверждения — токен устойчиво растёт без видимой причины.</i>`,
      `⚠️ <i>Не торговый сигнал. Следите за OI и объёмом для подтверждения.</i>`,
      ``,
      `🔗 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P">TradingView</a>`,
      ``,
      `#${base} #ghostpump`,
    ].join("\n");

    try {
      await broadcast(msg);
      logger.info(
        { sym, cycles: entry.cycleCount, price24h: entry.lastPrice24h.toFixed(1) + "%", growth: growthSinceFirst + "%" },
        "👁 PERSISTENT MOMENTUM: алерт отправлен"
      );
    } catch (err) {
      logger.warn({ err, sym }, "Persistent momentum: ошибка отправки алерта");
    }
  }

  // Persist OI baselines to DB every 5 min so restarts don't lose context
  await persistBaselinesToDb();

  return { signalsFound: totalSignals, marketsScanned: usdtTickers.length, durationMs };
}

/**
 * Вычисляет задержку до следующего выровненного интервала скана.
 * Например, при интервале 30 мин и текущем времени HH:17:xx →
 * следующий скан будет ровно в HH:30:00 (+ 2с), а не HH:17+30=HH:47.
 * Это устраняет drift: каждый скан попадает в начало 30-минутной свечи.
 */
function msUntilNextBoundary(intervalMs: number): number {
  const now = Date.now();
  const msSinceEpoch = now % intervalMs;
  const msToNext = intervalMs - msSinceEpoch;
  // Добавляем 2 секунды, чтобы гарантированно попасть в новую свечу
  return msToNext + 2000;
}

async function scheduledScan() {
  if (!state.running) return;
  try {
    await performScan();
  } catch (err) {
    logger.error({ err }, "Scheduled scan error");
  }
  if (state.running) {
    const settings = await getSettings();
    state.scanIntervalMs = settings.scanIntervalMs;
    const delay = msUntilNextBoundary(settings.scanIntervalMs);
    state.nextScanAt = new Date(Date.now() + delay);
    scanTimer = setTimeout(scheduledScan, delay);
    logger.info({ nextScanIn: `${Math.round(delay / 1000)}s`, nextScanAt: state.nextScanAt }, "Next scan scheduled");
  }
}

export async function startScanner(): Promise<void> {
  if (state.running) return;
  state.running = true;
  logger.info("Alpha Scanner started (5-Pattern, 5m scan, 30m TF)");

  state.bingxConnected = await testBingX();
  state.telegramConnected = await testTelegram();

  // Restore OI baselines from DB so restarts don't cause a blind period
  await loadBaselinesFromDb();

  const settings = await getSettings();
  state.scanIntervalMs = settings.scanIntervalMs;

  await performScan();

  const delay = msUntilNextBoundary(settings.scanIntervalMs);
  state.nextScanAt = new Date(Date.now() + delay);
  scanTimer = setTimeout(scheduledScan, delay);
  logger.info({ nextScanIn: `${Math.round(delay / 1000)}s`, nextScanAt: state.nextScanAt }, "Next scan scheduled");
}

export async function stopScanner(): Promise<void> {
  state.running = false;
  state.nextScanAt = null;
  if (scanTimer) {
    clearTimeout(scanTimer);
    scanTimer = null;
  }
  logger.info("Scanner stopped");
}

export async function getScannerState(): Promise<ScannerState & { totalSignals: number; signalsToday: number }> {
  const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(signalsTable);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [todayResult] = await db
    .select({ count: sql<number>`count(*)` })
    .from(signalsTable)
    .where(gte(signalsTable.detectedAt, today));

  return {
    ...state,
    totalSignals: Number(totalResult.count),
    signalsToday: Number(todayResult.count),
  };
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/telegram.ts
// ═══════════════════════════════════════════════════════

import { logger } from "./logger.js";
import type { Signal } from "@workspace/db";
import { db, subscribersTable, settingsTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";
import { getAllWhaleAccumCandidates, getWhaleDataCoverage } from "./whaleTracker.js";
import { buildPositionsStatusText } from "./positionsReport.js";

const TELEGRAM_API = "https://api.telegram.org";

export async function sendMessage(chatId: number | string, text: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;

  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: false,
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram send failed");
      if (res.status === 403) {
        await db.update(subscribersTable)
          .set({ active: false, unsubscribedAt: new Date() })
          .where(eq(subscribersTable.chatId, Number(chatId)));
      }
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Telegram send error");
    return false;
  }
}

export async function testConnection(): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/getMe`);
    return res.ok;
  } catch {
    return false;
  }
}

export async function getBotInfo(): Promise<{ username?: string; firstName?: string } | null> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/getMe`);
    if (!res.ok) return null;
    const data = await res.json() as { ok: boolean; result: { username?: string; first_name?: string } };
    return { username: data.result.username, firstName: data.result.first_name };
  } catch {
    return null;
  }
}

export async function answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return;
  try {
    await fetch(`${TELEGRAM_API}/bot${token}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ callback_query_id: callbackQueryId, text: text ?? "" }),
    });
  } catch (err) {
    logger.error({ err }, "answerCallbackQuery error");
  }
}

export async function sendMessageWithKeyboard(
  chatId: number | string,
  text: string,
  inlineKeyboard: Array<Array<{ text: string; callback_data: string }>>,
): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }
  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup: { inline_keyboard: inlineKeyboard },
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram sendMessageWithKeyboard failed");
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "sendMessageWithKeyboard error");
    return false;
  }
}

const DIGEST_KEYBOARD = [
  [
    { text: "🟢 Открытые сделки", callback_data: "menu:open_trades" },
  ],
  [
    { text: "📊 Дневной отчёт",  callback_data: "digest:daily"   },
    { text: "📅 Недельный",       callback_data: "digest:weekly"  },
    { text: "📆 Месячный",        callback_data: "digest:monthly" },
  ],
];

export async function setWebhook(webhookUrl: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message"],
        drop_pending_updates: true,
      }),
    });
    const data = await res.json() as { ok: boolean; description?: string };
    if (!data.ok) {
      logger.warn({ description: data.description }, "Failed to set webhook");
      return false;
    }
    logger.info({ webhookUrl }, "Telegram webhook registered");
    return true;
  } catch (err) {
    logger.error({ err }, "Error setting webhook");
    return false;
  }
}

function formatNumber(n: number, decimals = 2): string {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(2)}B`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(2)}K`;
  return n.toFixed(decimals);
}

export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha" | "bingx_volume";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number | null;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  coinalyzeOiChange?: number | null;
  coinalyzeConfirmed?: boolean;
  isExhaustedSqueeze?: boolean;
  isNewListing?: boolean;
  pumpFromOpen?: number | null;
  candleCount?: number;
  sentiment: string;
  sentimentKey: string;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "5m", "30m", "1h" или комбинация */
  oiTriggerTf?: string;
  /** Значение 5m OI изменения */
  oiChange5m?: number | null;
  /** Значение 1h OI изменения */
  oiChange1h?: number | null;
  /** Значение 4h OI изменения */
  oiChange4h?: number | null;
  /** Значение 24h OI изменения */
  oiChange24h?: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже встречался в сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт (decimal, напр. -0.0004 = -0.04% за 8ч) */
  fundingRate?: number | null;
  /** Mark price (перп) */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Насколько цена уже выросла с момента обнаружения до момента выстрела (%) */
  priceConfirmPct?: number | null;
  /** Анализ стакана BingX: имбаланс бидов/асков, bid-стены */
  obImbalance?: {
    bidAskRatio:       number;
    bidVolumeUsd:      number;
    bias:              "strong_bull" | "bull" | "neutral" | "bear";
    bidWallCount:      number;
    largestBidWallUsd: number;
    largestBidWallPrice: number;
    largestBidWallPct: number;
    scoreBonus:        number;
  } | null;
}

/** "BTC-USDT" → "#BTC" */
function tickerTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

export function formatAlphaSignal(s: AlphaResult): string {
  // Метка скорости: сколько ждать движения
  const speedLabel = (() => {
    const key = s.sentimentKey;
    if (key === "volume_flash") {
      return `⚡⚡ <b>ФЛЕШ-ПАМП</b> — объём взорвался, движение прямо сейчас`;
    }
    if (key === "bear_trap" || key === "short_squeeze" || key === "aggressive_breakout" || key === "sharp_impulse") {
      return `🚀 <b>БЫСТРЫЙ ПАМП</b> — движение ожидается в течение 1–4ч`;
    }
    if (key === "hidden_accumulation" || key === "bullish_accumulation") {
      return `⏳ <b>МЕДЛЕННЫЙ ГРАЙНД</b> — накопление, движение может занять 6–24ч`;
    }
    if (key === "anomaly") {
      return `⚠️ <b>АНОМАЛИЯ</b> — нет чёткого паттерна, повышенный риск`;
    }
    return null;
  })();

  const gradeHeader = s.grade === "bingx_volume"
    ? `📈 <b>BINGX VOLUME: ${s.symbol}</b>`
    : s.grade === "super_alpha"
    ? `⚡️⚡️ <b>SUPER ALPHA DETECTED: ${s.symbol}</b>`
    : `⚡️ <b>ALPHA DETECTED: ${s.symbol}</b>`;

  const priceSign = s.priceChange30m >= 0 ? "+" : "";
  const oiSign = s.oiChangePercent >= 0 ? "+" : "";

  // OI отображение: показываем только подтверждённые ТФ (всегда ≥ 2 кроме fast_track/long TF)
  let oiDisplay: string;
  const tf = s.oiTriggerTf ?? "30m";
  const isFastTrackSignal  = tf.startsWith("fast_track");
  const isBingxVolSignal   = tf === "bingx_volume";
  const is4hMomentumSignal = tf === "4h_momentum";
  const triggered = new Set(tf.split("+"));
  const fmtOI = (v: number) => `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`;
  // Показываем ВСЕ доступные ТФ; ✅ — подтверждённые (сработали), просто значение — для контекста
  const fmtTf = (key: string, val: number | null | undefined) =>
    val != null ? (triggered.has(key) ? `✅${key}:${fmtOI(val)}` : `${key}:${fmtOI(val)}`) : null;
  const fmt5m  = fmtTf("5m",  s.oiChange5m);
  const fmt30m = fmtTf("30m", s.coinalyzeOiChange);
  const fmt1h  = fmtTf("1h",  s.oiChange1h);
  const fmt4h  = fmtTf("4h",  s.oiChange4h);
  const fmt24h = fmtTf("24h", s.oiChange24h);
  const allTfParts = [fmt5m, fmt30m, fmt1h, fmt4h, fmt24h].filter(Boolean) as string[];
  const confirmedCount = [triggered.has("5m")  && s.oiChange5m       != null,
                          triggered.has("30m") && s.coinalyzeOiChange != null,
                          triggered.has("1h")  && s.oiChange1h        != null,
                          triggered.has("4h")  && s.oiChange4h        != null,
                          triggered.has("24h") && s.oiChange24h       != null].filter(Boolean).length;
  if (isBingxVolSignal) {
    oiDisplay = `📈 BingX Volume`;
  } else if (is4hMomentumSignal) {
    oiDisplay = `📈 4h Momentum`;
  } else if (isFastTrackSignal && allTfParts.length === 0) {
    oiDisplay = `⚡ BingX Momentum`;
  } else if (allTfParts.length > 0) {
    const prefix = confirmedCount >= 2 ? `ОИ подтверждён: ` : `ОИ: `;
    oiDisplay = prefix + allTfParts.join(" / ");
  } else {
    // Последний резерв: ни один TF не вернул данные — показываем глобальное значение с TF-меткой
    const tfLabel = tf && tf !== "steady" && !tf.startsWith("fast_track") && tf !== "bingx_volume"
      ? ` (${tf})`
      : "";
    oiDisplay = `OI ${oiSign}${s.oiChangePercent.toFixed(1)}%${tfLabel}`;
  }

  const techLine = `🔹 <b>TECH:</b> Vol ${s.volumeMultiplier.toFixed(1)}x | ${oiDisplay} | Price ${priceSign}${s.priceChange30m.toFixed(1)}%`;

  // Context line
  let contextLine: string;
  const parts: string[] = [];

  if (s.cmcAvailable) {
    if (s.cmcRank !== null) {
      parts.push(`#${s.cmcRank} Trending on ${s.cmcSource ?? "CMC"}`);
    } else {
      parts.push(`Not trending on ${s.cmcSource ?? "CMC"}`);
    }
  }

  if (s.coinglassAvailable) {
    if (s.liquidationsUsd !== null && s.liquidationsUsd > 0) {
      const liqStr = `Short Liqs: $${formatNumber(s.liquidationsUsd)}`;
      const multStr = s.liquidationsMultiple !== null ? ` (${s.liquidationsMultiple.toFixed(1)}x avg)` : "";
      parts.push(liqStr + multStr);
    } else {
      parts.push("Liqs: Low");
    }
  }

  // Coinalyze cross-exchange OI confirmation
  if (s.coinalyzeOiChange != null) {
    const sign = s.coinalyzeOiChange >= 0 ? "+" : "";
    const confirmed = s.coinalyzeConfirmed ? "✅" : "⚠️";
    parts.push(`${confirmed} Global OI: ${sign}${s.coinalyzeOiChange.toFixed(1)}% (CoinGlass)`);
  }

  if (parts.length === 0) {
    contextLine = `🔹 <b>CONTEXT:</b> No external data (Filter 1 only)`;
  } else {
    contextLine = `🔹 <b>CONTEXT:</b> ${parts.join(" | ")}`;
  }

  // Funding rate — отдельная строка, отображается всегда когда есть данные
  let fundingLine = "";
  if (s.fundingRate != null) {
    const fr = s.fundingRate;
    const frPct = (fr * 100).toFixed(4);
    const frSign = fr >= 0 ? "+" : "";
    let frLabel: string;
    if (fr <= -0.0003) {
      frLabel = `💰 Фандинг: ${frSign}${frPct}% — шорты в ловушке, сквиз-давление`;
    } else if (fr <= -0.0001) {
      frLabel = `💰 Фандинг: ${frSign}${frPct}% — шорты платят, позитивно`;
    } else if (fr < 0.0001) {
      frLabel = `⚖️ Фандинг: ${frSign}${frPct}% — нейтрально`;
    } else if (fr < 0.0003) {
      frLabel = `📈 Фандинг: ${frSign}${frPct}% — лонги платят`;
    } else {
      frLabel = `⚠️ Фандинг: ${frSign}${frPct}% — лонги перегреты`;
    }
    if (s.indexPrice != null && s.markPrice != null && s.indexPrice > 0) {
      const premium = ((s.markPrice - s.indexPrice) / s.indexPrice) * 100;
      const premSign = premium >= 0 ? "+" : "";
      frLabel += ` | Базис: ${premSign}${premium.toFixed(3)}%`;
    }
    fundingLine = frLabel;
  }

  // Alpha Score bar: filled blocks out of 10
  const filled = Math.round(s.alphaScore);
  const scoreBar = "█".repeat(filled) + "░".repeat(10 - filled);
  const scoreLine = `🎯 <b>Alpha Score: ${s.alphaScore}/10</b>  <code>${scoreBar}</code>`;

  // Emoji per pattern
  const patternEmoji: Record<string, string> = {
    hidden_accumulation: "💎",
    aggressive_breakout: "🔥",
    bullish_accumulation: "📈",
    short_squeeze:        "💥",
    bearish_pressure:     "🐻",
    bear_trap:            "🪤",
    anomaly:              "⚠️",
    sharp_impulse:        "⚡",
    impulse_breakout:     "📊",
    volume_flash:         "⚡⚡",

  };

  // Russian pattern names
  const patternRuName: Record<string, string> = {
    hidden_accumulation:  "💎 Скрытое накопление — умные деньги загружают позицию тихо",
    aggressive_breakout:  "🔥 Агрессивный пробой — истинный пробой уровня на больших деньгах",
    bullish_accumulation: "📈 Бычье накопление — здоровый тренд, новые лонги заходят в позицию",
    short_squeeze:        "💥 Short Squeeze — шортистов принудительно выбивает по ликвидациям",
    bear_trap:            "🪤 Медвежья ловушка — толпа шортит в пол, крупный выкупает",
    bearish_pressure:     "🐻 Медвежье давление — продавцы доминируют",
    anomaly:              "⚠️ Аномалия — нет чёткого паттерна, повышенный риск",
    sharp_impulse:        "⚡ Острый импульс — резкое движение на объёме",
    impulse_breakout:     "📊 Импульсный пробой — пробой на нарастающем OI",
    volume_flash:         "⚡⚡ Флеш-памп — объём взорвался, скальп прямо сейчас",

    "4h_momentum":        "🕯 4h Моментум — медленный грайнд, накопление за 4ч+",
  };

  const pEmoji = patternEmoji[s.sentimentKey] ?? "🔹";
  const patternLine = `🏷 <b>Паттерн:</b> ${patternRuName[s.sentimentKey] ?? s.sentiment}`;
  const sentimentLine = `${pEmoji} <b>SENTIMENT:</b> ${s.sentiment}`;
  const actionLine = `⚡ <b>ДЕЙСТВИЕ:</b> ${s.traderAction}`;

  const continuingLine = s.isContinuing
    ? `📡 <i>Продолжает движение (OI ${s.cumulativeOiChange >= 0 ? "+" : ""}${s.cumulativeOiChange.toFixed(1)}% суммарно)</i>`
    : "";

  // Ценовое подтверждение — показываем насколько цена уже прошла до выстрела
  const confirmLine = (s.priceConfirmPct != null && s.priceConfirmPct >= 1)
    ? `✅ <b>Подтверждён:</b> цена уже +${s.priceConfirmPct.toFixed(1)}% с момента обнаружения`
    : "";

  // Повторный сигнал — символ уже был в сигналах за последние 24ч
  const repeatLine = s.isRepeatSignal
    ? `🔁 <i>Повторный сигнал за 24ч — тезис подтвердился снова, вход ещё актуален</i>`
    : "";

  // Exhaustion warning — SHORT_SQUEEZE с CoinGlass OI < -20%
  const exhaustionLine = s.isExhaustedSqueeze
    ? `⚠️ <b>ВНИМАНИЕ:</b> Global OI ${s.coinalyzeOiChange != null ? s.coinalyzeOiChange.toFixed(0) : ""}% — шорты уже выдавлены, вход может быть поздним`
    : "";

  // Slippage warning — цена успела уйти пока шёл CoinGlass batch
  const slippageLine = s.klineSlippage != null && Math.abs(s.klineSlippage) >= 5
    ? `⚠️ <b>ПОЗДНИЙ ВХОД:</b> цена ушла на ${s.klineSlippage >= 0 ? "+" : ""}${s.klineSlippage.toFixed(1)}% пока шёл анализ`
    : "";

  // ── Двойной вход + стоп лосс ─────────────────────────────────────────────────
  // Вход 1: по рынку (50%) — сразу, чтобы не пропустить движение
  // Вход 2: лимиткой -2% (50%) — усредняем если будет откат
  // Стоп: -10% от рыночного входа
  // Исключение: volume_flash (скальп) — только один вход по рынку
  const STOP_PCT   = 10;  // % стоп от рыночного входа (совпадает с watcher.ts STOP_LOSS)
  const LIMIT_PCT  = 2;   // % ниже рынка для лимитки
  const fmtPrice = (p: number) => p < 1 ? p.toFixed(6) : p < 100 ? p.toFixed(4) : p.toFixed(2);
  const marketEntry = s.price;
  const limitEntry  = s.price * (1 - LIMIT_PCT / 100);
  const stopLevel   = s.price * (1 - STOP_PCT / 100);
  let entryBlock: string;
  if (s.sentimentKey === "volume_flash") {
    // Скальп — только рыночный вход, нет смысла ставить лимитку
    entryBlock = [
      `📍 <b>Вход:</b> $${fmtPrice(marketEntry)} по рынку`,
      `🛑 <b>Стоп:</b> $${fmtPrice(stopLevel)} (−${STOP_PCT}%)`,
    ].join("\n");
  } else {
    entryBlock = [
      `📍 <b>Вход 1:</b> $${fmtPrice(marketEntry)} по рынку — 50%`,
      `📍 <b>Вход 2:</b> $${fmtPrice(limitEntry)} лимиткой −${LIMIT_PCT}% — 50%`,
      `🛑 <b>Стоп:</b> $${fmtPrice(stopLevel)} (−${STOP_PCT}% от рынка)`,
    ].join("\n");
  }

  const priceFormatted = fmtPrice(s.price);
  const cgBase = s.symbol.replace("-USDT", "");
  const cgLink = `https://www.coinglass.com/futures/${cgBase}`;
  const linksLine = `📊 <a href="${s.tradingViewUrl}">Chart</a>  |  📈 <a href="${s.bingxUrl}">BingX</a>  |  🔍 <a href="${cgLink}">OI (CoinGlass)</a>  |  💵 $${priceFormatted}`;
  const tagsLine = s.grade === "bingx_volume"
    ? `${tickerTag(s.symbol)} #bingx_volume`
    : tickerTag(s.symbol);

  // Order Book Imbalance line — показываем если данные есть и стакан интересный
  let obLine = "";
  if (s.obImbalance && s.obImbalance.bias !== "neutral") {
    const ob = s.obImbalance;
    if (ob.bias === "strong_bull") {
      const wallStr = ob.bidWallCount > 0
        ? ` | 🧱 Стена $${(ob.largestBidWallUsd / 1000).toFixed(0)}k`
        : "";
      obLine = `📚 <b>Стакан:</b> 🟢🟢 Сильный бид (${ob.bidAskRatio.toFixed(1)}:1)${wallStr}`;
    } else if (ob.bias === "bull") {
      obLine = `📚 <b>Стакан:</b> 🟢 Биды доминируют (${ob.bidAskRatio.toFixed(1)}:1)`;
    } else if (ob.bias === "bear") {
      obLine = `📚 <b>Стакан:</b> 🔴 Аски давят (${ob.bidAskRatio.toFixed(1)}:1) — осторожно`;
    }
  }

  return [gradeHeader, patternLine, speedLabel, confirmLine, scoreLine, techLine, contextLine, fundingLine, obLine, sentimentLine, actionLine, ``, entryBlock, ``, repeatLine, exhaustionLine, slippageLine, continuingLine, linksLine, ``, tagsLine]
    .filter(l => l !== undefined && l !== null && l !== "")
    .join("\n");
}

async function getTargets(): Promise<(number | string)[]> {
  const seen = new Set<string>();
  const targets: (number | string)[] = [];

  const addTarget = (id: number | string) => {
    const key = String(id);
    if (!seen.has(key)) { seen.add(key); targets.push(id); }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) addTarget(asNum);
    else if (envId.startsWith("@")) addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers
  const activeSubscribers = await db.select({ chatId: subscribersTable.chatId })
    .from(subscribersTable)
    .where(eq(subscribersTable.active, true));
  for (const s of activeSubscribers) addTarget(s.chatId);

  // Add channel from settings (only if non-empty)
  const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
  const ch = rows[0]?.channelId?.trim();
  if (ch) addTarget(ch);

  return targets;
}

export async function broadcastBatchAlert(signals: AlphaResult[]): Promise<void> {
  if (signals.length === 0) return;

  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("No Telegram targets to send to");
    return;
  }

  // BingX Volume signals sent individually (separate type, standalone format)
  const bingxSignals  = signals.filter(s => s.grade === "bingx_volume");
  const oi_signals    = signals.filter(s => s.grade !== "bingx_volume");

  for (const sig of bingxSignals) {
    const text = formatAlphaSignal(sig);
    for (const target of targets) {
      await sendMessage(target, text);
      await new Promise(r => setTimeout(r, 50));
    }
  }

  if (oi_signals.length === 0) return;

  // Sort: SUPER ALPHA first, then ALPHA
  const sorted = [...oi_signals].sort((a, b) => {
    if (a.grade === "super_alpha" && b.grade !== "super_alpha") return -1;
    if (b.grade === "super_alpha" && a.grade !== "super_alpha") return 1;
    return 0;
  });

  const superCount  = sorted.filter(s => s.grade === "super_alpha").length;
  const alphaCount  = sorted.filter(s => s.grade === "alpha").length;

  const headerParts: string[] = [];
  if (superCount > 0) headerParts.push(`${superCount} SUPER ALPHA`);
  if (alphaCount > 0) headerParts.push(`${alphaCount} ALPHA`);
  const text = oi_signals.length === 1
    ? formatAlphaSignal(sorted[0])
    : [
        `🚨 <b>BingX Alpha Scanner — ${headerParts.join(" + ")}</b>`,
        ``,
        sorted.map(formatAlphaSignal).join("\n\n─────────────────────\n\n"),
      ].join("\n");

  logger.info({ count: oi_signals.length, targets: targets.length }, "Broadcasting alpha batch alert");

  for (const chatId of targets) {
    await sendMessage(chatId, text);
    await new Promise(r => setTimeout(r, 50));
  }
}

/** Broadcast a raw pre-formatted text message to all configured Telegram targets */
export async function broadcastRawAlert(text: string): Promise<void> {
  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("broadcastRawAlert: нет получателей");
    return;
  }
  for (const target of targets) {
    try {
      await sendMessage(target, text);
      await new Promise(r => setTimeout(r, 50));
    } catch (err) {
      logger.error({ err, target }, "broadcastRawAlert: не удалось отправить сообщение");
    }
  }
}

// Legacy single-signal broadcast (kept for compatibility)
export async function broadcastSignalAlert(signal: Omit<Signal, "id">): Promise<void> {
  const data: AlphaResult = {
    symbol: signal.symbol,
    grade: (signal.type === "super_alpha" ? "super_alpha" : "alpha") as "alpha" | "super_alpha",
    price: signal.price,
    priceChange30m: signal.priceChangePercent,
    currentVolume: signal.volume24h,
    avgVolume: signal.avgVolume,
    volumeMultiplier: signal.value,
    oiChangePercent: signal.oiChangePercent ?? 0,
    openInterest: signal.openInterest ?? 0,
    cmcRank: null,
    cmcSource: null,
    cmcAvailable: false,
    liquidationsUsd: null,
    liquidationsMultiple: null,
    coinglassAvailable: false,
    sentiment: (signal as any).sentiment ?? "Аномальная активность",
    sentimentKey: (signal as any).sentimentKey ?? "anomaly",
    traderAction: "Наблюдение",
    alphaScore: (signal as any).alphaScore ?? 5,
    isContinuing: false,
    cumulativeOiChange: signal.oiChangePercent ?? 0,
    tradingViewUrl: signal.tradingViewUrl,
    bingxUrl: `https://bingx.com/en/trade/${signal.symbol.replace("-", "")}/`,
  };
  await broadcastBatchAlert([data]);
}

// ── Whale Accumulation Signal ──────────────────────────────────────────────────

export interface WhaleAccumSignalInput {
  symbol:         string;
  daysTracked:    number;
  oiGrowthPct:    number;
  priceChangePct: number;
  consistencyPct: number;
  avgVolRatio:    number;
  confidence:     "high" | "medium";
  reason:         string;
}

export function formatWhaleAccumSignal(s: WhaleAccumSignalInput): string {
  const coin    = s.symbol.replace("-USDT", "");
  const tvUrl   = `https://www.tradingview.com/chart/?symbol=BINGX:${coin}USDT`;
  const bingxUrl = `https://bingx.com/en/trade/${coin}USDT/`;

  const confEmoji  = s.confidence === "high" ? "🔴" : "🟡";
  const confLabel  = s.confidence === "high" ? "ВЫСОКАЯ" : "СРЕДНЯЯ";

  const priceStr = s.priceChangePct >= 0
    ? `+${s.priceChangePct.toFixed(1)}%`
    : `${s.priceChangePct.toFixed(1)}%`;

  const volStr = s.avgVolRatio >= 1.5
    ? `📈 объём +${((s.avgVolRatio - 1) * 100).toFixed(0)}% vs старт`
    : s.avgVolRatio >= 1.2
      ? `📊 объём умеренно растёт (${s.avgVolRatio.toFixed(1)}x)`
      : `📊 объём стабильный`;

  return [
    `🐋 <b>WHALE ACCUMULATION — ${coin}</b>`,
    ``,
    `${confEmoji} Уверенность: <b>${confLabel}</b>`,
    `📅 Период наблюдения: <b>${s.daysTracked} дней</b>`,
    ``,
    `📊 OI вырос: <b>+${s.oiGrowthPct.toFixed(1)}%</b>`,
    `💰 Цена за период: <b>${priceStr}</b>  ← накопление не реализовалось`,
    `🔁 Дней с ростом OI: <b>${s.consistencyPct.toFixed(0)}%</b>`,
    volStr,
    ``,
    `📌 ${s.reason}`,
    ``,
    `⚡️ Это не сигнал входа — это предупреждение о потенциальном насосе.`,
    `Когда начнётся движение — будет стандартный сигнал.`,
    ``,
    `<a href="${tvUrl}">TradingView</a> | <a href="${bingxUrl}">BingX</a>`,
    ``,
    `#${coin} #whale_accumulation #alpha_scanner`,
  ].join("\n");
}

export async function broadcastWhaleAccumAlert(signals: WhaleAccumSignalInput[]): Promise<void> {
  if (signals.length === 0) return;

  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("No Telegram targets for whale accum alert");
    return;
  }

  logger.info({ count: signals.length, targets: targets.length }, "Broadcasting whale accumulation alert");

  if (signals.length === 1) {
    const text = formatWhaleAccumSignal(signals[0]);
    for (const target of targets) {
      await sendMessage(target, text);
      await new Promise(r => setTimeout(r, 50));
    }
    return;
  }

  // Батч: заголовок + список
  const header = `🐋 <b>WHALE WATCH — ${signals.length} токенов накапливаются китами</b>\n`;
  const items   = signals.map((s, i) => {
    const coin  = s.symbol.replace("-USDT", "");
    const conf  = s.confidence === "high" ? "🔴" : "🟡";
    return `${i + 1}. ${conf} <b>${coin}</b> — OI +${s.oiGrowthPct.toFixed(0)}% за ${s.daysTracked}д | цена ${s.priceChangePct >= 0 ? "+" : ""}${s.priceChangePct.toFixed(1)}%`;
  });
  const footer  = `\nПодробный анализ: /whalewatch`;
  const text    = header + items.join("\n") + footer;

  for (const target of targets) {
    await sendMessage(target, text);
    await new Promise(r => setTimeout(r, 50));
  }
}

export async function handleWebhookUpdate(update: unknown): Promise<void> {
  const upd = update as {
    message?: {
      chat: { id: number; username?: string; first_name?: string; last_name?: string };
      text?: string;
    };
  };

  const msg = upd.message;
  if (!msg) return;

  const chatId = msg.chat.id;
  const text = msg.text ?? "";
  const command = text.split("@")[0].toLowerCase();

  if (command === "/start") {
    await db.insert(subscribersTable).values({
      chatId,
      username: msg.chat.username ?? null,
      firstName: msg.chat.first_name ?? null,
      lastName: msg.chat.last_name ?? null,
      active: true,
      subscribedAt: new Date(),
      unsubscribedAt: null,
    }).onConflictDoUpdate({
      target: subscribersTable.chatId,
      set: {
        active: true,
        username: msg.chat.username ?? null,
        firstName: msg.chat.first_name ?? null,
        lastName: msg.chat.last_name ?? null,
        unsubscribedAt: null,
      },
    });

    await sendMessageWithKeyboard(chatId, [
      `✅ <b>Подписка на BingX Alpha Scanner активна!</b>`,
      ``,
      `Ты будешь получать <b>Alpha-сигналы</b> каждые 30 минут когда одновременно выполнены все условия:`,
      ``,
      `📊 <b>Объём</b> — текущий 30м объём &gt; 3× среднего`,
      `📈 <b>OI</b> — открытый интерес вырос &gt; 5% за 30м`,
      `💰 <b>Цена</b> — цена двинулась &gt; 2% за 30м`,
      ``,
      `Этот фильтр отсекает 95% рыночного шума.`,
      ``,
      `📋 <b>Команды:</b>`,
      `/status — текущие открытые позиции`,
      `/whalewatch — whale-накопления (OI анализ)`,
      `/menu — дайджест по периодам`,
      ``,
      `👇 Нажми кнопку чтобы получить дайджест прямо сейчас:`,
    ].join("\n"), DIGEST_KEYBOARD);

    logger.info({ chatId, username: msg.chat.username }, "New subscriber");
  } else if (command === "/menu") {
    await sendMessageWithKeyboard(chatId, [
      `📋 <b>Меню дайджестов</b>`,
      ``,
      `Выбери период — получишь статистику прямо сейчас:`,
    ].join("\n"), DIGEST_KEYBOARD);
  } else if (command === "/stop" || command === "/unsubscribe") {
    await db.update(subscribersTable)
      .set({ active: false, unsubscribedAt: new Date() })
      .where(eq(subscribersTable.chatId, chatId));

    await sendMessage(chatId, `❌ <b>Unsubscribed.</b>\n\nYou will no longer receive signals.\nSend /start to subscribe again.`);
    logger.info({ chatId }, "Subscriber unsubscribed");
  } else if (command === "/status" || command === "/positions") {
    await sendMessage(chatId, `📊 Загружаю позиции...`);
    try {
      const text = await buildPositionsStatusText();
      await sendMessage(chatId, text);
    } catch (err) {
      logger.error({ err }, "positions command error");
      await sendMessage(chatId, `❌ Ошибка при загрузке позиций. Попробуй позже.`);
    }
  } else if (command === "/whalewatch") {
    await sendMessage(chatId, `🐋 Анализирую данные...`);
    try {
      const coverage = await getWhaleDataCoverage();
      const candidates = await getAllWhaleAccumCandidates();

      if (coverage.total === 0 || coverage.ready === 0) {
        await sendMessage(chatId, [
          `🐋 <b>Whale Watch — данных пока недостаточно</b>`,
          ``,
          `Система собирает снимки OI ежедневно.`,
          `Для анализа нужно минимум 14 дней данных.`,
          ``,
          `📊 Токенов с данными: <b>${coverage.total}</b>`,
          `✅ Готовы к анализу (14+ дней): <b>${coverage.ready}</b>`,
          coverage.oldestDate ? `📅 Самые ранние данные: <b>${coverage.oldestDate}</b>` : `📅 Данных пока нет`,
          ``,
          `Первые сигналы появятся через ~14 дней после запуска.`,
          `Каждую субботу в 10:00 МСК отправляется Whale Watch отчёт.`,
        ].join("\n"));
        return;
      }

      if (candidates.length === 0) {
        await sendMessage(chatId, [
          `🐋 <b>Whale Watch — активных накоплений не найдено</b>`,
          ``,
          `📊 Токенов в базе: <b>${coverage.total}</b>`,
          `✅ Проанализировано (14+ дней): <b>${coverage.ready}</b>`,
          ``,
          `Нет токенов с устойчивым ростом OI при плоской цене.`,
          `Обновлённый отчёт — каждую субботу в 10:00 МСК.`,
        ].join("\n"));
        return;
      }

      // Показываем топ-5 кандидатов
      const top5 = candidates.slice(0, 5);
      const lines: string[] = [
        `🐋 <b>Whale Watch — ${candidates.length} токенов в накоплении</b>`,
        ``,
      ];

      for (const c of top5) {
        const coin   = c.symbol.replace("-USDT", "");
        const conf   = c.confidence === "high" ? "🔴 HIGH" : "🟡 MED";
        const pStr   = c.priceChangePct >= 0 ? `+${c.priceChangePct.toFixed(1)}%` : `${c.priceChangePct.toFixed(1)}%`;
        lines.push(`${conf} <b>${coin}</b>`);
        lines.push(`  OI +${c.oiGrowthPct.toFixed(0)}% за ${c.daysTracked}д | цена ${pStr} | постоянство ${c.consistencyPct.toFixed(0)}%`);
        lines.push(``);
      }

      if (candidates.length > 5) {
        lines.push(`...и ещё ${candidates.length - 5} токенов`);
        lines.push(``);
      }

      lines.push(`📊 Всего проанализировано: <b>${coverage.ready}</b> токенов`);
      lines.push(`🕒 Полный отчёт — каждую субботу в 10:00 МСК`);

      await sendMessage(chatId, lines.join("\n"));
    } catch (err) {
      logger.error({ err }, "whalewatch command error");
      await sendMessage(chatId, `❌ Ошибка при анализе. Попробуй позже.`);
    }
  }
}


// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/trending.ts
// ═══════════════════════════════════════════════════════

import { logger } from "./logger.js";

export interface TrendingResult {
  rank: number | null;
  source: "CMC" | "CoinGecko" | null;
  available: boolean;
}

// Normalize symbol for comparison: "BTC-USDT" → "BTC", "BTCUSDT" → "BTC"
function normalizeSymbol(symbol: string): string {
  return symbol.replace(/-USDT$/, "").replace(/USDT$/, "").toUpperCase();
}

// CoinGecko trending — free, no API key needed, returns top 7 trending
let cgCacheTime = 0;
let cgCache: { id: string; symbol: string; rank: number }[] = [];
const CG_CACHE_TTL = 15 * 60 * 1000; // 15 min

async function getCoinGeckoTrending(): Promise<{ id: string; symbol: string; rank: number }[]> {
  if (Date.now() - cgCacheTime < CG_CACHE_TTL && cgCache.length > 0) return cgCache;

  try {
    const res = await fetch("https://api.coingecko.com/api/v3/search/trending", {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return cgCache;

    const data = await res.json() as {
      coins: { item: { id: string; symbol: string; market_cap_rank: number } }[];
    };

    cgCache = data.coins.map((c, i) => ({
      id: c.item.id,
      symbol: c.item.symbol.toUpperCase(),
      rank: i + 1,
    }));
    cgCacheTime = Date.now();
    return cgCache;
  } catch {
    return cgCache;
  }
}

// CMC Trending — requires CMC_API_KEY (free Basic plan)
let cmcCacheTime = 0;
let cmcCache: { symbol: string; rank: number }[] = [];

async function getCMCTrending(): Promise<{ symbol: string; rank: number }[]> {
  const apiKey = process.env.CMC_API_KEY;
  if (!apiKey) return [];

  if (Date.now() - cmcCacheTime < CG_CACHE_TTL && cmcCache.length > 0) return cmcCache;

  try {
    const res = await fetch(
      "https://pro-api.coinmarketcap.com/v1/cryptocurrency/trending/latest?limit=50",
      {
        headers: { "X-CMC_PRO_API_KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(5000),
      }
    );
    if (!res.ok) return cmcCache;

    const data = await res.json() as {
      data: { symbol: string; cmc_rank: number }[];
    };

    cmcCache = data.data.map((c, i) => ({
      symbol: c.symbol.toUpperCase(),
      rank: i + 1,
    }));
    cmcCacheTime = Date.now();
    return cmcCache;
  } catch {
    return cmcCache;
  }
}

export async function getTrendingRank(symbol: string): Promise<TrendingResult> {
  const base = normalizeSymbol(symbol);

  // Try CMC first if key available
  const cmcData = await getCMCTrending();
  if (cmcData.length > 0) {
    const match = cmcData.find(c => c.symbol === base);
    return {
      rank: match?.rank ?? null,
      source: "CMC",
      available: true,
    };
  }

  // Fallback to CoinGecko (free, top 7)
  const cgData = await getCoinGeckoTrending();
  if (cgData.length > 0) {
    const match = cgData.find(c => c.symbol === base);
    return {
      rank: match?.rank ?? null,
      source: "CoinGecko",
      available: true,
    };
  }

  return { rank: null, source: null, available: false };
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/watcher.ts
// ═══════════════════════════════════════════════════════

import { logger } from "./logger.js";
import { db, trackedSignalsTable, settingsTable, subscribersTable, oiWatchTable, signalsTable } from "@workspace/db";
import type { TrackedSignal, InsertTrackedSignal, OiWatch, InsertSignal } from "@workspace/db";
import { eq, and, inArray, sql, lt } from "drizzle-orm";
import { getFutureTickers, getOpenInterest, getKlines, fetchCVD, getFundingRate, getOrderBookAnalysis } from "./bingx.js";

import { sendMessage, broadcastBatchAlert, formatAlphaSignal, broadcastWhaleAccumAlert } from "./telegram.js";
import type { WhaleAccumSignalInput } from "./telegram.js";
import { getCoinglassOI, batchGetCoinglassOI } from "./coinglass_oi.js";
import { saveDailyOiSnapshots, getAllWhaleAccumCandidates } from "./whaleTracker.js";
import { buildPositionsStatusText } from "./positionsReport.js";

// ── Constants ─────────────────────────────────────────────────────────────────
const PARTIAL_TARGET         = 5;    // % частичная фиксация и перенос стопа в БУ
const FIRST_TARGET           = 10;  // % первая цель: фиксируем часть, переставляем стоп в БУ
const TRAILING_ACTIVATION_PCT = 15;  // % от входа: активируем трейлинг
const TRAILING_FIXED_PCT      = 10;  // % отступ трейлинга от пика (фиксированный)
const STOP_LOSS              = 10;   // % стоп лосс от входа (только для active до первой цели)
const ACCUMULATION_H         = 24;   // часов до статуса ACCUMULATION
const ACCUMULATION_REENTRY_H = 12;   // часов в статусе accumulation до проверки re-entry
const ACCUM_REMINDER_H       = 6;    // ч: промежуточное напоминание в статусе accumulation
const ACCUM_SCOUT_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4ч кулдаун между pre-breakout алертами
const ACCUM_OI_COOLDOWN_MS   = 2 * 60 * 60 * 1000;  // 2ч кулдаун между OI-алертами
const MAX_WATCH_DAYS         = 4;    // максимум наблюдения
const RE_ENTRY_VOL_MULT      = 3;    // объём для RE-ENTRY
const FAST_CYCLE_MS          = 2 * 60 * 1000; // 2 мин — быстрый цикл для in_run

// Milestones для Moonshot уведомлений (%)
// +25, +50, +100, затем каждые +50 до бесконечности — генерируем первые 20
const MILESTONES = [25, 50, ...Array.from({ length: 20 }, (_, i) => 100 + i * 50)];

// ── Telegram helpers ──────────────────────────────────────────────────────────
async function getTargets(): Promise<(number | string)[]> {
  const seen = new Set<string>();
  const targets: (number | string)[] = [];

  const addTarget = (id: number | string) => {
    const key = String(id);
    if (!seen.has(key)) { seen.add(key); targets.push(id); }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) addTarget(asNum);
    else if (envId.startsWith("@")) addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers
  const subs = await db.select({ chatId: subscribersTable.chatId })
    .from(subscribersTable)
    .where(eq(subscribersTable.active, true));
  for (const s of subs) addTarget(s.chatId);

  // Add channel from settings (only if non-empty)
  const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
  const ch = rows[0]?.channelId?.trim();
  if (ch) addTarget(ch);

  return targets;
}

export async function broadcast(text: string) {
  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch (err) {
    logger.error({ err }, "broadcast: не удалось получить список получателей");
    return;
  }
  for (const t of targets) {
    try {
      await sendMessage(t, text);
    } catch (err) {
      // Ошибка Telegram (таймаут, rate limit и т.д.) не должна ломать весь цикл.
      // Логируем и продолжаем — остальные получатели получат сообщение.
      logger.error({ err, target: t }, "broadcast: не удалось отправить сообщение");
    }
  }
}

/** Admin broadcast — отправляет произвольный текст всем подписчикам (для уведомлений об обновлениях) */
export async function adminBroadcast(text: string): Promise<void> {
  await broadcast(text);
}

async function sendTo(text: string, targetChatId?: number | string): Promise<void> {
  if (targetChatId !== undefined) {
    await sendMessage(targetChatId, text);
  } else {
    await broadcast(text);
  }
}

// ── Formatters ────────────────────────────────────────────────────────────────
function fmtP(p: number) {
  return p < 1 ? `$${p.toFixed(6)}` : p < 100 ? `$${p.toFixed(4)}` : `$${p.toFixed(2)}`;
}
function fmtPct(n: number) { return `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`; }
function scoreBar(s: number) { const f = Math.round(s); return "█".repeat(f) + "░".repeat(10-f); }

function hoursAndDays(from: Date): { h: number; d: number; str: string } {
  const ms = Date.now() - from.getTime();
  const h = ms / 3_600_000;
  const d = Math.floor(h / 24);
  const rem = Math.round(h % 24);
  return { h, d, str: d > 0 ? `${d}д ${rem}ч` : `${Math.round(h)}ч` };
}

// ── Hashtag helper ────────────────────────────────────────────────────────────
/** "BTC-USDT" → "#BTC" */
function tickerTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

// ── Telegram message formats ──────────────────────────────────────────────────

function msgVolumeCollapse(t: TrackedSignal, currentPrice: number): string {
  const pnl = ((currentPrice - t.entryPrice) / t.entryPrice) * 100;
  return [
    `📉 <b>${t.symbol}: Выход по затуханию импульса</b>`,
    ``,
    `Объем упал ниже 0.2x от среднего — движение выдохлось.`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `💡 Капитал освобожден для новых сделок.`,
    ``,
    `${tickerTag(t.symbol)} #volume_collapse`,
  ].join("\n");
}

function msgFirstTarget(t: TrackedSignal, currentPrice: number): string {
  const pnl = computePnl(t, currentPrice);
  return [
    `🔥 <b>${t.symbol}: Первая цель +${FIRST_TARGET}% достигнута!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `💡 <b>Действия:</b>`,
    `✂️ Зафиксируй часть прибыли (25–50% позиции)`,
    `🛡 Переставь Stop-Loss в безубыток → ${fmtP(t.entryPrice)}`,
    ``,
    `⏳ Следующее уведомление при +${TRAILING_ACTIVATION_PCT}% — активация трейлинга.`,
    `📡 Проверяю каждые 2 минуты.`,
    ``,
    `${tickerTag(t.symbol)} #in_run`,
  ].join("\n");
}

function msgTrailingActivated(t: TrackedSignal, currentPrice: number, trailingStopLevel: number): string {
  const pnl = computePnl(t, currentPrice);
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  return [
    `🚀 <b>${t.symbol}: Трейлинг активирован!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `🛡 Трейлинг Stop-Loss: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    `📐 Отступ: ${TRAILING_FIXED_PCT}% от пика — стоп тянется вверх автоматически`,
    ``,
    `⚡️ Минимальная фиксация гарантирована на уровне +${TRAILING_FIXED_PCT}%.`,
    ``,
    `${tickerTag(t.symbol)} #in_run #trailing`,
  ].join("\n");
}

function msgSmallLossStop(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `📉 <b>МАЛЫЙ УБЫТОК: ${t.symbol}</b>`,
    ``,
    `Цена вернулась к точке входа после достижения первой цели, с небольшим убытком.`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Выход: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `💡 Капитал освобожден для новых сделок.`,
    ``,
    `${tickerTag(t.symbol)} #small_loss`,
  ].join("\n");
}

function msgMilestone(t: TrackedSignal, milestone: number, currentPrice: number, trailingStopLevel: number): string {
  const gain = fmtPct(milestone);
  const emoji = milestone >= 100 ? "🌙" : milestone >= 50 ? "🚀" : "📈";
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  return [
    `${emoji} <b>MOONSHOT! ${t.symbol}: ${gain}</b>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} → Сейчас: ${fmtP(currentPrice)}`,
    `📊 Текущий профит: <b>${gain}</b>`,
    `🛡 Трейлинг Stop-Loss: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    ``,
    `⚡️ Ракета летит — держим до трейлинг-стопа!`,
    ``,
    `${tickerTag(t.symbol)} #moonshot`,
  ].join("\n");
}

function msgTrailingStopHit(t: TrackedSignal, currentPrice: number, peakPnl: number, finalPnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🏁 <b>${t.symbol}: Ралли завершено!</b>`,
    ``,
    `📈 Пиковый рост: <b>${fmtPct(peakPnl)}</b>`,
    `💰 Фиксация по трейлингу: <b>${fmtPct(finalPnl)}</b>`,
    `⏳ Длительность сделки: ${dur.str}`,
    t.alphaScore ? `🎯 Alpha Score был: ${t.alphaScore}/10  <code>${scoreBar(t.alphaScore)}</code>` : "",
    ``,
    `<i>Мы забрали основное движение!</i>`,
    ``,
    `${tickerTag(t.symbol)} #profit`,
  ].filter(Boolean).join("\n");
}

function msgStopLoss(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `❌ <b>STOP LOSS: ${t.symbol}</b>`,
    ``,
    `🛑 Стоп-лосс ${STOP_LOSS}% сработал`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)}`,
    `📊 P&L: <b>${fmtPct(pnl)}</b>`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `${tickerTag(t.symbol)} #stop_loss`,
  ].join("\n");
}

function msgPartialTakeProfit(t: TrackedSignal, currentPrice: number, pnl: number): string {
  return [
    `📌 <b>${t.symbol}: +${PARTIAL_TARGET}% — переноси стоп в БУ!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `💡 <b>Действия прямо сейчас:</b>`,
    `🛡 Переставь Stop-Loss в безубыток → ${fmtP(t.entryPrice)}`,
    `✂️ Можно зафиксировать 20–25% позиции`,
    ``,
    `🎯 Первая цель +${FIRST_TARGET}% | Трейлинг при +${TRAILING_ACTIVATION_PCT}%`,
    ``,
    `${tickerTag(t.symbol)} #partial`,
  ].join("\n");
}

function msgAccumThesisBroken(t: TrackedSignal, currentPrice: number, pnl: number, oiDropPct: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🚫 <b>${t.symbol}: тезис накопления нарушен</b>`,
    ``,
    `📉 OI упал на <b>${oiDropPct.toFixed(1)}%</b> от уровня входа`,
    `<i>Позиции открытые при сигнале — закрыты. Smart money вышел.</i>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} → Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `⚡️ Рекомендуем выйти из позиции.`,
    ``,
    `${tickerTag(t.symbol)} #cancelled`,
  ].join("\n");
}

function msgAccumVolumeBuilding(t: TrackedSignal, currentPrice: number, pnl: number, volMult: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `📡 <b>${t.symbol}: объём оживает в накоплении</b>`,
    ``,
    `📊 Активность: <b>${volMult.toFixed(1)}x</b> нормы — интерес возвращается`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏳ Сигнал ${dur.str} назад`,
    ``,
    `<i>Объём 2x+ — первый признак выхода из боковика. Слежу дальше.</i>`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgAccumOiBuilding(t: TrackedSignal, currentPrice: number, pnl: number, oiChange: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `👀 <b>${t.symbol}: OI растёт при боковике</b>`,
    ``,
    `📈 OI: <b>+${oiChange.toFixed(1)}%</b> за 30м — позиции набираются`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏳ Сигнал ${dur.str} назад`,
    ``,
    `<i>Классический скрытый аккумулятор — крупный игрок не торопится.</i>`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgAccumulationReminder(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  const pnlStr = fmtPct(pnl);
  const pnlEmoji = pnl >= 0 ? "📗" : "📕";
  return [
    `⏳ <b>${t.symbol}: 6ч в накоплении</b>`,
    ``,
    `🕐 Время в позиции: ${dur.str}`,
    `${pnlEmoji} Текущий P&L: <b>${pnlStr}</b>`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)}`,
    ``,
    `<i>Монета продолжает накапливаться. Жду движения до ${MAX_WATCH_DAYS} дней.</i>`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgAccumulation(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const sign = pnl >= 0 ? "+" : "";
  return [
    `⏳ <b>ACCUMULATION: ${t.symbol}</b>`,
    ``,
    `Прошло 24ч — монета ждёт своего момента`,
    `💰 ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${sign}${pnl.toFixed(1)}%)`,
    `👁 Продолжаю наблюдение до ${MAX_WATCH_DAYS} дней`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgReEntry(t: TrackedSignal, currentPrice: number, volMult: number): string {
  const { str } = hoursAndDays(t.detectedAt);
  return [
    `🔥 <b>${t.symbol}: Второе дыхание!</b>`,
    ``,
    `📅 Сигнал был ${str} назад`,
    `📊 Текущая активность: Vol ${volMult.toFixed(1)}x`,
    `⚡️ Статус: Накопление завершено, ожидается импульс`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)}`,
    ``,
    `${tickerTag(t.symbol)} #re_entry`,
  ].join("\n");
}

function msgLateSignal(t: TrackedSignal, currentPrice: number, pnl: number): string {
  return [
    `⚠️ <b>${t.symbol}: Запоздалый сигнал</b>`,
    ``,
    `Монета уже двинулась на <b>${fmtPct(pnl)}</b> к моменту обнаружения — движение началось раньше скана.`,
    ``,
    `📌 Цена входа (при сигнале): ${fmtP(t.entryPrice)}`,
    `📈 Текущая цена: ${fmtP(currentPrice)}`,
    ``,
    `⚡️ Включен Moonshot Management с трейлинг-стопом ${TRAILING_FIXED_PCT}%.`,
    `⚠️ Входить в позицию не рекомендуется — момент пропущен.`,
    ``,
    `${tickerTag(t.symbol)} #late_signal #in_run`,
  ].join("\n");
}

function msgBreakeven(t: TrackedSignal, currentPrice: number, pnl: number): string {
  return [
    `⚖️ <b>BREAKEVEN (7д): ${t.symbol}</b>`,
    ``,
    `Монета наблюдалась 7 дней без чёткого результата`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Закрытие: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `📁 Перенесено в архив`,
    ``,
    `${tickerTag(t.symbol)} #breakeven`,
  ].join("\n");
}

function msgInvalidated(t: TrackedSignal, currentPrice: number, pnl: number, reason: "oi_drop" | "vol_drop", oiDrop?: number, volMult?: number): string {
  const reasonText = reason === "oi_drop"
    ? `📉 OI упал на <b>${oiDrop?.toFixed(1)}%</b> от входа — крупный игрок вышел из позиции`
    : `📭 Объём упал до <b>${volMult?.toFixed(2)}x</b> нормы — катализатор не материализовался`;
  return [
    `🚫 <b>СИГНАЛ ОТМЕНЁН: ${t.symbol}</b>`,
    ``,
    reasonText,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `⚡️ Тезис сделки нарушен — рекомендуем выйти из позиции.`,
    ``,
    `${tickerTag(t.symbol)} #cancelled`,
  ].join("\n");
}

// ── P&L calculation (always long direction) ───────────────────────────────────
function computePnl(t: TrackedSignal, price: number): number {
  return ((price - t.entryPrice) / t.entryPrice) * 100;
}

function computePeakPnl(t: TrackedSignal): number {
  if (!t.peakPrice) return 0;
  return ((t.peakPrice - t.entryPrice) / t.entryPrice) * 100;
}

// ── Next milestone to announce ────────────────────────────────────────────────
function nextMilestone(lastMilestone: number | null, currentPnl: number): number | null {
  const last = lastMilestone ?? 0;
  for (const m of MILESTONES) {
    if (m > last && currentPnl >= m) return m;
  }
  return null;
}

// ── Add signal to tracker ─────────────────────────────────────────────────────
export async function trackSignal(params: {
  symbol: string;
  signalId: number | null;
  signalType: string;
  sentiment?: string | null;
  sentimentKey?: string | null;
  alphaScore?: number | null;
  entryPrice: number;
  entryOi?: number | null;
}): Promise<void> {
  try {
    const existing = await db.select({
      id: trackedSignalsTable.id,
      status: trackedSignalsTable.status,
      entryPrice: trackedSignalsTable.entryPrice,
    })
      .from(trackedSignalsTable)
      .where(and(
        eq(trackedSignalsTable.symbol, params.symbol),
        inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run"])
      ))
      .limit(1);

    if (existing.length > 0) {
      const rec = existing[0];

      // in_run: монета уже летит — игнорируем любые новые сигналы
      if (rec.status === "in_run") {
        logger.info(
          { symbol: params.symbol, status: rec.status },
          "Already in_run — skipping new signal (moonshot active)"
        );
        return;
      }

      // active: позиция уже открыта — НЕ перезаписываем цену входа.
      // Перезапись entry на новую (более дорогую) цену ухудшает позицию.
      // Ждём пока текущая позиция закроется, затем откроем новую.
      if (rec.status === "active") {
        logger.info(
          { symbol: params.symbol, existingEntry: rec.entryPrice, newPrice: params.entryPrice },
          "Already active — skipping new signal (entry price protected)"
        );
        return;
      }

      // accumulation: монета накапливается давно — новый сигнал означает возобновление
      // импульса, сбрасываем вход на актуальную цену.
      const oldEntry = rec.entryPrice;
      await db.update(trackedSignalsTable)
        .set({
          signalId: params.signalId,
          signalType: params.signalType,
          sentiment: params.sentiment ?? null,
          sentimentKey: params.sentimentKey ?? null,
          alphaScore: params.alphaScore ?? null,
          isShort: false,
          entryPrice: params.entryPrice,
          entryOi: params.entryOi ?? null,
          peakPrice: params.entryPrice,
          trailingStopLevel: null,
          lastMilestone: null,
          status: "active",
          reEntryCount: 0,
          detectedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(trackedSignalsTable.id, rec.id));

      logger.info(
        { symbol: params.symbol, oldEntry, newEntry: params.entryPrice },
        "📍 Signal tracker reset (accumulation → active) — fresh entry price"
      );
      return;
    }

    await db.insert(trackedSignalsTable).values({
      symbol: params.symbol,
      signalId: params.signalId,
      signalType: params.signalType,
      sentiment: params.sentiment ?? null,
      sentimentKey: params.sentimentKey ?? null,
      alphaScore: params.alphaScore ?? null,
      isShort: false,
      entryPrice: params.entryPrice,
      entryOi: params.entryOi ?? null,
      peakPrice: params.entryPrice,
      trailingStopLevel: null,
      lastMilestone: null,
      status: "active",
      reEntryCount: 0,
      detectedAt: new Date(),
      updatedAt: new Date(),
    } as InsertTrackedSignal);

    logger.info({ symbol: params.symbol, price: params.entryPrice }, "📍 Signal added to tracker");
  } catch (err) {
    logger.error({ err, symbol: params.symbol }, "Failed to add signal to tracker");
  }
}

// ── Startup reset: normalize stale active signals after server restart ─────────
// Если сервер перезагрузился пока монета двигалась — entry price устарел.
// Вместо молчаливого сброса — отправляем уведомление «Пропущено движение»,
// затем сбрасываем entry до текущей цены чтобы сопровождение продолжалось корректно.
async function sendBotRestartNotification(): Promise<void> {
  const openSignals = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation"]));

  const targets = await getTargets().catch(() => [] as (number | string)[]);
  if (targets.length === 0) return;

  // Получаем актуальные цены
  let tickers: { symbol: string; lastPrice: string }[] = [];
  try { tickers = await getFutureTickers() as any[]; } catch { /* non-critical */ }
  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
  const lines: string[] = [`🔄 <b>Бот перезапущен</b>`, ``];
  if (openSignals.length === 0) {
    lines.push(`Открытых позиций нет.`);
  } else {
    lines.push(`Открытые позиции (${openSignals.length}):`);
    for (const sig of openSignals) {
      const price = priceMap.get(sig.symbol);
      const pnl = (price && sig.entryPrice > 0)
        ? ((price - sig.entryPrice) / sig.entryPrice) * 100
        : null;
      const pnlStr = pnl !== null
        ? ` — <b>${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%</b>`
        : ` — цена недоступна`;
      const warn = pnl !== null && pnl <= -7 ? ` ⚠️ ПРОВЕРЬ ВРУЧНУЮ` : pnl !== null && pnl <= -5 ? ` ⚠️` : ``;
      lines.push(`• ${sig.symbol} [${sig.status}]${pnlStr}${warn}`);
    }
  }
  lines.push(``);
  lines.push(`<i>Мониторинг возобновлён.</i>`);

  const text = lines.join("\n");
  for (const target of targets) {
    await sendMessage(target, text).catch(() => {});
  }
  logger.info({ openCount: openSignals.length }, "🔄 Bot restart notification sent");
}

export async function runStartupReset(): Promise<void> {
  // Проверяем и active (стоп-лосс 10%) и in_run (трейлинг стоп / бу-стоп)
  const openSignals = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run"]));

  if (openSignals.length === 0) return;

  // ── Retry: BingX API нестабилен при холодном старте (таймауты, DNS) ──────
  // 3 попытки с экспоненциальной задержкой. Если все упали — логируем и выходим.
  // НЕ молчим: раньше был просто return, что скрывало пропуск стоп-лоссов.
  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fetchOk = false;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      tickers = await getFutureTickers() as any[];
      fetchOk = true;
      break;
    } catch (err) {
      logger.warn({ err, attempt }, `Startup reset: BingX fetch attempt ${attempt}/3 failed`);
      if (attempt < 3) await new Promise(r => setTimeout(r, 3000 * attempt));
    }
  }
  if (!fetchOk) {
    logger.error("Startup reset: все попытки получить цены провалились — стоп-лоссы не проверены");
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  let targets: (number | string)[] = [];
  try { targets = await getTargets(); } catch { /* non-critical */ }

  let resetCount = 0;
  for (const tracked of openSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const base = tracked.symbol.replace("-USDT", "");
    const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

    // ── active: проверка стоп-лосса (-10%) ─────────────────────────────────
    if (tracked.status === "active" && pnl <= -STOP_LOSS) {
      const msg =
        `🛑 <b>Пропущен стоп-лосс (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Убыток: <b>${pnl.toFixed(1)}%</b>\n\n` +
        `Позиция закрыта по стоп-лоссу.\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} #stop_loss`;

      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      logger.warn(
        { symbol: tracked.symbol, entry: tracked.entryPrice, currentPrice, pnl: pnl.toFixed(1) + "%" },
        "🛑 Startup reset: missed stop-loss (active) — signal closed"
      );
      resetCount++;

    // ── in_run: проверка трейлинг-стопа ────────────────────────────────────
    // После первой цели (+10%) стоп переносится в БУ (entry). Трейлинг (10% от пика)
    // активируется при +15% от входа. Если сервер лежал и цена рухнула — закрываем.
    } else if (tracked.status === "in_run") {
      const peak = tracked.peakPrice ?? currentPrice;
      const peakPnl = computePnl(tracked, peak);
      const trailingActive = peakPnl >= TRAILING_ACTIVATION_PCT;
      const trailingStop = peak * (1 - TRAILING_FIXED_PCT / 100);
      const trailingHit = trailingActive && currentPrice <= trailingStop;
      // Бу-стоп: если трейлинг ещё не активен но цена упала ниже входа — закрываем
      const beStopHit = !trailingActive && currentPrice < tracked.entryPrice;

      if (trailingHit || beStopHit) {
        const finalPnl = ((currentPrice - tracked.entryPrice) / tracked.entryPrice) * 100;
        const msg = trailingHit
          ? `🔴 <b>Пропущен трейлинг-стоп (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `Пик: <b>$${peak.toPrecision(4)}</b> | Трейлинг: <b>$${trailingStop.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #trailing_stop`
          : `🔴 <b>Пропущен бу-стоп (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #be_stop`;

        for (const chatId of targets) {
          try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
        }
        await db.update(trackedSignalsTable).set({
          status: "profit", exitPrice: currentPrice, pnlPercent: finalPnl,
          closedAt: new Date(), updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        logger.warn(
          { symbol: tracked.symbol, entry: tracked.entryPrice, peak, currentPrice, finalPnl: finalPnl.toFixed(1) + "%" },
          trailingHit
            ? "🔴 Startup reset: missed trailing-stop (in_run) — signal closed"
            : "🔴 Startup reset: missed be-stop (in_run) — signal closed"
        );
        resetCount++;
      }

    // ── active: приближается к стоп-лоссу — предупреждаем, но не закрываем ─
    } else if (tracked.status === "active" && pnl <= -5 && pnl > -STOP_LOSS) {
      const msg =
        `⚠️ <b>Близко к стоп-лоссу (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `P&L: <b>${pnl.toFixed(1)}%</b> (стоп: −${STOP_LOSS}%)\n\n` +
        `Бот перезапускался — проверьте позицию вручную!\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} #near_stop`;
      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      logger.warn(
        { symbol: tracked.symbol, pnl: pnl.toFixed(1) + "%" },
        "⚠️ Startup reset: position near stop-loss — warning sent"
      );

    // ── active: выросло пока сервер лежал — сбрасываем entry ───────────────
    } else if (tracked.status === "active" && pnl >= FIRST_TARGET) {
      const sign = pnl >= 0 ? "+" : "";
      const msg =
        `⚠️ <b>Пропущено движение (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Движение: <b>${sign}${pnl.toFixed(1)}%</b>\n\n` +
        `Продолжаем сопровождение от <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)}`;

      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      await db.update(trackedSignalsTable).set({
        entryPrice: currentPrice, peakPrice: currentPrice,
        lastMilestone: null, trailingStopLevel: null,
        detectedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      logger.warn(
        { symbol: tracked.symbol, oldEntry: tracked.entryPrice, currentPrice, pnl: pnl.toFixed(1) + "%" },
        "⚠️ Startup reset: missed move notified — entry reset to current price"
      );
      resetCount++;
    }
  }

  if (resetCount > 0) {
    logger.info({ resetCount }, "Startup reset complete: missed moves notified, entries normalized");
  } else {
    logger.info("Startup reset: all active signals are fresh (no reset needed)");
  }
}

// ── In-memory cooldown для accumulation scouts (сбрасывается при рестарте) ───
// Структура: Map<signalId, { volBuild: timestampMs, oiBuild: timestampMs }>
const accumScoutCooldowns = new Map<number, { volBuild: number; oiBuild: number; oiDrain: number }>();

// ── Main watcher cycle (every 10 min): handles ONLY accumulation signals ──────
// active + in_run обрабатываются исключительно FastCycle (каждые 2 мин),
// чтобы исключить race condition при одновременном запуске обоих циклов.
export async function runWatcherCycle(): Promise<{ checked: number; updated: number }> {
  const accumSignals = await db.select()
    .from(trackedSignalsTable)
    .where(eq(trackedSignalsTable.status, "accumulation"));

  if (accumSignals.length === 0) return { checked: 0, updated: 0 };

  logger.info({ count: accumSignals.length }, "Watcher: checking accumulation signals");

  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch (err) {
    logger.error({ err }, "Watcher: failed to fetch tickers");
    return { checked: 0, updated: 0 };
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  let updated = 0;

  for (const tracked of accumSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const { h: ageHours } = hoursAndDays(tracked.detectedAt);
    const ageDays = ageHours / 24;

    const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
    const peakChanged = newPeak !== tracked.peakPrice;

    // ── 7 days → Breakeven ────────────────────────────────────────────────────
    if (ageDays >= MAX_WATCH_DAYS) {
      await db.update(trackedSignalsTable).set({
        status: "breakeven", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgBreakeven(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "Watcher: BREAKEVEN (7d)");
      updated++;
      continue;
    }

    // ── Stop loss ─────────────────────────────────────────────────────────────
    if (pnl <= -STOP_LOSS) {
      await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgStopLoss(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "Watcher: STOP LOSS (accum) ❌");
      updated++;
      continue;
    }

    // ── 6ч напоминание в накоплении (один раз) ───────────────────────────────
    // lastMilestone = -1 используется как сентинель "напоминание отправлено"
    // Это безопасно: в accumulation статусе milestones (25/50/100%) не используются
    const reminderSent = tracked.lastMilestone === -1;
    if (!reminderSent && ageHours >= ACCUM_REMINDER_H) {
      await broadcast(msgAccumulationReminder(tracked, currentPrice, pnl));
      await db.update(trackedSignalsTable)
        .set({ lastMilestone: -1 })
        .where(eq(trackedSignalsTable.id, tracked.id));
      logger.info({ symbol: tracked.symbol, ageHours: ageHours.toFixed(1) }, "Watcher: ACCUMULATION REMINDER 6h ⏳");
    }

    // ── OI Drain check: тезис всё ещё в силе? ────────────────────────────────
    // После перехода в accumulation проверяем раз в 4ч: не слился ли OI.
    // OI был причиной сигнала — если он вернулся к норме, а цена нет → выходим.
    // short_squeeze не проверяем: там OI ДОЛЖЕН падать по тезису.
    const scoutNow = Date.now();
    const cooldowns = accumScoutCooldowns.get(tracked.id) ?? { volBuild: 0, oiBuild: 0, oiDrain: 0 };
    const oiDrainCooldownOk = scoutNow - (cooldowns.oiDrain ?? 0) > 4 * 3_600_000;
    const oiFallingPatternAccum = tracked.sentimentKey === "short_squeeze";
    if (oiDrainCooldownOk && !oiFallingPatternAccum && tracked.entryOi && tracked.entryOi > 0) {
      try {
        const oiData = await getOpenInterest(tracked.symbol);
        if (oiData) {
          const currentOi = parseFloat(oiData.openInterest) || 0;
          const oiDropFromEntry = ((tracked.entryOi - currentOi) / tracked.entryOi) * 100;
          // OI слился >20% от входа, а цена не выросла — тезис нарушен
          if (oiDropFromEntry >= 20 && pnl < 3) {
            await db.update(trackedSignalsTable).set({
              status: "cancelled", exitPrice: currentPrice, pnlPercent: pnl,
              closedAt: new Date(), updatedAt: new Date(),
            }).where(eq(trackedSignalsTable.id, tracked.id));
            await broadcast(msgAccumThesisBroken(tracked, currentPrice, pnl, oiDropFromEntry));
            logger.info({ symbol: tracked.symbol, oiDropFromEntry: oiDropFromEntry.toFixed(1), pnl }, "Watcher: ACCUM THESIS BROKEN — OI drained 🚫");
            updated++;
            continue;
          }
          // Записываем время последней проверки OI drain (даже если не сработало)
          accumScoutCooldowns.set(tracked.id, { ...cooldowns, oiDrain: scoutNow });
        }
      } catch { /* non-critical */ }
    }

    // ── Accumulation scout: pre-fetch klines (используется и здесь, и в re-entry) ──
    let scoutVolMult = 0;
    try {
      const klines = await getKlines(tracked.symbol, "30m", 21);
      if (klines.length >= 5) {
        const current = klines[klines.length - 1];
        const historical = klines.slice(0, -1);
        const close = parseFloat(current.close) || 0;
        const currentVol = (parseFloat(current.volume) || 0) * close;
        const avgVol = historical.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / historical.length;
        scoutVolMult = avgVol > 0 ? currentVol / avgVol : 0;

        // 📡 Объём оживает (2x-3x): ранний сигнал до re-entry порога
        const volBuildCooldownOk = scoutNow - cooldowns.volBuild > ACCUM_SCOUT_COOLDOWN_MS;
        if (scoutVolMult >= 2.0 && scoutVolMult < RE_ENTRY_VOL_MULT && volBuildCooldownOk) {
          await broadcast(msgAccumVolumeBuilding(tracked, currentPrice, pnl, scoutVolMult));
          accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns), volBuild: scoutNow });
          logger.info({ symbol: tracked.symbol, volMult: scoutVolMult.toFixed(2) }, "Watcher: ACCUM VOL BUILDING 📡");
        }
      }
    } catch { /* non-critical */ }

    // 👀 OI растёт при боковике: CoinGlass check с 2ч кулдауном
    const oiBuildCooldownOk = scoutNow - cooldowns.oiBuild > ACCUM_OI_COOLDOWN_MS;
    if (oiBuildCooldownOk && Math.abs(pnl) <= 6) {
      try {
        const cgOI = await getCoinglassOI(tracked.symbol);
        const oiChange = cgOI.oiChange30m ?? cgOI.oiChange5m ?? null;
        if (cgOI.available && oiChange !== null && oiChange >= 5) {
          await broadcast(msgAccumOiBuilding(tracked, currentPrice, pnl, oiChange));
          accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns), oiBuild: scoutNow });
          logger.info({ symbol: tracked.symbol, oiChange }, "Watcher: ACCUM OI BUILDING 👀");
        }
        // Записываем время последней проверки независимо от результата
        accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? { volBuild: 0, oiBuild: 0 }), oiBuild: scoutNow });
      } catch { /* non-critical */ }
    }

    // ── Re-entry check (≥12h in accumulation, 3x объём) ──────────────────────
    const hoursInAccumulation = (Date.now() - tracked.updatedAt.getTime()) / 3_600_000;
    if (hoursInAccumulation >= ACCUMULATION_REENTRY_H && scoutVolMult >= RE_ENTRY_VOL_MULT) {
      await broadcast(msgReEntry(tracked, currentPrice, scoutVolMult));
      await db.update(trackedSignalsTable).set({
        status: "accumulation",
        reEntryCount: (tracked.reEntryCount ?? 0) + 1,
        peakPrice: newPeak, updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      logger.info({ symbol: tracked.symbol, volMult: scoutVolMult }, "Watcher: RE-ENTRY 🔄");
      updated++;
      continue;
    }

    // Update peak silently
    if (peakChanged) {
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }
  }

  return { checked: accumSignals.length, updated };
}

// ── Daily report (21:00 МСК = 18:00 UTC) ─────────────────────────────────────
export async function sendDailyReport(targetChatId?: number | string): Promise<void> {
  // Берём последние 24 часа чтобы не пропускать сигналы при catch-up после перезапуска
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const allOpen = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run"]));

  const closedToday = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.closedAt} >= ${since}`);

  const profitsToday    = closedToday.filter(s => s.status === "profit");
  const stopsToday      = closedToday.filter(s => s.status === "stop_loss");
  const cancelledToday  = closedToday.filter(s => s.status === "cancelled");
  const inRunNow        = allOpen.filter(s => s.status === "in_run");

  // Fetch live prices for open positions
  const priceMap = new Map<string, number>();
  if (allOpen.length > 0) {
    try {
      const tickers = await getFutureTickers() as any[];
      for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
    } catch { /* non-critical — show without live price */ }
  }

  const lines: string[] = [
    `📊 <b>DAILY REPORT — Alpha Watcher</b>`,
    `<i>${new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "long", year: "numeric" })}</i>`,
    ``,
  ];

  const symTag  = (symbol: string) => `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
  const symBase = (symbol: string) => symbol.replace("-USDT", "");
  const priceRow = (s: TrackedSignal, curPrice: number | undefined) => {
    if (!s.entryPrice) return "";
    if (!curPrice) return ` | Вход: ${fmtP(s.entryPrice)}`;
    const pnl = ((curPrice - s.entryPrice) / s.entryPrice) * 100;
    const sign = pnl >= 0 ? "+" : "";
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(curPrice)} (${sign}${pnl.toFixed(1)}%)`;
  };
  const priceRowClosed = (s: TrackedSignal) => {
    if (!s.entryPrice) return "";
    const exit = s.exitPrice ?? s.peakPrice;
    if (!exit) return ` | Вход: ${fmtP(s.entryPrice)}`;
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(exit)} (${fmtPct(s.pnlPercent ?? 0)})`;
  };

  if (inRunNow.length > 0) {
    lines.push(`🚀 <b>В полёте (Moonshot) — ${inRunNow.length}:</b>`);
    for (const s of inRunNow) {
      const peakPnl = computePeakPnl(s);
      const curPrice = priceMap.get(s.symbol);
      const trStop = s.trailingStopLevel ? fmtP(s.trailingStopLevel) : "—";
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRow(s, curPrice)} | Пик: +${peakPnl.toFixed(1)}% | Trailing: ${trStop}`);
    }
    lines.push(``);
  }

  if (allOpen.length > 0) {
    const watching = allOpen.filter(s => s.status === "active" || s.status === "accumulation");
    if (watching.length > 0) {
      lines.push(`👁 <b>В наблюдении (${watching.length}):</b>`);
      for (const s of watching) {
        const curPrice = priceMap.get(s.symbol);
        lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRow(s, curPrice)}`);
      }
      lines.push(``);
    }
  }

  if (profitsToday.length > 0) {
    lines.push(`✅ <b>Закрыто в профит (${profitsToday.length}):</b>`);
    for (const s of profitsToday) {
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (stopsToday.length > 0) {
    lines.push(`❌ <b>Стоп-лосс (${stopsToday.length}):</b>`);
    for (const s of stopsToday) {
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (cancelledToday.length > 0) {
    lines.push(`🚫 <b>Отменено сегодня (${cancelledToday.length}):</b>`);
    for (const s of cancelledToday) {
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (allOpen.length === 0 && closedToday.length === 0) {
    lines.push(`Сегодня активных сигналов нет.`);
  }

  lines.push(``, `#ежедневный_отчет`);

  await sendTo(lines.join("\n"), targetChatId);

  if (!targetChatId) {
    // Сохраняем время отправки только при запуске по расписанию
    await db.update(settingsTable)
      .set({ lastDailyReportAt: new Date() })
      .where(sql`id = (SELECT id FROM settings LIMIT 1)`);
  }

  logger.info("Daily report sent");
}

// ── Weekly digest (09:00 МСК = 06:00 UTC, воскресенье) ───────────────────────
export async function sendWeeklyDigest(targetChatId?: number | string): Promise<void> {
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const all = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneWeekAgo}`);

  const profits    = all.filter(s => s.status === "profit");
  const stops      = all.filter(s => s.status === "stop_loss");
  const cancelled  = all.filter(s => s.status === "cancelled");
  const accum      = all.filter(s => s.status === "accumulation" || s.status === "re_entry");
  const inRun      = all.filter(s => s.status === "in_run");
  const breakevens = all.filter(s => s.status === "breakeven");

  if (all.length === 0) {
    await sendTo("📊 <b>Еженедельный дайджест</b>\n\nНа этой неделе сигналов не было.", targetChatId);
    return;
  }

  const sorted = [...profits].sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0));
  const medals = ["🥇", "🥈", "🥉"];
  const topProfits = sorted.slice(0, 3);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    return `${medals[i]} $${s.symbol.replace("-USDT", "")}${priceStr} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  // TOP ALPHA OF THE WEEK: all signals with >30% profit
  const moonshots = sorted.filter(s => (s.pnlPercent ?? 0) >= 30);
  const moonshotLines = moonshots.map(s => {
    const peak = computePeakPnl(s);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    return `🚀 ${s.symbol.replace("-USDT", "")}${priceStr} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`;
  });

  const winRate = (profits.length + stops.length) > 0
    ? Math.round((profits.length / (profits.length + stops.length)) * 100)
    : null;
  const avgProfit = profits.length > 0
    ? profits.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) / profits.length
    : null;

  const wFmtRow = (s: TrackedSignal) => {
    const base = `$${s.symbol.replace("-USDT", "")}`;
    const pattern = s.sentimentKey ? ` [${s.sentimentKey}]` : "";
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const exitFmt = exit ? fmtP(exit) : null;
    const pnl   = s.pnlPercent ?? 0;
    const sign  = pnl >= 0 ? "+" : "";
    const priceStr = entry && exitFmt ? ` (${entry} → ${exitFmt})` : entry ? ` (Вход: ${entry})` : "";
    return `  • ${base}${pattern}${priceStr} — ${sign}${pnl.toFixed(1)}%`;
  };

  // Stop-loss details
  const stopLines = [...stops]
    .sort((a, b) => (a.pnlPercent ?? 0) - (b.pnlPercent ?? 0))
    .map(s => wFmtRow(s));

  // Cancelled details
  const cancelLines = [...cancelled]
    .sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0))
    .map(s => wFmtRow(s));

  const lines = [
    `🏆 <b>ИТОГИ НЕДЕЛИ: ЛУЧШАЯ АЛЬФА</b>`,
    ``,
    ...(topLines.length > 0 ? topLines : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshotLines.length > 0) {
    lines.push(``, `🌙 <b>TOP ALPHA OF THE WEEK (>+30%):</b>`);
    lines.push(...moonshotLines);
  }

  if (stopLines.length > 0) {
    lines.push(``, `❌ <b>Стоп-лоссы (${stops.length}):</b>`);
    lines.push(...stopLines);
  }

  if (cancelLines.length > 0) {
    lines.push(``, `🚫 <b>Отменённые сигналы (${cancelled.length}):</b>`);
    lines.push(...cancelLines);
  }

  lines.push(
    ``,
    `📊 <b>Статистика:</b>`,
    `✅ Профит: ${profits.length} сигналов`,
    `🚀 В полёте: ${inRun.length} сигналов`,
    `⏳ В накоплении: ${accum.length} сигналов`,
    `❌ Стоп-лосс: ${stops.length} сигналов`,
    `🚫 Отменено: ${cancelled.length} сигналов`,
    `⚖️ Безубыток (7д): ${breakevens.length} сигналов`,
    ...(avgProfit !== null ? [`📈 Средний профит: ${fmtPct(avgProfit)}`] : []),
    ...(winRate !== null ? [`🎯 Win Rate: ${winRate}%`] : []),
    ``,
    `<i>Мы видим деньги там, где другие видят тишину.</i>`,
    ``,
    `#еженедельный_отчет`,
  );

  await sendTo(lines.join("\n"), targetChatId);

  if (!targetChatId) {
    // Сохраняем время отправки только при запуске по расписанию
    await db.update(settingsTable)
      .set({ lastWeeklyDigestAt: new Date() })
      .where(sql`id = (SELECT id FROM settings LIMIT 1)`);
  }

  logger.info({ total: all.length }, "Weekly digest sent");
}

// ── Monthly digest (30 days stats) ───────────────────────────────────────────
export async function sendMonthlyDigest(targetChatId?: number | string): Promise<void> {
  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const all = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneMonthAgo}`);

  const profits    = all.filter(s => s.status === "profit");
  const stops      = all.filter(s => s.status === "stop_loss");
  const inRun      = all.filter(s => s.status === "in_run");
  const accum      = all.filter(s => s.status === "accumulation" || s.status === "re_entry");
  const breakevens = all.filter(s => s.status === "breakeven");

  if (all.length === 0) {
    await sendTo("📆 <b>Ежемесячный дайджест</b>\n\nЗа последние 30 дней сигналов не было.", targetChatId);
    return;
  }

  const sorted = [...profits].sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0));
  const medals = ["🥇", "🥈", "🥉", "🏅", "🏅"];
  const topProfits = sorted.slice(0, 5);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    return `${medals[i] ?? "🏅"} $${s.symbol.replace("-USDT", "")} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  const moonshots = sorted.filter(s => (s.pnlPercent ?? 0) >= 30);
  const winRate = (profits.length + stops.length) > 0
    ? Math.round((profits.length / (profits.length + stops.length)) * 100)
    : null;
  const avgProfit = profits.length > 0
    ? profits.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) / profits.length
    : null;

  const lines = [
    `📆 <b>ИТОГИ МЕСЯЦА: АЛЬФА-СТАТИСТИКА</b>`,
    `<i>Последние 30 дней</i>`,
    ``,
    ...(topLines.length > 0 ? [`🏆 <b>Топ профитов:</b>`, ...topLines] : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshots.length > 0) {
    lines.push(``, `🚀 <b>Moonshots (>+30%):</b> ${moonshots.length} шт`);
    for (const s of moonshots.slice(0, 5)) {
      const peak = computePeakPnl(s);
      lines.push(`  • ${s.symbol.replace("-USDT", "")} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`);
    }
  }

  lines.push(
    ``,
    `📊 <b>Статистика за 30 дней:</b>`,
    `📡 Всего сигналов: ${all.length}`,
    `✅ Профит: ${profits.length}`,
    `🚀 В полёте: ${inRun.length}`,
    `⏳ В накоплении: ${accum.length}`,
    `❌ Стоп-лосс: ${stops.length}`,
    `⚖️ Безубыток: ${breakevens.length}`,
    ...(avgProfit !== null ? [`📈 Средний профит: ${fmtPct(avgProfit)}`] : []),
    ...(winRate !== null ? [`🎯 Win Rate: ${winRate}%`] : []),
    ``,
    `#ежемесячный_отчет`,
  );

  await sendTo(lines.join("\n"), targetChatId);

  if (!targetChatId) {
    // Сохраняем время отправки только при запуске по расписанию
    await db.update(settingsTable)
      .set({ lastMonthlyDigestAt: new Date() })
      .where(sql`id = (SELECT id FROM settings LIMIT 1)`);
  }

  logger.info({ total: all.length }, "Monthly digest sent");
}

// ── Market Health: OI + Volume snapshot для апдейтов ─────────────────────────
async function fetchMarketHealth(symbol: string): Promise<{ oiPct: number | null; volMult: number | null; fundingRate: number | null }> {
  let oiPct: number | null = null;
  let volMult: number | null = null;
  let fundingRate: number | null = null;
  try {
    const [cgOI, klines, fundingData] = await Promise.all([
      getCoinglassOI(symbol).catch(() => null),
      getKlines(symbol, "30m", 6).catch(() => [] as Awaited<ReturnType<typeof getKlines>>),
      getFundingRate(symbol).catch(() => null),
    ]);
    if (cgOI?.available) {
      oiPct = cgOI.oiChange30m ?? cgOI.oiChange5m ?? null;
    }
    if (klines.length >= 5) {
      const cur = klines[klines.length - 1];
      const hist = klines.slice(0, -1);
      const curVol = (parseFloat(cur.volume) || 0) * (parseFloat(cur.close) || 0);
      const avgVol = hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length;
      volMult = avgVol > 0 ? curVol / avgVol : null;
    }
    if (fundingData?.lastFundingRate != null) {
      fundingRate = parseFloat(fundingData.lastFundingRate);
    }
  } catch { /* non-critical */ }
  return { oiPct, volMult, fundingRate };
}

function buildMarketHealthBlock(oiPct: number | null, volMult: number | null, fundingRate: number | null): string {
  const lines: string[] = ["", "📊 <b>Состояние рынка:</b>"];

  if (oiPct !== null) {
    const sign = oiPct >= 0 ? "+" : "";
    if (oiPct >= 3)       lines.push(`📈 OI: ${sign}${oiPct.toFixed(1)}% — позиции набираются ✅`);
    else if (oiPct >= 0)  lines.push(`➡️ OI: ${sign}${oiPct.toFixed(1)}% — стабильно`);
    else if (oiPct >= -5) lines.push(`📉 OI: ${oiPct.toFixed(1)}% — лёгкая разгрузка ⚠️`);
    else                  lines.push(`🔻 OI: ${oiPct.toFixed(1)}% — позиции закрываются ⚠️`);
  }

  if (volMult !== null) {
    if (volMult >= 3)        lines.push(`🔥 Объём: ${volMult.toFixed(1)}x нормы — горячо`);
    else if (volMult >= 1.5) lines.push(`📊 Объём: ${volMult.toFixed(1)}x нормы — выше среднего`);
    else if (volMult >= 0.8) lines.push(`➡️ Объём: ${volMult.toFixed(1)}x нормы — норма`);
    else                     lines.push(`📭 Объём: ${volMult.toFixed(1)}x нормы — угасает ⚠️`);
  }

  if (fundingRate !== null) {
    const frPct = (fundingRate * 100).toFixed(4);
    const frSign = fundingRate >= 0 ? "+" : "";
    if (fundingRate <= -0.0003)      lines.push(`💰 Фандинг: ${frSign}${frPct}% — шорты в ловушке, сквиз-давление`);
    else if (fundingRate <= -0.0001) lines.push(`💰 Фандинг: ${frSign}${frPct}% — шорты платят, позитивно`);
    else if (fundingRate < 0.0001)   lines.push(`⚖️ Фандинг: ${frSign}${frPct}% — нейтрально`);
    else if (fundingRate < 0.0003)   lines.push(`📈 Фандинг: ${frSign}${frPct}% — лонги платят`);
    else                             lines.push(`⚠️ Фандинг: ${frSign}${frPct}% — лонги перегреты, осторожно`);
  }

  // Итоговая рекомендация по OI + объёму
  if (oiPct !== null && volMult !== null) {
    const oiGood  = oiPct >= 1;
    const volGood = volMult >= 1.5;
    if (oiGood && volGood)   lines.push(`💪 <b>Держи</b> — оба индикатора подтверждают движение`);
    else if (oiGood)         lines.push(`⏳ <b>Держи</b> — OI строится, объём немного просел`);
    else if (volGood)        lines.push(`👀 <b>Следи</b> — объём есть, но OI разгружается`);
    else                     lines.push(`⚠️ <b>Рассмотри выход</b> — импульс угасает`);
  } else if (oiPct !== null) {
    lines.push(oiPct >= 1 ? `💪 <b>Держи</b> — OI подтверждает` : `👀 <b>Следи</b> — OI не растёт`);
  } else if (volMult !== null) {
    lines.push(volMult >= 1.5 ? `💪 <b>Держи</b> — объём подтверждает` : `👀 <b>Следи</b> — объём не растёт`);
  }

  if (lines.length <= 1) return ""; // нет данных — не добавляем блок
  return lines.join("\n");
}

// ── Fast cycle (every 2 min): active + in_run for stop-loss / first-target / trailing ──────────
async function runInRunFastCycle(): Promise<void> {
  // Check active AND in_run signals every 2 min for fast stop-loss and target detection
  const fastSignals = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run"]));

  if (fastSignals.length === 0) return;

  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fastFetchOk = false;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      tickers = await getFutureTickers() as any[];
      fastFetchOk = true;
      break;
    } catch (err) {
      logger.warn({ err, attempt }, `FastCycle: BingX fetch attempt ${attempt}/2 failed`);
      if (attempt < 2) await new Promise(r => setTimeout(r, 3000));
    }
  }
  if (!fastFetchOk) {
    logger.error("FastCycle: не удалось получить цены — стоп-лоссы пропущены в этом цикле");
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  for (const tracked of fastSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) {
      // Нет цены в течение >30 минут после обнаружения — монета недоступна на BingX.
      // Авто-отмена с уведомлением. Случай BingX down обработан выше (fastFetchOk gate).
      const ageMs = Date.now() - tracked.detectedAt.getTime();
      const NO_PRICE_CANCEL_MS = 30 * 60_000;
      if (ageMs > NO_PRICE_CANCEL_MS) {
        const base = tracked.symbol.replace("-USDT", "");
        const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;
        const msg =
          `❌ <b>Позиция отменена — цена недоступна</b>\n\n` +
          `<b>${tracked.symbol}</b>\n` +
          `Цена не найдена на BingX более ${Math.round(ageMs / 60_000)}м.\n` +
          `Монета возможно делистингована или не торгуется на BingX.\n\n` +
          `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #cancelled`;
        const cancelTargets = await getTargets().catch(() => [] as (number | string)[]);
        for (const t of cancelTargets) await sendMessage(t, msg).catch(() => {});
        await db.update(trackedSignalsTable).set({
          status: "cancelled", closedAt: new Date(), updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        logger.warn({ symbol: tracked.symbol, ageMin: Math.round(ageMs / 60_000) }, "⚠️ FastCycle: no BingX price — signal auto-cancelled");
      }
      continue;
    }

    const pnl = computePnl(tracked, currentPrice);
    const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
    const peakChanged = newPeak !== tracked.peakPrice;

    // Трейлинг активируется только при достижении TRAILING_ACTIVATION_PCT (20%) от входа
    const peakPnlNow = computePnl(tracked, newPeak);
    const prevPeakPnl = tracked.peakPrice ? computePnl(tracked, tracked.peakPrice) : 0;
    const trailingActive = peakPnlNow >= TRAILING_ACTIVATION_PCT;
    const trailingStop = newPeak * (1 - TRAILING_FIXED_PCT / 100);
    // Трейлинг сработал: только если активен и цена пробила уровень вниз
    const trailingHit = trailingActive && currentPrice <= trailingStop;
    // Трейлинг только что активировался в этом цикле (пик пересёк 20%)
    const trailingJustActivated = tracked.status === "in_run"
      && prevPeakPnl < TRAILING_ACTIVATION_PCT
      && peakPnlNow >= TRAILING_ACTIVATION_PCT;

    // ── Сохраняем peak НЕМЕДЛЕННО — до любого continue ──────────────────────
    // Без этого continue в stale-check / OI-extended window пропускают строки
    // 1725-1733 и peak никогда не записывается в БД. Монета бьёт +10%, но
    // следующий цикл читает peak=entry из БД → trailing stop не активируется,
    // milestone не шлётся, сигнал отменяется с peak=entry.
    if (peakChanged) {
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }

    const ageMs = Date.now() - tracked.detectedAt.getTime();
    const ageHours = ageMs / 3_600_000;
    const ageDays = ageHours / 24;

    // 7d → Breakeven (FastCycle handles this for active/in_run)
    if (ageDays >= MAX_WATCH_DAYS) {
      await db.update(trackedSignalsTable).set({
        status: "breakeven", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgBreakeven(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BREAKEVEN (7d)");
      continue;
    }

    // ── STALE SIGNAL: авто-отмена при отсутствии движения ───────────────────
    // Время ожидания зависит от паттерна: медленное накопление идёт 6-24ч, быстрые — 3ч.
    // Перед отменой: проверяем свежий OI — если накопление ещё идёт, даём ещё 3ч.
    // Статистика: 0 прибыльных из 98 сигналов где peak < 2% к моменту отмены.
    if (
      tracked.status === "active" &&
      tracked.peakPrice != null &&
      tracked.entryPrice != null &&
      tracked.entryPrice > 0
    ) {
      const peakPct = ((newPeak - tracked.entryPrice) / tracked.entryPrice) * 100;
      if (peakPct < 2.0) {
        // Базовое окно по паттерну:
        // hidden_accumulation / bullish_accumulation — медленная игра, минимум 6ч
        // 4h_momentum / steady — ещё медленнее, 8ч
        // Всё остальное (bear_trap, short_squeeze, anomaly, breakout) — 6ч (было 3ч)
        const sentKey = tracked.sentimentKey ?? "";
        const baseStaleH =
          (sentKey === "hidden_accumulation" || sentKey === "bullish_accumulation") ? 6
          : (sentKey === "4h_momentum" || sentKey === "steady") ? 8
          : 6; // Увеличено с 3ч до 6ч: быстрые паттерны с триггерным входом дольше развиваются

        if (ageHours < baseStaleH) continue; // ещё в базовом окне — ждём

        // Базовое окно истекло. Проверяем свежий OI перед финальной отменой.
        // Три исхода: 'positive' (OI ≥ 3% → ждём), 'negative' (OI < 3% → отменяем), 'error' (таймаут → ждём).
        // ВАЖНО: таймаут CoinGlass ≠ "OI иссяк". Таймауты частые (MEZO, SAPIEN, SYRUP...).
        // При ошибке — продлеваем, отменяем ТОЛЬКО при явном отрицательном ответе.
        if (ageHours < baseStaleH + 3) {
          type OiResult = "positive" | "negative" | "error";
          let oiResult: OiResult = "error"; // по умолчанию — ошибка → ждём
          try {
            const cgOIFresh = await getCoinglassOI(tracked.symbol);
            const freshOI = cgOIFresh.oiChange30m ?? cgOIFresh.oiChange5m ?? null;
            if (cgOIFresh.available && freshOI !== null) {
              oiResult = freshOI >= 3.0 ? "positive" : "negative";
            }
            // available=false или freshOI=null → oiResult остаётся 'error' → ждём
          } catch {
            oiResult = "error"; // таймаут или сетевая ошибка → ждём, не отменяем
          }

          if (oiResult === "positive") {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
              "⏳ STALE EXTENDED: OI ещё строится — продлеваем"
            );
            continue;
          }
          if (oiResult === "error") {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
              "⏳ STALE EXTENDED: CoinGlass недоступен — ждём следующего цикла"
            );
            continue;
          }
          // oiResult === 'negative': OI иссяк — но проверяем рынок перед отменой.
          // Если объём или стакан ещё живые — даём ещё один цикл.
          const healthCheck = await fetchMarketHealth(tracked.symbol);
          const obCheck = await getOrderBookAnalysis(tracked.symbol, 20);
          const isVolumeDead = healthCheck.volMult !== null && healthCheck.volMult < 0.5;
          const isBearishOB = obCheck !== null && obCheck.bias === "bear";
          if (!isVolumeDead && !isBearishOB) {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1), volMult: healthCheck.volMult, obBias: obCheck?.bias ?? "n/a" },
              "⏳ STALE EXTENDED: OI упал, но объём/стакан ещё держат — продлеваем"
            );
            continue;
          }
        }

        // Окно истекло и OI не подтвердил — отменяем
        await db.update(trackedSignalsTable).set({
          status: "cancelled",
          exitPrice: currentPrice,
          pnlPercent: pnl,
          closedAt: new Date(),
          updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast([
          `⏱ <b>${tracked.symbol.replace("-USDT","")}</b> — Сигнал отменён (нет движения)`,
          `За ${baseStaleH}ч пик не превысил +2% и OI не подтвердил продолжение → капитал освобождён`,
          `Вход: <b>${tracked.entryPrice.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
          `#${tracked.symbol.replace("-","_").toLowerCase()} #stale_cancel`,
        ].join("\n"));
        logger.info(
          { symbol: tracked.symbol, ageHours: ageHours.toFixed(1), peakPct: peakPct.toFixed(1), pattern: sentKey },
          `FastCycle: STALE CANCEL (${baseStaleH}h window, peak < 2%)`
        );
        continue;
      }
    }

    // BE стоп: active сигнал уже достиг +5% (стоп перенесён), цена вернулась к входу
    // Срабатывает РАНЬШЕ обычного стоп-лосса — если достигли +5%, не уходим на -7%
    if (tracked.status === "active" && (tracked.lastMilestone ?? 0) >= PARTIAL_TARGET && pnl <= 0) {
      await db.update(trackedSignalsTable).set({
        status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgSmallLossStop(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: SMALL LOSS STOP (active +5% → back to entry) ⚖️");
      continue;
    }

    // Стоп-лосс -10% (STOP_LOSS) применяется только к ACTIVE (до первой цели)
    if (tracked.status === "active" && pnl <= -STOP_LOSS) {
      await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgStopLoss(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: STOP LOSS (active) ❌");
      continue;
    }

    // Стоп в безубыток: in_run, трейлинг ещё не активен, цена вернулась к входу (-2% буфер)
    if (tracked.status === "in_run" && !trailingActive && pnl <= -2) {
      await db.update(trackedSignalsTable).set({
        status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgSmallLossStop(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: SMALL LOSS STOP hit ⚖️");
      continue;
    }

    // ── ПЕРИОДИЧЕСКОЕ СОПРОВОЖДЕНИЕ (каждые 4 часа) ─────────────────────────
    // updatedAt обновляется при каждом milestone/stop, поэтому используем его как
    // "время последнего значимого события". Первый апдейт — через 4ч после входа.
    const lastUpdateMs = Date.now() - tracked.updatedAt.getTime();
    if ((tracked.status === "active" || tracked.status === "in_run") && lastUpdateMs >= 4 * 3_600_000) {
      const health4h = await fetchMarketHealth(tracked.symbol);
      const healthBlock4h = buildMarketHealthBlock(health4h.oiPct, health4h.volMult, health4h.fundingRate);
      const coin = tracked.symbol.replace("-USDT", "");

      const oiGrowing  = health4h.oiPct  !== null && health4h.oiPct  > 1;
      const volHealthy = health4h.volMult !== null && health4h.volMult >= 1.0;
      const oiFalling  = health4h.oiPct  !== null && health4h.oiPct  < -3;
      const volDead    = health4h.volMult !== null && health4h.volMult < 0.8;

      let holdExitLine: string;
      if (oiGrowing && volHealthy) {
        holdExitLine = `💎 <b>#${coin}: HOLD</b> — Накопление продолжается, интерес растёт`;
      } else if (oiFalling && volDead) {
        holdExitLine = `⚠️ <b>#${coin}: EXIT</b> — Интерес пропал, лучше выйти`;
      } else if (oiGrowing) {
        holdExitLine = `💎 <b>#${coin}: HOLD</b> — OI строится, объём чуть просел`;
      } else if (volDead) {
        holdExitLine = `⚠️ <b>#${coin}: СЛЕДИ</b> — Объём угасает, ставь стоп`;
      } else {
        holdExitLine = `⏳ <b>#${coin}: ДЕРЖИ</b> — Ситуация стабильна`;
      }

      await broadcast([
        `🔄 <b>Апдейт: ${coin}</b> | ${ageHours.toFixed(0)}ч в позиции`,
        `Паттерн: ${tracked.sentimentKey ?? "—"} | PnL: ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%`,
        ``,
        holdExitLine,
        healthBlock4h,
        `${tickerTag(tracked.symbol)} #update`,
      ].join("\n"));
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
      logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(1), ageH: ageHours.toFixed(1) }, "FastCycle: 4h periodic update sent");
    }

    // Принудительный переход если active > 48ч и пик < 5% — монета не двигается
    if (tracked.status === "active" && ageHours >= 48) {
      const peakPct = tracked.peakPrice && tracked.entryPrice > 0
        ? ((tracked.peakPrice - tracked.entryPrice) / tracked.entryPrice) * 100
        : 0;
      if (peakPct < 5.0) {
        await db.update(trackedSignalsTable).set({
          status: "accumulation",
          peakPrice: newPeak,
          updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgAccumulation(tracked, currentPrice, pnl));
        logger.info(
          { symbol: tracked.symbol, ageHours: ageHours.toFixed(1), peakPct: peakPct.toFixed(1) },
          "FastCycle: → ACCUMULATION (48h force, peak < 5%) ⏳"
        );
        continue;
      }
    }

    // 24h without first target → transition to Accumulation
    if (tracked.status === "active" && ageHours >= ACCUMULATION_H) {
      await db.update(trackedSignalsTable).set({
        status: "accumulation", peakPrice: newPeak, updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgAccumulation(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl, ageHours: ageHours.toFixed(1) }, "FastCycle: → ACCUMULATION ⏳");
      continue;
    }

    // ── Trade Invalidation: OI drop or volume collapse (active only, ≥10 min old) ──
    // Patterns where OI FALLING is the thesis → skip OI check (it's expected).
    // OI falling is the thesis for these patterns → skip OI drop check
    // short_squeeze: OI падает по тезису (шорты выдавлены) — OI drop не является отменой
    const oiFallingPattern = tracked.sentimentKey === "short_squeeze";
    const minutesSinceEntry = ageMs / 60_000;
    const isGracePeriod = minutesSinceEntry < 60;

    if (tracked.status === "active" && !isGracePeriod) {
      let invalidateReason: "oi_drop" | "vol_drop" | null = null;
      let oiDropPct = 0;
      let volMultiplier = 1;

      try {
        // Volume check: current 30m kline vs avg of previous 4
        const klines = await getKlines(tracked.symbol, "30m", 6);
        if (klines.length >= 5) {
          const cur = klines[klines.length - 1];
          const hist = klines.slice(0, -1);
          const curVol = (parseFloat(cur.volume) || 0) * (parseFloat(cur.close) || 0);
          const avgVol = hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length;
          volMultiplier = avgVol > 0 ? curVol / avgVol : 1;

          // Volume Collapse: объём упал ниже 0.5x через 30+ минут после входа → выход
          const isEarlyCollapseWindow = minutesSinceEntry >= 30 && minutesSinceEntry <= 120;
          if (volMultiplier < 0.5 && isEarlyCollapseWindow) {
            await db.update(trackedSignalsTable).set({
              status: "cancelled",
              exitPrice: currentPrice,
              pnlPercent: pnl,
              closedAt: new Date(),
              updatedAt: new Date(),
            }).where(eq(trackedSignalsTable.id, tracked.id));
            await broadcast(msgVolumeCollapse(tracked, currentPrice));
            logger.info(
              { symbol: tracked.symbol, volMultiplier: volMultiplier.toFixed(2), minutesSinceEntry: minutesSinceEntry.toFixed(0) },
              "FastCycle: VOLUME COLLAPSE — объём угас, сделка закрыта 📭"
            );
            continue;
          }

          if (volMultiplier < 0.2) {
            invalidateReason = "vol_drop";
          }
        }

        // OI drop check: only if entryOi stored and not an OI-falling pattern
        // Порог поднят с 15% до 25% — OI регулярно колышется на 10-20% внутри дня, это шум.
        if (!invalidateReason && !oiFallingPattern && tracked.entryOi && tracked.entryOi > 0) {
          const oiData = await getOpenInterest(tracked.symbol);
          if (oiData) {
            const currentOi = parseFloat(oiData.openInterest) || 0;
            oiDropPct = ((tracked.entryOi - currentOi) / tracked.entryOi) * 100;
            if (oiDropPct >= 25) {
              invalidateReason = "oi_drop";
            }
          }
        }
      } catch { /* non-critical — skip invalidation check this cycle */ }

      // CVD мониторинг: проверяем дельту для контекста и как тай-брейкер
      let cvdNegative = false;
      try {
        const cvd = await fetchCVD(tracked.symbol);
        if (cvd) {
          logger.info(
            { symbol: tracked.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", pnl: pnl.toFixed(2) },
            cvd.positive ? "FastCycle: CVD ✅ покупки доминируют" : "FastCycle: CVD 🔴 продажи доминируют"
          );
          cvdNegative = !cvd.positive;
        }
      } catch { /* non-critical */ }

      // А) PnL-защита: если цена держится (PnL >= -2%) — не отменяем.
      // Исключение: если CVD отрицательный — дельта против нас, отменяем невзирая на цену.
      if (invalidateReason && pnl >= -2) {
        if (cvdNegative) {
          logger.info(
            { symbol: tracked.symbol, pnl: pnl.toFixed(2), reason: invalidateReason },
            "FastCycle: CVD отрицательный — отмена разрешена несмотря на удержание цены"
          );
        } else {
          logger.info(
            { symbol: tracked.symbol, pnl: pnl.toFixed(2), reason: invalidateReason, oiDropPct: oiDropPct.toFixed(1), volMultiplier: volMultiplier.toFixed(2) },
            "FastCycle: отмена заблокирована — цена держится (PnL >= -2%)"
          );
          invalidateReason = null;
        }
      }

      if (invalidateReason) {
        await db.update(trackedSignalsTable).set({
          status: "cancelled",
          exitPrice: currentPrice,
          pnlPercent: pnl,
          closedAt: new Date(),
          updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgInvalidated(tracked, currentPrice, pnl, invalidateReason, oiDropPct, volMultiplier));
        logger.info({ symbol: tracked.symbol, pnl, reason: invalidateReason, oiDropPct: oiDropPct.toFixed(1), volMultiplier: volMultiplier.toFixed(2) }, "FastCycle: CANCELLED 🚫");
        continue;
      }
    }

    // +5%: уведомление о частичной фиксации + переносе стопа в БУ (один раз)
    // Отправляем и продолжаем — в том же цикле может сработать +10%
    if (tracked.status === "active" && pnl >= PARTIAL_TARGET && (tracked.lastMilestone ?? 0) < PARTIAL_TARGET) {
      await db.update(trackedSignalsTable).set({
        lastMilestone: PARTIAL_TARGET, peakPrice: newPeak, updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      const health5 = await fetchMarketHealth(tracked.symbol);
      await broadcast(msgPartialTakeProfit(tracked, currentPrice, pnl) + buildMarketHealthBlock(health5.oiPct, health5.volMult, health5.fundingRate));
      logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(2) }, "FastCycle: PARTIAL TARGET +5% 📌");
    }

    // Active → in_run transition (first target)
    if (tracked.status === "active" && pnl >= FIRST_TARGET) {
      await db.update(trackedSignalsTable).set({
        status: "in_run", peakPrice: newPeak, trailingStopLevel: trailingStop,
        updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));

      // Проверяем запоздалый сигнал: цена уже улетела сразу на >25% в первые 10 мин.
      // С fresh-price fix это редкость — entry = текущий рынок, поэтому +10% за 15 мин
      // это честный сигнал. Только если >25% за 10 мин — значит entryPrice всё ещё устарел.
      const minutesSinceDetection = ageMs / 60000;
      const isLateSignal = minutesSinceDetection < 10 && pnl >= 25;
      if (isLateSignal) {
        await broadcast(msgLateSignal(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl, minutesSinceDetection: minutesSinceDetection.toFixed(1) }, "FastCycle: → IN_RUN (late signal) ⚠️");
      } else {
        const health10 = await fetchMarketHealth(tracked.symbol);
        await broadcast(msgFirstTarget(tracked, currentPrice) + buildMarketHealthBlock(health10.oiPct, health10.volMult, health10.fundingRate));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: → IN_RUN 🚀");
      }
      continue;
    }

    // in_run: trailing stop and milestones
    if (tracked.status === "in_run") {
      // Трейлинг только что активировался (пик пересёк +20%)
      if (trailingJustActivated) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        const health15 = await fetchMarketHealth(tracked.symbol);
        await broadcast(msgTrailingActivated(tracked, currentPrice, trailingStop) + buildMarketHealthBlock(health15.oiPct, health15.volMult, health15.fundingRate));
        logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(2), trailingStop }, "FastCycle: TRAILING ACTIVATED 🚀");
        continue;
      }

      // Трейлинг сработал — фиксируем прибыль
      if (trailingHit && newPeak !== tracked.entryPrice) {
        const peakPnl = computePeakPnl({ ...tracked, peakPrice: newPeak });
        await db.update(trackedSignalsTable).set({
          status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
          peakPrice: newPeak, trailingStopLevel: trailingStop,
          closedAt: new Date(), updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgTrailingStopHit(tracked, currentPrice, peakPnl, pnl));
        logger.info({ symbol: tracked.symbol, pnl, peakPnl }, "FastCycle: TRAILING STOP hit 🏁");
        continue;
      }

      const reachedMilestone = nextMilestone(tracked.lastMilestone, pnl);
      if (reachedMilestone) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop,
          lastMilestone: reachedMilestone, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        const healthMs = await fetchMarketHealth(tracked.symbol);
        await broadcast(msgMilestone(tracked, reachedMilestone, currentPrice, trailingStop) + buildMarketHealthBlock(healthMs.oiPct, healthMs.volMult, healthMs.fundingRate));
        logger.info({ symbol: tracked.symbol, milestone: reachedMilestone }, "FastCycle: MILESTONE 🎯");
        continue;
      }

      if (peakChanged) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
      }
    } else if (peakChanged) {
      // Update peak for active signals silently
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }
  }
}

// ── OI Watch: message when volume finally confirms ────────────────────────────
function msgOiWatchFired(w: OiWatch, currentPrice: number, volMult: number, priceMovePct: number): string {
  const priceSinceWatch = ((currentPrice - w.priceAtEntry) / w.priceAtEntry * 100);
  const waitMin = Math.round((Date.now() - w.addedAt.getTime()) / 60_000);
  const tag = `#${w.symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
  const priceSign = priceMovePct >= 0 ? "+" : "";
  const pswSign = priceSinceWatch >= 0 ? "+" : "";
  const oiSign = w.oiChange >= 0 ? "+" : "";

  // Формат OI: показываем ТФ который сработал
  const oiDisplay = `ОИ: ${w.triggerTf}:${oiSign}${w.oiChange.toFixed(1)}%`;

  return [
    `⚡️ <b>ALPHA DETECTED: ${w.symbol}</b>`,
    ``,
    `🔹 <b>TECH:</b> Vol ${volMult.toFixed(1)}x | ${oiDisplay} | Price ${priceSign}${priceMovePct.toFixed(1)}%`,
    ``,
    `💰 <b>Цена:</b> ${fmtP(currentPrice)} | Вход в watch: ${fmtP(w.priceAtEntry)} (${pswSign}${priceSinceWatch.toFixed(1)}%)`,
    ``,
    `🔭 OI Watch: наблюдал <b>${waitMin} мин</b> — объём подтвердился (${volMult.toFixed(1)}x нормы)`,
    ``,
    `${tag} #oi_watch`,
  ].join("\n");
}

// ── OI Watch Cycle: checks every 2 min for volume/price confirmation ──────────
export async function runOiWatchCycle(): Promise<void> {
  const now = new Date();

  // Expire stale entries
  try {
    await db.update(oiWatchTable)
      .set({ status: "expired" })
      .where(and(eq(oiWatchTable.status, "watching"), lt(oiWatchTable.expiresAt, now)));
  } catch { /* non-critical */ }

  const watching = await db.select()
    .from(oiWatchTable)
    .where(eq(oiWatchTable.status, "watching"));

  if (watching.length === 0) return;

  // Fetch all prices in one call
  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch { return; }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  for (const w of watching) {
    const currentPrice = priceMap.get(w.symbol);
    if (!currentPrice) continue;

    const priceMovePct = ((currentPrice - w.priceAtEntry) / w.priceAtEntry) * 100;

    // ── PATH A: Confirmed signal (vol was already ≥ 2x at scanner time) ────────
    // Full payload stored — re-confirm price didn't collapse, then fire full signal.
    if (w.isVolConfirmed && w.signalPayload) {
      const pathAPayload = w.signalPayload as { alphaResult: any; signalRow: any };
      const pathASentimentKey: string = pathAPayload.alphaResult?.sentimentKey ?? "";

      // ── UNIFIED PRICE CONFIRMATION GATE ──────────────────────────────────────
      // Сигнал публикуется ТОЛЬКО если цена уже реально двинулась с момента обнаружения.
      // Статистика: 0 прибыльных сделок из 98 сигналов где итоговый пик < 3%.
      // Окно мониторинга 90 мин — либо цена подтверждает движение, либо сигнал тихо истекает.
      const PRICE_CONFIRM_PCT: Record<string, number> = {
        bear_trap:            2.0,  // шорты давят → быстрый разворот
        short_squeeze:        2.0,  // аналогично — ловим выдавливание
        aggressive_breakout:  1.5,  // уже взрывной объём — порог ниже
        sharp_impulse:        1.5,  // импульс на объёме — порог ниже
        impulse_breakout:     1.5,
        hidden_accumulation:  2.0,  // detectSentiment уже требует +2% при входе — не удваиваем
        bullish_accumulation: 2.0,
        anomaly:              3.5,  // нет чёткого паттерна → высокий порог
      };
      const minPriceMove = PRICE_CONFIRM_PCT[pathASentimentKey] ?? 2.0;

      // Если цена ещё не дошла до порога — ждём следующего цикла (не удаляем запись)
      if (priceMovePct < minPriceMove) {
        logger.debug(
          { symbol: w.symbol, pattern: pathASentimentKey, priceMovePct: priceMovePct.toFixed(1), required: minPriceMove },
          `OI Watch: ждём подтверждения цены — нужно +${minPriceMove}%, сейчас ${priceMovePct.toFixed(1)}%`
        );
        continue;
      }

      // Hard dump cancel: если цена упала > 5% с начала watch — монета не туда идёт
      if (priceMovePct < -5) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info({ symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) }, "OI Watch: отменён (дамп > 5% с начала watch)");
        continue;
      }

      // CVD финальная проверка: если продажи доминируют в момент выстрела — отменяем
      const cvd = await fetchCVD(w.symbol);
      if (cvd && !cvd.positive) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%" },
          "🔴 OI Watch: CVD негативный при выстреле — сигнал отменён"
        );
        continue;
      }
      if (cvd) {
        logger.info(
          { symbol: w.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%" },
          "🟢 OI Watch: CVD подтверждён — стреляем"
        );
      }

      try {
        const payload = w.signalPayload as { alphaResult: any; signalRow: InsertSignal };
        const alphaResult = payload.alphaResult;
        const signalRow   = payload.signalRow;

        // Insert signal to DB
        const [inserted] = await db.insert(signalsTable).values({
          ...signalRow,
          price: currentPrice, // обновляем до текущей рыночной цены
          detectedAt: new Date(),
        }).returning();

        // Start tracking (stop-loss / targets)
        await trackSignal({
          symbol: w.symbol,
          signalId: inserted.id,
          signalType: alphaResult.grade ?? "alpha",
          sentiment: alphaResult.sentiment,
          sentimentKey: alphaResult.sentimentKey,
          alphaScore: alphaResult.alphaScore,
          entryPrice: currentPrice,
          entryOi: alphaResult.openInterest > 0 ? alphaResult.openInterest : null,
        });

        // Атомарно захватываем запись перед отправкой — защита от дублей при параллельном деплое.
        const claimedA = await db.update(oiWatchTable)
          .set({ status: "fired", firedAt: new Date() })
          .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
          .returning({ id: oiWatchTable.id });
        if (claimedA.length === 0) continue; // другой процесс уже обработал

        // Send full Telegram alert — включаем priceConfirmPct: насколько цена уже прошла
        await broadcastBatchAlert([{ ...alphaResult, price: currentPrice, priceConfirmPct: priceMovePct }]);

        logger.info(
          { symbol: w.symbol, grade: alphaResult.grade, alphaScore: alphaResult.alphaScore, priceMovePct: priceMovePct.toFixed(1) },
          "✅ OI Watch → ПОЛНЫЙ СИГНАЛ: подтверждён и отправлен"
        );
      } catch (err) {
        logger.error({ err, symbol: w.symbol }, "OI Watch: ошибка при firing confirmed signal");
      }
      continue; // не падаем в PATH B
    }

    // ── PATH B-special: BingX Volume Watch — ждём OI подтверждения ───────────────
    // bingx_volume_watch: у монеты был взрывной объём + цена, но OI ещё не подтвердил.
    // Проверяем каждые 2 мин появление CoinGlass OI. Окно: 15 мин.
    // Если OI подтвердился → апгрейд до alpha и выстрел. Иначе → тихо истекаем.
    if (w.triggerTf === "bingx_volume_watch") {
      let cgOiBv: Awaited<ReturnType<typeof getCoinglassOI>> | null = null;
      try { cgOiBv = await getCoinglassOI(w.symbol); } catch { /* non-critical */ }

      const oiConfirmed = cgOiBv?.available && (
        (cgOiBv.oiChange5m  !== null && cgOiBv.oiChange5m  > 0) ||
        (cgOiBv.oiChange30m !== null && cgOiBv.oiChange30m > 0) ||
        (cgOiBv.oiChange1h  !== null && cgOiBv.oiChange1h  > 0)
      );

      if (oiConfirmed && w.signalPayload) {
        const payload = w.signalPayload as { alphaResult: any; signalRow: InsertSignal };
        const upgradedResult = { ...payload.alphaResult, grade: "alpha" as const };
        const upgradedRow: InsertSignal = { ...payload.signalRow, type: "alpha" };

        try {
          const [inserted] = await db.insert(signalsTable).values({
            ...upgradedRow,
            price: currentPrice,
            detectedAt: new Date(),
          }).returning();

          await trackSignal({
            symbol: w.symbol,
            signalId: inserted.id,
            signalType: "alpha",
            sentiment: upgradedResult.sentiment,
            sentimentKey: upgradedResult.sentimentKey,
            alphaScore: upgradedResult.alphaScore,
            entryPrice: currentPrice,
            entryOi: null,
          });

          // Атомарно захватываем запись перед отправкой — защита от дублей при деплое.
          const claimedBv = await db.update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
            .returning({ id: oiWatchTable.id });
          if (claimedBv.length === 0) continue; // другой процесс уже обработал

          await broadcastBatchAlert([{ ...upgradedResult, price: currentPrice }]);

          logger.info(
            { symbol: w.symbol, oi5m: cgOiBv?.oiChange5m?.toFixed(1), oi30m: cgOiBv?.oiChange30m?.toFixed(1) },
            "📈 BingX Volume Watch → UPGRADED to alpha (OI подтвердил)"
          );
        } catch (err) {
          logger.error({ err, symbol: w.symbol }, "BingX Volume Watch: ошибка при апгрейде до alpha");
        }
      } else {
        logger.debug({ symbol: w.symbol, oiConfirmed }, "BingX Volume Watch: OI ещё не подтвердил — ждём...");
      }
      continue; // не проваливаемся в обычный PATH B
    }

    // ── PATH B: Unconfirmed watch (vol was < 2x at scanner time) ────────────────
    // Waiting for volume spike or price breakout to fire a lightweight alert.
    if (priceMovePct < -8) {
      await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
      logger.info({ symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) }, "OI Watch: expired (price dumped)");
      continue;
    }

    // Если цена уже улетела >20% от точки входа в watch — памп уже случился.
    // Входить сейчас = покупать на хае. BLEND: +61% от точки входа → не стреляем.
    if (priceMovePct >= 20) {
      // Атомарно захватываем запись (AND status='watching') — гарантирует что только один
      // процесс отправит уведомление при параллельном запуске двух инстансов во время деплоя.
      const claimed = await db.update(oiWatchTable)
        .set({ status: "expired" })
        .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
        .returning({ id: oiWatchTable.id });
      if (claimed.length === 0) continue; // другой процесс уже обработал
      logger.info(
        { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
        "OI Watch PATH B: expired — памп уже случился (price >= 20% от входа в watch)"
      );
      // Уведомляем — монета улетела пока наблюдали, сигнал упущен
      const coin = w.symbol.replace("-USDT", "");
      const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${coin}USDT.P`;
      await broadcast(
        `👀 <b>#${coin}: ПАМП ПРОПУЩЕН</b>\n\n` +
        `Монета была в наблюдении (OI накапливался), но памп случился раньше чем объём подтвердился.\n\n` +
        `Движение от точки обнаружения: <b>+${priceMovePct.toFixed(1)}%</b>\n` +
        `Точка входа в watch: <b>${w.priceAtEntry.toPrecision(4)}</b>\n` +
        `Сейчас: <b>${currentPrice.toPrecision(4)}</b>\n\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `#${coin.toLowerCase()} #missed_pump`
      ).catch(() => {});
      continue;
    }

    try {
      const klines = await getKlines(w.symbol, "30m", 7);
      if (klines.length < 5) continue;

      const cur  = klines[klines.length - 1];
      const hist = klines.slice(0, -1);
      const close    = parseFloat(cur.close) || 0;
      const curVol   = (parseFloat(cur.volume) || 0) * close;
      const avgVol   = w.avgVolume
        ?? (hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length);
      if (!avgVol) continue;

      const volMult        = curVol / avgVol;
      const currentPriceMove = ((close - parseFloat(cur.open)) / parseFloat(cur.open)) * 100;
      // Порог объёма PATH B: 2.5x (синхронно с основным сканером).
      // Ключевой фильтр — OI кеп 10% (ниже), а не объём.
      // M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%) — победители с низким объёмом.
      const volThresholdB  = 2.5;
      const volConfirmed   = volMult >= volThresholdB;

      // Если OI отрицательный — накопления нет, это распродажа. Не стреляем.
      if (w.oiChange < 0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.debug({ symbol: w.symbol, oiChange: w.oiChange }, "OI Watch PATH B: OI отрицательный — сигнал отменён");
        continue;
      }

      // OI cap 10%: если OI при добавлении в watch уже был > 10% — это перегретый лонг/ловушка.
      // Данные: OI 25%+ = 0% win rate. AXL(90%), PIPPIN(56%), MOODENG(23%) — все SL.
      // Не стреляем даже если объём подтвердился — позиции уже перегреты.
      if (w.oiChange > 10) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, oiChange: w.oiChange.toFixed(1) + "%" },
          "OI Watch PATH B: OI > 10% — ловушка перегретого лонга, отменяем"
        );
        continue;
      }

      // Если цена уже упала >4% с момента входа в watch — движение идёт против нас.
      // Это либо распродажа, либо OI-рост был за счёт шортов. Отменяем.
      if (priceMovePct < -4.0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
          "OI Watch PATH B: цена упала >4% от входа — сигнал отменён"
        );
        continue;
      }

      // ── ОБЯЗАТЕЛЬНАЯ ПРОВЕРКА: Cross OI должен быть положительным при срабатывании ──
      // Подтягиваем свежие данные CoinGlass — 30m OI отражает текущий импульс.
      // Если он стал отрицательным — накопление завершилось / шорты уже закрыты. Отменяем.
      let cgOI: Awaited<ReturnType<typeof getCoinglassOI>> | null = null;
      try { cgOI = await getCoinglassOI(w.symbol); } catch { /* non-critical */ }

      if (cgOI?.available && cgOI.oiChange30m !== null && cgOI.oiChange30m < 0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, crossOi30m: cgOI.oiChange30m.toFixed(1) + "%" },
          "OI Watch PATH B: Cross OI отрицательный — сигнал отменён"
        );
        continue;
      }

      // ── ФИЛЬТР: для накопления требуем подтверждение ценой ──────────────────────
      // PATH B стреляет когда объём подтвердился. Но для hidden_accumulation этого мало —
      // нужно чтобы цена ТОЖЕ начала двигаться (>= 2%). Иначе это накопление без выстрела.
      // null payload = добавлен из low-vol пути (OI есть, объём не пришёл) = всегда накопление.
      // Токены без движения цены (RARE +0.9%, WAVES +0.76%) остаются в watching до 2h экспайра.
      const pathBSentimentKey = (w.signalPayload as any)?.alphaResult?.sentimentKey ?? null;
      // Аномалия добавлена в список "требует подтверждения ценой" (наравне с накоплением).
      // Данные: anomaly win rate 13%, 9 SL из 15. Без OI-поддержки это просто спайк объёма — шум.
      // Требуем price >= 2% перед выстрелом — хотя бы минимальное подтверждение движения.
      const isAccumPatternB = pathBSentimentKey === "hidden_accumulation"
                           || pathBSentimentKey === "bullish_accumulation"
                           || pathBSentimentKey === "anomaly"
                           || pathBSentimentKey === null;
      const minPriceMoveB = 2.0;

      if (isAccumPatternB && priceMovePct < minPriceMoveB) {
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1), sentimentKey: pathBSentimentKey },
          `OI Watch PATH B: накопление — ждём движения цены >= ${minPriceMoveB}% (держим в watching)`
        );
        continue; // Остаётся в watching, не меняем статус — ждём пока цена тронется
      }

      if (volConfirmed) {
        // Атомарно захватываем запись перед отправкой — защита от дублей при деплое.
        const claimedB = await db.update(oiWatchTable)
          .set({ status: "fired", firedAt: new Date() })
          .where(and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")))
          .returning({ id: oiWatchTable.id });
        if (claimedB.length === 0) continue; // другой процесс уже обработал

        // Если payload с полным AlphaResult сохранён — используем полный формат с OI по ТФ
        if (w.signalPayload) {
          const payload = w.signalPayload as { alphaResult: any; signalRow: any };
          // Обновляем coinalyzeOiChange свежими данными CoinGlass перед отправкой
          const freshCoinalyze = cgOI?.oiChange30m ?? (payload.alphaResult.coinalyzeOiChange ?? null);
          const fullResult = {
            ...payload.alphaResult,
            price: currentPrice,
            volumeMultiplier: volMult,
            priceChange30m: priceMovePct,
            coinalyzeOiChange: freshCoinalyze,
          };
          await broadcastBatchAlert([fullResult]);
        } else {
          // Fallback: payload отсутствует (токен добавлен с низким объёмом без полного скана).
          // Используем уже полученный cgOI (не делаем повторный запрос).
          const base = w.symbol.replace("-USDT", "");
          const tvUrl  = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT`;
          const bingxUrl = `https://bingx.com/en/trade/${base}USDT/`;
          const waitMin = Math.round((Date.now() - w.addedAt.getTime()) / 60_000);

          // Определяем triggerTf — убираем префикс "all+" если был
          const displayTf = w.triggerTf.replace(/^all\+/, "");

          // Если CoinGlass API недоступен (cgOI = null) — используем сохранённое w.oiChange
          // как значение для сработавшего TF, чтобы в сигнале было видно OI по ТФ, а не просто число.
          const storedOi = w.oiChange;
          const cgOi5m  = cgOI?.oiChange5m  ?? (displayTf === "5m"  ? storedOi : null);
          const cgOi30m = cgOI?.oiChange30m ?? (displayTf === "30m" || displayTf === "steady" ? storedOi : null);
          const cgOi1h  = cgOI?.oiChange1h  ?? (displayTf === "1h"  ? storedOi : null);
          const cgOi4h  = cgOI?.oiChange4h  ?? (displayTf === "4h"  ? storedOi : null);
          const cgOi24h = cgOI?.oiChange24h ?? (displayTf === "24h" ? storedOi : null);

          const syntheticResult: Parameters<typeof broadcastBatchAlert>[0][0] = {
            symbol: w.symbol,
            grade: "alpha",
            price: currentPrice,
            priceChange30m: priceMovePct,
            currentVolume: curVol,
            avgVolume: avgVol,
            volumeMultiplier: volMult,
            oiChangePercent: w.oiChange,
            openInterest: null,
            cmcRank: null,
            cmcSource: null,
            cmcAvailable: false,
            liquidationsUsd: null,
            liquidationsMultiple: null,
            coinglassAvailable: cgOI?.available ?? false,
            coinalyzeOiChange: cgOi30m,
            coinalyzeConfirmed: false,
            isNewListing: false,
            isExhaustedSqueeze: false,
            pumpFromOpen: null,
            candleCount: 48,
            sentiment: "🔭 OI Watch",
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            traderAction: `Наблюдал ${waitMin} мин — объём подтвердился`,
            alphaScore: 5,
            isContinuing: false,
            cumulativeOiChange: w.oiChange,
            tradingViewUrl: tvUrl,
            bingxUrl,
            oiTriggerTf: displayTf,
            oiChange5m:  cgOi5m,
            oiChange1h:  cgOi1h,
            oiChange4h:  cgOi4h,
            oiChange24h: cgOi24h,
          };
          await broadcastBatchAlert([syntheticResult]);
        }

        // ── Создаём tracked_signal чтобы вотчер мог сопровождать сигнал ─────────
        // PATH B раньше не создавал запись → не было уведомлений о БУ и milestone.
        // Теперь вставляем сигнал и запускаем tracking, как в PATH A.
        try {
          const base = w.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

          // Используем свежую цену из тикера (currentPrice), а не close из kline!
          // close — это цена закрытия 30м свечи, может быть на 30 минут устаревшей.
          // Ошибка: entryPrice: close → бот считал +11% вместо реального +1%.
          const [inserted] = await db.insert(signalsTable).values({
            symbol: w.symbol,
            type: "alpha",
            value: volMult,       // множитель объёма (как в PATH A), не OI
            threshold: 0,
            price: currentPrice,
            priceChangePercent: priceMovePct,
            volume24h: curVol,
            avgVolume: w.avgVolume ?? 0,
            openInterest: null,
            oiChangePercent: w.oiChange,
            tradingViewUrl: tvUrl,
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            detectedAt: new Date(),
          }).returning();

          // Если памп уже случился до выстрела (priceMovePct > 10%) — используем
          // оригинальную цену обнаружения как точку отсчёта для peakPct и stale cancel.
          // Иначе stale cancel видит peak=0% и отменяет сигнал где уже было +17%.
          const effectiveEntry = priceMovePct > 10 ? w.priceAtEntry : currentPrice;

          await trackSignal({
            symbol: w.symbol,
            signalId: inserted.id,
            signalType: "alpha",
            sentiment: null,
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            alphaScore: null,
            entryPrice: effectiveEntry,
            entryOi: null,
          });

          logger.info(
            { symbol: w.symbol, entryPrice: effectiveEntry, firePriceNow: currentPrice, klinesClose: close, priceMovePct: priceMovePct.toFixed(1) },
            "🔭 OI Watch PATH B: tracked_signal создан — сопровождение активно"
          );
        } catch (trackErr) {
          logger.error({ err: trackErr, symbol: w.symbol }, "OI Watch PATH B: ошибка при создании tracked_signal");
        }

        logger.info(
          { symbol: w.symbol, volMult: volMult.toFixed(2), priceMovePct: priceMovePct.toFixed(1), volConfirmed },
          "🔭➡️🚀 OI Watch FIRED (volume confirmed)"
        );
      }
    } catch (err) {
      logger.debug({ err, symbol: w.symbol }, "OI Watch PATH B: klines fetch failed");
    }
  }
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
let cycleTimer:       NodeJS.Timeout | null = null;
let fastTimer:        NodeJS.Timeout | null = null;
let dailyTimer:       NodeJS.Timeout | null = null;
let weeklyTimer:      NodeJS.Timeout | null = null;
let monthlyTimer:     NodeJS.Timeout | null = null;
let whaleTimer:       NodeJS.Timeout | null = null;
let whaleSatTimer:    NodeJS.Timeout | null = null;
let positionsTimer:   NodeJS.Timeout | null = null;

/** Миллисекунды до следующего HH:MM:00 UTC */
function msUntilUtc(targetHour: number, targetMin: number, targetDayOfWeek?: number): number {
  const now = new Date();
  const next = new Date(now);
  next.setUTCSeconds(0, 0);
  next.setUTCMinutes(targetMin);
  next.setUTCHours(targetHour);

  if (targetDayOfWeek !== undefined) {
    // Воскресенье = 0
    const currentDay = now.getUTCDay();
    let daysUntil = (targetDayOfWeek - currentDay + 7) % 7;
    // Если сегодня целевой день, но время уже прошло — ждём следующей недели
    if (daysUntil === 0 && next.getTime() <= now.getTime()) {
      daysUntil = 7;
    }
    next.setUTCDate(now.getUTCDate() + daysUntil);
  } else {
    // Ежедневно — если уже прошло сегодня, переносим на завтра
    if (next.getTime() <= now.getTime()) {
      next.setUTCDate(next.getUTCDate() + 1);
    }
  }

  return next.getTime() - now.getTime();
}

/** Миллисекунды до следующего 1-го числа месяца в HH:MM UTC */
function msUntilFirstOfMonth(targetHour: number, targetMin: number): number {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, targetHour, targetMin, 0, 0));
  // Если сейчас уже 1-е число и время ещё не наступило — отправляем сегодня
  if (now.getUTCDate() === 1) {
    const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, targetHour, targetMin, 0, 0));
    if (today.getTime() > now.getTime()) return today.getTime() - now.getTime();
  }
  return next.getTime() - now.getTime();
}

// ── Whale Accumulation Jobs ───────────────────────────────────────────────────

/**
 * Ежедневный сбор OI снимков (00:05 UTC).
 * Читает все активные тикеры BingX, параллельно батчем CoinGlass, сохраняет по одному на символ.
 */
async function runDailyOiSnapshot(): Promise<void> {
  logger.info("🐋 Daily OI snapshot job started");

  let tickers: any[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch (err) {
    logger.error({ err }, "🐋 OI snapshot: failed to fetch tickers");
    return;
  }

  // Фильтруем USDT-M перпетуалы
  const symbols: string[] = tickers
    .filter((t: any) => t.symbol?.endsWith("-USDT"))
    .map((t: any) => t.symbol as string);

  const priceMap = new Map<string, number>();
  const vol24Map = new Map<string, number>();
  for (const t of tickers) {
    if (t.symbol) {
      priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
      vol24Map.set(t.symbol, parseFloat(t.quoteVolume) || parseFloat(t.volume) || 0);
    }
  }

  // Батч CoinGlass (уже ограничен 30 req/min внутри batchGetCoinglassOI)
  let cgData = new Map<string, any>();
  try {
    cgData = await batchGetCoinglassOI(symbols);
  } catch (err) {
    logger.warn({ err }, "🐋 OI snapshot: CoinGlass batch failed — prices only");
  }

  const { saved, skipped } = await saveDailyOiSnapshots(cgData, priceMap, vol24Map);
  logger.info({ saved, skipped, total: symbols.length }, "🐋 Daily OI snapshot job complete");
}

/**
 * Еженедельный whale анализ (Суббота 10:00 МСК = 07:00 UTC).
 * Находит токены с признаками китового накопления и рассылает отчёт.
 */
async function runWeeklyWhaleAnalysis(): Promise<void> {
  logger.info("🐋 Weekly whale analysis started");

  const candidates = await getAllWhaleAccumCandidates();

  if (candidates.length === 0) {
    logger.info("🐋 Weekly whale analysis: нет кандидатов (high/medium confidence)");
    return;
  }

  const signals: WhaleAccumSignalInput[] = candidates
    .filter(c => c.confidence !== "low")
    .map(c => ({
      symbol:         c.symbol,
      daysTracked:    c.daysTracked,
      oiGrowthPct:    c.oiGrowthPct,
      priceChangePct: c.priceChangePct,
      consistencyPct: c.consistencyPct,
      avgVolRatio:    c.avgVolRatio,
      confidence:     c.confidence as "high" | "medium",
      reason:         c.reason,
    }));

  logger.info({ count: signals.length }, "🐋 Broadcasting whale accumulation signals");
  await broadcastWhaleAccumAlert(signals);
}

export function startWatcher(): void {
  logger.info("Alpha Watcher started");

  // Startup reset — проверяем стоп-лоссы и трейлинги пропущенные за время простоя.
  // Запуск 1: через 10с (BingX API ещё может быть холодным — внутри retry 3×3s).
  // Запуск 2: через 3 мин — страховочный прогон если первый упал на API таймауте.
  setTimeout(async () => {
    try { await runStartupReset(); } catch (err) { logger.error({ err }, "Startup reset #1 error"); }
  }, 10_000);
  setTimeout(async () => {
    try { await runStartupReset(); } catch (err) { logger.error({ err }, "Startup reset #2 error"); }
    logger.info("Startup reset #2 complete (safety net)");
    // Уведомляем пользователей о рестарте — только в продакшне
    if (process.env.NODE_ENV !== "development") {
      sendBotRestartNotification().catch(err => logger.warn({ err }, "Restart notification failed (non-critical)"));
    }
  }, 3 * 60_000);

  // Fast cycle every 2 min — active + in_run (stop-loss, first target, trailing)
  // Also runs OI Watch cycle (check for volume confirmation on watch candidates)
  const runFast = async () => {
    if (!fastTimer) return;
    try { await runInRunFastCycle(); } catch (err) { logger.error({ err }, "FastCycle error"); }
    try { await runOiWatchCycle(); } catch (err) { logger.error({ err }, "OiWatchCycle error"); }
    fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  };
  // First fast cycle at 2 min (after startup reset at 5s)
  fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  logger.info({ intervalMin: FAST_CYCLE_MS / 60000 }, "Fast cycle started (active + in_run + OI watch, 2min)");

  // Watcher cycle every 10 min — handles ONLY accumulation signals.
  // Starts at 7 min to avoid any race with the first FastCycle (at 2 min).
  const runCycle = async () => {
    if (!cycleTimer) return;
    try {
      const r = await runWatcherCycle();
      logger.info(r, "Watcher cycle complete");
    } catch (err) {
      logger.error({ err }, "Watcher cycle error");
    }
    cycleTimer = setTimeout(runCycle, 10 * 60 * 1000);
  };
  cycleTimer = setTimeout(runCycle, 7 * 60 * 1000);

  // Daily at 21:00 МСК = 18:00 UTC
  const scheduleDaily = () => {
    const ms = msUntilUtc(18, 0);
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Daily report scheduled (21:00 МСК)");
    dailyTimer = setTimeout(async () => {
      try { await sendDailyReport(); } catch (err) { logger.error({ err }, "Daily report error"); }
      scheduleDaily();
    }, ms);
  };
  scheduleDaily();

  // ── Missed-report guard ───────────────────────────────────────────────────────
  // Ловим два случая пропуска:
  // 1. Перезапуск ПОСЛЕ 18:00 UTC сегодня — отчёт за сегодня не отправлен.
  // 2. Перезапуск утром (до 18:00 UTC) — но вчерашний отчёт тоже не отправлен.
  // Задержка 90с: продакшн-DB иногда требует 30–60с на холодный reconnect.
  // При ошибке DB — retry через 60с (до 3 попыток).
  const runDailyGuard = async (attempt = 1): Promise<void> => {
    try {
      const nowUtc = new Date();

      // Порог за сегодня (18:00 UTC = 21:00 МСК)
      const todayReportUtc = new Date(nowUtc);
      todayReportUtc.setUTCHours(18, 0, 0, 0);

      // Порог за вчера (18:00 UTC вчерашнего дня)
      const yesterdayReportUtc = new Date(todayReportUtc);
      yesterdayReportUtc.setUTCDate(yesterdayReportUtc.getUTCDate() - 1);

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastDailyReportAt;

      // Пропущен сегодняшний отчёт: уже после 18:00, но не отправляли с 18:00
      const missedToday = nowUtc >= todayReportUtc && (!lastSent || lastSent < todayReportUtc);

      // Пропущен вчерашний отчёт: последний раз отправляли раньше 18:00 вчера
      const missedYesterday = !lastSent || lastSent < yesterdayReportUtc;

      if (!missedToday && !missedYesterday) {
        logger.info({ lastSent }, "Daily report guard: всё в порядке, пропуска нет");
        return;
      }

      logger.warn(
        { lastSent, nowUtc, missedToday, missedYesterday },
        "Missed daily report detected — sending now"
      );
      await sendDailyReport();
    } catch (err) {
      logger.error({ err, attempt }, "Missed-report guard error");
      if (attempt < 3) {
        logger.info({ nextAttempt: attempt + 1 }, "Missed-report guard: retry in 60s");
        setTimeout(() => runDailyGuard(attempt + 1), 60_000);
      }
    }
  };
  setTimeout(() => runDailyGuard(), 90_000); // 90с после старта — даём DB восстановить соединение

  // ── Missed-weekly guard ───────────────────────────────────────────────────────
  // Если сервер перезапустился в воскресенье после 09:00 МСК (06:00 UTC) и дайджест
  // ещё не был отправлен на этой неделе — отправляем через 120с после старта.
  const runWeeklyGuard = async (attempt = 1): Promise<void> => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDay() !== 0) return; // Не воскресенье — пропускаем

      const thisWeekDigestUtc = new Date(nowUtc);
      thisWeekDigestUtc.setUTCHours(6, 0, 0, 0); // 06:00 UTC = 09:00 МСК

      if (nowUtc < thisWeekDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastWeeklyDigestAt;

      const alreadySentThisWeek = lastSent && lastSent >= thisWeekDigestUtc;
      if (alreadySentThisWeek) {
        logger.info({ lastSent }, "Weekly digest already sent this week — skipping missed-digest check");
        return;
      }

      logger.warn({ lastSent, nowUtc }, "Missed weekly digest detected — sending now");
      await sendWeeklyDigest();
    } catch (err) {
      logger.error({ err, attempt }, "Missed-weekly guard error");
      if (attempt < 3) {
        setTimeout(() => runWeeklyGuard(attempt + 1), 60_000);
      }
    }
  };
  setTimeout(() => runWeeklyGuard(), 120_000); // 120с после старта

  // Weekly Sunday at 09:00 МСК = 06:00 UTC
  const scheduleWeekly = () => {
    const ms = msUntilUtc(6, 0, 0); // 0 = Sunday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Weekly digest scheduled (Вс 09:00 МСК)");
    weeklyTimer = setTimeout(async () => {
      try { await sendWeeklyDigest(); } catch (err) { logger.error({ err }, "Weekly digest error"); }
      scheduleWeekly();
    }, ms);
  };
  scheduleWeekly();

  // ── Missed-monthly guard ──────────────────────────────────────────────────────
  // Если сервер перезапустился 1-го числа после 10:00 МСК (07:00 UTC) и дайджест
  // ещё не был отправлен в этом месяце — отправляем через 90с после старта.
  setTimeout(async () => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDate() !== 1) return; // Не 1-е число — пропускаем

      const thisMonthDigestUtc = new Date(Date.UTC(nowUtc.getUTCFullYear(), nowUtc.getUTCMonth(), 1, 7, 0, 0, 0));
      if (nowUtc < thisMonthDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastMonthlyDigestAt;

      const alreadySentThisMonth = lastSent && lastSent >= thisMonthDigestUtc;
      if (alreadySentThisMonth) {
        logger.info({ lastSent }, "Monthly digest already sent this month — skipping missed-digest check");
        return;
      }

      logger.warn({ lastSent, nowUtc }, "Missed monthly digest detected — sending now");
      await sendMonthlyDigest();
    } catch (err) {
      logger.error({ err }, "Missed-monthly guard error");
    }
  }, 90_000); // 90с после старта

  // Monthly — 1-е число каждого месяца в 10:00 МСК = 07:00 UTC
  // ВНИМАНИЕ: setTimeout имеет лимит ~24.8 дней (2^31 мс). Для месячного таймера
  // это может переполниться (30 дней = 2.6 млрд мс > 2.15 млрд лимита) и вызвать
  // бесконечный цикл (таймер срабатывает немедленно через 1мс).
  // Решение: если до события > 23 дней — планируем промежуточную проверку.
  const MAX_SAFE_TIMEOUT_MS = 23 * 24 * 60 * 60 * 1000; // 23 дня — безопасный максимум
  const scheduleMonthly = () => {
    const ms = msUntilFirstOfMonth(7, 0);
    if (ms > MAX_SAFE_TIMEOUT_MS) {
      // Слишком далеко для одного setTimeout — планируем промежуточную проверку через 23 дня
      logger.info({ nextAt: new Date(Date.now() + ms).toISOString(), retryIn: "23d" }, "Monthly digest: слишком далеко, промежуточная проверка через 23 дня");
      monthlyTimer = setTimeout(scheduleMonthly, MAX_SAFE_TIMEOUT_MS);
      return;
    }
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Monthly digest scheduled (1-е число, 10:00 МСК)");
    monthlyTimer = setTimeout(async () => {
      try { await sendMonthlyDigest(); } catch (err) { logger.error({ err }, "Monthly digest error"); }
      scheduleMonthly();
    }, ms);
  };
  scheduleMonthly();

  // ── Daily OI snapshot at 00:05 UTC (whale accumulation data collection) ────
  const scheduleWhaleSnapshot = () => {
    const ms = msUntilUtc(0, 5);
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "🐋 Daily OI snapshot scheduled (00:05 UTC)");
    whaleTimer = setTimeout(async () => {
      try { await runDailyOiSnapshot(); } catch (err) { logger.error({ err }, "🐋 Daily OI snapshot error"); }
      scheduleWhaleSnapshot();
    }, ms);
  };
  scheduleWhaleSnapshot();

  // ── Weekly whale analysis on Saturday 07:00 UTC = 10:00 МСК ───────────────
  const scheduleWhaleSaturday = () => {
    const ms = msUntilUtc(7, 0, 6); // 6 = Saturday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "🐋 Weekly whale analysis scheduled (Сб 10:00 МСК)");
    whaleSatTimer = setTimeout(async () => {
      try { await runWeeklyWhaleAnalysis(); } catch (err) { logger.error({ err }, "🐋 Weekly whale analysis error"); }
      scheduleWhaleSaturday();
    }, ms);
  };
  scheduleWhaleSaturday();

  // ── Periodic positions update every 4 hours ───────────────────────────────
  const POSITIONS_INTERVAL_MS = 4 * 60 * 60 * 1000; // 4 часа
  const runPositionsUpdate = async () => {
    if (!positionsTimer) return;
    try {
      const text = await buildPositionsStatusText();
      const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
      const channelId = rows[0]?.channelId?.trim();
      if (channelId) {
        await sendMessage(channelId, text);
      }
      logger.info("Positions update sent to channel");
    } catch (err) {
      logger.error({ err }, "Positions update error");
    }
    positionsTimer = setTimeout(runPositionsUpdate, POSITIONS_INTERVAL_MS);
  };
  positionsTimer = setTimeout(runPositionsUpdate, POSITIONS_INTERVAL_MS);
  logger.info({ intervalH: 4 }, "Positions update scheduled (every 4h)");
}

export function stopWatcher(): void {
  if (fastTimer)       { clearTimeout(fastTimer);       fastTimer       = null; }
  if (cycleTimer)      { clearTimeout(cycleTimer);      cycleTimer      = null; }
  if (dailyTimer)      { clearTimeout(dailyTimer);      dailyTimer      = null; }
  if (weeklyTimer)     { clearTimeout(weeklyTimer);     weeklyTimer     = null; }
  if (monthlyTimer)    { clearTimeout(monthlyTimer);    monthlyTimer    = null; }
  if (whaleTimer)      { clearTimeout(whaleTimer);      whaleTimer      = null; }
  if (whaleSatTimer)   { clearTimeout(whaleSatTimer);   whaleSatTimer   = null; }
  if (positionsTimer)  { clearTimeout(positionsTimer);  positionsTimer  = null; }
  logger.info("Alpha Watcher stopped");
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/lib/whaleTracker.ts
// ═══════════════════════════════════════════════════════

/**
 * Whale Accumulation Tracker
 *
 * Сохраняет ежедневные снимки OI + объём для всех активных токенов.
 * Анализирует тренды: если OI стабильно растёт несколько недель при плоской цене —
 * это признак китового накопления.
 *
 * Цикл сбора: 1 раз в сутки (в 00:05 UTC).
 * Анализ: запускается при каждом скане (если данных >= 14 дней).
 */

import { db, oiDailySnapshotsTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";
import type { CoinglassOIResult } from "./coinglass_oi.js";
import { logger } from "./logger.js";

const TODAY_UTC = () => new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"

// ── Snapshot collection ──────────────────────────────────────────────────────

/**
 * Сохраняет дневной снимок OI для всех символов из batch CoinGlass.
 * Вызывается один раз в сутки. Дубли (один символ + одна дата) игнорируются.
 */
export async function saveDailyOiSnapshots(
  batchData: Map<string, CoinglassOIResult>,
  priceMap: Map<string, number>,
  volume24hMap: Map<string, number>,
): Promise<{ saved: number; skipped: number }> {
  const date = TODAY_UTC();
  let saved = 0;
  let skipped = 0;

  for (const [symbol, oi] of batchData.entries()) {
    if (!oi.available || oi.oiUsd == null) { skipped++; continue; }

    // Проверяем нет ли уже записи за сегодня
    const existing = await db
      .select({ id: oiDailySnapshotsTable.id })
      .from(oiDailySnapshotsTable)
      .where(and(
        eq(oiDailySnapshotsTable.symbol, symbol),
        eq(oiDailySnapshotsTable.date, date),
      ))
      .limit(1);

    if (existing.length > 0) { skipped++; continue; }

    await db.insert(oiDailySnapshotsTable).values({
      symbol,
      date,
      oiUsd:       oi.oiUsd,
      oiChange24h: oi.oiChange24h ?? null,
      priceUsd:    priceMap.get(symbol) ?? null,
      volume24h:   volume24hMap.get(symbol) ?? null,
    });
    saved++;
  }

  logger.info({ date, saved, skipped }, "🐋 Daily OI snapshots saved");
  return { saved, skipped };
}

// ── Whale analysis ────────────────────────────────────────────────────────────

export interface WhaleAccumResult {
  symbol:          string;
  daysTracked:     number;
  oiGrowthPct:     number;   // OI % change from first to last snapshot
  priceChangePct:  number;   // Price % change over same period
  oiGrowthPerDay:  number;   // Average daily OI growth %
  positiveDays:    number;   // How many days had positive OI change24h
  totalDays:       number;
  consistencyPct:  number;   // positiveDays / totalDays * 100
  avgVolRatio:     number;   // avg volume vs first-week avg (volume building signal)
  isWhaleAccum:    boolean;
  confidence:      "high" | "medium" | "low";
  reason:          string;
}

/**
 * Анализирует исторические снимки для одного символа.
 * Возвращает null если данных недостаточно (< 14 дней).
 */
export async function analyzeWhaleAccumulation(symbol: string): Promise<WhaleAccumResult | null> {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 90); // берём до 90 дней

  const snapshots = await db
    .select()
    .from(oiDailySnapshotsTable)
    .where(and(
      eq(oiDailySnapshotsTable.symbol, symbol),
      gte(oiDailySnapshotsTable.takenAt, cutoff),
    ))
    .orderBy(oiDailySnapshotsTable.date);

  if (snapshots.length < 14) return null; // нужно минимум 2 недели

  const first   = snapshots[0];
  const last    = snapshots[snapshots.length - 1];
  const daysTracked = snapshots.length;

  if (!first.oiUsd || !last.oiUsd || first.oiUsd === 0) return null;

  // OI рост от начала к концу периода
  const oiGrowthPct = ((last.oiUsd - first.oiUsd) / first.oiUsd) * 100;

  // Изменение цены за период
  const priceChangePct = (first.priceUsd && last.priceUsd && first.priceUsd > 0)
    ? ((last.priceUsd - first.priceUsd) / first.priceUsd) * 100
    : 0;

  // Средний дневной рост OI
  const oiGrowthPerDay = oiGrowthPct / daysTracked;

  // Сколько дней был положительный oiChange24h (накопление, не распределение)
  const positiveDays = snapshots.filter(s => (s.oiChange24h ?? 0) > 0).length;
  const consistencyPct = (positiveDays / daysTracked) * 100;

  // Сравниваем средний объём первой недели vs последней недели
  const firstWeek = snapshots.slice(0, 7).filter(s => s.volume24h != null);
  const lastWeek  = snapshots.slice(-7).filter(s => s.volume24h != null);
  const firstVolAvg = firstWeek.length > 0
    ? firstWeek.reduce((s, r) => s + (r.volume24h ?? 0), 0) / firstWeek.length : 0;
  const lastVolAvg  = lastWeek.length > 0
    ? lastWeek.reduce((s, r) => s + (r.volume24h ?? 0), 0) / lastWeek.length : 0;
  const avgVolRatio = firstVolAvg > 0 ? lastVolAvg / firstVolAvg : 1;

  // ── Критерии китового накопления ─────────────────────────────────────────
  // 1. OI вырос минимум на 15% за период
  // 2. Цена не выросла сильно (< 15%) — значит накопление ещё не реализовалось
  // 3. Накопление устойчивое: > 55% дней с позитивным OI
  const oiGrowing     = oiGrowthPct >= 15;
  const priceSuppressed = priceChangePct < 15;
  const consistent    = consistencyPct >= 55;
  const volumeBuilding = avgVolRatio >= 1.2; // объём в последнюю неделю на 20% выше первой

  const isWhaleAccum  = oiGrowing && priceSuppressed && consistent;

  // Уверенность
  let confidence: "high" | "medium" | "low" = "low";
  let reason = "";

  if (isWhaleAccum) {
    if (oiGrowthPct >= 40 && consistencyPct >= 65 && volumeBuilding) {
      confidence = "high";
      reason = `OI +${oiGrowthPct.toFixed(0)}% за ${daysTracked}д при цене ${priceChangePct >= 0 ? "+" : ""}${priceChangePct.toFixed(0)}%, объём растёт (${avgVolRatio.toFixed(1)}x)`;
    } else if (oiGrowthPct >= 25 && consistencyPct >= 60) {
      confidence = "medium";
      reason = `OI +${oiGrowthPct.toFixed(0)}% за ${daysTracked}д при цене ${priceChangePct >= 0 ? "+" : ""}${priceChangePct.toFixed(0)}%`;
    } else {
      confidence = "low";
      reason = `Слабые признаки: OI +${oiGrowthPct.toFixed(0)}% за ${daysTracked}д`;
    }
  }

  return {
    symbol, daysTracked, oiGrowthPct, priceChangePct,
    oiGrowthPerDay, positiveDays, totalDays: daysTracked,
    consistencyPct, avgVolRatio, isWhaleAccum, confidence, reason,
  };
}

/**
 * Быстрая проверка: есть ли по символу достаточно данных для whale-анализа?
 */
export async function hasEnoughWhaleData(symbol: string): Promise<boolean> {
  const result = await db
    .select({ cnt: sql<number>`count(*)` })
    .from(oiDailySnapshotsTable)
    .where(eq(oiDailySnapshotsTable.symbol, symbol));
  return (Number(result[0]?.cnt ?? 0)) >= 14;
}

/**
 * Возвращает все символы с активным whale accumulation (HIGH или MEDIUM confidence).
 * Используется для ежедневного отчёта.
 */
export async function getAllWhaleAccumCandidates(): Promise<WhaleAccumResult[]> {
  // Получаем список символов с >= 14 снимками
  const symbolsWithData = await db
    .selectDistinct({ symbol: oiDailySnapshotsTable.symbol })
    .from(oiDailySnapshotsTable)
    .groupBy(oiDailySnapshotsTable.symbol)
    .having(sql`count(*) >= 14`);

  const results: WhaleAccumResult[] = [];
  for (const { symbol } of symbolsWithData) {
    const analysis = await analyzeWhaleAccumulation(symbol);
    if (analysis?.isWhaleAccum && analysis.confidence !== "low") {
      results.push(analysis);
    }
  }

  // Сортируем по силе: сначала высокая уверенность + больший рост OI
  return results.sort((a, b) => {
    if (a.confidence !== b.confidence) {
      return a.confidence === "high" ? -1 : 1;
    }
    return b.oiGrowthPct - a.oiGrowthPct;
  });
}

/**
 * Сколько символов уже имеет достаточно данных для whale-анализа?
 */
export async function getWhaleDataCoverage(): Promise<{ total: number; ready: number; oldestDate: string | null }> {
  const stats = await db
    .select({
      total:      sql<number>`count(distinct symbol)`,
      ready:      sql<number>`count(distinct symbol) filter (where cnt >= 14)`,
      oldest:     sql<string>`min(date)`,
    })
    .from(
      db.select({
        symbol: oiDailySnapshotsTable.symbol,
        date:   oiDailySnapshotsTable.date,
        cnt:    sql<number>`count(*) over (partition by symbol)`,
      })
      .from(oiDailySnapshotsTable)
      .as("sub")
    );

  return {
    total:      Number(stats[0]?.total ?? 0),
    ready:      Number(stats[0]?.ready ?? 0),
    oldestDate: stats[0]?.oldest ?? null,
  };
}

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/health.ts
// ═══════════════════════════════════════════════════════

import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

export default router;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/index.ts
// ═══════════════════════════════════════════════════════

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scannerRouter from "./scanner.js";
import signalsRouter from "./signals.js";
import settingsRouter from "./settings.js";
import subscribersRouter from "./subscribers.js";
import trackerRouter from "./tracker.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(scannerRouter);
router.use(signalsRouter);
router.use(settingsRouter);
router.use(subscribersRouter);
router.use(trackerRouter);

export default router;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/scanner.ts
// ═══════════════════════════════════════════════════════

import { Router } from "express";
import {
  getScannerState,
  startScanner,
  stopScanner,
  performScan,
} from "../lib/scanner.js";

const router = Router();

router.get("/scanner/status", async (req, res) => {
  try {
    const state = await getScannerState();
    res.json({
      running: state.running,
      lastScanAt: state.lastScanAt?.toISOString() ?? null,
      nextScanAt: state.nextScanAt?.toISOString() ?? null,
      totalSignals: state.totalSignals,
      signalsToday: state.signalsToday,
      marketsScanned: state.marketsScanned,
      telegramConnected: state.telegramConnected,
      bingxConnected: state.bingxConnected,
      scanIntervalMs: state.scanIntervalMs,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get scanner status");
    res.status(500).json({ error: "Failed to get scanner status" });
  }
});

router.post("/scanner/start", async (req, res) => {
  try {
    await startScanner();
    res.json({ success: true, message: "Scanner started" });
  } catch (err) {
    req.log.error({ err }, "Failed to start scanner");
    res.status(500).json({ success: false, message: "Failed to start scanner" });
  }
});

router.post("/scanner/stop", async (req, res) => {
  try {
    await stopScanner();
    res.json({ success: true, message: "Scanner stopped" });
  } catch (err) {
    req.log.error({ err }, "Failed to stop scanner");
    res.status(500).json({ success: false, message: "Failed to stop scanner" });
  }
});

router.post("/scanner/scan-now", async (req, res) => {
  try {
    const result = await performScan();
    res.json({
      success: true,
      signalsFound: result.signalsFound,
      marketsScanned: result.marketsScanned,
      durationMs: result.durationMs,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to run scan");
    res.status(500).json({ success: false, signalsFound: 0, marketsScanned: 0, durationMs: 0 });
  }
});

export default router;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/settings.ts
// ═══════════════════════════════════════════════════════

import { Router } from "express";
import { db, settingsTable } from "@workspace/db";
import { UpdateSettingsBody } from "@workspace/api-zod";

const router = Router();

async function getOrCreateSettings() {
  const rows = await db.select().from(settingsTable).limit(1);
  if (rows.length === 0) {
    const inserted = await db.insert(settingsTable).values({
      volumeMultiplier: 3,
      oiChangePercent: 10,
      fundingRateThreshold: 0.0005,
      scanIntervalMs: 300000,
      telegramEnabled: true,
      maxSymbols: 50,
    }).returning();
    return inserted[0];
  }
  return rows[0];
}

router.get("/settings", async (req, res) => {
  try {
    const settings = await getOrCreateSettings();
    res.json({
      volumeMultiplier: settings.volumeMultiplier,
      oiChangePercent: settings.oiChangePercent,
      fundingRateThreshold: settings.fundingRateThreshold,
      scanIntervalMs: settings.scanIntervalMs,
      telegramEnabled: settings.telegramEnabled,
      maxSymbols: settings.maxSymbols,
      channelId: settings.channelId ?? null,
      watchlist: settings.watchlist ?? null,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get settings");
    res.status(500).json({ error: "Failed to get settings" });
  }
});

router.put("/settings", async (req, res) => {
  try {
    const parsed = UpdateSettingsBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid settings data" });
      return;
    }

    await getOrCreateSettings();
    const updates = parsed.data;

    // Auto-prepend @ to channel usernames that look like text handles
    if (updates.channelId && typeof updates.channelId === "string") {
      const ch = updates.channelId.trim();
      if (ch && !ch.startsWith("@") && !ch.startsWith("-") && isNaN(Number(ch))) {
        updates.channelId = `@${ch}`;
      }
    }

    const [updated] = await db.update(settingsTable)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Settings not found" });
      return;
    }

    res.json({
      volumeMultiplier: updated.volumeMultiplier,
      oiChangePercent: updated.oiChangePercent,
      fundingRateThreshold: updated.fundingRateThreshold,
      scanIntervalMs: updated.scanIntervalMs,
      telegramEnabled: updated.telegramEnabled,
      maxSymbols: updated.maxSymbols,
      channelId: updated.channelId ?? null,
      watchlist: updated.watchlist ?? null,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to update settings");
    res.status(500).json({ error: "Failed to update settings" });
  }
});

export default router;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/signals.ts
// ═══════════════════════════════════════════════════════

import { Router } from "express";
import { db, signalsTable } from "@workspace/db";
import { desc, eq, gte, sql, and } from "drizzle-orm";

const router = Router();

router.get("/signals", async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string ?? "50") || 50, 200);
    const type = req.query.type as string ?? "all";

    const conditions = type !== "all"
      ? [eq(signalsTable.type, type as "volume_spike" | "oi_increase" | "funding_rate" | "strict_alpha" | "alpha" | "super_alpha" | "short_sniper")]
      : [];

    const signals = await db.select()
      .from(signalsTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(signalsTable.detectedAt))
      .limit(limit);

    const [totalResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    res.json({
      signals: signals.map(s => ({
        ...s,
        detectedAt: s.detectedAt.toISOString(),
      })),
      total: Number(totalResult.count),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get signals");
    res.status(500).json({ error: "Failed to get signals" });
  }
});

router.get("/signals/summary", async (req, res) => {
  try {
    const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(signalsTable);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [todayResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(gte(signalsTable.detectedAt, today));

    const [strictAlphaResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(and(eq(signalsTable.type, "strict_alpha"), gte(signalsTable.detectedAt, today)));

    const [strictAlphaTotalResult] = await db.select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(eq(signalsTable.type, "strict_alpha"));

    const topSymbolsRaw = await db.select({
      symbol: signalsTable.symbol,
      count: sql<number>`count(*)`,
    })
      .from(signalsTable)
      .where(and(eq(signalsTable.type, "strict_alpha"), gte(signalsTable.detectedAt, today)))
      .groupBy(signalsTable.symbol)
      .orderBy(desc(sql`count(*)`))
      .limit(5);

    res.json({
      totalSignals: Number(totalResult.count),
      signalsToday: Number(todayResult.count),
      strictAlphaToday: Number(strictAlphaResult.count),
      strictAlphaTotal: Number(strictAlphaTotalResult.count),
      // Legacy fields kept for compatibility
      volumeSpikes: Number(strictAlphaResult.count),
      oiIncreases: 0,
      fundingRateAlerts: 0,
      topSymbols: topSymbolsRaw.map(r => ({ symbol: r.symbol, count: Number(r.count) })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get signals summary");
    res.status(500).json({ error: "Failed to get signals summary" });
  }
});

router.get("/signals/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid signal ID" });
      return;
    }

    const [signal] = await db.select().from(signalsTable).where(eq(signalsTable.id, id)).limit(1);

    if (!signal) {
      res.status(404).json({ error: "Signal not found" });
      return;
    }

    res.json({ ...signal, detectedAt: signal.detectedAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get signal");
    res.status(500).json({ error: "Failed to get signal" });
  }
});

export default router;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/subscribers.ts
// ═══════════════════════════════════════════════════════

import { Router } from "express";
import { db, subscribersTable, settingsTable, trackedSignalsTable } from "@workspace/db";
import { eq, gte, inArray, sql } from "drizzle-orm";
import { handleWebhookUpdate, sendMessage, answerCallbackQuery } from "../lib/telegram.js";
import { sendDailyReport, sendWeeklyDigest, sendMonthlyDigest } from "../lib/watcher.js";
import { getFutureTickers } from "../lib/bingx.js";

const router = Router();

router.post("/telegram/webhook", async (req, res) => {
  try {
    const body = req.body as {
      callback_query?: {
        id: string;
        data?: string;
        message?: { chat?: { id?: number } };
        from?: { id?: number };
      };
    };

    if (body.callback_query) {
      const cq = body.callback_query;
      const chatId = cq.message?.chat?.id ?? cq.from?.id;
      const data = cq.data ?? "";

      await answerCallbackQuery(cq.id);

      if (chatId) {
        if (data === "menu:open_trades") {
          const activeSignals = await db.select().from(trackedSignalsTable)
            .where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "breakeven"]));
          if (activeSignals.length === 0) {
            await sendMessage(chatId, "🟢 <b>Открытых сделок нет.</b>\n\nСканер работает в режиме реального времени.");
          } else {
            // Загружаем текущие цены для реального PnL
            const priceMap = new Map<string, number>();
            try {
              const tickers = await getFutureTickers() as { symbol: string; lastPrice: string }[];
              for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
            } catch { /* если API недоступен — покажем без PnL */ }

            const fmtPct = (n: number) => `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`;
            const fmtAge = (d: Date) => {
              const h = (Date.now() - d.getTime()) / 3_600_000;
              return h < 24 ? `${h.toFixed(0)}ч` : `${(h / 24).toFixed(1)}д`;
            };
            const statusEmoji: Record<string, string> = {
              active: "⚡", in_run: "🚀", accumulation: "⏳", breakeven: "⚖️",
            };

            const lines = [`🟢 <b>Открытые сделки (${activeSignals.length})</b>\n`];
            for (const s of activeSignals) {
              const coin = s.symbol.replace("-USDT", "");
              const curPrice = priceMap.get(s.symbol);
              const pnl = curPrice && s.entryPrice
                ? ((curPrice - s.entryPrice) / s.entryPrice) * 100
                : null;
              const peakPct = s.peakPrice && s.entryPrice
                ? ((s.peakPrice - s.entryPrice) / s.entryPrice) * 100
                : null;
              const pnlStr  = pnl  != null ? ` | Сейчас: <b>${fmtPct(pnl)}</b>` : "";
              const peakStr = peakPct != null && peakPct > 0.5 ? ` | Пик: <b>+${peakPct.toFixed(1)}%</b>` : "";
              const emo = statusEmoji[s.status] ?? "•";
              lines.push(`${emo} <b>${coin}</b> [${s.sentimentKey ?? "—"}] — ${fmtAge(s.detectedAt)}${pnlStr}${peakStr}`);
            }
            await sendMessage(chatId, lines.join("\n"));
          }
        } else if (data === "digest:daily") {
          await sendDailyReport(chatId);
        } else if (data === "digest:weekly") {
          await sendWeeklyDigest(chatId);
        } else if (data === "digest:monthly") {
          await sendMonthlyDigest(chatId);
        }
      }

      return res.json({ ok: true });
    }

    await handleWebhookUpdate(req.body);
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Webhook processing error");
    res.json({ ok: true });
  }
});

router.get("/subscribers", async (req, res) => {
  try {
    const subscribers = await db.select().from(subscribersTable)
      .orderBy(subscribersTable.subscribedAt);

    const activeCount = subscribers.filter(s => s.active).length;

    res.json({
      subscribers: subscribers.map(s => ({
        chatId: s.chatId,
        username: s.username,
        firstName: s.firstName,
        lastName: s.lastName,
        active: s.active,
        subscribedAt: s.subscribedAt.toISOString(),
        unsubscribedAt: s.unsubscribedAt?.toISOString() ?? null,
      })),
      total: subscribers.length,
      active: activeCount,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get subscribers");
    res.status(500).json({ error: "Failed to get subscribers" });
  }
});

router.get("/subscribers/stats", async (req, res) => {
  try {
    const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(subscribersTable);
    const [activeResult] = await db.select({ count: sql<number>`count(*)` })
      .from(subscribersTable).where(eq(subscribersTable.active, true));

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [todayResult] = await db.select({ count: sql<number>`count(*)` })
      .from(subscribersTable).where(gte(subscribersTable.subscribedAt, today));

    const weekAgo = new Date(Date.now() - 7 * 24 * 3600_000);
    const [weekResult] = await db.select({ count: sql<number>`count(*)` })
      .from(subscribersTable).where(gte(subscribersTable.subscribedAt, weekAgo));

    const total = Number(totalResult.count);
    const active = Number(activeResult.count);

    res.json({
      total,
      active,
      inactive: total - active,
      newToday: Number(todayResult.count),
      newThisWeek: Number(weekResult.count),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get subscriber stats");
    res.status(500).json({ error: "Failed to get subscriber stats" });
  }
});

// ── Channel test ─────────────────────────────────────────────────────────────
router.post("/telegram/test-channel", async (req, res) => {
  try {
    const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
    const channelId = rows[0]?.channelId ?? null;

    if (!channelId) {
      return res.json({ success: false, message: "Channel ID не настроен в Settings" });
    }

    const testText = [
      `✅ <b>Тест канала BingX Alpha Scanner</b>`,
      ``,
      `Канал: <code>${channelId}</code>`,
      `Время: ${new Date().toUTCString()}`,
      ``,
      `Если видишь это — бот корректно пересылает сигналы в этот канал.`,
    ].join("\n");

    const ok = await sendMessage(channelId, testText);

    if (ok) {
      res.json({ success: true, message: `Тестовое сообщение отправлено в ${channelId}` });
    } else {
      res.json({
        success: false,
        message: "Не удалось отправить. Проверь: бот добавлен в канал как Admin с правом 'Post Messages'",
      });
    }
  } catch (err) {
    req.log.error({ err }, "Channel test error");
    res.status(500).json({ success: false, message: "Ошибка сервера" });
  }
});

export default router;

// ═══════════════════════════════════════════════════════
// FILE: artifacts/api-server/src/routes/tracker.ts
// ═══════════════════════════════════════════════════════

import { Router } from "express";
import { db, trackedSignalsTable } from "@workspace/db";
import { desc, eq, and, inArray, sql } from "drizzle-orm";
import { runWatcherCycle, sendWeeklyDigest, sendDailyReport, adminBroadcast } from "../lib/watcher.js";
import { buildPositionsStatusText } from "../lib/positionsReport.js";

const router = Router();

// GET /api/tracker — list tracked signals
router.get("/tracker", async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const limit = Math.min(parseInt(req.query.limit as string ?? "100") || 100, 200);

    const where = status && status !== "all"
      ? eq(trackedSignalsTable.status, status as any)
      : undefined;

    const signals = await db.select()
      .from(trackedSignalsTable)
      .where(where)
      .orderBy(desc(trackedSignalsTable.detectedAt))
      .limit(limit);

    res.json({
      signals: signals.map(s => ({
        ...s,
        detectedAt: s.detectedAt.toISOString(),
        updatedAt:  s.updatedAt.toISOString(),
        closedAt:   s.closedAt?.toISOString() ?? null,
      })),
      total: signals.length,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch tracked signals" });
  }
});

// GET /api/tracker/stats — summary stats
router.get("/tracker/stats", async (req, res) => {
  try {
    const rows = await db.select({
      status: trackedSignalsTable.status,
      count: sql<number>`count(*)::int`,
      avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
    })
    .from(trackedSignalsTable)
    .groupBy(trackedSignalsTable.status);

    const stats: Record<string, { count: number; avgPnl: number | null }> = {};
    for (const row of rows) {
      stats[row.status] = { count: row.count, avgPnl: row.avgPnl };
    }

    const total = rows.reduce((s, r) => s + r.count, 0);
    const profits  = stats["profit"]?.count  ?? 0;
    const stops    = stats["stop_loss"]?.count ?? 0;
    const winRate  = (profits + stops) > 0 ? Math.round((profits / (profits + stops)) * 100) : null;
    const avgProfit = stats["profit"]?.avgPnl != null ? Number(stats["profit"].avgPnl) : null;
    const avgLoss   = stats["stop_loss"]?.avgPnl != null ? Number(stats["stop_loss"].avgPnl) : null;

    res.json({ stats, total, winRate, avgProfit, avgLoss });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch tracker stats" });
  }
});

// POST /api/tracker/run-cycle — manually trigger watcher cycle
router.post("/tracker/run-cycle", async (req, res) => {
  try {
    const result = await runWatcherCycle();
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ error: "Watcher cycle failed" });
  }
});

// POST /api/tracker/notify — admin broadcast custom message to all subscribers
router.post("/tracker/notify", async (req, res) => {
  try {
    const { text } = req.body as { text?: string };
    if (!text) return res.status(400).json({ error: "text required" });
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Broadcast failed" });
  }
});

// POST /api/tracker/weekly-digest — send weekly digest now
router.post("/tracker/weekly-digest", async (req, res) => {
  try {
    await sendWeeklyDigest();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Weekly digest failed" });
  }
});

// POST /api/tracker/daily-digest — send daily report now
router.post("/tracker/daily-digest", async (req, res) => {
  try {
    await sendDailyReport();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Daily report failed" });
  }
});

// POST /api/tracker/positions-update — send positions status to all subscribers now
router.post("/tracker/positions-update", async (req, res) => {
  try {
    const text = await buildPositionsStatusText();
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Positions update failed" });
  }
});

export default router;

// ═══════════════════════════════════════════════════════
// FILE: lib/db/src/index.ts
// ═══════════════════════════════════════════════════════

import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });

export * from "./schema";

// ═══════════════════════════════════════════════════════
// FILE: lib/db/src/schema/index.ts
// ═══════════════════════════════════════════════════════

export * from "./signals";
export * from "./subscribers";
// ═══════════════════════════════════════════════════════
// FILE: lib/db/src/schema/signals.ts
// ═══════════════════════════════════════════════════════

import { pgTable, serial, text, real, integer, timestamp, boolean, pgEnum, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const signalTypeEnum = pgEnum("signal_type", [
  "volume_spike",
  "oi_increase",
  "funding_rate",
  "strict_alpha",
  "alpha",
  "super_alpha",
  "short_sniper",
  "bingx_volume",
  "mexc_pump",
]);

export const signalsTable = pgTable("signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  type: signalTypeEnum("type").notNull(),
  value: real("value").notNull(),
  threshold: real("threshold").notNull(),
  price: real("price").notNull(),
  priceChangePercent: real("price_change_percent").notNull(),
  volume24h: real("volume_24h").notNull(),
  avgVolume: real("avg_volume").notNull(),
  openInterest: real("open_interest"),
  oiChangePercent: real("oi_change_percent"),
  fundingRate: real("funding_rate"),
  tradingViewUrl: text("trading_view_url").notNull(),
  // New fields for alpha/super_alpha
  cmcRank: integer("cmc_rank"),
  cmcSource: text("cmc_source"),
  liquidationsUsd: real("liquidations_usd"),
  liquidationsMultiple: real("liquidations_multiple"),
  sentiment: text("sentiment"),
  sentimentKey: text("sentiment_key"),
  alphaScore: integer("alpha_score"),
  isContinuing: boolean("is_continuing").default(false),
  cumulativeOiChange: real("cumulative_oi_change"),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signalsTable).omit({ id: true });
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signalsTable.$inferSelect;

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  volumeMultiplier: real("volume_multiplier").notNull().default(2),
  oiChangePercent: real("oi_change_percent").notNull().default(5),
  fundingRateThreshold: real("funding_rate_threshold").notNull().default(0.0005),
  scanIntervalMs: integer("scan_interval_ms").notNull().default(1800000),
  telegramEnabled: boolean("telegram_enabled").notNull().default(true),
  maxSymbols: integer("max_symbols").notNull().default(50),
  channelId: text("channel_id"),
  watchlist: text("watchlist"),  // comma-separated symbols always included in scan, e.g. "IOST-USDT,BIO-USDT"
  lastDailyReportAt: timestamp("last_daily_report_at"),     // track when daily report was last sent (missed-report guard)
  lastWeeklyDigestAt: timestamp("last_weekly_digest_at"),  // track when weekly digest was last sent (missed-digest guard)
  lastMonthlyDigestAt: timestamp("last_monthly_digest_at"), // track when monthly digest was last sent (missed-digest guard)
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;

// ── OI baselines: persisted across restarts ───────────────────────────────────
export const oiBaselinesTable = pgTable("oi_baselines", {
  symbol: text("symbol").primaryKey(),
  oi: real("oi").notNull(),
  takenAt: timestamp("taken_at").notNull(),
});

// ── Alpha Watcher: signal outcome tracking ────────────────────────────────────
export const trackedStatusEnum = pgEnum("tracked_status", [
  "active",       // Freshly created, being monitored
  "in_run",       // Hit first target +10% — now trailing stop active
  "profit",       // Closed in profit (trailing stop hit)
  "stop_loss",    // Hit stop loss (-5% long / +5% short)
  "accumulation", // 24h passed, still in range — watching up to 7 days
  "breakeven",    // 7 days passed, no clear result
  "re_entry",     // Spike detected while in accumulation
  "cancelled",    // Trade invalidated: OI dropped ≥ 5% or volume dried up
]);

export const trackedSignalsTable = pgTable("tracked_signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  signalId: integer("signal_id").references(() => signalsTable.id),
  signalType: text("signal_type").notNull(), // "alpha" | "super_alpha" | "short_sniper"
  sentiment: text("sentiment"),
  sentimentKey: text("sentiment_key"),
  alphaScore: integer("alpha_score"),
  isShort: boolean("is_short").notNull().default(false), // true for short_sniper
  entryPrice: real("entry_price").notNull(),
  entryOi: real("entry_oi"),                // OI (base asset) at the moment of signal detection
  exitPrice: real("exit_price"),
  pnlPercent: real("pnl_percent"),
  peakPrice: real("peak_price"),            // Best price seen (highest for long, lowest for short)
  trailingStopLevel: real("trailing_stop_level"), // peakPrice * 0.95 — dynamic exit level
  lastMilestone: integer("last_milestone"),  // Last milestone % announced (25, 50, 100, 200…)
  status: trackedStatusEnum("status").notNull().default("active"),
  reEntryCount: integer("re_entry_count").notNull().default(0),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
});

export const insertTrackedSignalSchema = createInsertSchema(trackedSignalsTable).omit({ id: true });
export type InsertTrackedSignal = z.infer<typeof insertTrackedSignalSchema>;
export type TrackedSignal = typeof trackedSignalsTable.$inferSelect;

// ── OI Watch List: symbols with OI spike but no volume yet ───────────────────
// When OI threshold met but volume is too low to fire a signal,
// we park the symbol here and monitor every 2 min for volume/price confirmation.
export const oiWatchStatusEnum = pgEnum("oi_watch_status", [
  "watching",    // active, being monitored every 2 min
  "fired",       // signal fired from watch list (volume confirmed)
  "expired",     // 2h elapsed without confirmation
  "confirming",  // detected condition, waiting 7 min to confirm move is sustained (not flash pump)
]);

export const oiWatchTable = pgTable("oi_watch", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  triggerTf: text("trigger_tf").notNull(),           // "5m"|"30m"|"1h"|"4h"|"24h" — what TF triggered OI
  oiChange: real("oi_change").notNull(),             // OI change % at detection
  priceAtEntry: real("price_at_entry").notNull(),    // price when added to watch
  volumeMultiplier: real("volume_multiplier").notNull(), // vol at detection
  sentimentKey: text("sentiment_key"),               // predicted pattern
  status: oiWatchStatusEnum("status").notNull().default("watching"),
  addedAt: timestamp("added_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  firedAt: timestamp("fired_at"),
  avgVolume: real("avg_volume"),                     // stored to avoid re-fetching klines
  // ── Two-stage confirmation fields ──────────────────────────────────────────
  isVolConfirmed: boolean("is_vol_confirmed").notNull().default(false), // vol was already ≥ 2x at scanner time
  signalPayload: jsonb("signal_payload"),            // full AlphaResult + InsertSignal — used to fire from watcher
}, (table) => ({
  symbolStatusIdx: index("oi_watch_symbol_status_idx").on(table.symbol, table.status),
  statusIdx:       index("oi_watch_status_idx").on(table.status),
}));

export type OiWatch = typeof oiWatchTable.$inferSelect;
export type InsertOiWatch = typeof oiWatchTable.$inferInsert;

// ── Daily OI Snapshots: long-term whale accumulation tracking ─────────────────
// One row per symbol per day. Used to detect sustained whale accumulation over weeks/months.
export const oiDailySnapshotsTable = pgTable("oi_daily_snapshots", {
  id: serial("id").primaryKey(),
  symbol:       text("symbol").notNull(),
  date:         text("date").notNull(),           // "YYYY-MM-DD" — one entry per symbol per day
  oiUsd:        real("oi_usd"),                   // Open Interest in USD from CoinGlass
  oiChange24h:  real("oi_change_24h"),            // 24h OI change %
  priceUsd:     real("price_usd"),                // price at snapshot time
  volume24h:    real("volume_24h"),               // 24h volume USD
  takenAt:      timestamp("taken_at").notNull().defaultNow(),
});

export type OiDailySnapshot = typeof oiDailySnapshotsTable.$inferSelect;
export type InsertOiDailySnapshot = typeof oiDailySnapshotsTable.$inferInsert;

// ═══════════════════════════════════════════════════════
// FILE: lib/db/src/schema/subscribers.ts
// ═══════════════════════════════════════════════════════

import { pgTable, bigint, text, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const subscribersTable = pgTable("subscribers", {
  chatId: bigint("chat_id", { mode: "number" }).primaryKey(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  active: boolean("active").notNull().default(true),
  subscribedAt: timestamp("subscribed_at").notNull().defaultNow(),
  unsubscribedAt: timestamp("unsubscribed_at"),
});

export const insertSubscriberSchema = createInsertSchema(subscribersTable);
export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;
export type Subscriber = typeof subscribersTable.$inferSelect;
