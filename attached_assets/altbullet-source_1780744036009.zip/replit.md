# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains BingX Alpha Scanner — a real-time crypto futures signal detection dashboard.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + Tailwind CSS + shadcn/ui

## Architecture

- `artifacts/api-server` — Express backend with BingX API integration, scanner engine, and Telegram alerts
- `artifacts/alpha-scanner` — React frontend dashboard (dark terminal theme)
- `lib/db` — Drizzle ORM schema: `signals`, `settings` tables
- `lib/api-spec` — OpenAPI spec for all endpoints

## Key Features

- BingX Futures market scanner (scans up to 500+ USDT perpetual pairs)
- 9 alpha signal patterns: hidden_accumulation, bullish_accumulation, aggressive_breakout, short_squeeze, bear_trap, bearish_pressure, anomaly, impulse_breakout, sharp_impulse
- PATH A price confirmation gate (per-pattern thresholds before firing)
- OI Watch: 90-min window for volume confirmation after OI spike detected
- 4h Momentum pattern (slow grind pumps, BLEND/LYN type)
- Stale signal auto-cancel at 3h if peak < 2%
- 🐋 Whale Accumulation Tracker: daily OI snapshots, weekly whale report (Сб 10:00 МСК)
  - `/whalewatch` Telegram command for on-demand analysis
  - Detects sustained OI growth (15%+) with flat price over 14–90 days
  - HIGH/MEDIUM confidence badges
- Telegram notifications in Russian with speed labels (🚀/⏳/⚠️) and price confirmation
- Daily/Weekly/Monthly digest reports
- Configurable thresholds via UI settings page
- Auto-refresh dashboard every 5-10 seconds

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Required Secrets

- `BINGX_API_KEY` — BingX API key
- `BINGX_API_SECRET` — BingX API secret
- `TELEGRAM_BOT_TOKEN` — Telegram bot token
- `TELEGRAM_CHAT_ID` — Telegram chat ID for alerts
