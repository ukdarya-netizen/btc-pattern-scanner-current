import { pgTable, serial, text, real, integer, timestamp, boolean, pgEnum, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const signalTypeEnum = pgEnum("signal_type", [
  "volume_spike",
  "oi_increase",
  "funding_rate",
  "strict_alpha",
  "alpha",
  "super_alpha",
  "short_sniper",
  "bingx_volume",
  "mexc_pump",
  "whale_watch",
]);

export const signalsTable = pgTable("signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  type: signalTypeEnum("type").notNull(),
  value: real("value").notNull(),
  threshold: real("threshold").notNull(),
  price: real("price").notNull(),
  priceChangePercent: real("price_change_percent").notNull(),
  volume24h: real("volume_24h").notNull(),
  avgVolume: real("avg_volume").notNull(),
  openInterest: real("open_interest"),
  oiChangePercent: real("oi_change_percent"),
  fundingRate: real("funding_rate"),
  tradingViewUrl: text("trading_view_url").notNull(),
  // New fields for alpha/super_alpha
  cmcRank: integer("cmc_rank"),
  cmcSource: text("cmc_source"),
  liquidationsUsd: real("liquidations_usd"),
  liquidationsMultiple: real("liquidations_multiple"),
  sentiment: text("sentiment"),
  sentimentKey: text("sentiment_key"),
  alphaScore: integer("alpha_score"),
  isContinuing: boolean("is_continuing").default(false),
  cumulativeOiChange: real("cumulative_oi_change"),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signalsTable).omit({ id: true });
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signalsTable.$inferSelect;

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  volumeMultiplier: real("volume_multiplier").notNull().default(2),
  oiChangePercent: real("oi_change_percent").notNull().default(5),
  fundingRateThreshold: real("funding_rate_threshold").notNull().default(0.0005),
  scanIntervalMs: integer("scan_interval_ms").notNull().default(1800000),
  telegramEnabled: boolean("telegram_enabled").notNull().default(true),
  maxSymbols: integer("max_symbols").notNull().default(50),
  channelId: text("channel_id"),
  watchlist: text("watchlist"),  // comma-separated symbols always included in scan, e.g. "IOST-USDT,BIO-USDT"
  whaleWatchStagesJson: text("whale_watch_stages_json"), // persisted whale watch stages across restarts
  lastDailyReportAt: timestamp("last_daily_report_at"),         // daily report dedup
  lastWeeklyDigestAt: timestamp("last_weekly_digest_at"),       // weekly digest dedup
  lastMonthlyDigestAt: timestamp("last_monthly_digest_at"),     // monthly digest dedup
  lastRestartNotifiedAt: timestamp("last_restart_notified_at"), // restart notification dedup across processes
  lastPositionsReportAt: timestamp("last_positions_report_at"), // positions update dedup across processes
  scannerLastScanAt: timestamp("scanner_last_scan_at"),          // cross-process: last successful scan time
  lastCoinalyzeBatchAt: timestamp("last_coinalyze_batch_at"),   // cross-process dedup for Coinalyze OI batch
  // ── Smart Cancel thresholds ──────────────────────────────────────────────────
  smartCancelBidWallUsd: real("smart_cancel_bid_wall_usd").default(50_000), // мин. размер стены в стакане для блокировки отмены ($)
  smartCancelOiPct: real("smart_cancel_oi_pct").default(5.0),               // мин. рост OI за 4ч (%) для блокировки отмены
  // ── Moonshot Momentum thresholds ─────────────────────────────────────────────
  moonshotVolMult: real("moonshot_vol_mult").default(5.0),         // мин. объём (x) для паттерна Moonshot
  moonshotPriceChange: real("moonshot_price_change").default(15.0), // мин. рост цены (%) за 30m свечу
  moonshotOiChange: real("moonshot_oi_change").default(10.0),       // мин. рост OI (%) для Moonshot
  moonshotAskWallUsd: real("moonshot_ask_wall_usd").default(50_000), // мин. стена на продажу ($) которая БЛОКИРУЕТ Moonshot
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;

// ── OI baselines: persisted across restarts ───────────────────────────────────
export const oiBaselinesTable = pgTable("oi_baselines", {
  symbol: text("symbol").primaryKey(),
  oi: real("oi").notNull(),
  takenAt: timestamp("taken_at").notNull(),
});

// ── Alpha Watcher: signal outcome tracking ────────────────────────────────────
export const trackedStatusEnum = pgEnum("tracked_status", [
  "active",       // Freshly created, being monitored
  "in_run",       // Hit first target +10% — now trailing stop active
  "profit",       // Closed in profit (trailing stop hit)
  "stop_loss",    // Hit stop loss (-5% long / +5% short)
  "bu_stop",      // Stopped at breakeven (in_run, price returned to entry) — counts as profit
  "accumulation", // 24h passed, still in range — watching up to 7 days
  "breakeven",    // 7 days passed, no clear result
  "re_entry",     // Spike detected while in accumulation
  "cancelled",    // Trade invalidated: OI dropped ≥ 5% or volume dried up
]);

export const trackedSignalsTable = pgTable("tracked_signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  signalId: integer("signal_id").references(() => signalsTable.id),
  signalType: text("signal_type").notNull(), // "alpha" | "super_alpha" | "short_sniper"
  sentiment: text("sentiment"),
  sentimentKey: text("sentiment_key"),
  alphaScore: integer("alpha_score"),
  isShort: boolean("is_short").notNull().default(false), // true for short_sniper
  entryPrice: real("entry_price").notNull(),
  entryOi: real("entry_oi"),                // OI (base asset) at the moment of signal detection
  exitPrice: real("exit_price"),
  pnlPercent: real("pnl_percent"),
  peakPrice: real("peak_price"),            // Best price seen (highest for long, lowest for short)
  trailingStopLevel: real("trailing_stop_level"), // peakPrice * 0.95 — dynamic exit level
  lastMilestone: integer("last_milestone"),  // Last milestone % announced (25, 50, 100, 200…)
  lastHourlyAt: timestamp("last_hourly_at"),           // hourly update dedup
  lastPeriodicUpdateAt: timestamp("last_periodic_update_at"), // 4h periodic update dedup
  lastVolBuildAt: timestamp("last_vol_build_at"),       // accum vol-building alert dedup
  lastOiBuildAt: timestamp("last_oi_build_at"),         // accum OI-building alert dedup
  status: trackedStatusEnum("status").notNull().default("active"),
  reEntryCount: integer("re_entry_count").notNull().default(0),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
});

export const insertTrackedSignalSchema = createInsertSchema(trackedSignalsTable).omit({ id: true });
export type InsertTrackedSignal = z.infer<typeof insertTrackedSignalSchema>;
export type TrackedSignal = typeof trackedSignalsTable.$inferSelect;

// ── OI Watch List: symbols with OI spike but no volume yet ───────────────────
// When OI threshold met but volume is too low to fire a signal,
// we park the symbol here and monitor every 2 min for volume/price confirmation.
export const oiWatchStatusEnum = pgEnum("oi_watch_status", [
  "watching",    // active, being monitored every 2 min
  "fired",       // signal fired from watch list (volume confirmed)
  "expired",     // 2h elapsed without confirmation
  "confirming",  // detected condition, waiting 7 min to confirm move is sustained (not flash pump)
]);

export const oiWatchTable = pgTable("oi_watch", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  triggerTf: text("trigger_tf").notNull(),           // "5m"|"30m"|"1h"|"4h"|"24h" — what TF triggered OI
  oiChange: real("oi_change").notNull(),             // OI change % at detection
  priceAtEntry: real("price_at_entry").notNull(),    // price when added to watch
  volumeMultiplier: real("volume_multiplier").notNull(), // vol at detection
  sentimentKey: text("sentiment_key"),               // predicted pattern
  oi5mChange:  real("oi_5m"),                        // CoinGlass 5m OI % at detection
  oi30mChange: real("oi_30m"),                       // CoinGlass 30m OI % at detection
  oi1hChange:  real("oi_1h"),                        // CoinGlass 1h OI % at detection
  status: oiWatchStatusEnum("status").notNull().default("watching"),
  addedAt: timestamp("added_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  firedAt: timestamp("fired_at"),
  avgVolume: real("avg_volume"),                     // stored to avoid re-fetching klines
  // ── Two-stage confirmation fields ──────────────────────────────────────────
  isVolConfirmed: boolean("is_vol_confirmed").notNull().default(false), // vol was already ≥ 2x at scanner time
  signalPayload: jsonb("signal_payload"),            // full AlphaResult + InsertSignal — used to fire from watcher
}, (table) => ({
  symbolStatusIdx: index("oi_watch_symbol_status_idx").on(table.symbol, table.status),
  statusIdx:       index("oi_watch_status_idx").on(table.status),
}));

export type OiWatch = typeof oiWatchTable.$inferSelect;
export type InsertOiWatch = typeof oiWatchTable.$inferInsert;

// ── Daily OI Snapshots: long-term whale accumulation tracking ─────────────────
// One row per symbol per day. Used to detect sustained whale accumulation over weeks/months.
export const oiDailySnapshotsTable = pgTable("oi_daily_snapshots", {
  id: serial("id").primaryKey(),
  symbol:       text("symbol").notNull(),
  date:         text("date").notNull(),           // "YYYY-MM-DD" — one entry per symbol per day
  oiUsd:        real("oi_usd"),                   // Open Interest in USD from CoinGlass
  oiChange24h:  real("oi_change_24h"),            // 24h OI change %
  priceUsd:     real("price_usd"),                // price at snapshot time
  volume24h:    real("volume_24h"),               // 24h volume USD
  takenAt:      timestamp("taken_at").notNull().defaultNow(),
});

export type OiDailySnapshot = typeof oiDailySnapshotsTable.$inferSelect;
export type InsertOiDailySnapshot = typeof oiDailySnapshotsTable.$inferInsert;

// ── Whale Watch 2.0: Spot CVD Accumulation Watchlist ─────────────────────────
// Each row = one symbol being monitored for whale accumulation via Spot CVD.
// avgBuyPrice tracks weighted-average price of accumulation periods for Smart Cancel.
export const whaleWatchlistTable = pgTable("whale_watchlist", {
  id:              serial("id").primaryKey(),
  symbol:          text("symbol").notNull().unique(),
  firstSeenAt:     timestamp("first_seen_at").notNull().defaultNow(),
  updatedAt:       timestamp("updated_at").notNull().defaultNow(),
  /** Накопленный спот CVD (сумма нетто-покупок в USD) за период наблюдения */
  accumulatedCvdUsd: real("accumulated_cvd_usd").notNull().default(0),
  /** Количество накопительных 5m периодов подряд (или с момента добавления) */
  accumPeriods:    integer("accum_periods").notNull().default(0),
  /** Средневзвешенная цена накопления (для Smart Cancel) */
  avgBuyPrice:     real("avg_buy_price"),
  /** Market Cap токена USD (CoinGecko, кэш 24ч) */
  marketCapUsd:    real("market_cap_usd"),
  /** 24h объём споте USD на момент добавления */
  vol24hUsd:       real("vol24h_usd"),
  /** Цена при первом обнаружении */
  priceAtEntry:    real("price_at_entry"),
  /** Последняя известная цена */
  lastPrice:       real("last_price"),
  /** Алерт о входе в накопление уже отправлен */
  alertedAt:       timestamp("alerted_at"),
  /** Сигнал пробоя уже отправлен (breakout fired) */
  breakoutFiredAt: timestamp("breakout_fired_at"),
  /** Статус: watching | accumulating | breakout | expired */
  status:          text("status").notNull().default("watching"),
});

export type WhaleWatchlistRow = typeof whaleWatchlistTable.$inferSelect;
export type InsertWhaleWatchlist = typeof whaleWatchlistTable.$inferInsert;

// ── Prescan Tracker: persist cycle counts across restarts ─────────────────────
// Key fields saved after every scan cycle so cycleCount / firstSeenAt survive
// server rebuilds. Volatile per-cycle fields (lastOi*, lastScore, etc.) are
// recomputed on the next scan and are NOT stored here.
// ── Whale Futures Watchlist: spot buy detection + retail futures confirmation ──
// Phase 1 (scanner): single large spot buy + OI growing → added here.
// Phase 2 (watcher fast cycle): retail taker flow >= 15% + funding > 0 → fire signal.
// Window: 72 hours. One active entry per symbol (UNIQUE on symbol + watching).
export const whaleFuturesWatchlistTable = pgTable("whale_futures_watchlist", {
  id:               serial("id").primaryKey(),
  symbol:           text("symbol").notNull(),
  detectedAt:       timestamp("detected_at").notNull().defaultNow(),
  expiresAt:        timestamp("expires_at").notNull(),
  priceAtDetection: real("price_at_detection").notNull(),
  oi30mAtDetection: real("oi_30m_at_detection"),
  oi1hAtDetection:  real("oi_1h_at_detection"),
  /** "watching" | "fired" | "expired" */
  status:           text("status").notNull().default("watching"),
  /** "futures" | "spot" — тип детектора */
  type:             text("type").notNull().default("futures"),
  firedAt:          timestamp("fired_at"),
  lastCheckedAt:    timestamp("last_checked_at"),
  checkCount:       integer("check_count").notNull().default(0),
  // Spot price tracking (Variant A): price % change vs priceAtDetection
  price24hPct:      real("price_24h_pct"),
  price48hPct:      real("price_48h_pct"),
  price7dMaxPct:    real("price_7d_max_pct"),
}, (table) => ({
  symbolStatusIdx: index("wf_symbol_status_idx").on(table.symbol, table.status),
}));

export type WhaleFuturesWatchlistRow = typeof whaleFuturesWatchlistTable.$inferSelect;
export type InsertWhaleFuturesWatchlist = typeof whaleFuturesWatchlistTable.$inferInsert;

export const prescanTrackerTable = pgTable("prescan_tracker", {
  symbol:        text("symbol").primaryKey(),
  cycleCount:    integer("cycle_count").notNull().default(1),
  firstSeenAt:   real("first_seen_at").notNull(),   // unix ms (stored as float)
  bestRank:      integer("best_rank").notNull().default(1),
  firstPrice:    real("first_price").notNull(),
  firstPrice24h: real("first_price_24h").notNull(),
  firstScore:    real("first_score").notNull(),
  lastFiredAt:   real("last_fired_at").notNull().default(0), // unix ms; 0 = never
  updatedAt:     timestamp("updated_at").notNull().defaultNow(),
});

export type PrescanTrackerRow = typeof prescanTrackerTable.$inferSelect;

// ── Signal Whale Seeds: cancelled signals with OI spike → long-term monitoring ─
// When a signal is cancelled but had a meaningful OI spike (≥3%) at detection,
// it gets seeded here for Whale Watch to track over the next 90 days.
// If OI continues to grow → it surfaces in whale accumulation reports.
export const signalWhaleSeedsTable = pgTable("signal_whale_seeds", {
  id:              serial("id").primaryKey(),
  symbol:          text("symbol").notNull(),
  trackedSignalId: integer("tracked_signal_id").references(() => trackedSignalsTable.id),
  signalId:        integer("signal_id").references(() => signalsTable.id),
  sentimentKey:    text("sentiment_key"),
  oiAtSeed:        real("oi_at_seed"),       // cumulative OI % at time of original signal detection
  priceAtSeed:     real("price_at_seed"),    // price at time of cancel
  seededAt:        timestamp("seeded_at").notNull().defaultNow(),
  expiresAt:       timestamp("expires_at").notNull(),
  status:          text("status").notNull().default("watching"), // watching | graduated | expired
  oiAtFirstSnap:   real("oi_at_first_snap"), // first OI snapshot after seeding (USD) — baseline
  lastOiUsd:       real("last_oi_usd"),      // most recent OI snapshot USD
  lastCheckedAt:   timestamp("last_checked_at"),
  oiGrowthPct:     real("oi_growth_pct"),    // growth from first snap to last snap
}, (table) => ({
  symbolStatusIdx: index("signal_whale_seeds_symbol_status_idx").on(table.symbol, table.status),
}));

export type SignalWhaleSeed = typeof signalWhaleSeedsTable.$inferSelect;
export type InsertSignalWhaleSeed = typeof signalWhaleSeedsTable.$inferInsert;
