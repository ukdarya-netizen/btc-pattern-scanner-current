# AltBullet Bot — Audit: Restart Notification Flow

Цель аудита: найти причину, по которой уведомление о рестарте иногда НЕ приходит, приходит дважды, или приходит с неверным содержимым.

---

## 1. index.ts — точка входа, запуск watcher

```typescript
// artifacts/api-server/src/index.ts (полный файл, 137 строк)

import app from "./app";
import { logger } from "./lib/logger";
import { pool, db, settingsTable } from "@workspace/db";
import { setWebhook, registerBotCommands } from "./lib/telegram.js";
import { startScanner, stopScanner, getLastScanAt } from "./lib/scanner.js";
import { startWatcher, startWatchdog, broadcast } from "./lib/watcher.js";
import { lt, sql as drizzleSql } from "drizzle-orm";

async function runStartupMigration() {
  try {
    await db.execute(drizzleSql`ALTER TABLE settings ADD COLUMN IF NOT EXISTS scanner_last_scan_at TIMESTAMP`);
    const updated = await db.update(settingsTable)
      .set({ oiChangePercent: 8 })
      .where(lt(settingsTable.oiChangePercent, 8))
      .returning({ oiChangePercent: settingsTable.oiChangePercent });
    if (updated.length > 0) logger.info({ newThreshold: 8 }, "Startup migration: oiChangePercent обновлён до 8%");
  } catch (err) {
    logger.warn({ err }, "Startup migration: ошибка (non-critical)");
  }
}

pool.on("error", (err) => {
  logger.warn({ err: String(err) }, "pg pool: idle client error (Neon closed connection) — pool will reconnect automatically");
});

process.on("unhandledRejection", (reason, promise) => {
  logger.error({ reason, promise: String(promise) }, "⚠️ Unhandled promise rejection — caught, server stays alive");
});

process.on("uncaughtException", (err) => {
  logger.error({ err }, "⚠️ Uncaught exception — caught, server stays alive");
});

let isShuttingDown = false;
async function gracefulShutdown(signal: string) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  logger.info({ signal }, "Graceful shutdown: получен сигнал, останавливаем сканер...");
  try {
    await stopScanner();
  } catch { /* non-critical */ }
  await new Promise(resolve => setTimeout(resolve, 5_000));
  logger.info("Graceful shutdown: завершено, выходим");
  process.exit(0);
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT",  () => gracefulShutdown("SIGINT"));

const rawPort = process.env["PORT"];
if (!rawPort) throw new Error("PORT environment variable is required but was not provided.");
const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) throw new Error(`Invalid PORT value: "${rawPort}"`);

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Webhook регистрируем ТОЛЬКО в production
  const domains = process.env.REPLIT_DOMAINS;
  if (domains && process.env.NODE_ENV !== "development") {
    const domain = domains.split(",")[0].trim();
    const webhookUrl = `https://${domain}/api/telegram/webhook`;
    const ok = await setWebhook(webhookUrl);
    if (ok) {
      logger.info({ webhookUrl }, "Telegram webhook registered");
    } else {
      logger.warn("Failed to register Telegram webhook — bot subscriptions may not work");
    }
    await registerBotCommands();
  } else if (process.env.NODE_ENV === "development") {
    logger.info("DEV mode — webhook registration skipped (production webhook preserved)");
  } else {
    logger.info("REPLIT_DOMAINS not set, skipping webhook registration");
  }

  // One-time migration
  if (process.env.NODE_ENV !== "development") {
    runStartupMigration().catch(() => {/* logged inside */});
  }

  // В dev-режиме сканер и watcher НЕ запускаются
  if (process.env.NODE_ENV === "development") {
    logger.info("DEV mode — scanner and watcher NOT started (production only)");
  } else {
    // Auto-start scanner on server boot
    startScanner().catch(err => logger.error({ err }, "Failed to auto-start scanner"));

    // Auto-start alpha watcher
    startWatcher();

    // Auto-start watchdog
    const restartScanner = async () => {
      await stopScanner();
      await startScanner();
    };
    startWatchdog(getLastScanAt, restartScanner);
  }

  // Startup notification отправляется из sendBotRestartNotification() через 7 мин
  // (после первого watcher цикла) с DB-дедупликацией.
});
```

---

## 2. watcher.ts — sendBotRestartNotification (строки 385–454)

```typescript
// artifacts/api-server/src/lib/watcher.ts

async function sendBotRestartNotification(): Promise<void> {
  // ── Шаг 1: атомарный guard с собственным retry (до 3 попыток, 30с) ──────────
  // Guard UPDATE вынесен в отдельный цикл потому что DB connection pool
  // перегружен в первые ~2 мин после старта. Если guard UPDATE падает с DB timeout
  // и нет retry, вся функция бросает исключение, .catch() снаружи глотает его молча,
  // и last_restart_notified_at остаётся на старом значении — уведомление теряется.
  let claimed = false;
  for (let guardAttempt = 1; guardAttempt <= 3; guardAttempt++) {
    try {
      const restartThreshold = new Date(Date.now() - 5 * 60 * 1000);
      const rows = await db.update(settingsTable)
        .set({ lastRestartNotifiedAt: new Date() })
        .where(sql`id = (SELECT id FROM settings LIMIT 1) AND (last_restart_notified_at IS NULL OR last_restart_notified_at < ${restartThreshold})`)
        .returning({ id: settingsTable.id });
      if (rows.length === 0) {
        logger.info("Restart notification skipped — другой процесс уже отправил");
        return;
      }
      claimed = true;
      break;
    } catch (err) {
      logger.warn({ err, guardAttempt }, "Restart notification: guard DB error, retry in 30s");
      if (guardAttempt < 3) await new Promise(r => setTimeout(r, 30_000));
    }
  }
  if (!claimed) {
    logger.error("Restart notification: guard claim failed after 3 attempts — уведомление не отправлено");
    return;
  }

  // ── Шаг 2: отправка с retry ───────────────────────────────────────────────
  // Retry loop: 3 попытки с задержкой 60с.
  // getTargets() вызывается ВНУТРИ цикла — если первая попытка упала из-за DB,
  // вторая через 60с сделает свежий запрос к уже восстановившейся БД.
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const text = `🔄 <b>Бот перезапущен. Мониторинг возобновлён.</b>\n\nАктуальные позиции: /status`;

      const targets = await getTargets();
      if (targets.length === 0) {
        logger.warn({ attempt }, "Restart notification: нет получателей — пропускаем");
        return;
      }

      let sent = 0;
      for (const target of targets) {
        try {
          await sendMessage(target, text);
          sent++;
        } catch (err) {
          logger.warn({ err, target, attempt }, "Restart notification: sendMessage failed for target");
        }
      }

      if (sent > 0) {
        logger.info({ sent, total: targets.length }, "🔄 Bot restart notification sent");
        return;
      }
      logger.warn({ attempt, total: targets.length }, "Restart notification: все отправки упали, retry через 60с");
    } catch (err) {
      logger.warn({ err, attempt }, "Restart notification: ошибка (DB/Telegram/getTargets), retry через 60с");
    }

    if (attempt < 3) await new Promise(r => setTimeout(r, 60_000));
  }
  logger.error("🔄 Restart notification: все 3 попытки провалились — уведомление не отправлено");
}
```

---

## 3. watcher.ts — startWatcher(), место вызова sendBotRestartNotification (строки 2720–2741)

```typescript
// artifacts/api-server/src/lib/watcher.ts (внутри startWatcher())

// Watcher cycle every 10 min — handles ONLY accumulation signals.
// Starts at 7 min to avoid any race with the first FastCycle (at 2 min).
// Уведомление о рестарте — отправляем ПОСЛЕ завершения первого watcher цикла,
// чтобы stale-cancel и все обновления уже применились.
let restartNotifSent = false;
const runCycle = async () => {
  if (!cycleTimer) return;
  try {
    const r = await runWatcherCycle();
    logger.info(r, "Watcher cycle complete");
  } catch (err) {
    logger.error({ err }, "Watcher cycle error");
  }
  // Уведомление о рестарте — после первого цикла независимо от его успеха/ошибки.
  // Раньше было внутри try, и если цикл падал — уведомление не уходило никогда.
  if (!restartNotifSent && process.env.NODE_ENV !== "development") {
    restartNotifSent = true;
    sendBotRestartNotification().catch(err => logger.warn({ err }, "Restart notification failed (non-critical)"));
  }
  cycleTimer = setTimeout(runCycle, 10 * 60 * 1000);
};
cycleTimer = setTimeout(runCycle, 7 * 60 * 1000);
```

**Итого**: уведомление о рестарте отправляется через **~7 минут** после старта (после первого watcher цикла).

---

## 4. telegram.ts — getTargets() (строки 601–648)

```typescript
// artifacts/api-server/src/lib/telegram.ts

const _chatIdCache = new Map<string, number>();

async function resolveToNumericId(username: string): Promise<number | null> {
  const key = username.toLowerCase();
  if (_chatIdCache.has(key)) return _chatIdCache.get(key)!;
  try {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    if (!token) return null;
    const res = await fetch(`https://api.telegram.org/bot${token}/getChat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: username }),
    });
    if (!res.ok) return null;
    const data = await res.json() as { ok: boolean; result?: { id: number } };
    if (data.ok && data.result?.id) {
      _chatIdCache.set(key, data.result.id);
      return data.result.id;
    }
  } catch { /* ignore — fall back to string dedup */ }
  return null;
}

export async function getTargets(): Promise<(number | string)[]> {
  const seenNumeric = new Set<number>();
  const seenString = new Set<string>();
  const targets: (number | string)[] = [];

  const addTarget = async (id: number | string) => {
    if (typeof id === "number") {
      if (!seenNumeric.has(id)) { seenNumeric.add(id); targets.push(id); }
    } else if (id.startsWith("@")) {
      const numId = await resolveToNumericId(id);
      if (numId !== null) {
        if (!seenNumeric.has(numId)) { seenNumeric.add(numId); targets.push(numId); }
      } else {
        const key = id.toLowerCase();
        if (!seenString.has(key)) { seenString.add(key); targets.push(id); }
      }
    } else {
      const key = id.toLowerCase();
      if (!seenString.has(key)) { seenString.add(key); targets.push(id); }
    }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) await addTarget(asNum);
    else if (envId.startsWith("@")) await addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers
  const activeSubscribers = await db.select({ chatId: subscribersTable.chatId })
    .from(subscribersTable)
    .where(eq(subscribersTable.active, true));
  for (const s of activeSubscribers) await addTarget(s.chatId);

  // Always add channelId from settings
  const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
  const ch = rows[0]?.channelId?.trim();
  if (ch) await addTarget(ch);

  return targets;
}
```

---

## 5. telegram.ts — sendMessage() (строки 10–44)

```typescript
// artifacts/api-server/src/lib/telegram.ts

export async function sendMessage(chatId: number | string, text: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;

  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: false,
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram send failed");
      if (res.status === 403) {
        // Авто-отписка при "bot was blocked by the user"
        await db.update(subscribersTable)
          .set({ active: false, unsubscribedAt: new Date() })
          .where(eq(subscribersTable.chatId, Number(chatId)));
      }
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Telegram send error");
    return false;
  }
}
```

**Потенциальная проблема**: при `status 403` (бот заблокирован пользователем) код пытается `db.update(subscribersTable).where(eq(subscribersTable.chatId, Number(chatId)))`. Если `chatId` — это ID канала (строка типа `"-100xxxxx"`), `Number(chatId)` может вернуть NaN или неверный ID, и `eq()` с Drizzle bigint может упасть.

---

## 6. telegram.ts — handleWebhookUpdate() (строки 955–1118)

```typescript
// artifacts/api-server/src/lib/telegram.ts

export async function handleWebhookUpdate(update: unknown): Promise<void> {
  const upd = update as {
    message?: {
      chat: { id: number };
      from?: { id: number; username?: string; first_name?: string; last_name?: string };
      text?: string;
    };
    channel_post?: {
      chat: { id: number };
      from?: { id: number; username?: string; first_name?: string; last_name?: string };
      text?: string;
    };
  };

  const msg = upd.message ?? upd.channel_post;
  if (!msg) return;

  const chatId = msg.chat.id;   // куда отвечать
  const userId = msg.from?.id ?? msg.chat.id;  // кто отправил
  const text = msg.text ?? "";
  const command = text.split("@")[0].toLowerCase();

  // Определение владельца: OWNER_CHAT_ID (личный ID) или TELEGRAM_CHAT_ID (может быть канал!)
  const ownerChatIdRaw = process.env.OWNER_CHAT_ID ?? process.env.TELEGRAM_CHAT_ID;
  const ownerChatId = ownerChatIdRaw ? Number(ownerChatIdRaw) : null;
  const isOwner = ownerChatId !== null && userId === ownerChatId;

  // Подписчик проверяется по userId (личный ID, не ID группы/канала)
  const [sub] = await db.select()
    .from(subscribersTable)
    .where(eq(subscribersTable.chatId, userId))
    .limit(1);
  const isSubscriber = sub?.active === true;

  // /myid — доступна всем (помогает узнать свой ID для OWNER_CHAT_ID)
  if (command === "/myid") {
    await sendMessage(chatId, `🆔 Твой Telegram User ID: <code>${userId}</code>\n\nПередай его администратору для активации.`);
    return;
  }

  if (command === "/start") {
    if (isSubscriber) {
      await sendMessage(chatId, ALREADY_SUBSCRIBED_TEXT);
    } else {
      await sendMessageWithKeyboard(chatId, WELCOME_TEXT, PAYMENT_KEYBOARD);
    }
    return;
  }

  if (command === "/prices" || command === "/pricing") {
    await sendMessageWithKeyboard(chatId, PRICES_TEXT, [[{ text: "✍️ Написать админу", url: "https://t.me/darshakl" }]]);
    return;
  }

  // Тестовая команда для владельца
  if (command === "/activate_test" && isOwner) {
    await activateSubscriber(userId, msg.from?.username ?? null, msg.from?.first_name ?? null, msg.from?.last_name ?? null);
    await sendMessageWithKeyboard(chatId, ACTIVATION_TEXT, DIGEST_KEYBOARD);
    return;
  }

  // Все остальные команды — только для подписчиков (и владельца)
  if (!isSubscriber && !isOwner) {
    await sendMessageWithKeyboard(chatId, WELCOME_TEXT, PAYMENT_KEYBOARD);
    return;
  }

  if (command === "/menu") {
    await sendMessageWithKeyboard(chatId, [...], DIGEST_KEYBOARD);
  } else if (command === "/stop" || command === "/unsubscribe") {
    await db.update(subscribersTable)
      .set({ active: false, unsubscribedAt: new Date() })
      .where(eq(subscribersTable.chatId, userId));
    await sendMessage(chatId, `❌ <b>Unsubscribed.</b>...`);
  } else if (command === "/status" || command === "/positions") {
    await sendMessage(chatId, `📊 Загружаю позиции...`);
    try {
      const text = await buildPositionsStatusText();
      await sendMessage(chatId, text);
    } catch (err) {
      await sendMessage(chatId, `❌ Ошибка при загрузке позиций. Попробуй позже.`);
    }
  } else if (command === "/whalewatch") {
    // ... отдельный обработчик
  }
}
```

---

## 7. routes/subscribers.ts — webhook route (строки 12–168)

```typescript
// artifacts/api-server/src/routes/subscribers.ts

router.post("/telegram/webhook", async (req, res) => {
  try {
    const body = req.body as { callback_query?: { id: string; data?: string; ... } };

    // ── callback_query (кнопки) ───────────────────────────────────────────────
    if (body.callback_query) {
      const cq = body.callback_query;
      const chatId = cq.message?.chat?.id ?? cq.from?.id;
      const data = cq.data ?? "";

      await answerCallbackQuery(cq.id);

      if (chatId) {
        if (data === "payment_pending") { ... }
        else if (data === "menu:open_trades") {
          const text = await buildPositionsStatusText();
          await sendMessage(chatId, text);
        }
        else if (data === "digest:daily")   { await sendDailyReport(chatId); }
        else if (data === "digest:weekly")  { await sendWeeklyDigest(chatId); }
        else if (data === "digest:monthly") { await sendMonthlyDigest(chatId); }
        else if (data === "whale_tracker")  { ... }
        else if (data === "settings")       { ... }
      }
      return res.json({ ok: true });
    }

    // ── /whalewatch текстовая команда (обрабатывается ДО handleWebhookUpdate) ─
    const msgText = (req.body as { message?: { text?: string; chat?: { id?: number } } })?.message;
    if (msgText?.text?.toLowerCase().startsWith("/whalewatch")) {
      const chatId = msgText.chat?.id;
      if (chatId) {
        // ... whale watch logic
        return res.json({ ok: true });
      }
    }

    // ── всё остальное → handleWebhookUpdate ──────────────────────────────────
    await handleWebhookUpdate(req.body);
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Webhook processing error");
    res.json({ ok: true });
  }
});
```

---

## Ключевые вопросы для аудита

### Проблема 1: Когда именно приходит restart notification?
- `startWatcher()` вызывается сразу после `app.listen()` (синхронно)
- Первый `runCycle()` — через **7 минут** (`setTimeout(runCycle, 7 * 60 * 1000)`)
- `sendBotRestartNotification()` вызывается **после** первого watcher цикла (который сам может занять 1–2 мин)
- Итого: уведомление приходит через **~8–10 минут** после деплоя

### Проблема 2: 2 воркер-процесса (Replit production)
- Production запускает **2 worker processes** (pid=19, pid=21)
- Оба вызывают `startWatcher()` и оба через 7 мин попытаются вызвать `sendBotRestartNotification()`
- DB guard (`UPDATE ... WHERE last_restart_notified_at IS NULL OR < threshold RETURNING id`) должен гарантировать, что только 1 процесс выиграет
- **Риск**: если оба процесса стартуют с разницей > 5 мин — guard порог 5 мин пропустит второй процесс

### Проблема 3: `getTargets()` добавляет подписчиков
- При рестарте уведомление уходит всем активным подписчикам (subscribers table) + TELEGRAM_CHAT_ID + channelId
- Если кто-то новый подписался, он тоже получит "бот перезапущен"

### Проблема 4: `_chatIdCache` — in-process кэш
- Кэш разрешения @username → numeric ID хранится в памяти (`Map`)
- При каждом рестарте кэш пустой → новый `getChat` API запрос к Telegram
- Если запрос падает — возможен дублирующий `@username` в targets (не критично)

### Проблема 5: sendMessage + 403 auto-unsubscribe
- Если `chatId` — строковый ID канала (не число), `Number(chatId)` может дать NaN
- `eq(subscribersTable.chatId, NaN)` — поведение Drizzle с bigint не определено, может бросить ошибку

### Переменные окружения
- `TELEGRAM_CHAT_ID` — ID личного чата или канала (уходит в getTargets как первый target)
- `OWNER_CHAT_ID` — личный Telegram ID владельца (7818695412) — для isOwner проверки в handleWebhookUpdate
- `TELEGRAM_BOT_TOKEN` — токен бота

---

## Схема вызовов restart notification

```
app.listen() → startWatcher()
  └─ setTimeout(runCycle, 7min)
       └─ runWatcherCycle()   [может занять 1-2мин]
       └─ if !restartNotifSent:
            restartNotifSent = true
            sendBotRestartNotification()
              └─ DB guard UPDATE (3 retry × 30s)
              └─ if claimed:
                   getTargets()     [TELEGRAM_CHAT_ID + subscribers + channelId]
                   sendMessage() × N  [3 retry × 60s]
```
