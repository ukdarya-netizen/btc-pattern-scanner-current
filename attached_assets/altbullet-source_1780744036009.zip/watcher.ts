import { logger } from "./logger.js";
import { db, trackedSignalsTable, settingsTable, subscribersTable, oiWatchTable, signalsTable } from "@workspace/db";
import type { TrackedSignal, InsertTrackedSignal, OiWatch, InsertSignal } from "@workspace/db";
import { eq, and, inArray, sql, lt } from "drizzle-orm";
import { getFutureTickers, getOpenInterest, getKlines, fetchCVD } from "./bingx.js";
import { getMexcFuturesTickers } from "./mexc.js";
import { sendMessage, broadcastBatchAlert, formatAlphaSignal, broadcastWhaleAccumAlert } from "./telegram.js";
import type { WhaleAccumSignalInput } from "./telegram.js";
import { getCoinglassOI, batchGetCoinglassOI } from "./coinglass_oi.js";
import { saveDailyOiSnapshots, getAllWhaleAccumCandidates } from "./whaleTracker.js";
import { buildPositionsStatusText } from "./positionsReport.js";
import { startMexcScanner, stopMexcScanner } from "./mexcScanner.js";

// ── Constants ─────────────────────────────────────────────────────────────────
const PARTIAL_TARGET         = 5;    // % частичная фиксация и перенос стопа в БУ
const FIRST_TARGET           = 10;  // % первая цель: фиксируем часть, переставляем стоп в БУ
const TRAILING_ACTIVATION_PCT = 15;  // % от входа: активируем трейлинг
const TRAILING_FIXED_PCT      = 10;  // % отступ трейлинга от пика (фиксированный)
const STOP_LOSS              = 10;   // % стоп лосс от входа (только для active до первой цели)
const ACCUMULATION_H         = 24;   // часов до статуса ACCUMULATION
const ACCUMULATION_REENTRY_H = 12;   // часов в статусе accumulation до проверки re-entry
const ACCUM_REMINDER_H       = 6;    // ч: промежуточное напоминание в статусе accumulation
const ACCUM_SCOUT_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4ч кулдаун между pre-breakout алертами
const ACCUM_OI_COOLDOWN_MS   = 2 * 60 * 60 * 1000;  // 2ч кулдаун между OI-алертами
const MAX_WATCH_DAYS         = 4;    // максимум наблюдения
const RE_ENTRY_VOL_MULT      = 3;    // объём для RE-ENTRY
const FAST_CYCLE_MS          = 2 * 60 * 1000; // 2 мин — быстрый цикл для in_run

// ── MEXC price cache ──────────────────────────────────────────────────────────
// MEXC API нестабилен (8s таймаут). Кэшируем последние цены чтобы стоп-лосс
// не пропускался при таймаутах. TTL 5 мин — достаточно для стоп-лосса.
const _mexcPriceCache = new Map<string, number>(); // BingX-format key: "TOKEN-USDT"
const MEXC_CACHE_TTL_MS = 5 * 60 * 1000;
let _mexcCacheFetchedAt = 0;

async function enrichPriceMapWithMexc(priceMap: Map<string, number>): Promise<void> {
  try {
    const mexcTickers = await getMexcFuturesTickers();
    _mexcCacheFetchedAt = Date.now();
    for (const t of mexcTickers) {
      const sym = t.symbol.replace("_USDT", "-USDT");
      priceMap.set(sym, t.lastPrice);
      _mexcPriceCache.set(sym, t.lastPrice);
    }
  } catch (err) {
    // Фетч не удался — используем кэш если не старше 5 мин
    if (Date.now() - _mexcCacheFetchedAt < MEXC_CACHE_TTL_MS && _mexcPriceCache.size > 0) {
      for (const [sym, price] of _mexcPriceCache) priceMap.set(sym, price);
      logger.warn({ err }, "MEXC tickers: fetch failed, using cached prices");
    } else {
      logger.warn({ err }, "MEXC tickers: fetch failed, cache stale or empty — skip");
    }
  }
}

// Milestones для Moonshot уведомлений (%)
// +25, +50, +100, затем каждые +50 до бесконечности — генерируем первые 20
const MILESTONES = [25, 50, ...Array.from({ length: 20 }, (_, i) => 100 + i * 50)];

// ── Telegram helpers ──────────────────────────────────────────────────────────
async function getTargets(): Promise<(number | string)[]> {
  const seen = new Set<string>();
  const targets: (number | string)[] = [];

  const addTarget = (id: number | string) => {
    const key = String(id);
    if (!seen.has(key)) { seen.add(key); targets.push(id); }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) addTarget(asNum);
    else if (envId.startsWith("@")) addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers
  const subs = await db.select({ chatId: subscribersTable.chatId })
    .from(subscribersTable)
    .where(eq(subscribersTable.active, true));
  for (const s of subs) addTarget(s.chatId);

  // Add channel from settings (only if non-empty)
  const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
  const ch = rows[0]?.channelId?.trim();
  if (ch) addTarget(ch);

  return targets;
}

async function broadcast(text: string) {
  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch (err) {
    logger.error({ err }, "broadcast: не удалось получить список получателей");
    return;
  }
  for (const t of targets) {
    try {
      await sendMessage(t, text);
    } catch (err) {
      // Ошибка Telegram (таймаут, rate limit и т.д.) не должна ломать весь цикл.
      // Логируем и продолжаем — остальные получатели получат сообщение.
      logger.error({ err, target: t }, "broadcast: не удалось отправить сообщение");
    }
  }
}

/** Admin broadcast — отправляет произвольный текст всем подписчикам (для уведомлений об обновлениях) */
export async function adminBroadcast(text: string): Promise<void> {
  await broadcast(text);
}

async function sendTo(text: string, targetChatId?: number | string): Promise<void> {
  if (targetChatId !== undefined) {
    await sendMessage(targetChatId, text);
  } else {
    await broadcast(text);
  }
}

// ── Formatters ────────────────────────────────────────────────────────────────
function fmtP(p: number) {
  return p < 1 ? `$${p.toFixed(6)}` : p < 100 ? `$${p.toFixed(4)}` : `$${p.toFixed(2)}`;
}
function fmtPct(n: number) { return `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`; }
function scoreBar(s: number) { const f = Math.round(s); return "█".repeat(f) + "░".repeat(10-f); }

function hoursAndDays(from: Date): { h: number; d: number; str: string } {
  const ms = Date.now() - from.getTime();
  const h = ms / 3_600_000;
  const d = Math.floor(h / 24);
  const rem = Math.round(h % 24);
  return { h, d, str: d > 0 ? `${d}д ${rem}ч` : `${Math.round(h)}ч` };
}

// ── Hashtag helper ────────────────────────────────────────────────────────────
/** "BTC-USDT" → "#BTC" */
function tickerTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

// ── Telegram message formats ──────────────────────────────────────────────────

function msgFirstTarget(t: TrackedSignal, currentPrice: number): string {
  const pnl = computePnl(t, currentPrice);
  return [
    `🔥 <b>${t.symbol}: Первая цель +${FIRST_TARGET}% достигнута!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `💡 <b>Действия:</b>`,
    `✂️ Зафиксируй часть прибыли (25–50% позиции)`,
    `🛡 Переставь Stop-Loss в безубыток → ${fmtP(t.entryPrice)}`,
    ``,
    `⏳ Следующее уведомление при +${TRAILING_ACTIVATION_PCT}% — активация трейлинга.`,
    `📡 Проверяю каждые 2 минуты.`,
    ``,
    `${tickerTag(t.symbol)} #in_run`,
  ].join("\n");
}

function msgTrailingActivated(t: TrackedSignal, currentPrice: number, trailingStopLevel: number): string {
  const pnl = computePnl(t, currentPrice);
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  return [
    `🚀 <b>${t.symbol}: Трейлинг активирован!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `🛡 Трейлинг Stop-Loss: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    `📐 Отступ: ${TRAILING_FIXED_PCT}% от пика — стоп тянется вверх автоматически`,
    ``,
    `⚡️ Минимальная фиксация гарантирована на уровне +${TRAILING_FIXED_PCT}%.`,
    ``,
    `${tickerTag(t.symbol)} #in_run #trailing`,
  ].join("\n");
}

function msgBeStop(t: TrackedSignal, currentPrice: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `⚖️ <b>${t.symbol}: Стоп в безубыток</b>`,
    ``,
    `Цена вернулась к уровню входа — выходим без потерь.`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)}`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `${tickerTag(t.symbol)} #breakeven`,
  ].join("\n");
}

function msgMilestone(t: TrackedSignal, milestone: number, currentPrice: number, trailingStopLevel: number): string {
  const gain = fmtPct(milestone);
  const emoji = milestone >= 100 ? "🌙" : milestone >= 50 ? "🚀" : "📈";
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  return [
    `${emoji} <b>MOONSHOT! ${t.symbol}: ${gain}</b>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} → Сейчас: ${fmtP(currentPrice)}`,
    `📊 Текущий профит: <b>${gain}</b>`,
    `🛡 Трейлинг Stop-Loss: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    ``,
    `⚡️ Ракета летит — держим до трейлинг-стопа!`,
    ``,
    `${tickerTag(t.symbol)} #moonshot`,
  ].join("\n");
}

function msgTrailingStopHit(t: TrackedSignal, currentPrice: number, peakPnl: number, finalPnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🏁 <b>${t.symbol}: Ралли завершено!</b>`,
    ``,
    `📈 Пиковый рост: <b>${fmtPct(peakPnl)}</b>`,
    `💰 Фиксация по трейлингу: <b>${fmtPct(finalPnl)}</b>`,
    `⏳ Длительность сделки: ${dur.str}`,
    t.alphaScore ? `🎯 Alpha Score был: ${t.alphaScore}/10  <code>${scoreBar(t.alphaScore)}</code>` : "",
    ``,
    `<i>Мы забрали основное движение!</i>`,
    ``,
    `${tickerTag(t.symbol)} #profit`,
  ].filter(Boolean).join("\n");
}

function msgStopLoss(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `❌ <b>STOP LOSS: ${t.symbol}</b>`,
    ``,
    `🛑 Стоп-лосс ${STOP_LOSS}% сработал`,
    `💰 Вход: ${fmtP(t.entryPrice)} → Выход: ${fmtP(currentPrice)}`,
    `📊 P&L: <b>${fmtPct(pnl)}</b>`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `${tickerTag(t.symbol)} #stop_loss`,
  ].join("\n");
}

function msgPartialTakeProfit(t: TrackedSignal, currentPrice: number, pnl: number): string {
  return [
    `📌 <b>${t.symbol}: +${PARTIAL_TARGET}% — переноси стоп в БУ!</b>`,
    ``,
    `📈 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `💡 <b>Действия прямо сейчас:</b>`,
    `🛡 Переставь Stop-Loss в безубыток → ${fmtP(t.entryPrice)}`,
    `✂️ Можно зафиксировать 20–25% позиции`,
    ``,
    `🎯 Первая цель +${FIRST_TARGET}% | Трейлинг при +${TRAILING_ACTIVATION_PCT}%`,
    ``,
    `${tickerTag(t.symbol)} #partial`,
  ].join("\n");
}

function msgAccumThesisBroken(t: TrackedSignal, currentPrice: number, pnl: number, oiDropPct: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `🚫 <b>${t.symbol}: тезис накопления нарушен</b>`,
    ``,
    `📉 OI упал на <b>${oiDropPct.toFixed(1)}%</b> от уровня входа`,
    `<i>Позиции открытые при сигнале — закрыты. Smart money вышел.</i>`,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} → Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏱ Время в позиции: ${dur.str}`,
    ``,
    `⚡️ Рекомендуем выйти из позиции.`,
    ``,
    `${tickerTag(t.symbol)} #cancelled`,
  ].join("\n");
}

function msgAccumVolumeBuilding(t: TrackedSignal, currentPrice: number, pnl: number, volMult: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `📡 <b>${t.symbol}: объём оживает в накоплении</b>`,
    ``,
    `📊 Активность: <b>${volMult.toFixed(1)}x</b> нормы — интерес возвращается`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏳ Сигнал ${dur.str} назад`,
    ``,
    `<i>Объём 2x+ — первый признак выхода из боковика. Слежу дальше.</i>`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgAccumOiBuilding(t: TrackedSignal, currentPrice: number, pnl: number, oiChange: number): string {
  const dur = hoursAndDays(t.detectedAt);
  return [
    `👀 <b>${t.symbol}: OI растёт при боковике</b>`,
    ``,
    `📈 OI: <b>+${oiChange.toFixed(1)}%</b> за 30м — позиции набираются`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `⏳ Сигнал ${dur.str} назад`,
    ``,
    `<i>Классический скрытый аккумулятор — крупный игрок не торопится.</i>`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgAccumulationReminder(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const dur = hoursAndDays(t.detectedAt);
  const pnlStr = fmtPct(pnl);
  const pnlEmoji = pnl >= 0 ? "📗" : "📕";
  return [
    `⏳ <b>${t.symbol}: 6ч в накоплении</b>`,
    ``,
    `🕐 Время в позиции: ${dur.str}`,
    `${pnlEmoji} Текущий P&L: <b>${pnlStr}</b>`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)}`,
    ``,
    `<i>Монета продолжает накапливаться. Жду движения до ${MAX_WATCH_DAYS} дней.</i>`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgAccumulation(t: TrackedSignal, currentPrice: number, pnl: number): string {
  const sign = pnl >= 0 ? "+" : "";
  return [
    `⏳ <b>ACCUMULATION: ${t.symbol}</b>`,
    ``,
    `Прошло 24ч — монета ждёт своего момента`,
    `💰 ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${sign}${pnl.toFixed(1)}%)`,
    `👁 Продолжаю наблюдение до ${MAX_WATCH_DAYS} дней`,
    ``,
    `${tickerTag(t.symbol)} #accumulation`,
  ].join("\n");
}

function msgReEntry(t: TrackedSignal, currentPrice: number, volMult: number): string {
  const { str } = hoursAndDays(t.detectedAt);
  return [
    `🔥 <b>${t.symbol}: Второе дыхание!</b>`,
    ``,
    `📅 Сигнал был ${str} назад`,
    `📊 Текущая активность: Vol ${volMult.toFixed(1)}x`,
    `⚡️ Статус: Накопление завершено, ожидается импульс`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)}`,
    ``,
    `${tickerTag(t.symbol)} #re_entry`,
  ].join("\n");
}

function msgLateSignal(t: TrackedSignal, currentPrice: number, pnl: number): string {
  return [
    `⚠️ <b>${t.symbol}: Запоздалый сигнал</b>`,
    ``,
    `Монета уже двинулась на <b>${fmtPct(pnl)}</b> к моменту обнаружения — движение началось раньше скана.`,
    ``,
    `📌 Цена входа (при сигнале): ${fmtP(t.entryPrice)}`,
    `📈 Текущая цена: ${fmtP(currentPrice)}`,
    ``,
    `⚡️ Включен Moonshot Management с трейлинг-стопом 7%.`,
    `⚠️ Входить в позицию не рекомендуется — момент пропущен.`,
    ``,
    `${tickerTag(t.symbol)} #late_signal #in_run`,
  ].join("\n");
}

function msgBreakeven(t: TrackedSignal, currentPrice: number, pnl: number): string {
  return [
    `⚖️ <b>BREAKEVEN (7д): ${t.symbol}</b>`,
    ``,
    `Монета наблюдалась 7 дней без чёткого результата`,
    `💰 Вход: ${fmtP(t.entryPrice)} | Закрытие: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    `📁 Перенесено в архив`,
    ``,
    `${tickerTag(t.symbol)} #breakeven`,
  ].join("\n");
}

function msgInvalidated(t: TrackedSignal, currentPrice: number, pnl: number, reason: "oi_drop" | "vol_drop", oiDrop?: number, volMult?: number): string {
  const reasonText = reason === "oi_drop"
    ? `📉 OI упал на <b>${oiDrop?.toFixed(1)}%</b> от входа — крупный игрок вышел из позиции`
    : `📭 Объём упал до <b>${volMult?.toFixed(2)}x</b> нормы — катализатор не материализовался`;
  return [
    `🚫 <b>СИГНАЛ ОТМЕНЁН: ${t.symbol}</b>`,
    ``,
    reasonText,
    ``,
    `💰 Вход: ${fmtP(t.entryPrice)} | Сейчас: ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `⚡️ Тезис сделки нарушен — рекомендуем выйти из позиции.`,
    ``,
    `${tickerTag(t.symbol)} #cancelled`,
  ].join("\n");
}

// ── P&L calculation (always long direction) ───────────────────────────────────
function computePnl(t: TrackedSignal, price: number): number {
  return ((price - t.entryPrice) / t.entryPrice) * 100;
}

function computePeakPnl(t: TrackedSignal): number {
  if (!t.peakPrice) return 0;
  return ((t.peakPrice - t.entryPrice) / t.entryPrice) * 100;
}

// ── Next milestone to announce ────────────────────────────────────────────────
function nextMilestone(lastMilestone: number | null, currentPnl: number): number | null {
  const last = lastMilestone ?? 0;
  for (const m of MILESTONES) {
    if (m > last && currentPnl >= m) return m;
  }
  return null;
}

// ── Add signal to tracker ─────────────────────────────────────────────────────
export async function trackSignal(params: {
  symbol: string;
  signalId: number | null;
  signalType: string;
  sentiment?: string | null;
  sentimentKey?: string | null;
  alphaScore?: number | null;
  entryPrice: number;
  entryOi?: number | null;
}): Promise<void> {
  try {
    const existing = await db.select({
      id: trackedSignalsTable.id,
      status: trackedSignalsTable.status,
      entryPrice: trackedSignalsTable.entryPrice,
    })
      .from(trackedSignalsTable)
      .where(and(
        eq(trackedSignalsTable.symbol, params.symbol),
        inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run"])
      ))
      .limit(1);

    if (existing.length > 0) {
      const rec = existing[0];

      // Живой мунщот в in_run — не трогаем, сигнал пришёл пока монета уже летит
      if (rec.status === "in_run") {
        logger.info(
          { symbol: params.symbol, status: rec.status },
          "Already in_run — skipping new signal (moonshot active)"
        );
        return;
      }

      // active / accumulation — у символа старая цена входа, новый сигнал свежее.
      // Сбрасываем цену входа, пик и milestones на актуальные значения.
      const oldEntry = rec.entryPrice;
      await db.update(trackedSignalsTable)
        .set({
          signalId: params.signalId,
          signalType: params.signalType,
          sentiment: params.sentiment ?? null,
          sentimentKey: params.sentimentKey ?? null,
          alphaScore: params.alphaScore ?? null,
          isShort: false,
          entryPrice: params.entryPrice,
          entryOi: params.entryOi ?? null,
          peakPrice: params.entryPrice,
          trailingStopLevel: null,
          lastMilestone: null,
          status: "active",
          reEntryCount: 0,
          detectedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(trackedSignalsTable.id, rec.id));

      logger.info(
        { symbol: params.symbol, oldEntry, newEntry: params.entryPrice },
        "📍 Signal tracker reset — fresh entry price (was stale)"
      );
      return;
    }

    await db.insert(trackedSignalsTable).values({
      symbol: params.symbol,
      signalId: params.signalId,
      signalType: params.signalType,
      sentiment: params.sentiment ?? null,
      sentimentKey: params.sentimentKey ?? null,
      alphaScore: params.alphaScore ?? null,
      isShort: false,
      entryPrice: params.entryPrice,
      entryOi: params.entryOi ?? null,
      peakPrice: params.entryPrice,
      trailingStopLevel: null,
      lastMilestone: null,
      status: "active",
      reEntryCount: 0,
      detectedAt: new Date(),
      updatedAt: new Date(),
    } as InsertTrackedSignal);

    logger.info({ symbol: params.symbol, price: params.entryPrice }, "📍 Signal added to tracker");
  } catch (err) {
    logger.error({ err, symbol: params.symbol }, "Failed to add signal to tracker");
  }
}

// ── Startup reset: normalize stale active signals after server restart ─────────
// Если сервер перезагрузился пока монета двигалась — entry price устарел.
// Вместо молчаливого сброса — отправляем уведомление «Пропущено движение»,
// затем сбрасываем entry до текущей цены чтобы сопровождение продолжалось корректно.
export async function runStartupReset(): Promise<void> {
  // Проверяем и active (стоп-лосс 10%) и in_run (трейлинг стоп / бу-стоп)
  const openSignals = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run"]));

  if (openSignals.length === 0) return;

  // ── Retry: BingX API нестабилен при холодном старте (таймауты, DNS) ──────
  // 3 попытки с экспоненциальной задержкой. Если все упали — логируем и выходим.
  // НЕ молчим: раньше был просто return, что скрывало пропуск стоп-лоссов.
  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fetchOk = false;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      tickers = await getFutureTickers() as any[];
      fetchOk = true;
      break;
    } catch (err) {
      logger.warn({ err, attempt }, `Startup reset: BingX fetch attempt ${attempt}/3 failed`);
      if (attempt < 3) await new Promise(r => setTimeout(r, 3000 * attempt));
    }
  }
  if (!fetchOk) {
    logger.error("Startup reset: все попытки получить цены провалились — стоп-лоссы не проверены");
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  // Добавляем MEXC цены для mexc_pump сигналов (с кэшем на случай таймаута)
  if (openSignals.some(s => s.sentimentKey === "mexc_pump")) {
    await enrichPriceMapWithMexc(priceMap);
  }

  let targets: (number | string)[] = [];
  try { targets = await getTargets(); } catch { /* non-critical */ }

  let resetCount = 0;
  for (const tracked of openSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const base = tracked.symbol.replace("-USDT", "");
    const isMexc = tracked.sentimentKey === "mexc_pump";
    const tvUrl = isMexc
      ? `https://www.tradingview.com/chart/?symbol=MEXC:${base}USDTPERP`
      : `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

    // ── active: проверка стоп-лосса (-10%) ─────────────────────────────────
    if (tracked.status === "active" && pnl <= -STOP_LOSS) {
      const msg =
        `🛑 <b>Пропущен стоп-лосс (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Убыток: <b>${pnl.toFixed(1)}%</b>\n\n` +
        `Позиция закрыта по стоп-лоссу.\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} #stop_loss`;

      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      logger.warn(
        { symbol: tracked.symbol, entry: tracked.entryPrice, currentPrice, pnl: pnl.toFixed(1) + "%" },
        "🛑 Startup reset: missed stop-loss (active) — signal closed"
      );
      resetCount++;

    // ── in_run: проверка трейлинг-стопа ────────────────────────────────────
    // После первой цели (+10%) стоп переносится в БУ (entry). Трейлинг (10% от пика)
    // активируется при +15% от входа. Если сервер лежал и цена рухнула — закрываем.
    } else if (tracked.status === "in_run") {
      const peak = tracked.peakPrice ?? currentPrice;
      const peakPnl = computePnl(tracked, peak);
      const trailingActive = peakPnl >= TRAILING_ACTIVATION_PCT;
      const trailingStop = peak * (1 - TRAILING_FIXED_PCT / 100);
      const trailingHit = trailingActive && currentPrice <= trailingStop;
      // Бу-стоп: если трейлинг ещё не активен но цена упала ниже входа — закрываем
      const beStopHit = !trailingActive && currentPrice < tracked.entryPrice;

      if (trailingHit || beStopHit) {
        const finalPnl = ((currentPrice - tracked.entryPrice) / tracked.entryPrice) * 100;
        const msg = trailingHit
          ? `🔴 <b>Пропущен трейлинг-стоп (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `Пик: <b>$${peak.toPrecision(4)}</b> | Трейлинг: <b>$${trailingStop.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #trailing_stop`
          : `🔴 <b>Пропущен бу-стоп (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} #be_stop`;

        for (const chatId of targets) {
          try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
        }
        await db.update(trackedSignalsTable).set({
          status: "profit", exitPrice: currentPrice, pnlPercent: finalPnl,
          closedAt: new Date(), updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        logger.warn(
          { symbol: tracked.symbol, entry: tracked.entryPrice, peak, currentPrice, finalPnl: finalPnl.toFixed(1) + "%" },
          trailingHit
            ? "🔴 Startup reset: missed trailing-stop (in_run) — signal closed"
            : "🔴 Startup reset: missed be-stop (in_run) — signal closed"
        );
        resetCount++;
      }

    // ── active: выросло пока сервер лежал — сбрасываем entry ───────────────
    } else if (tracked.status === "active" && pnl >= FIRST_TARGET) {
      const sign = pnl >= 0 ? "+" : "";
      const msg =
        `⚠️ <b>Пропущено движение (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Движение: <b>${sign}${pnl.toFixed(1)}%</b>\n\n` +
        `Продолжаем сопровождение от <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)}`;

      for (const chatId of targets) {
        try { await sendMessage(chatId, msg); } catch { /* non-critical */ }
      }
      await db.update(trackedSignalsTable).set({
        entryPrice: currentPrice, peakPrice: currentPrice,
        lastMilestone: null, trailingStopLevel: null,
        detectedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      logger.warn(
        { symbol: tracked.symbol, oldEntry: tracked.entryPrice, currentPrice, pnl: pnl.toFixed(1) + "%" },
        "⚠️ Startup reset: missed move notified — entry reset to current price"
      );
      resetCount++;
    }
  }

  if (resetCount > 0) {
    logger.info({ resetCount }, "Startup reset complete: missed moves notified, entries normalized");
  } else {
    logger.info("Startup reset: all active signals are fresh (no reset needed)");
  }
}

// ── In-memory cooldown для accumulation scouts (сбрасывается при рестарте) ───
// Структура: Map<signalId, { volBuild: timestampMs, oiBuild: timestampMs }>
const accumScoutCooldowns = new Map<number, { volBuild: number; oiBuild: number; oiDrain: number }>();

// ── Main watcher cycle (every 10 min): handles ONLY accumulation signals ──────
// active + in_run обрабатываются исключительно FastCycle (каждые 2 мин),
// чтобы исключить race condition при одновременном запуске обоих циклов.
export async function runWatcherCycle(): Promise<{ checked: number; updated: number }> {
  const accumSignals = await db.select()
    .from(trackedSignalsTable)
    .where(eq(trackedSignalsTable.status, "accumulation"));

  if (accumSignals.length === 0) return { checked: 0, updated: 0 };

  logger.info({ count: accumSignals.length }, "Watcher: checking accumulation signals");

  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch (err) {
    logger.error({ err }, "Watcher: failed to fetch tickers");
    return { checked: 0, updated: 0 };
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  // Добавляем MEXC цены для mexc_pump сигналов (с кэшем на случай таймаута)
  if (accumSignals.some(s => s.sentimentKey === "mexc_pump")) {
    await enrichPriceMapWithMexc(priceMap);
  }

  let updated = 0;

  for (const tracked of accumSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const { h: ageHours } = hoursAndDays(tracked.detectedAt);
    const ageDays = ageHours / 24;

    const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
    const peakChanged = newPeak !== tracked.peakPrice;

    // ── 7 days → Breakeven ────────────────────────────────────────────────────
    if (ageDays >= MAX_WATCH_DAYS) {
      await db.update(trackedSignalsTable).set({
        status: "breakeven", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgBreakeven(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "Watcher: BREAKEVEN (7d)");
      updated++;
      continue;
    }

    // ── Stop loss ─────────────────────────────────────────────────────────────
    if (pnl <= -STOP_LOSS) {
      await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgStopLoss(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "Watcher: STOP LOSS (accum) ❌");
      updated++;
      continue;
    }

    // ── 6ч напоминание в накоплении (один раз) ───────────────────────────────
    // lastMilestone = -1 используется как сентинель "напоминание отправлено"
    // Это безопасно: в accumulation статусе milestones (25/50/100%) не используются
    const reminderSent = tracked.lastMilestone === -1;
    if (!reminderSent && ageHours >= ACCUM_REMINDER_H) {
      await broadcast(msgAccumulationReminder(tracked, currentPrice, pnl));
      await db.update(trackedSignalsTable)
        .set({ lastMilestone: -1 })
        .where(eq(trackedSignalsTable.id, tracked.id));
      logger.info({ symbol: tracked.symbol, ageHours: ageHours.toFixed(1) }, "Watcher: ACCUMULATION REMINDER 6h ⏳");
    }

    // ── OI Drain check: тезис всё ещё в силе? ────────────────────────────────
    // После перехода в accumulation проверяем раз в 4ч: не слился ли OI.
    // OI был причиной сигнала — если он вернулся к норме, а цена нет → выходим.
    // short_squeeze не проверяем: там OI ДОЛЖЕН падать по тезису.
    const scoutNow = Date.now();
    const cooldowns = accumScoutCooldowns.get(tracked.id) ?? { volBuild: 0, oiBuild: 0, oiDrain: 0 };
    const oiDrainCooldownOk = scoutNow - (cooldowns.oiDrain ?? 0) > 4 * 3_600_000;
    const oiFallingPatternAccum = tracked.sentimentKey === "short_squeeze";
    if (oiDrainCooldownOk && !oiFallingPatternAccum && tracked.entryOi && tracked.entryOi > 0) {
      try {
        const oiData = await getOpenInterest(tracked.symbol);
        if (oiData) {
          const currentOi = parseFloat(oiData.openInterest) || 0;
          const oiDropFromEntry = ((tracked.entryOi - currentOi) / tracked.entryOi) * 100;
          // OI слился >20% от входа, а цена не выросла — тезис нарушен
          if (oiDropFromEntry >= 20 && pnl < 3) {
            await db.update(trackedSignalsTable).set({
              status: "cancelled", exitPrice: currentPrice, pnlPercent: pnl,
              closedAt: new Date(), updatedAt: new Date(),
            }).where(eq(trackedSignalsTable.id, tracked.id));
            await broadcast(msgAccumThesisBroken(tracked, currentPrice, pnl, oiDropFromEntry));
            logger.info({ symbol: tracked.symbol, oiDropFromEntry: oiDropFromEntry.toFixed(1), pnl }, "Watcher: ACCUM THESIS BROKEN — OI drained 🚫");
            updated++;
            continue;
          }
          // Записываем время последней проверки OI drain (даже если не сработало)
          accumScoutCooldowns.set(tracked.id, { ...cooldowns, oiDrain: scoutNow });
        }
      } catch { /* non-critical */ }
    }

    // ── Accumulation scout: pre-fetch klines (используется и здесь, и в re-entry) ──
    let scoutVolMult = 0;
    try {
      const klines = await getKlines(tracked.symbol, "30m", 21);
      if (klines.length >= 5) {
        const current = klines[klines.length - 1];
        const historical = klines.slice(0, -1);
        const close = parseFloat(current.close) || 0;
        const currentVol = (parseFloat(current.volume) || 0) * close;
        const avgVol = historical.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / historical.length;
        scoutVolMult = avgVol > 0 ? currentVol / avgVol : 0;

        // 📡 Объём оживает (2x-3x): ранний сигнал до re-entry порога
        const volBuildCooldownOk = scoutNow - cooldowns.volBuild > ACCUM_SCOUT_COOLDOWN_MS;
        if (scoutVolMult >= 2.0 && scoutVolMult < RE_ENTRY_VOL_MULT && volBuildCooldownOk) {
          await broadcast(msgAccumVolumeBuilding(tracked, currentPrice, pnl, scoutVolMult));
          accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns), volBuild: scoutNow });
          logger.info({ symbol: tracked.symbol, volMult: scoutVolMult.toFixed(2) }, "Watcher: ACCUM VOL BUILDING 📡");
        }
      }
    } catch { /* non-critical */ }

    // 👀 OI растёт при боковике: CoinGlass check с 2ч кулдауном
    const oiBuildCooldownOk = scoutNow - cooldowns.oiBuild > ACCUM_OI_COOLDOWN_MS;
    if (oiBuildCooldownOk && Math.abs(pnl) <= 6) {
      try {
        const cgOI = await getCoinglassOI(tracked.symbol);
        const oiChange = cgOI.oiChange30m ?? cgOI.oiChange5m ?? null;
        if (cgOI.available && oiChange !== null && oiChange >= 5) {
          await broadcast(msgAccumOiBuilding(tracked, currentPrice, pnl, oiChange));
          accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns), oiBuild: scoutNow });
          logger.info({ symbol: tracked.symbol, oiChange }, "Watcher: ACCUM OI BUILDING 👀");
        }
        // Записываем время последней проверки независимо от результата
        accumScoutCooldowns.set(tracked.id, { ...(accumScoutCooldowns.get(tracked.id) ?? { volBuild: 0, oiBuild: 0 }), oiBuild: scoutNow });
      } catch { /* non-critical */ }
    }

    // ── Re-entry check (≥12h in accumulation, 3x объём) ──────────────────────
    const hoursInAccumulation = (Date.now() - tracked.updatedAt.getTime()) / 3_600_000;
    if (hoursInAccumulation >= ACCUMULATION_REENTRY_H && scoutVolMult >= RE_ENTRY_VOL_MULT) {
      await broadcast(msgReEntry(tracked, currentPrice, scoutVolMult));
      await db.update(trackedSignalsTable).set({
        status: "accumulation",
        reEntryCount: (tracked.reEntryCount ?? 0) + 1,
        peakPrice: newPeak, updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      logger.info({ symbol: tracked.symbol, volMult: scoutVolMult }, "Watcher: RE-ENTRY 🔄");
      updated++;
      continue;
    }

    // Update peak silently
    if (peakChanged) {
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }
  }

  return { checked: accumSignals.length, updated };
}

// ── Daily report (21:00 МСК = 18:00 UTC) ─────────────────────────────────────
export async function sendDailyReport(targetChatId?: number | string): Promise<void> {
  // Берём последние 24 часа чтобы не пропускать сигналы при catch-up после перезапуска
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const allOpen = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "accumulation", "in_run"]));

  const closedToday = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.closedAt} >= ${since}`);

  const profitsToday    = closedToday.filter(s => s.status === "profit");
  const stopsToday      = closedToday.filter(s => s.status === "stop_loss");
  const cancelledToday  = closedToday.filter(s => s.status === "cancelled");
  const inRunNow        = allOpen.filter(s => s.status === "in_run");

  // Fetch live prices for open positions
  const priceMap = new Map<string, number>();
  if (allOpen.length > 0) {
    try {
      const tickers = await getFutureTickers() as any[];
      for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
    } catch { /* non-critical — show without live price */ }
    // MEXC позиции: TOKEN_USDT → TOKEN-USDT
    if (allOpen.some(s => s.sentimentKey === "mexc_pump")) {
      try {
        const mexcTickers = await getMexcFuturesTickers();
        for (const t of mexcTickers) priceMap.set(t.symbol.replace("_USDT", "-USDT"), t.lastPrice);
      } catch { /* non-critical */ }
    }
  }

  const lines: string[] = [
    `📊 <b>DAILY REPORT — Alpha Watcher</b>`,
    `<i>${new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "long", year: "numeric" })}</i>`,
    ``,
  ];

  const symTag  = (symbol: string) => `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
  const symBase = (symbol: string) => symbol.replace("-USDT", "");
  const priceRow = (s: TrackedSignal, curPrice: number | undefined) => {
    if (!s.entryPrice) return "";
    if (!curPrice) return ` | Вход: ${fmtP(s.entryPrice)}`;
    const pnl = ((curPrice - s.entryPrice) / s.entryPrice) * 100;
    const sign = pnl >= 0 ? "+" : "";
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(curPrice)} (${sign}${pnl.toFixed(1)}%)`;
  };
  const priceRowClosed = (s: TrackedSignal) => {
    if (!s.entryPrice) return "";
    const exit = s.exitPrice ?? s.peakPrice;
    if (!exit) return ` | Вход: ${fmtP(s.entryPrice)}`;
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(exit)} (${fmtPct(s.pnlPercent ?? 0)})`;
  };

  if (inRunNow.length > 0) {
    lines.push(`🚀 <b>В полёте (Moonshot) — ${inRunNow.length}:</b>`);
    for (const s of inRunNow) {
      const peakPnl = computePeakPnl(s);
      const curPrice = priceMap.get(s.symbol);
      const trStop = s.trailingStopLevel ? fmtP(s.trailingStopLevel) : "—";
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRow(s, curPrice)} | Пик: +${peakPnl.toFixed(1)}% | Trailing: ${trStop}`);
    }
    lines.push(``);
  }

  if (allOpen.length > 0) {
    const watching = allOpen.filter(s => s.status === "active" || s.status === "accumulation");
    if (watching.length > 0) {
      lines.push(`👁 <b>В наблюдении (${watching.length}):</b>`);
      for (const s of watching) {
        const curPrice = priceMap.get(s.symbol);
        lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRow(s, curPrice)}`);
      }
      lines.push(``);
    }
  }

  if (profitsToday.length > 0) {
    lines.push(`✅ <b>Закрыто в профит (${profitsToday.length}):</b>`);
    for (const s of profitsToday) {
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (stopsToday.length > 0) {
    lines.push(`❌ <b>Стоп-лосс (${stopsToday.length}):</b>`);
    for (const s of stopsToday) {
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (cancelledToday.length > 0) {
    lines.push(`🚫 <b>Отменено сегодня (${cancelledToday.length}):</b>`);
    for (const s of cancelledToday) {
      lines.push(`  • ${symBase(s.symbol)} ${symTag(s.symbol)}${priceRowClosed(s)}`);
    }
    lines.push(``);
  }

  if (allOpen.length === 0 && closedToday.length === 0) {
    lines.push(`Сегодня активных сигналов нет.`);
  }

  lines.push(``, `#ежедневный_отчет`);

  await sendTo(lines.join("\n"), targetChatId);

  if (!targetChatId) {
    // Сохраняем время отправки только при запуске по расписанию
    await db.update(settingsTable)
      .set({ lastDailyReportAt: new Date() })
      .where(sql`id = (SELECT id FROM settings LIMIT 1)`);
  }

  logger.info("Daily report sent");
}

// ── Weekly digest (09:00 МСК = 06:00 UTC, воскресенье) ───────────────────────
export async function sendWeeklyDigest(targetChatId?: number | string): Promise<void> {
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const all = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneWeekAgo}`);

  const profits    = all.filter(s => s.status === "profit");
  const stops      = all.filter(s => s.status === "stop_loss");
  const cancelled  = all.filter(s => s.status === "cancelled");
  const accum      = all.filter(s => s.status === "accumulation" || s.status === "re_entry");
  const inRun      = all.filter(s => s.status === "in_run");
  const breakevens = all.filter(s => s.status === "breakeven");

  if (all.length === 0) {
    await sendTo("📊 <b>Еженедельный дайджест</b>\n\nНа этой неделе сигналов не было.", targetChatId);
    return;
  }

  const sorted = [...profits].sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0));
  const medals = ["🥇", "🥈", "🥉"];
  const topProfits = sorted.slice(0, 3);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    return `${medals[i]} $${s.symbol.replace("-USDT", "")}${priceStr} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  // TOP ALPHA OF THE WEEK: all signals with >30% profit
  const moonshots = sorted.filter(s => (s.pnlPercent ?? 0) >= 30);
  const moonshotLines = moonshots.map(s => {
    const peak = computePeakPnl(s);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    return `🚀 ${s.symbol.replace("-USDT", "")}${priceStr} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`;
  });

  const winRate = (profits.length + stops.length) > 0
    ? Math.round((profits.length / (profits.length + stops.length)) * 100)
    : null;
  const avgProfit = profits.length > 0
    ? profits.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) / profits.length
    : null;

  const wFmtRow = (s: TrackedSignal) => {
    const base = `$${s.symbol.replace("-USDT", "")}`;
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit  = s.exitPrice ?? s.peakPrice;
    const exitFmt = exit ? fmtP(exit) : null;
    const pnl   = s.pnlPercent ?? 0;
    const sign  = pnl >= 0 ? "+" : "";
    const priceStr = entry && exitFmt ? ` (${entry} → ${exitFmt})` : entry ? ` (Вход: ${entry})` : "";
    return `  • ${base}${priceStr} — ${sign}${pnl.toFixed(1)}%`;
  };

  // Stop-loss details
  const stopLines = [...stops]
    .sort((a, b) => (a.pnlPercent ?? 0) - (b.pnlPercent ?? 0))
    .map(s => wFmtRow(s));

  // Cancelled details
  const cancelLines = [...cancelled]
    .sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0))
    .map(s => wFmtRow(s));

  const lines = [
    `🏆 <b>ИТОГИ НЕДЕЛИ: ЛУЧШАЯ АЛЬФА</b>`,
    ``,
    ...(topLines.length > 0 ? topLines : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshotLines.length > 0) {
    lines.push(``, `🌙 <b>TOP ALPHA OF THE WEEK (>+30%):</b>`);
    lines.push(...moonshotLines);
  }

  if (stopLines.length > 0) {
    lines.push(``, `❌ <b>Стоп-лоссы (${stops.length}):</b>`);
    lines.push(...stopLines);
  }

  if (cancelLines.length > 0) {
    lines.push(``, `🚫 <b>Отменённые сигналы (${cancelled.length}):</b>`);
    lines.push(...cancelLines);
  }

  lines.push(
    ``,
    `📊 <b>Статистика:</b>`,
    `✅ Профит: ${profits.length} сигналов`,
    `🚀 В полёте: ${inRun.length} сигналов`,
    `⏳ В накоплении: ${accum.length} сигналов`,
    `❌ Стоп-лосс: ${stops.length} сигналов`,
    `🚫 Отменено: ${cancelled.length} сигналов`,
    `⚖️ Безубыток (7д): ${breakevens.length} сигналов`,
    ...(avgProfit !== null ? [`📈 Средний профит: ${fmtPct(avgProfit)}`] : []),
    ...(winRate !== null ? [`🎯 Win Rate: ${winRate}%`] : []),
    ``,
    `<i>Мы видим деньги там, где другие видят тишину.</i>`,
    ``,
    `#еженедельный_отчет`,
  );

  await sendTo(lines.join("\n"), targetChatId);

  if (!targetChatId) {
    // Сохраняем время отправки только при запуске по расписанию
    await db.update(settingsTable)
      .set({ lastWeeklyDigestAt: new Date() })
      .where(sql`id = (SELECT id FROM settings LIMIT 1)`);
  }

  logger.info({ total: all.length }, "Weekly digest sent");
}

// ── Monthly digest (30 days stats) ───────────────────────────────────────────
export async function sendMonthlyDigest(targetChatId?: number | string): Promise<void> {
  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const all = await db.select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneMonthAgo}`);

  const profits    = all.filter(s => s.status === "profit");
  const stops      = all.filter(s => s.status === "stop_loss");
  const inRun      = all.filter(s => s.status === "in_run");
  const accum      = all.filter(s => s.status === "accumulation" || s.status === "re_entry");
  const breakevens = all.filter(s => s.status === "breakeven");

  if (all.length === 0) {
    await sendTo("📆 <b>Ежемесячный дайджест</b>\n\nЗа последние 30 дней сигналов не было.", targetChatId);
    return;
  }

  const sorted = [...profits].sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0));
  const medals = ["🥇", "🥈", "🥉", "🏅", "🏅"];
  const topProfits = sorted.slice(0, 5);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    return `${medals[i] ?? "🏅"} $${s.symbol.replace("-USDT", "")} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  const moonshots = sorted.filter(s => (s.pnlPercent ?? 0) >= 30);
  const winRate = (profits.length + stops.length) > 0
    ? Math.round((profits.length / (profits.length + stops.length)) * 100)
    : null;
  const avgProfit = profits.length > 0
    ? profits.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) / profits.length
    : null;

  const lines = [
    `📆 <b>ИТОГИ МЕСЯЦА: АЛЬФА-СТАТИСТИКА</b>`,
    `<i>Последние 30 дней</i>`,
    ``,
    ...(topLines.length > 0 ? [`🏆 <b>Топ профитов:</b>`, ...topLines] : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshots.length > 0) {
    lines.push(``, `🚀 <b>Moonshots (>+30%):</b> ${moonshots.length} шт`);
    for (const s of moonshots.slice(0, 5)) {
      const peak = computePeakPnl(s);
      lines.push(`  • ${s.symbol.replace("-USDT", "")} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`);
    }
  }

  lines.push(
    ``,
    `📊 <b>Статистика за 30 дней:</b>`,
    `📡 Всего сигналов: ${all.length}`,
    `✅ Профит: ${profits.length}`,
    `🚀 В полёте: ${inRun.length}`,
    `⏳ В накоплении: ${accum.length}`,
    `❌ Стоп-лосс: ${stops.length}`,
    `⚖️ Безубыток: ${breakevens.length}`,
    ...(avgProfit !== null ? [`📈 Средний профит: ${fmtPct(avgProfit)}`] : []),
    ...(winRate !== null ? [`🎯 Win Rate: ${winRate}%`] : []),
    ``,
    `#ежемесячный_отчет`,
  );

  await sendTo(lines.join("\n"), targetChatId);

  if (!targetChatId) {
    // Сохраняем время отправки только при запуске по расписанию
    await db.update(settingsTable)
      .set({ lastMonthlyDigestAt: new Date() })
      .where(sql`id = (SELECT id FROM settings LIMIT 1)`);
  }

  logger.info({ total: all.length }, "Monthly digest sent");
}

// ── Fast cycle (every 2 min): active + in_run for stop-loss / first-target / trailing ──────────
async function runInRunFastCycle(): Promise<void> {
  // Check active AND in_run signals every 2 min for fast stop-loss and target detection
  const fastSignals = await db.select()
    .from(trackedSignalsTable)
    .where(inArray(trackedSignalsTable.status, ["active", "in_run"]));

  if (fastSignals.length === 0) return;

  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fastFetchOk = false;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      tickers = await getFutureTickers() as any[];
      fastFetchOk = true;
      break;
    } catch (err) {
      logger.warn({ err, attempt }, `FastCycle: BingX fetch attempt ${attempt}/2 failed`);
      if (attempt < 2) await new Promise(r => setTimeout(r, 3000));
    }
  }
  if (!fastFetchOk) {
    logger.error("FastCycle: не удалось получить цены — стоп-лоссы пропущены в этом цикле");
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  // Добавляем MEXC цены для mexc_pump сигналов (с кэшем на случай таймаута)
  if (fastSignals.some(s => s.sentimentKey === "mexc_pump")) {
    await enrichPriceMapWithMexc(priceMap);
  }

  for (const tracked of fastSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
    const peakChanged = newPeak !== tracked.peakPrice;

    // Трейлинг активируется только при достижении TRAILING_ACTIVATION_PCT (20%) от входа
    const peakPnlNow = computePnl(tracked, newPeak);
    const prevPeakPnl = tracked.peakPrice ? computePnl(tracked, tracked.peakPrice) : 0;
    const trailingActive = peakPnlNow >= TRAILING_ACTIVATION_PCT;
    const trailingStop = newPeak * (1 - TRAILING_FIXED_PCT / 100);
    // Трейлинг сработал: только если активен и цена пробила уровень вниз
    const trailingHit = trailingActive && currentPrice <= trailingStop;
    // Трейлинг только что активировался в этом цикле (пик пересёк 20%)
    const trailingJustActivated = tracked.status === "in_run"
      && prevPeakPnl < TRAILING_ACTIVATION_PCT
      && peakPnlNow >= TRAILING_ACTIVATION_PCT;

    const ageMs = Date.now() - tracked.detectedAt.getTime();
    const ageHours = ageMs / 3_600_000;
    const ageDays = ageHours / 24;

    // 7d → Breakeven (FastCycle handles this for active/in_run)
    if (ageDays >= MAX_WATCH_DAYS) {
      await db.update(trackedSignalsTable).set({
        status: "breakeven", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgBreakeven(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BREAKEVEN (7d)");
      continue;
    }

    // ── STALE SIGNAL: авто-отмена при отсутствии движения ───────────────────
    // Время ожидания зависит от паттерна: медленное накопление идёт 6-24ч, быстрые — 3ч.
    // Перед отменой: проверяем свежий OI — если накопление ещё идёт, даём ещё 3ч.
    // Статистика: 0 прибыльных из 98 сигналов где peak < 2% к моменту отмены.
    if (
      tracked.status === "active" &&
      tracked.peakPrice != null &&
      tracked.entryPrice != null &&
      tracked.entryPrice > 0
    ) {
      const peakPct = ((tracked.peakPrice - tracked.entryPrice) / tracked.entryPrice) * 100;
      if (peakPct < 2.0) {
        // Базовое окно по паттерну:
        // hidden_accumulation / bullish_accumulation — медленная игра, минимум 6ч
        // 4h_momentum / steady — ещё медленнее, 8ч
        // Всё остальное (bear_trap, short_squeeze, anomaly, breakout) — 6ч (было 3ч)
        const sentKey = tracked.sentimentKey ?? "";
        const baseStaleH =
          (sentKey === "hidden_accumulation" || sentKey === "bullish_accumulation") ? 6
          : (sentKey === "4h_momentum" || sentKey === "steady") ? 8
          : 6; // Увеличено с 3ч до 6ч: быстрые паттерны с триггерным входом дольше развиваются

        if (ageHours < baseStaleH) continue; // ещё в базовом окне — ждём

        // Базовое окно истекло. Проверяем свежий OI перед финальной отменой.
        // Три исхода: 'positive' (OI ≥ 3% → ждём), 'negative' (OI < 3% → отменяем), 'error' (таймаут → ждём).
        // ВАЖНО: таймаут CoinGlass ≠ "OI иссяк". Таймауты частые (MEZO, SAPIEN, SYRUP...).
        // При ошибке — продлеваем, отменяем ТОЛЬКО при явном отрицательном ответе.
        if (ageHours < baseStaleH + 3) {
          type OiResult = "positive" | "negative" | "error";
          let oiResult: OiResult = "error"; // по умолчанию — ошибка → ждём
          try {
            const cgOIFresh = await getCoinglassOI(tracked.symbol);
            const freshOI = cgOIFresh.oiChange30m ?? cgOIFresh.oiChange5m ?? null;
            if (cgOIFresh.available && freshOI !== null) {
              oiResult = freshOI >= 3.0 ? "positive" : "negative";
            }
            // available=false или freshOI=null → oiResult остаётся 'error' → ждём
          } catch {
            oiResult = "error"; // таймаут или сетевая ошибка → ждём, не отменяем
          }

          if (oiResult === "positive") {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
              "⏳ STALE EXTENDED: OI ещё строится — продлеваем"
            );
            continue;
          }
          if (oiResult === "error") {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
              "⏳ STALE EXTENDED: CoinGlass недоступен — ждём следующего цикла"
            );
            continue;
          }
          // oiResult === 'negative' → OI подтверждённо иссяк → отменяем (ниже)
        }

        // Окно истекло и OI не подтвердил — отменяем
        await db.update(trackedSignalsTable).set({
          status: "cancelled",
          exitPrice: currentPrice,
          pnlPercent: pnl,
          closedAt: new Date(),
          updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast([
          `⏱ <b>${tracked.symbol.replace("-USDT","")}</b> — Сигнал отменён (нет движения)`,
          `За ${baseStaleH}ч пик не превысил +2% и OI не подтвердил продолжение → капитал освобождён`,
          `Вход: <b>${tracked.entryPrice.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
          `#${tracked.symbol.replace("-","_").toLowerCase()} #stale_cancel`,
        ].join("\n"));
        logger.info(
          { symbol: tracked.symbol, ageHours: ageHours.toFixed(1), peakPct: peakPct.toFixed(1), pattern: sentKey },
          `FastCycle: STALE CANCEL (${baseStaleH}h window, peak < 2%)`
        );
        continue;
      }
    }

    // BE стоп: active сигнал уже достиг +5% (стоп перенесён), цена вернулась к входу
    // Срабатывает РАНЬШЕ обычного стоп-лосса — если достигли +5%, не уходим на -7%
    if (tracked.status === "active" && (tracked.lastMilestone ?? 0) >= PARTIAL_TARGET && pnl <= 0) {
      await db.update(trackedSignalsTable).set({
        status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgBeStop(tracked, currentPrice));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BE STOP (active +5% → back to entry) ⚖️");
      continue;
    }

    // Стоп-лосс -7% применяется только к ACTIVE (до первой цели)
    if (tracked.status === "active" && pnl <= -STOP_LOSS) {
      await db.update(trackedSignalsTable).set({
        status: "stop_loss", exitPrice: currentPrice, pnlPercent: pnl,
        closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgStopLoss(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: STOP LOSS (active) ❌");
      continue;
    }

    // Стоп в безубыток: in_run, трейлинг ещё не активен, цена вернулась к входу (-2% буфер)
    if (tracked.status === "in_run" && !trailingActive && pnl <= -2) {
      await db.update(trackedSignalsTable).set({
        status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
        peakPrice: newPeak, closedAt: new Date(), updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgBeStop(tracked, currentPrice));
      logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BE STOP hit ⚖️");
      continue;
    }

    // Принудительный переход если active > 48ч и пик < 5% — монета не двигается
    if (tracked.status === "active" && ageHours >= 48) {
      const peakPct = tracked.peakPrice && tracked.entryPrice > 0
        ? ((tracked.peakPrice - tracked.entryPrice) / tracked.entryPrice) * 100
        : 0;
      if (peakPct < 5.0) {
        await db.update(trackedSignalsTable).set({
          status: "accumulation",
          peakPrice: newPeak,
          updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgAccumulation(tracked, currentPrice, pnl));
        logger.info(
          { symbol: tracked.symbol, ageHours: ageHours.toFixed(1), peakPct: peakPct.toFixed(1) },
          "FastCycle: → ACCUMULATION (48h force, peak < 5%) ⏳"
        );
        continue;
      }
    }

    // 24h without first target → transition to Accumulation
    if (tracked.status === "active" && ageHours >= ACCUMULATION_H) {
      await db.update(trackedSignalsTable).set({
        status: "accumulation", peakPrice: newPeak, updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgAccumulation(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl, ageHours: ageHours.toFixed(1) }, "FastCycle: → ACCUMULATION ⏳");
      continue;
    }

    // ── Trade Invalidation: OI drop or volume collapse (active only, ≥10 min old) ──
    // Patterns where OI FALLING is the thesis → skip OI check (it's expected).
    // OI falling is the thesis for these patterns → skip OI drop check
    // short_squeeze: OI падает по тезису (шорты выдавлены) — OI drop не является отменой
    const oiFallingPattern = tracked.sentimentKey === "short_squeeze";
    const minutesSinceEntry = ageMs / 60_000;
    const isGracePeriod = minutesSinceEntry < 60;

    if (tracked.status === "active" && !isGracePeriod) {
      let invalidateReason: "oi_drop" | "vol_drop" | null = null;
      let oiDropPct = 0;
      let volMultiplier = 1;

      try {
        // Volume check: current 30m kline vs avg of previous 4
        const klines = await getKlines(tracked.symbol, "30m", 6);
        if (klines.length >= 5) {
          const cur = klines[klines.length - 1];
          const hist = klines.slice(0, -1);
          const curVol = (parseFloat(cur.volume) || 0) * (parseFloat(cur.close) || 0);
          const avgVol = hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length;
          volMultiplier = avgVol > 0 ? curVol / avgVol : 1;
          if (volMultiplier < 0.2) {
            invalidateReason = "vol_drop";
          }
        }

        // OI drop check: only if entryOi stored and not an OI-falling pattern
        // Порог поднят с 15% до 25% — OI регулярно колышется на 10-20% внутри дня, это шум.
        if (!invalidateReason && !oiFallingPattern && tracked.entryOi && tracked.entryOi > 0) {
          const oiData = await getOpenInterest(tracked.symbol);
          if (oiData) {
            const currentOi = parseFloat(oiData.openInterest) || 0;
            oiDropPct = ((tracked.entryOi - currentOi) / tracked.entryOi) * 100;
            if (oiDropPct >= 25) {
              invalidateReason = "oi_drop";
            }
          }
        }
      } catch { /* non-critical — skip invalidation check this cycle */ }

      // CVD мониторинг: проверяем дельту для контекста и как тай-брейкер
      let cvdNegative = false;
      try {
        const cvd = await fetchCVD(tracked.symbol);
        if (cvd) {
          logger.info(
            { symbol: tracked.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%", pnl: pnl.toFixed(2) },
            cvd.positive ? "FastCycle: CVD ✅ покупки доминируют" : "FastCycle: CVD 🔴 продажи доминируют"
          );
          cvdNegative = !cvd.positive;
        }
      } catch { /* non-critical */ }

      // А) PnL-защита: если цена держится (PnL >= -2%) — не отменяем.
      // Исключение: если CVD отрицательный — дельта против нас, отменяем невзирая на цену.
      if (invalidateReason && pnl >= -2) {
        if (cvdNegative) {
          logger.info(
            { symbol: tracked.symbol, pnl: pnl.toFixed(2), reason: invalidateReason },
            "FastCycle: CVD отрицательный — отмена разрешена несмотря на удержание цены"
          );
        } else {
          logger.info(
            { symbol: tracked.symbol, pnl: pnl.toFixed(2), reason: invalidateReason, oiDropPct: oiDropPct.toFixed(1), volMultiplier: volMultiplier.toFixed(2) },
            "FastCycle: отмена заблокирована — цена держится (PnL >= -2%)"
          );
          invalidateReason = null;
        }
      }

      if (invalidateReason) {
        await db.update(trackedSignalsTable).set({
          status: "cancelled",
          exitPrice: currentPrice,
          pnlPercent: pnl,
          closedAt: new Date(),
          updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgInvalidated(tracked, currentPrice, pnl, invalidateReason, oiDropPct, volMultiplier));
        logger.info({ symbol: tracked.symbol, pnl, reason: invalidateReason, oiDropPct: oiDropPct.toFixed(1), volMultiplier: volMultiplier.toFixed(2) }, "FastCycle: CANCELLED 🚫");
        continue;
      }
    }

    // +5%: уведомление о частичной фиксации + переносе стопа в БУ (один раз)
    // Отправляем и продолжаем — в том же цикле может сработать +10%
    if (tracked.status === "active" && pnl >= PARTIAL_TARGET && (tracked.lastMilestone ?? 0) < PARTIAL_TARGET) {
      await db.update(trackedSignalsTable).set({
        lastMilestone: PARTIAL_TARGET, peakPrice: newPeak, updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));
      await broadcast(msgPartialTakeProfit(tracked, currentPrice, pnl));
      logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(2) }, "FastCycle: PARTIAL TARGET +5% 📌");
    }

    // Active → in_run transition (first target)
    if (tracked.status === "active" && pnl >= FIRST_TARGET) {
      await db.update(trackedSignalsTable).set({
        status: "in_run", peakPrice: newPeak, trailingStopLevel: trailingStop,
        updatedAt: new Date(),
      }).where(eq(trackedSignalsTable.id, tracked.id));

      // Проверяем запоздалый сигнал: цена уже улетела сразу на >25% в первые 10 мин.
      // С fresh-price fix это редкость — entry = текущий рынок, поэтому +10% за 15 мин
      // это честный сигнал. Только если >25% за 10 мин — значит entryPrice всё ещё устарел.
      const minutesSinceDetection = ageMs / 60000;
      const isLateSignal = minutesSinceDetection < 10 && pnl >= 25;
      if (isLateSignal) {
        await broadcast(msgLateSignal(tracked, currentPrice, pnl));
        logger.info({ symbol: tracked.symbol, pnl, minutesSinceDetection: minutesSinceDetection.toFixed(1) }, "FastCycle: → IN_RUN (late signal) ⚠️");
      } else {
        await broadcast(msgFirstTarget(tracked, currentPrice));
        logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: → IN_RUN 🚀");
      }
      continue;
    }

    // in_run: trailing stop and milestones
    if (tracked.status === "in_run") {
      // Трейлинг только что активировался (пик пересёк +20%)
      if (trailingJustActivated) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgTrailingActivated(tracked, currentPrice, trailingStop));
        logger.info({ symbol: tracked.symbol, pnl: pnl.toFixed(2), trailingStop }, "FastCycle: TRAILING ACTIVATED 🚀");
        continue;
      }

      // Трейлинг сработал — фиксируем прибыль
      if (trailingHit && newPeak !== tracked.entryPrice) {
        const peakPnl = computePeakPnl({ ...tracked, peakPrice: newPeak });
        await db.update(trackedSignalsTable).set({
          status: "profit", exitPrice: currentPrice, pnlPercent: pnl,
          peakPrice: newPeak, trailingStopLevel: trailingStop,
          closedAt: new Date(), updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgTrailingStopHit(tracked, currentPrice, peakPnl, pnl));
        logger.info({ symbol: tracked.symbol, pnl, peakPnl }, "FastCycle: TRAILING STOP hit 🏁");
        continue;
      }

      const reachedMilestone = nextMilestone(tracked.lastMilestone, pnl);
      if (reachedMilestone) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop,
          lastMilestone: reachedMilestone, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
        await broadcast(msgMilestone(tracked, reachedMilestone, currentPrice, trailingStop));
        logger.info({ symbol: tracked.symbol, milestone: reachedMilestone }, "FastCycle: MILESTONE 🎯");
        continue;
      }

      if (peakChanged) {
        await db.update(trackedSignalsTable).set({
          peakPrice: newPeak, trailingStopLevel: trailingStop, updatedAt: new Date(),
        }).where(eq(trackedSignalsTable.id, tracked.id));
      }
    } else if (peakChanged) {
      // Update peak for active signals silently
      await db.update(trackedSignalsTable)
        .set({ peakPrice: newPeak, updatedAt: new Date() })
        .where(eq(trackedSignalsTable.id, tracked.id));
    }
  }
}

// ── OI Watch: message when volume finally confirms ────────────────────────────
function msgOiWatchFired(w: OiWatch, currentPrice: number, volMult: number, priceMovePct: number): string {
  const priceSinceWatch = ((currentPrice - w.priceAtEntry) / w.priceAtEntry * 100);
  const waitMin = Math.round((Date.now() - w.addedAt.getTime()) / 60_000);
  const tag = `#${w.symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
  const priceSign = priceMovePct >= 0 ? "+" : "";
  const pswSign = priceSinceWatch >= 0 ? "+" : "";
  const oiSign = w.oiChange >= 0 ? "+" : "";

  // Формат OI: показываем ТФ который сработал
  const oiDisplay = `ОИ: ${w.triggerTf}:${oiSign}${w.oiChange.toFixed(1)}%`;

  return [
    `⚡️ <b>ALPHA DETECTED: ${w.symbol}</b>`,
    ``,
    `🔹 <b>TECH:</b> Vol ${volMult.toFixed(1)}x | ${oiDisplay} | Price ${priceSign}${priceMovePct.toFixed(1)}%`,
    ``,
    `💰 <b>Цена:</b> ${fmtP(currentPrice)} | Вход в watch: ${fmtP(w.priceAtEntry)} (${pswSign}${priceSinceWatch.toFixed(1)}%)`,
    ``,
    `🔭 OI Watch: наблюдал <b>${waitMin} мин</b> — объём подтвердился (${volMult.toFixed(1)}x нормы)`,
    ``,
    `${tag} #oi_watch`,
  ].join("\n");
}

// ── OI Watch Cycle: checks every 2 min for volume/price confirmation ──────────
export async function runOiWatchCycle(): Promise<void> {
  const now = new Date();

  // Expire stale entries
  try {
    await db.update(oiWatchTable)
      .set({ status: "expired" })
      .where(and(eq(oiWatchTable.status, "watching"), lt(oiWatchTable.expiresAt, now)));
  } catch { /* non-critical */ }

  const watching = await db.select()
    .from(oiWatchTable)
    .where(eq(oiWatchTable.status, "watching"));

  if (watching.length === 0) return;

  // Fetch all prices in one call
  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch { return; }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  for (const w of watching) {
    const currentPrice = priceMap.get(w.symbol);
    if (!currentPrice) continue;

    const priceMovePct = ((currentPrice - w.priceAtEntry) / w.priceAtEntry) * 100;

    // ── PATH A: Confirmed signal (vol was already ≥ 2x at scanner time) ────────
    // Full payload stored — re-confirm price didn't collapse, then fire full signal.
    if (w.isVolConfirmed && w.signalPayload) {
      const pathAPayload = w.signalPayload as { alphaResult: any; signalRow: any };
      const pathASentimentKey: string = pathAPayload.alphaResult?.sentimentKey ?? "";

      // ── UNIFIED PRICE CONFIRMATION GATE ──────────────────────────────────────
      // Сигнал публикуется ТОЛЬКО если цена уже реально двинулась с момента обнаружения.
      // Статистика: 0 прибыльных сделок из 98 сигналов где итоговый пик < 3%.
      // Окно мониторинга 90 мин — либо цена подтверждает движение, либо сигнал тихо истекает.
      const PRICE_CONFIRM_PCT: Record<string, number> = {
        bear_trap:            2.0,  // шорты давят → быстрый разворот
        short_squeeze:        2.0,  // аналогично — ловим выдавливание
        aggressive_breakout:  1.5,  // уже взрывной объём — порог ниже
        sharp_impulse:        1.5,  // импульс на объёме — порог ниже
        impulse_breakout:     1.5,
        hidden_accumulation:  2.0,  // detectSentiment уже требует +2% при входе — не удваиваем
        bullish_accumulation: 2.0,
        anomaly:              3.5,  // нет чёткого паттерна → высокий порог
      };
      const minPriceMove = PRICE_CONFIRM_PCT[pathASentimentKey] ?? 2.0;

      // Если цена ещё не дошла до порога — ждём следующего цикла (не удаляем запись)
      if (priceMovePct < minPriceMove) {
        logger.debug(
          { symbol: w.symbol, pattern: pathASentimentKey, priceMovePct: priceMovePct.toFixed(1), required: minPriceMove },
          `OI Watch: ждём подтверждения цены — нужно +${minPriceMove}%, сейчас ${priceMovePct.toFixed(1)}%`
        );
        continue;
      }

      // Hard dump cancel: если цена упала > 5% с начала watch — монета не туда идёт
      if (priceMovePct < -5) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info({ symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) }, "OI Watch: отменён (дамп > 5% с начала watch)");
        continue;
      }

      // CVD финальная проверка: если продажи доминируют в момент выстрела — отменяем
      const cvd = await fetchCVD(w.symbol);
      if (cvd && !cvd.positive) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%" },
          "🔴 OI Watch: CVD негативный при выстреле — сигнал отменён"
        );
        continue;
      }
      if (cvd) {
        logger.info(
          { symbol: w.symbol, buyPct: cvd.buyPct.toFixed(1) + "%", sellPct: cvd.sellPct.toFixed(1) + "%" },
          "🟢 OI Watch: CVD подтверждён — стреляем"
        );
      }

      try {
        const payload = w.signalPayload as { alphaResult: any; signalRow: InsertSignal };
        const alphaResult = payload.alphaResult;
        const signalRow   = payload.signalRow;

        // Insert signal to DB
        const [inserted] = await db.insert(signalsTable).values({
          ...signalRow,
          price: currentPrice, // обновляем до текущей рыночной цены
          detectedAt: new Date(),
        }).returning();

        // Start tracking (stop-loss / targets)
        await trackSignal({
          symbol: w.symbol,
          signalId: inserted.id,
          signalType: alphaResult.grade ?? "alpha",
          sentiment: alphaResult.sentiment,
          sentimentKey: alphaResult.sentimentKey,
          alphaScore: alphaResult.alphaScore,
          entryPrice: currentPrice,
          entryOi: alphaResult.openInterest > 0 ? alphaResult.openInterest : null,
        });

        // Send full Telegram alert — включаем priceConfirmPct: насколько цена уже прошла
        await broadcastBatchAlert([{ ...alphaResult, price: currentPrice, priceConfirmPct: priceMovePct }]);

        // Mark fired
        await db.update(oiWatchTable)
          .set({ status: "fired", firedAt: new Date() })
          .where(eq(oiWatchTable.id, w.id));

        logger.info(
          { symbol: w.symbol, grade: alphaResult.grade, alphaScore: alphaResult.alphaScore, priceMovePct: priceMovePct.toFixed(1) },
          "✅ OI Watch → ПОЛНЫЙ СИГНАЛ: подтверждён и отправлен"
        );
      } catch (err) {
        logger.error({ err, symbol: w.symbol }, "OI Watch: ошибка при firing confirmed signal");
      }
      continue; // не падаем в PATH B
    }

    // ── PATH B-special: BingX Volume Watch — ждём OI подтверждения ───────────────
    // bingx_volume_watch: у монеты был взрывной объём + цена, но OI ещё не подтвердил.
    // Проверяем каждые 2 мин появление CoinGlass OI. Окно: 15 мин.
    // Если OI подтвердился → апгрейд до alpha и выстрел. Иначе → тихо истекаем.
    if (w.triggerTf === "bingx_volume_watch") {
      let cgOiBv: Awaited<ReturnType<typeof getCoinglassOI>> | null = null;
      try { cgOiBv = await getCoinglassOI(w.symbol); } catch { /* non-critical */ }

      const oiConfirmed = cgOiBv?.available && (
        (cgOiBv.oiChange5m  !== null && cgOiBv.oiChange5m  > 0) ||
        (cgOiBv.oiChange30m !== null && cgOiBv.oiChange30m > 0) ||
        (cgOiBv.oiChange1h  !== null && cgOiBv.oiChange1h  > 0)
      );

      if (oiConfirmed && w.signalPayload) {
        const payload = w.signalPayload as { alphaResult: any; signalRow: InsertSignal };
        const upgradedResult = { ...payload.alphaResult, grade: "alpha" as const };
        const upgradedRow: InsertSignal = { ...payload.signalRow, type: "alpha" };

        try {
          const [inserted] = await db.insert(signalsTable).values({
            ...upgradedRow,
            price: currentPrice,
            detectedAt: new Date(),
          }).returning();

          await trackSignal({
            symbol: w.symbol,
            signalId: inserted.id,
            signalType: "alpha",
            sentiment: upgradedResult.sentiment,
            sentimentKey: upgradedResult.sentimentKey,
            alphaScore: upgradedResult.alphaScore,
            entryPrice: currentPrice,
            entryOi: null,
          });

          await broadcastBatchAlert([{ ...upgradedResult, price: currentPrice }]);

          await db.update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(eq(oiWatchTable.id, w.id));

          logger.info(
            { symbol: w.symbol, oi5m: cgOiBv?.oiChange5m?.toFixed(1), oi30m: cgOiBv?.oiChange30m?.toFixed(1) },
            "📈 BingX Volume Watch → UPGRADED to alpha (OI подтвердил)"
          );
        } catch (err) {
          logger.error({ err, symbol: w.symbol }, "BingX Volume Watch: ошибка при апгрейде до alpha");
        }
      } else {
        logger.debug({ symbol: w.symbol, oiConfirmed }, "BingX Volume Watch: OI ещё не подтвердил — ждём...");
      }
      continue; // не проваливаемся в обычный PATH B
    }

    // ── PATH B: Unconfirmed watch (vol was < 2x at scanner time) ────────────────
    // Waiting for volume spike or price breakout to fire a lightweight alert.
    if (priceMovePct < -8) {
      await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
      logger.info({ symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) }, "OI Watch: expired (price dumped)");
      continue;
    }

    // Если цена уже улетела >20% от точки входа в watch — памп уже случился.
    // Входить сейчас = покупать на хае. BLEND: +61% от точки входа → не стреляем.
    if (priceMovePct >= 20) {
      await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
      logger.info(
        { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
        "OI Watch PATH B: expired — памп уже случился (price >= 20% от входа в watch)"
      );
      continue;
    }

    try {
      const klines = await getKlines(w.symbol, "30m", 7);
      if (klines.length < 5) continue;

      const cur  = klines[klines.length - 1];
      const hist = klines.slice(0, -1);
      const close    = parseFloat(cur.close) || 0;
      const curVol   = (parseFloat(cur.volume) || 0) * close;
      const avgVol   = w.avgVolume
        ?? (hist.reduce((s, k) => s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0), 0) / hist.length);
      if (!avgVol) continue;

      const volMult        = curVol / avgVol;
      const currentPriceMove = ((close - parseFloat(cur.open)) / parseFloat(cur.open)) * 100;
      // Порог объёма PATH B: 2.5x (синхронно с основным сканером).
      // Ключевой фильтр — OI кеп 10% (ниже), а не объём.
      // M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%) — победители с низким объёмом.
      const volThresholdB  = 2.5;
      const volConfirmed   = volMult >= volThresholdB;

      // Если OI отрицательный — накопления нет, это распродажа. Не стреляем.
      if (w.oiChange < 0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.debug({ symbol: w.symbol, oiChange: w.oiChange }, "OI Watch PATH B: OI отрицательный — сигнал отменён");
        continue;
      }

      // OI cap 10%: если OI при добавлении в watch уже был > 10% — это перегретый лонг/ловушка.
      // Данные: OI 25%+ = 0% win rate. AXL(90%), PIPPIN(56%), MOODENG(23%) — все SL.
      // Не стреляем даже если объём подтвердился — позиции уже перегреты.
      if (w.oiChange > 10) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, oiChange: w.oiChange.toFixed(1) + "%" },
          "OI Watch PATH B: OI > 10% — ловушка перегретого лонга, отменяем"
        );
        continue;
      }

      // Если цена уже упала >4% с момента входа в watch — движение идёт против нас.
      // Это либо распродажа, либо OI-рост был за счёт шортов. Отменяем.
      if (priceMovePct < -4.0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
          "OI Watch PATH B: цена упала >4% от входа — сигнал отменён"
        );
        continue;
      }

      // ── ОБЯЗАТЕЛЬНАЯ ПРОВЕРКА: Cross OI должен быть положительным при срабатывании ──
      // Подтягиваем свежие данные CoinGlass — 30m OI отражает текущий импульс.
      // Если он стал отрицательным — накопление завершилось / шорты уже закрыты. Отменяем.
      let cgOI: Awaited<ReturnType<typeof getCoinglassOI>> | null = null;
      try { cgOI = await getCoinglassOI(w.symbol); } catch { /* non-critical */ }

      if (cgOI?.available && cgOI.oiChange30m !== null && cgOI.oiChange30m < 0) {
        await db.update(oiWatchTable).set({ status: "expired" }).where(eq(oiWatchTable.id, w.id));
        logger.info(
          { symbol: w.symbol, crossOi30m: cgOI.oiChange30m.toFixed(1) + "%" },
          "OI Watch PATH B: Cross OI отрицательный — сигнал отменён"
        );
        continue;
      }

      // ── ФИЛЬТР: для накопления требуем подтверждение ценой ──────────────────────
      // PATH B стреляет когда объём подтвердился. Но для hidden_accumulation этого мало —
      // нужно чтобы цена ТОЖЕ начала двигаться (>= 2%). Иначе это накопление без выстрела.
      // null payload = добавлен из low-vol пути (OI есть, объём не пришёл) = всегда накопление.
      // Токены без движения цены (RARE +0.9%, WAVES +0.76%) остаются в watching до 2h экспайра.
      const pathBSentimentKey = (w.signalPayload as any)?.alphaResult?.sentimentKey ?? null;
      // Аномалия добавлена в список "требует подтверждения ценой" (наравне с накоплением).
      // Данные: anomaly win rate 13%, 9 SL из 15. Без OI-поддержки это просто спайк объёма — шум.
      // Требуем price >= 2% перед выстрелом — хотя бы минимальное подтверждение движения.
      const isAccumPatternB = pathBSentimentKey === "hidden_accumulation"
                           || pathBSentimentKey === "bullish_accumulation"
                           || pathBSentimentKey === "anomaly"
                           || pathBSentimentKey === null;
      const minPriceMoveB = 2.0;

      if (isAccumPatternB && priceMovePct < minPriceMoveB) {
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1), sentimentKey: pathBSentimentKey },
          `OI Watch PATH B: накопление — ждём движения цены >= ${minPriceMoveB}% (держим в watching)`
        );
        continue; // Остаётся в watching, не меняем статус — ждём пока цена тронется
      }

      if (volConfirmed) {
        await db.update(oiWatchTable)
          .set({ status: "fired", firedAt: new Date() })
          .where(eq(oiWatchTable.id, w.id));

        // Если payload с полным AlphaResult сохранён — используем полный формат с OI по ТФ
        if (w.signalPayload) {
          const payload = w.signalPayload as { alphaResult: any; signalRow: any };
          // Обновляем coinalyzeOiChange свежими данными CoinGlass перед отправкой
          const freshCoinalyze = cgOI?.oiChange30m ?? (payload.alphaResult.coinalyzeOiChange ?? null);
          const fullResult = {
            ...payload.alphaResult,
            price: currentPrice,
            volumeMultiplier: volMult,
            priceChange30m: priceMovePct,
            coinalyzeOiChange: freshCoinalyze,
          };
          await broadcastBatchAlert([fullResult]);
        } else {
          // Fallback: payload отсутствует (токен добавлен с низким объёмом без полного скана).
          // Используем уже полученный cgOI (не делаем повторный запрос).
          const base = w.symbol.replace("-USDT", "");
          const tvUrl  = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT`;
          const bingxUrl = `https://bingx.com/en/trade/${base}USDT/`;
          const waitMin = Math.round((Date.now() - w.addedAt.getTime()) / 60_000);

          // Определяем triggerTf — убираем префикс "all+" если был
          const displayTf = w.triggerTf.replace(/^all\+/, "");

          // Если CoinGlass API недоступен (cgOI = null) — используем сохранённое w.oiChange
          // как значение для сработавшего TF, чтобы в сигнале было видно OI по ТФ, а не просто число.
          const storedOi = w.oiChange;
          const cgOi5m  = cgOI?.oiChange5m  ?? (displayTf === "5m"  ? storedOi : null);
          const cgOi30m = cgOI?.oiChange30m ?? (displayTf === "30m" || displayTf === "steady" ? storedOi : null);
          const cgOi1h  = cgOI?.oiChange1h  ?? (displayTf === "1h"  ? storedOi : null);
          const cgOi4h  = cgOI?.oiChange4h  ?? (displayTf === "4h"  ? storedOi : null);
          const cgOi24h = cgOI?.oiChange24h ?? (displayTf === "24h" ? storedOi : null);

          const syntheticResult: Parameters<typeof broadcastBatchAlert>[0][0] = {
            symbol: w.symbol,
            grade: "alpha",
            price: currentPrice,
            priceChange30m: priceMovePct,
            currentVolume: curVol,
            avgVolume: avgVol,
            volumeMultiplier: volMult,
            oiChangePercent: w.oiChange,
            openInterest: null,
            cmcRank: null,
            cmcSource: null,
            cmcAvailable: false,
            liquidationsUsd: null,
            liquidationsMultiple: null,
            coinglassAvailable: cgOI?.available ?? false,
            coinalyzeOiChange: cgOi30m,
            coinalyzeConfirmed: false,
            isNewListing: false,
            isExhaustedSqueeze: false,
            pumpFromOpen: null,
            candleCount: 48,
            sentiment: "🔭 OI Watch",
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            traderAction: `Наблюдал ${waitMin} мин — объём подтвердился`,
            alphaScore: 5,
            isContinuing: false,
            cumulativeOiChange: w.oiChange,
            tradingViewUrl: tvUrl,
            bingxUrl,
            oiTriggerTf: displayTf,
            oiChange5m:  cgOi5m,
            oiChange1h:  cgOi1h,
            oiChange4h:  cgOi4h,
            oiChange24h: cgOi24h,
          };
          await broadcastBatchAlert([syntheticResult]);
        }

        // ── Создаём tracked_signal чтобы вотчер мог сопровождать сигнал ─────────
        // PATH B раньше не создавал запись → не было уведомлений о БУ и milestone.
        // Теперь вставляем сигнал и запускаем tracking, как в PATH A.
        try {
          const base = w.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

          // Используем свежую цену из тикера (currentPrice), а не close из kline!
          // close — это цена закрытия 30м свечи, может быть на 30 минут устаревшей.
          // Ошибка: entryPrice: close → бот считал +11% вместо реального +1%.
          const [inserted] = await db.insert(signalsTable).values({
            symbol: w.symbol,
            type: "alpha",
            value: volMult,       // множитель объёма (как в PATH A), не OI
            threshold: 0,
            price: currentPrice,
            priceChangePercent: priceMovePct,
            volume24h: curVol,
            avgVolume: w.avgVolume ?? 0,
            openInterest: null,
            oiChangePercent: w.oiChange,
            tradingViewUrl: tvUrl,
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            detectedAt: new Date(),
          }).returning();

          await trackSignal({
            symbol: w.symbol,
            signalId: inserted.id,
            signalType: "alpha",
            sentiment: null,
            sentimentKey: w.sentimentKey ?? "hidden_accumulation",
            alphaScore: null,
            entryPrice: currentPrice,
            entryOi: null,
          });

          logger.info(
            { symbol: w.symbol, entryPrice: currentPrice, klinesClose: close },
            "🔭 OI Watch PATH B: tracked_signal создан — сопровождение активно"
          );
        } catch (trackErr) {
          logger.error({ err: trackErr, symbol: w.symbol }, "OI Watch PATH B: ошибка при создании tracked_signal");
        }

        logger.info(
          { symbol: w.symbol, volMult: volMult.toFixed(2), priceMovePct: priceMovePct.toFixed(1), volConfirmed },
          "🔭➡️🚀 OI Watch FIRED (volume confirmed)"
        );
      }
    } catch (err) {
      logger.debug({ err, symbol: w.symbol }, "OI Watch PATH B: klines fetch failed");
    }
  }
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
let cycleTimer:       NodeJS.Timeout | null = null;
let fastTimer:        NodeJS.Timeout | null = null;
let dailyTimer:       NodeJS.Timeout | null = null;
let weeklyTimer:      NodeJS.Timeout | null = null;
let monthlyTimer:     NodeJS.Timeout | null = null;
let whaleTimer:       NodeJS.Timeout | null = null;
let whaleSatTimer:    NodeJS.Timeout | null = null;
let positionsTimer:   NodeJS.Timeout | null = null;

/** Миллисекунды до следующего HH:MM:00 UTC */
function msUntilUtc(targetHour: number, targetMin: number, targetDayOfWeek?: number): number {
  const now = new Date();
  const next = new Date(now);
  next.setUTCSeconds(0, 0);
  next.setUTCMinutes(targetMin);
  next.setUTCHours(targetHour);

  if (targetDayOfWeek !== undefined) {
    // Воскресенье = 0
    const currentDay = now.getUTCDay();
    let daysUntil = (targetDayOfWeek - currentDay + 7) % 7;
    // Если сегодня целевой день, но время уже прошло — ждём следующей недели
    if (daysUntil === 0 && next.getTime() <= now.getTime()) {
      daysUntil = 7;
    }
    next.setUTCDate(now.getUTCDate() + daysUntil);
  } else {
    // Ежедневно — если уже прошло сегодня, переносим на завтра
    if (next.getTime() <= now.getTime()) {
      next.setUTCDate(next.getUTCDate() + 1);
    }
  }

  return next.getTime() - now.getTime();
}

/** Миллисекунды до следующего 1-го числа месяца в HH:MM UTC */
function msUntilFirstOfMonth(targetHour: number, targetMin: number): number {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, targetHour, targetMin, 0, 0));
  // Если сейчас уже 1-е число и время ещё не наступило — отправляем сегодня
  if (now.getUTCDate() === 1) {
    const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, targetHour, targetMin, 0, 0));
    if (today.getTime() > now.getTime()) return today.getTime() - now.getTime();
  }
  return next.getTime() - now.getTime();
}

// ── Whale Accumulation Jobs ───────────────────────────────────────────────────

/**
 * Ежедневный сбор OI снимков (00:05 UTC).
 * Читает все активные тикеры BingX, параллельно батчем CoinGlass, сохраняет по одному на символ.
 */
async function runDailyOiSnapshot(): Promise<void> {
  logger.info("🐋 Daily OI snapshot job started");

  let tickers: any[] = [];
  try {
    tickers = await getFutureTickers() as any[];
  } catch (err) {
    logger.error({ err }, "🐋 OI snapshot: failed to fetch tickers");
    return;
  }

  // Фильтруем USDT-M перпетуалы
  const symbols: string[] = tickers
    .filter((t: any) => t.symbol?.endsWith("-USDT"))
    .map((t: any) => t.symbol as string);

  const priceMap = new Map<string, number>();
  const vol24Map = new Map<string, number>();
  for (const t of tickers) {
    if (t.symbol) {
      priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
      vol24Map.set(t.symbol, parseFloat(t.quoteVolume) || parseFloat(t.volume) || 0);
    }
  }

  // Батч CoinGlass (уже ограничен 30 req/min внутри batchGetCoinglassOI)
  let cgData = new Map<string, any>();
  try {
    cgData = await batchGetCoinglassOI(symbols);
  } catch (err) {
    logger.warn({ err }, "🐋 OI snapshot: CoinGlass batch failed — prices only");
  }

  const { saved, skipped } = await saveDailyOiSnapshots(cgData, priceMap, vol24Map);
  logger.info({ saved, skipped, total: symbols.length }, "🐋 Daily OI snapshot job complete");
}

/**
 * Еженедельный whale анализ (Суббота 10:00 МСК = 07:00 UTC).
 * Находит токены с признаками китового накопления и рассылает отчёт.
 */
async function runWeeklyWhaleAnalysis(): Promise<void> {
  logger.info("🐋 Weekly whale analysis started");

  const candidates = await getAllWhaleAccumCandidates();

  if (candidates.length === 0) {
    logger.info("🐋 Weekly whale analysis: нет кандидатов (high/medium confidence)");
    return;
  }

  const signals: WhaleAccumSignalInput[] = candidates
    .filter(c => c.confidence !== "low")
    .map(c => ({
      symbol:         c.symbol,
      daysTracked:    c.daysTracked,
      oiGrowthPct:    c.oiGrowthPct,
      priceChangePct: c.priceChangePct,
      consistencyPct: c.consistencyPct,
      avgVolRatio:    c.avgVolRatio,
      confidence:     c.confidence as "high" | "medium",
      reason:         c.reason,
    }));

  logger.info({ count: signals.length }, "🐋 Broadcasting whale accumulation signals");
  await broadcastWhaleAccumAlert(signals);
}

export function startWatcher(): void {
  logger.info("Alpha Watcher started");

  // Startup reset — проверяем стоп-лоссы и трейлинги пропущенные за время простоя.
  // Запуск 1: через 10с (BingX API ещё может быть холодным — внутри retry 3×3s).
  // Запуск 2: через 3 мин — страховочный прогон если первый упал на API таймауте.
  setTimeout(async () => {
    try { await runStartupReset(); } catch (err) { logger.error({ err }, "Startup reset #1 error"); }
  }, 10_000);
  setTimeout(async () => {
    try { await runStartupReset(); } catch (err) { logger.error({ err }, "Startup reset #2 error"); }
    logger.info("Startup reset #2 complete (safety net)");
  }, 3 * 60_000);

  // Fast cycle every 2 min — active + in_run (stop-loss, first target, trailing)
  // Also runs OI Watch cycle (check for volume confirmation on watch candidates)
  const runFast = async () => {
    if (!fastTimer) return;
    try { await runInRunFastCycle(); } catch (err) { logger.error({ err }, "FastCycle error"); }
    try { await runOiWatchCycle(); } catch (err) { logger.error({ err }, "OiWatchCycle error"); }
    fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  };
  // First fast cycle at 2 min (after startup reset at 5s)
  fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  logger.info({ intervalMin: FAST_CYCLE_MS / 60000 }, "Fast cycle started (active + in_run + OI watch, 2min)");

  // MEXC Spot Pump Scanner — every 15 min, independent of BingX futures scan
  startMexcScanner().catch(err => logger.error({ err }, "MEXC scanner start error"));

  // Watcher cycle every 10 min — handles ONLY accumulation signals.
  // Starts at 7 min to avoid any race with the first FastCycle (at 2 min).
  const runCycle = async () => {
    if (!cycleTimer) return;
    try {
      const r = await runWatcherCycle();
      logger.info(r, "Watcher cycle complete");
    } catch (err) {
      logger.error({ err }, "Watcher cycle error");
    }
    cycleTimer = setTimeout(runCycle, 10 * 60 * 1000);
  };
  cycleTimer = setTimeout(runCycle, 7 * 60 * 1000);

  // Daily at 21:00 МСК = 18:00 UTC
  const scheduleDaily = () => {
    const ms = msUntilUtc(18, 0);
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Daily report scheduled (21:00 МСК)");
    dailyTimer = setTimeout(async () => {
      try { await sendDailyReport(); } catch (err) { logger.error({ err }, "Daily report error"); }
      scheduleDaily();
    }, ms);
  };
  scheduleDaily();

  // ── Missed-report guard ───────────────────────────────────────────────────────
  // Ловим два случая пропуска:
  // 1. Перезапуск ПОСЛЕ 18:00 UTC сегодня — отчёт за сегодня не отправлен.
  // 2. Перезапуск утром (до 18:00 UTC) — но вчерашний отчёт тоже не отправлен.
  setTimeout(async () => {
    try {
      const nowUtc = new Date();

      // Порог за сегодня (18:00 UTC = 21:00 МСК)
      const todayReportUtc = new Date(nowUtc);
      todayReportUtc.setUTCHours(18, 0, 0, 0);

      // Порог за вчера (18:00 UTC вчерашнего дня)
      const yesterdayReportUtc = new Date(todayReportUtc);
      yesterdayReportUtc.setUTCDate(yesterdayReportUtc.getUTCDate() - 1);

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastDailyReportAt;

      // Пропущен сегодняшний отчёт: уже после 18:00, но не отправляли с 18:00
      const missedToday = nowUtc >= todayReportUtc && (!lastSent || lastSent < todayReportUtc);

      // Пропущен вчерашний отчёт: последний раз отправляли раньше 18:00 вчера
      const missedYesterday = !lastSent || lastSent < yesterdayReportUtc;

      if (!missedToday && !missedYesterday) {
        logger.info({ lastSent }, "Daily report guard: всё в порядке, пропуска нет");
        return;
      }

      logger.warn(
        { lastSent, nowUtc, missedToday, missedYesterday },
        "Missed daily report detected — sending now"
      );
      await sendDailyReport();
    } catch (err) {
      logger.error({ err }, "Missed-report guard error");
    }
  }, 30_000); // 30с после старта

  // ── Missed-weekly guard ───────────────────────────────────────────────────────
  // Если сервер перезапустился в воскресенье после 09:00 МСК (06:00 UTC) и дайджест
  // ещё не был отправлен на этой неделе — отправляем через 60с после старта.
  setTimeout(async () => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDay() !== 0) return; // Не воскресенье — пропускаем

      const thisWeekDigestUtc = new Date(nowUtc);
      thisWeekDigestUtc.setUTCHours(6, 0, 0, 0); // 06:00 UTC = 09:00 МСК

      if (nowUtc < thisWeekDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastWeeklyDigestAt;

      const alreadySentThisWeek = lastSent && lastSent >= thisWeekDigestUtc;
      if (alreadySentThisWeek) {
        logger.info({ lastSent }, "Weekly digest already sent this week — skipping missed-digest check");
        return;
      }

      logger.warn({ lastSent, nowUtc }, "Missed weekly digest detected — sending now");
      await sendWeeklyDigest();
    } catch (err) {
      logger.error({ err }, "Missed-weekly guard error");
    }
  }, 60_000); // 60с после старта

  // Weekly Sunday at 09:00 МСК = 06:00 UTC
  const scheduleWeekly = () => {
    const ms = msUntilUtc(6, 0, 0); // 0 = Sunday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Weekly digest scheduled (Вс 09:00 МСК)");
    weeklyTimer = setTimeout(async () => {
      try { await sendWeeklyDigest(); } catch (err) { logger.error({ err }, "Weekly digest error"); }
      scheduleWeekly();
    }, ms);
  };
  scheduleWeekly();

  // ── Missed-monthly guard ──────────────────────────────────────────────────────
  // Если сервер перезапустился 1-го числа после 10:00 МСК (07:00 UTC) и дайджест
  // ещё не был отправлен в этом месяце — отправляем через 90с после старта.
  setTimeout(async () => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDate() !== 1) return; // Не 1-е число — пропускаем

      const thisMonthDigestUtc = new Date(Date.UTC(nowUtc.getUTCFullYear(), nowUtc.getUTCMonth(), 1, 7, 0, 0, 0));
      if (nowUtc < thisMonthDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastMonthlyDigestAt;

      const alreadySentThisMonth = lastSent && lastSent >= thisMonthDigestUtc;
      if (alreadySentThisMonth) {
        logger.info({ lastSent }, "Monthly digest already sent this month — skipping missed-digest check");
        return;
      }

      logger.warn({ lastSent, nowUtc }, "Missed monthly digest detected — sending now");
      await sendMonthlyDigest();
    } catch (err) {
      logger.error({ err }, "Missed-monthly guard error");
    }
  }, 90_000); // 90с после старта

  // Monthly — 1-е число каждого месяца в 10:00 МСК = 07:00 UTC
  // ВНИМАНИЕ: setTimeout имеет лимит ~24.8 дней (2^31 мс). Для месячного таймера
  // это может переполниться (30 дней = 2.6 млрд мс > 2.15 млрд лимита) и вызвать
  // бесконечный цикл (таймер срабатывает немедленно через 1мс).
  // Решение: если до события > 23 дней — планируем промежуточную проверку.
  const MAX_SAFE_TIMEOUT_MS = 23 * 24 * 60 * 60 * 1000; // 23 дня — безопасный максимум
  const scheduleMonthly = () => {
    const ms = msUntilFirstOfMonth(7, 0);
    if (ms > MAX_SAFE_TIMEOUT_MS) {
      // Слишком далеко для одного setTimeout — планируем промежуточную проверку через 23 дня
      logger.info({ nextAt: new Date(Date.now() + ms).toISOString(), retryIn: "23d" }, "Monthly digest: слишком далеко, промежуточная проверка через 23 дня");
      monthlyTimer = setTimeout(scheduleMonthly, MAX_SAFE_TIMEOUT_MS);
      return;
    }
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Monthly digest scheduled (1-е число, 10:00 МСК)");
    monthlyTimer = setTimeout(async () => {
      try { await sendMonthlyDigest(); } catch (err) { logger.error({ err }, "Monthly digest error"); }
      scheduleMonthly();
    }, ms);
  };
  scheduleMonthly();

  // ── Daily OI snapshot at 00:05 UTC (whale accumulation data collection) ────
  const scheduleWhaleSnapshot = () => {
    const ms = msUntilUtc(0, 5);
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "🐋 Daily OI snapshot scheduled (00:05 UTC)");
    whaleTimer = setTimeout(async () => {
      try { await runDailyOiSnapshot(); } catch (err) { logger.error({ err }, "🐋 Daily OI snapshot error"); }
      scheduleWhaleSnapshot();
    }, ms);
  };
  scheduleWhaleSnapshot();

  // ── Weekly whale analysis on Saturday 07:00 UTC = 10:00 МСК ───────────────
  const scheduleWhaleSaturday = () => {
    const ms = msUntilUtc(7, 0, 6); // 6 = Saturday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "🐋 Weekly whale analysis scheduled (Сб 10:00 МСК)");
    whaleSatTimer = setTimeout(async () => {
      try { await runWeeklyWhaleAnalysis(); } catch (err) { logger.error({ err }, "🐋 Weekly whale analysis error"); }
      scheduleWhaleSaturday();
    }, ms);
  };
  scheduleWhaleSaturday();

  // ── Periodic positions update every 4 hours ───────────────────────────────
  const POSITIONS_INTERVAL_MS = 4 * 60 * 60 * 1000; // 4 часа
  const runPositionsUpdate = async () => {
    if (!positionsTimer) return;
    try {
      const text = await buildPositionsStatusText();
      const rows = await db.select({ channelId: settingsTable.channelId }).from(settingsTable).limit(1);
      const channelId = rows[0]?.channelId?.trim();
      if (channelId) {
        await sendMessage(channelId, text);
      }
      logger.info("Positions update sent to channel");
    } catch (err) {
      logger.error({ err }, "Positions update error");
    }
    positionsTimer = setTimeout(runPositionsUpdate, POSITIONS_INTERVAL_MS);
  };
  positionsTimer = setTimeout(runPositionsUpdate, POSITIONS_INTERVAL_MS);
  logger.info({ intervalH: 4 }, "Positions update scheduled (every 4h)");
}

export function stopWatcher(): void {
  if (fastTimer)       { clearTimeout(fastTimer);       fastTimer       = null; }
  if (cycleTimer)      { clearTimeout(cycleTimer);      cycleTimer      = null; }
  if (dailyTimer)      { clearTimeout(dailyTimer);      dailyTimer      = null; }
  if (weeklyTimer)     { clearTimeout(weeklyTimer);     weeklyTimer     = null; }
  if (monthlyTimer)    { clearTimeout(monthlyTimer);    monthlyTimer    = null; }
  if (whaleTimer)      { clearTimeout(whaleTimer);      whaleTimer      = null; }
  if (whaleSatTimer)   { clearTimeout(whaleSatTimer);   whaleSatTimer   = null; }
  if (positionsTimer)  { clearTimeout(positionsTimer);  positionsTimer  = null; }
  stopMexcScanner();
  logger.info("Alpha Watcher stopped");
}
