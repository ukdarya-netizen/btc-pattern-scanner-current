/**
 * MEXC Futures Pump Scanner
 *
 * Detects low-cap shitcoin pumps on MEXC perpetual futures.
 * Uses MEXC's own public API — no CoinGlass needed:
 *   • holdVol (OI in contracts) tracked between scans → OI change %
 *   • fundingRate — aggressive longs pushing rate up
 *   • 30m volume spike ≥ 2.5x baseline (первые 30 из 50 свечей = ~15h назад, pre-pump уровень)
 *   • 30m price >= 4%, 24h price >= 15%
 *   • Vol/OI ratio >= 2x (объём ≥ 2× капитализации фьючерса) — ключевой шиток-фильтр
 *     BTC ratio ~0.2x, активный щиток 2-10x+
 *
 * Baseline approach: используем СТАРЫЕ 30 свечей (из 50 фетченных) как базу.
 * Это даёт pre-pump уровень даже если монета уже качается несколько часов.
 * Rolling 20-avg поднимается вместе с пампом → мультипликатор занижается (LAB-кейс).
 *
 * Blocked majors: BTC ETH SOL BNB XRP ADA DOGE TON AVAX LINK DOT
 * Cooldown 4h per symbol. Runs every 15 min aligned to :00 :15 :30 :45.
 */

import { getMexcFuturesTickers, getMexcFuturesKlines, getMexcFuturesDepth } from "./mexc.js";
import type { MexcFuturesTicker }                                            from "./mexc.js";
import { broadcastMexcPumpAlert }                                            from "./telegram.js";
import { trackSignal }                                                       from "./watcher.js";
import { db, signalsTable }                                                  from "@workspace/db";
import { eq, and, gte }                                                      from "drizzle-orm";
import { logger as rootLogger }                                              from "./logger.js";

const logger = rootLogger.child({ module: "mexcScanner" });

// ── Thresholds ────────────────────────────────────────────────────────────────
const SCAN_INTERVAL_MS   = 15 * 60 * 1000;
const TOP_CANDIDATES     = 40;
const VOL_MULT_MIN       = 2.5;       // 30m volume spike vs pre-pump baseline (было 4.0 — слишком строго для slow grinders)
const PRICE_30M_MIN      = 4.0;       // 30m candle price move %
const PRICE_24H_MIN      = 15.0;      // 24h price change % — минимум
const PRICE_24H_MAX      = 40.0;      // 24h price change % — увеличено с 20% до 40%
const AMOUNT24_MIN_USD   = 10_000;    // мин. 24h USDT объём ($10K) — щитки могут быть маленькими
// Нет абсолютного потолка объёма — фильтруем по Vol/OI ratio:
const VOL_OI_RATIO_MIN   = 1.2;       // 24h объём ≥ 1.2× OI в USD = активный памп (снижено с 2.0)
//   BTC ~ 0.15–0.25x, ETH ~ 0.3x, активный щиток 2–15x+
const OI_CHANGE_MIN      = 2.0;       // OI must be growing >= 2%
const COOLDOWN_MS        = 4 * 60 * 60 * 1000;
// Baseline: фетчим 50 свечей, используем ПЕРВЫЕ 30 как pre-pump уровень.
// Rolling avg поднимается вместе с пампом → мультипликатор занижается (LAB-кейс).
// Первые 30 свечей = ~15h назад, как правило ДО начала движения.
const KLINES_FETCH       = 50;
const BASELINE_CANDLES   = 30;       // сколько старых свечей брать в baseline

const MAJOR_SYMBOLS = new Set([
  "BTC_USDT", "ETH_USDT", "SOL_USDT", "BNB_USDT", "XRP_USDT",
  "ADA_USDT", "DOGE_USDT", "TON_USDT", "AVAX_USDT", "LINK_USDT",
  "DOT_USDT", "MATIC_USDT", "LTC_USDT", "TRX_USDT", "SUI_USDT",
  "APT_USDT", "OP_USDT", "ARB_USDT", "NEAR_USDT", "FTM_USDT",
]);

// ── State ─────────────────────────────────────────────────────────────────────
let scanTimer: ReturnType<typeof setTimeout> | null = null;
let running = false;

/** OI snapshot from previous scan: symbol → holdVol */
const prevHoldVol = new Map<string, number>();

/** Cooldown: symbol → lastFiredAt timestamp */
const cooldownMap = new Map<string, number>();

// ── Helpers ───────────────────────────────────────────────────────────────────
function msUntilNextBoundary(intervalMs: number): number {
  const now = Date.now();
  const msToNext = intervalMs - (now % intervalMs);
  return msToNext + 2_000;
}

function isOnCooldown(symbol: string): boolean {
  const last = cooldownMap.get(symbol);
  return !!last && Date.now() - last < COOLDOWN_MS;
}

async function isOnDbCooldown(symbol: string): Promise<boolean> {
  const since = new Date(Date.now() - COOLDOWN_MS);
  const normalized = symbol.replace("_", "-");
  const rows = await db.select({ id: signalsTable.id })
    .from(signalsTable)
    .where(and(
      eq(signalsTable.symbol, normalized),
      eq(signalsTable.type, "mexc_pump"),
      gte(signalsTable.detectedAt, since),
    ))
    .limit(1);
  return rows.length > 0;
}

function volOiRatio(t: MexcFuturesTicker): number {
  const oiUsd = t.holdVol * t.lastPrice;
  return oiUsd > 0 ? t.amount24 / oiUsd : 0;
}

function isShitcoinCandidate(t: MexcFuturesTicker): boolean {
  if (MAJOR_SYMBOLS.has(t.symbol)) return false;
  const change24h = t.riseFallRate * 100;
  if (change24h < PRICE_24H_MIN)          return false;
  if (change24h > PRICE_24H_MAX)          return false; // уже улетела — поздно входить
  if (t.amount24 < AMOUNT24_MIN_USD)      return false;
  if (volOiRatio(t) < VOL_OI_RATIO_MIN)  return false; // мейджоры отсекаются здесь (BTC~0.2x)
  return true;
}

// ── Core scan ─────────────────────────────────────────────────────────────────
async function performMexcScan(): Promise<void> {
  logger.info("MEXC Futures pump scan started");
  const t0 = Date.now();

  let tickers: MexcFuturesTicker[];
  try {
    tickers = await getMexcFuturesTickers();
  } catch (err) {
    logger.error({ err }, "MEXC futures tickers fetch failed — skip scan");
    return;
  }

  // Pre-screen: сортируем по Vol/OI ratio desc — самые "горячие" по соотношению к OI первыми
  const prescreened = tickers
    .filter(isShitcoinCandidate)
    .sort((a, b) => volOiRatio(b) - volOiRatio(a))
    .slice(0, TOP_CANDIDATES);

  logger.info({ prescreened: prescreened.length, total: tickers.length }, "MEXC pre-screen done");

  const signals: MexcPumpCandidate[] = [];

  for (const ticker of prescreened) {
    const symbol = ticker.symbol; // "TOKEN_USDT"
    if (isOnCooldown(symbol)) { logger.debug({ symbol }, "MEXC cooldown — skip"); continue; }
    if (await isOnDbCooldown(symbol)) { logger.debug({ symbol }, "MEXC DB cooldown — skip"); continue; }

    // ── OI change vs previous scan ──────────────────────────────────────────
    const prevOI = prevHoldVol.get(symbol);
    const oiChangePct = prevOI && prevOI > 0
      ? ((ticker.holdVol - prevOI) / prevOI) * 100
      : null; // first scan — no baseline yet

    // Update snapshot
    prevHoldVol.set(symbol, ticker.holdVol);

    // Require positive OI growth OR allow on first scan if volume is anomalous
    if (oiChangePct !== null && oiChangePct < OI_CHANGE_MIN) {
      logger.debug({ symbol, oiChangePct: oiChangePct.toFixed(1) }, "MEXC OI not growing — skip");
      continue;
    }
    // Первый скан: если объём аномален (>10x) И цена уже растёт (>5% за 30m) — сигнал без OI-базы
    // Иначе ждём следующего скана когда oiChangePct будет доступен
    if (oiChangePct === null) {
      if (ticker.volMult > 10.0 && ticker.priceChange30m > 5.0) {
        logger.info(
          { symbol, volMult: ticker.volMult.toFixed(1), priceChange: ticker.priceChange30m.toFixed(1) },
          "MEXC: первый скан с аномальным объёмом и ростом — разрешаем вход без OI-базы"
        );
        // Продолжаем (не делаем continue) — сигнал пройдёт дальнейшие проверки
      } else {
        logger.debug({ symbol }, "MEXC: первый скан без аномального объёма — ждём OI-базу");
        continue;
      }
    }

    // ── Klines: 30m volume spike ────────────────────────────────────────────
    let klines: Awaited<ReturnType<typeof getMexcFuturesKlines>>;
    try {
      klines = await getMexcFuturesKlines(symbol, "Min30", KLINES_FETCH);
    } catch (err) {
      logger.debug({ symbol, err }, "MEXC klines fetch failed — skip");
      continue;
    }

    const len = klines.time.length;
    if (len < BASELINE_CANDLES + 1) continue;

    // ── Текущая (последняя) свеча ────────────────────────────────────────────
    const currentVol    = klines.vol[len - 1];
    const currentAmount = klines.amount[len - 1];  // USDT
    const currentClose  = klines.close[len - 1];
    const currentOpen   = klines.open[len - 1];
    const price30mPct   = currentOpen > 0
      ? ((currentClose - currentOpen) / currentOpen) * 100
      : 0;

    // ── Pre-pump baseline: ПЕРВЫЕ 30 свечей (oldest) вместо rolling-20 ────────
    // Rolling 20-avg растёт вместе с пампом → мультипликатор занижается (LAB-кейс).
    // Старые 30 свечей ≈ 15h назад, как правило ДО начала движения.
    const baselineVols  = klines.vol.slice(0, BASELINE_CANDLES);
    const avgVol        = baselineVols.reduce((s, v) => s + v, 0) / baselineVols.length;
    const baselineAmts  = klines.amount.slice(0, BASELINE_CANDLES);
    const avgAmount     = baselineAmts.reduce((s, v) => s + v, 0) / baselineAmts.length;

    if (avgVol <= 0) continue;
    const volMult = currentVol / avgVol;

    // ── Prev candle fast track (timing gap fix) ──────────────────────────────
    // Если сканер запустился когда большая свеча только что закрылась — ловим её.
    const prev1Vol    = len >= 2 ? klines.vol[len - 2]   : 0;
    const prev1Open   = len >= 2 ? klines.open[len - 2]  : 0;
    const prev1Close  = len >= 2 ? klines.close[len - 2] : 0;
    const prev1Price  = prev1Open > 0 ? ((prev1Close - prev1Open) / prev1Open) * 100 : 0;
    const prev1Mult   = avgVol > 0 ? prev1Vol / avgVol : 0;
    // Цена не откатилась >5% от закрытия предыдущей свечи — памп ещё держится
    const priceNotRetracedFromPrev = prev1Close > 0
      ? (currentClose - prev1Close) / prev1Close > -0.05
      : false;
    const prevCandleFastTrack = prev1Price >= PRICE_30M_MIN
      && prev1Mult >= VOL_MULT_MIN
      && priceNotRetracedFromPrev;

    const currentPasses = volMult >= VOL_MULT_MIN && price30mPct >= PRICE_30M_MIN;

    if (!currentPasses && !prevCandleFastTrack) {
      if (volMult < VOL_MULT_MIN) {
        logger.debug({ symbol, volMult: volMult.toFixed(2), prev1Mult: prev1Mult.toFixed(2) }, "MEXC vol spike < 2.5x — skip");
      } else {
        logger.debug({ symbol, price30mPct: price30mPct.toFixed(1) }, "MEXC 30m price < 4% — skip");
      }
      continue;
    }

    // Для сигнала используем свечу, которая сработала
    const triggerPrice30m = currentPasses ? price30mPct : prev1Price;
    const triggerVolMult  = currentPasses ? volMult      : prev1Mult;
    const isFastTrackPrev = !currentPasses && prevCandleFastTrack;

    // ── Depth: bid/ask imbalance ────────────────────────────────────────────
    let bidRatio: number | null = null;
    try {
      const depth = await getMexcFuturesDepth(symbol, 20);
      const bidVol = depth.bids.slice(0, 10).reduce((s, l) => s + l.qty, 0);
      const askVol = depth.asks.slice(0, 10).reduce((s, l) => s + l.qty, 0);
      if (askVol > 0) bidRatio = bidVol / askVol;
    } catch { /* non-critical */ }

    const price24hPct  = ticker.riseFallRate * 100;
    const oiUsd        = ticker.holdVol * currentClose;
    const volOiRatioCurrent = oiUsd > 0 ? ticker.amount24 / oiUsd : 0;

    signals.push({
      symbol,
      price: currentClose,
      price30mPct:      triggerPrice30m,
      price24hPct,
      volMult:          triggerVolMult,
      currentAmountUsd: currentAmount,
      avgAmountUsd:     avgAmount,
      amount24hUsd:     ticker.amount24,
      oiUsd,
      volOiRatio:       volOiRatioCurrent,
      holdVol:          ticker.holdVol,
      oiChangePct,
      fundingRate:      ticker.fundingRate,
      bidRatio,
      fastTrackPrev:    isFastTrackPrev,
    });

    logger.info(
      {
        symbol,
        volMult:       triggerVolMult.toFixed(2) + "x",
        price30m:      triggerPrice30m.toFixed(1) + "%",
        price24h:      price24hPct.toFixed(0) + "%",
        volOiRatio:    volOiRatioCurrent.toFixed(1) + "x",
        oiChange:      oiChangePct !== null ? oiChangePct.toFixed(1) + "%" : "n/a (first scan)",
        funding:       (ticker.fundingRate * 100).toFixed(4) + "%",
        bidRatio:      bidRatio?.toFixed(2) ?? "n/a",
        fastTrackPrev: isFastTrackPrev,
      },
      "🟣 MEXC FUTURES PUMP DETECTED"
    );
  }

  // ── Send signals ───────────────────────────────────────────────────────────
  if (signals.length > 0) {
    await broadcastMexcPumpAlert(signals);
    for (const s of signals) {
      cooldownMap.set(s.symbol, Date.now());
    }
    try {
      const inserted = await db.insert(signalsTable).values(signals.map(s => ({
        symbol:             s.symbol.replace("_", "-"),  // "TOKEN-USDT"
        type:               "mexc_pump" as const,
        value:              s.volMult,
        threshold:          VOL_MULT_MIN,
        price:              s.price,
        priceChangePercent: s.price30mPct,
        volume24h:          s.amount24hUsd,
        avgVolume:          s.avgAmountUsd,
        oiChangePercent:    s.oiChangePct ?? 0,
        fundingRate:        s.fundingRate,
        sentiment:          "mexc_futures_pump",
        sentimentKey:       "mexc_pump",
        alphaScore:         Math.round(Math.min(s.volMult * 8 + s.price24hPct * 0.5, 100)),
        tradingViewUrl:     `https://www.tradingview.com/chart/?symbol=MEXC:${s.symbol.replace("_", "")}PERP`,
        isContinuing:       false,
        cumulativeOiChange: s.oiChangePct ?? 0,
      }))).returning({ id: signalsTable.id });

      // Добавляем в трекер — сопровождение целей, стоп-лосса, трейлинга
      for (let i = 0; i < signals.length; i++) {
        const s = signals[i];
        const signalId = inserted[i]?.id ?? null;
        await trackSignal({
          symbol:      s.symbol.replace("_", "-"),
          signalId,
          signalType:  "mexc_pump",
          sentiment:   "mexc_futures_pump",
          sentimentKey: "mexc_pump",
          alphaScore:  Math.round(Math.min(s.volMult * 8 + s.price24hPct * 0.5, 100)),
          entryPrice:  s.price,
          entryOi:     null,
        });
      }
    } catch (err) {
      logger.warn({ err }, "MEXC pump DB insert failed — non-critical");
    }
  }

  logger.info({ found: signals.length, elapsedMs: Date.now() - t0 }, "MEXC Futures scan complete");
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
async function scheduledMexcScan(): Promise<void> {
  if (!running) return;
  try {
    await performMexcScan();
  } catch (err) {
    logger.error({ err }, "MEXC scan error");
  }
  if (running) {
    const delay = msUntilNextBoundary(SCAN_INTERVAL_MS);
    scanTimer = setTimeout(scheduledMexcScan, delay);
    logger.info({ nextScanIn: `${Math.round(delay / 1000)}s` }, "Next MEXC scan scheduled");
  }
}

export async function startMexcScanner(): Promise<void> {
  if (running) return;
  running = true;
  logger.info("MEXC Futures Pump Scanner started (15-min interval)");
  // First scan: just populate OI baselines without firing signals
  // (no prevHoldVol yet → oiChangePct = null → all skipped on first pass)
  await performMexcScan();
  const delay = msUntilNextBoundary(SCAN_INTERVAL_MS);
  scanTimer = setTimeout(scheduledMexcScan, delay);
  logger.info({ nextScanIn: `${Math.round(delay / 1000)}s` }, "MEXC Scanner: next scan scheduled");
}

export function stopMexcScanner(): void {
  running = false;
  if (scanTimer) { clearTimeout(scanTimer); scanTimer = null; }
  logger.info("MEXC Futures Pump Scanner stopped");
}

// ── Types ─────────────────────────────────────────────────────────────────────
export interface MexcPumpCandidate {
  symbol:           string;   // "TOKEN_USDT"
  price:            number;
  price30mPct:      number;
  price24hPct:      number;
  volMult:          number;
  currentAmountUsd: number;   // USDT volume current 30m candle
  avgAmountUsd:     number;   // avg USDT volume per 30m candle
  amount24hUsd:     number;
  oiUsd:            number;   // OI in USD (holdVol * price)
  volOiRatio:       number;   // amount24 / oiUsd — ключевой шиток-индикатор (BTC~0.2x, шиток 2-15x)
  holdVol:          number;   // OI in contracts (absolute)
  oiChangePct:      number | null; // OI change % vs prev scan (null = first scan)
  fundingRate:      number;   // e.g. 0.0001 = 0.01% per 8h
  bidRatio:         number | null; // bids/asks ratio
  fastTrackPrev?:   boolean;        // сработала предыдущая свеча (timing gap fix)
}
